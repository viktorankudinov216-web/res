// Bounded contact-batch cache; C ABI, no Python/BigWorld pointers or threads.
// Exact terrain/BSP misses are resolved by the game thread, never this DLL.
#include <stdint.h>
#include <math.h>
#include <string.h>
#ifdef _WIN32
#define API extern "C" __declspec(dllexport)
#else
#define API extern "C" __attribute__((visibility("default")))
#endif
struct Entry { uint32_t owner; int valid; double x,z,h,lo,hi,t,gx,gz,ny; };
static Entry entries[64*32];
API uint32_t h146_abi(){return 0x1460005;}
API void h146_reset(){memset(entries,0,sizeof(entries));}
API uint32_t h146_probe(uint32_t owner,uint32_t offset,uint32_t count,const double*req,double now,double ttl,double radius,double gx,double gz,double ny,double*out){
 if(!req||!out||count>12||offset+count>32)return 0xffffffff;
 uint32_t misses=0;
 for(uint32_t i=0;i<count;i++){
  const double*r=req+i*5;Entry&e=entries[(owner%64)*32+offset+i];
  double dx=r[0]-e.x,dz=r[1]-e.z,h=e.h+gx*dx+gz*dz;
  bool ok=e.valid&&e.owner==owner&&ttl>0&&now>=e.t&&now-e.t<ttl-1e-9&&dx*dx+dz*dz<=radius*radius;
  ok=ok&&isfinite(gx)&&isfinite(gz)&&ny>.5&&fabs(gx-e.gx)<.12&&fabs(gz-e.gz)<.12;
  ok=ok&&r[3]<=e.hi+.15&&r[2]>=e.lo-.15&&h>=r[2]-.001&&h<=r[3]+.001;
  ok=ok&&(!isfinite(r[4])||h<=r[4]+.01||ny<.995);
  if(ok)out[i]=h;else{out[i]=NAN;misses|=(1u<<i);}
 }
 return misses;
}
API void h146_store(uint32_t owner,uint32_t offset,uint32_t count,const double*req,double now,const double*values,uint32_t mask,double gx,double gz,double ny){
 if(!req||!values||count>12||offset+count>32)return;
 for(uint32_t i=0;i<count;i++)if(mask&(1u<<i)){
  const double*r=req+i*5;Entry&e=entries[(owner%64)*32+offset+i];
  e.owner=owner;e.valid=isfinite(values[i]);e.x=r[0];e.z=r[1];e.h=values[i];e.lo=r[2];e.hi=r[3];e.t=now;e.gx=gx;e.gz=gz;e.ny=ny;
 }
}
