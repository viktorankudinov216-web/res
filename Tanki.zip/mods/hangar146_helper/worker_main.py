# -*- coding: utf-8 -*-
"""Engine-free 60 Hz spring worker. No BigWorld imports, no listening port.

The game remains authoritative for BSP queries, horizontal drive, hits and HUD.
This is a bounded first-stage bridge, NOT a complete replacement game server.
"""
import json,math,os,select,socket,sys,time
from legacy0922 import vehicle_physics as physics
STEP=1./60.
MAX_FRAME=512*1024
MAX_ACTORS=64

def limited_job():
    """Fail closed if the helper cannot be capped; never cap the game itself."""
    import ctypes
    from ctypes import wintypes as W
    class BASIC(ctypes.Structure):
        _fields_=[('PerProcessUserTimeLimit',ctypes.c_longlong),('PerJobUserTimeLimit',ctypes.c_longlong),('LimitFlags',W.DWORD),('MinimumWorkingSetSize',ctypes.c_size_t),('MaximumWorkingSetSize',ctypes.c_size_t),('ActiveProcessLimit',W.DWORD),('Affinity',ctypes.c_size_t),('PriorityClass',W.DWORD),('SchedulingClass',W.DWORD)]
    class IO(ctypes.Structure):
        _fields_=[(n,ctypes.c_ulonglong) for n in ('ReadOperationCount','WriteOperationCount','OtherOperationCount','ReadTransferCount','WriteTransferCount','OtherTransferCount')]
    class EXTENDED(ctypes.Structure):
        _fields_=[('BasicLimitInformation',BASIC),('IoInfo',IO),('ProcessMemoryLimit',ctypes.c_size_t),('JobMemoryLimit',ctypes.c_size_t),('PeakProcessMemoryUsed',ctypes.c_size_t),('PeakJobMemoryUsed',ctypes.c_size_t)]
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.CreateJobObjectW.argtypes=[ctypes.c_void_p,W.LPCWSTR];k.CreateJobObjectW.restype=W.HANDLE
    k.SetInformationJobObject.argtypes=[W.HANDLE,ctypes.c_int,ctypes.c_void_p,W.DWORD];k.SetInformationJobObject.restype=W.BOOL
    k.AssignProcessToJobObject.argtypes=[W.HANDLE,W.HANDLE];k.AssignProcessToJobObject.restype=W.BOOL
    k.CloseHandle.argtypes=[W.HANDLE];k.CloseHandle.restype=W.BOOL
    k.GetCurrentProcess.argtypes=[];k.GetCurrentProcess.restype=W.HANDLE
    handle=k.CreateJobObjectW(None,None)
    if not handle:raise ctypes.WinError(ctypes.get_last_error())
    info=EXTENDED();info.BasicLimitInformation.LimitFlags=0x100|0x2000|0x8
    info.BasicLimitInformation.ActiveProcessLimit=1
    info.ProcessMemoryLimit=2048*1024*1024
    if not k.SetInformationJobObject(handle,9,ctypes.byref(info),ctypes.sizeof(info)) or not k.AssignProcessToJobObject(handle,k.GetCurrentProcess()):
        error=ctypes.get_last_error();k.CloseHandle(handle);raise ctypes.WinError(error)
    return k,handle


def encode(value):
    return (json.dumps(value,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')

def main():
    port=int(sys.argv[1]);token=sys.argv[2]
    if not 1024<=port<=65535 or len(token)!=64:raise ValueError('Invalid endpoint')
    job=limited_job() if os.name=='nt' else None
    sock=socket.create_connection(('127.0.0.1',port),timeout=5.)
    sock.settimeout(5.);sock.sendall(encode(dict(kind='hello',token=token,protocol=2,memory_limit_mb=2048,memory_limit_enforced=(job is not None))))
    # The child applies its own hard Job limit before announcing readiness.
    gate=b''
    while b'\n' not in gate:
        b=sock.recv(4096)
        if not b:return
        gate+=b
        if len(gate)>4096:raise ValueError('Invalid gate')
    line,buffer=gate.split(b'\n',1)
    if json.loads(line).get('kind')!='ready':return
    sock.setblocking(False);actors={};seq=0;out=b'';latest=None;clock=time.perf_counter;deadline=clock()+STEP
    steps=0;dropped=0.;last_input=clock();mean_ms=0.;peak_ms=0.;epoch=None
    while True:
        now=clock()
        ready=select.select([sock],[sock] if out else [],[],max(0.,min(.05,deadline-now)))
        if ready[0]:
            data=sock.recv(65536)
            if not data:return
            buffer+=data
            if len(buffer)>MAX_FRAME:raise ValueError('Input overflow')
            packets=0
            while b'\n' in buffer:
                line,buffer=buffer.split(b'\n',1);msg=json.loads(line);packets+=1
                if packets>8:raise ValueError('Input flood')
                if msg.get('kind')=='stop':return
                if msg.get('kind')=='reset':actors={};epoch=msg['epoch'];continue
                if msg.get('kind')!='contacts' or msg.get('epoch')!=epoch:continue
                batch=msg['actors']
                if len(batch)>MAX_ACTORS:raise ValueError('Actor limit')
                seq=int(msg['seq']);last_input=clock()
                active=set()
                for a in batch:
                    key=int(a['id']);active.add(key)
                    if len(a['heights'])>32 or len(a['pseudos'])>32:raise ValueError('Contact limit')
                    old=actors.get(key)
                    if old is None or a.get('reset'):
                        old=dict(params=a['params'],body=a['body'],generation=int(a['generation']))
                        actors[key]=old
                    if old['generation']!=int(a['generation']):
                        old.update(body=a['body'],generation=int(a['generation']))
                    old.update(heights=a['heights'],pseudos=a['pseudos'],support=float(a['support']),alive=a['alive'],drive_acceleration=float(a.get('drive_acceleration',0.)),lateral_acceleration=float(a.get('lateral_acceleration',0.)),input_time=last_input)
                actors={k:v for k,v in actors.items() if k in active}
        now=clock();n=0
        while now+1e-9>=deadline and n<4:
            started=clock()
            for a in actors.values():
                if not a['alive'] or now-a['input_time']>.2:continue
                a['body']['drive_acceleration']=a['drive_acceleration'];a['body']['lateral_acceleration']=a['lateral_acceleration']
                a['body']=physics.damper_suspension_step(a['params'],a['body'],a['heights'],STEP,a['pseudos'],a['support'])
                if any(not math.isfinite(float(a['body'][k])) for k in ('height','pitch','roll')):raise ValueError('Invalid state')
            cost=(clock()-started)*1000.;steps+=1;mean_ms+=(cost-mean_ms)/steps;peak_ms=max(peak_ms,cost)
            deadline+=STEP;n+=1
        if now-deadline>.2:dropped+=now-deadline;deadline=now+STEP
        if n and actors:
            latest=encode(dict(kind='state',epoch=epoch,seq=seq,steps=steps,mean_ms=mean_ms,peak_ms=peak_ms,dropped=dropped,
                actors=[dict(id=k,generation=a['generation'],body=a['body']) for k,a in actors.items()]))
            if len(latest)>MAX_FRAME:raise ValueError('Output overflow')
        if not out and latest is not None:out=latest;latest=None
        if ready[1] and out:
            try:sent=sock.send(out);out=out[sent:]
            except (BlockingIOError,InterruptedError):pass

if __name__=='__main__':
    try:main()
    except Exception:
        # No game credentials or contact dumps. Parent diagnoses lost bridge.
        import traceback
        folder=os.path.dirname(os.path.abspath(__file__))
        try:
            with open(os.path.join(folder,'worker_error.log'),'w') as f:traceback.print_exc(file=f)
        except OSError:pass
        sys.exit(1)
