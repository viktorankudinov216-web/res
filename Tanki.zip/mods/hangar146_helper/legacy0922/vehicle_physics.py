# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.13.15 (main, Aug 24 2026, 00:00:00) [GCC 11.5.0 20240719 (Red Hat 11.5.0-5)]
# Embedded file name: scripts/client/gui/mods/offline_lan_0922/vehicle_physics.py
# Compiled at: 2026-09-14 14:11:29
"""Uniform vehicle-physics laws for the offhangar mod (WoT 0.9.22 #1513).

ONE set of formulas, applied identically to the player and every bot. All
inputs come from the REAL vehicle descriptor (td.physics, built by
items/vehicles.pyc from the item_defs XML):

  weight            kg
  enginePower       W        (engine XML 'power' - reader converts)
  speedLimits       (fwd m/s, bwd m/s)
  terrainResistance (firm, medium, soft) multipliers
  specificFriction  mu*g in m/s^2 (chassis XML 0.07 x 9.81 = 0.6867 default)
  brakeForce        N when the target reader supplies it.  Exact #1513 leaves
                       this legacy descriptor field at zero; braking therefore
                       falls back to the shared track-grip limit.
  trackCenterOffset half track gauge in m (chassis topRightCarryingPoint.x)
  rotationSpeed     chassis, rad/s (reader applies radians())

This module must stay importable with nothing but the stdlib: it sits right
above paths.py at the bottom of the offhangar import graph.
"""
from .worker_diagnostics import observed
import math
G = 9.81
GRAVITY_FACTOR = 1.25
GRAVITY = G * GRAVITY_FACTOR
WEIGHT_SCALE = 0.001
COHESION = 1.3
DRIVE_TRACTION = 1.0
SLOPE_GRIP_LNG_FULL_Y = math.cos(math.radians(27.5))
SLOPE_GRIP_LNG_FULL = 1.0
SLOPE_GRIP_LNG_MIN_Y = math.cos(math.radians(32.0))
SLOPE_GRIP_LNG_MIN = 0.1
SLOPE_GRIP_SDW_FULL_Y = math.cos(math.radians(24.5))
SLOPE_GRIP_SDW_FULL = 1.0
SLOPE_GRIP_SDW_MIN_Y = math.cos(math.radians(29.0))
SLOPE_GRIP_SDW_MIN = 0.1
SLIP_THRESHOLD_TAN = math.tan(math.radians(27.5))
SLIP_DRAG = 10.0
FORWARD_FRICTION = 0.07
POWER_FACTOR = GRAVITY_FACTOR
BKWD_POWER_FRACTION = 1.0
ANG_ACCELERATION_TIME = 0.05
SPEED_AFFECT_ROT_DECREASE = 0.0
ROTATION_POWER_FRACTION = 0.85
COH_DECAY_Y = 0.969
COH_DECAY_FACTOR = 5.78
COH_DECAY_POW = 3.0
COH_DECAY_BOUND = 0.5
SLOPE_COH_DECAY = 0.25
SLOPE_COH_DECAY_Y = 0.72
COAST_BRAKE_SHARE = 0.65
STEER_RESIST_MULT = 1.6
ENGINE_MIN_V = 1.5
SCROLL_CAP = 0.995
FALL_SAFE_SPEED = 10.0
FALL_DMG_PER_MS = 0.03
OVERTURN_WARNING_COSINE = math.cos(math.radians(70.0))
OVERTURN_DANGER_COSINE = math.cos(math.radians(80.0))
GROUND_FOLLOW_BASE = 0.6
GROUND_FOLLOW_MIN = 0.8
GROUND_FOLLOW_MAX = 2.5
GROUND_PITCH_LIMIT = 0.96
SUSP_COMPRESSION_MIN = 0.85
SUSP_COMPRESSION_MIN_MASS = 60.0
SUSP_COMPRESSION_MAX = 0.88
SUSP_COMPRESSION_MAX_MASS = 30.0
CLEARANCE_SCALE = 1.75
CLEARANCE_MIN = 0.55
CLEARANCE_MAX = 0.6
CLEARANCE_TO_LENGTH_MIN = 0.085
CLEARANCE_TO_LENGTH_MAX = 0.112
TRACK_LENGTH_MIN = 0.6
TRACK_LENGTH_MAX = 0.64
HARD_RATIO_MIN = 0.5
HARD_RATIO_MAX = 0.52
NUM_SPRING_PAIRS = 5
SPRING_TRACK_WIDTH_RATIO = 0.45
TRIAL_HULL_INERTIA_FACTORS = (1.0, 1.0, 1.8)
SERVER_PHYSICS_HZ = 30.0
SERVER_PHYSICS_SUBSTEPS = 2
SERVER_PHYSICS_STEP = 1.0 / (SERVER_PHYSICS_HZ * SERVER_PHYSICS_SUBSTEPS)
SERVER_PHYSICS_MAX_SUBSTEPS = 12
SERVER_PHYSICS_CONSTRAINT_ITERATIONS = 10
SUSPENSION_PATH_MAX_PROBES = 3
SUSPENSION_PATH_PROBE_SPACING = 1.0
SERVER_PHYSICS_DAMPING_RATIO_BASE = 0.75
SERVER_PHYSICS_DAMPING_RATIO_SCALE = 0.25
SERVER_PHYSICS_MAX_SPRING_FORCE_FACTOR = 6.0
AIRBORNE_ANGULAR_DAMPING = 4.0
AIRBORNE_ANGULAR_SPEED_LIMIT = 0.6
FREEZE_ANG_ACCEL_EPSILON = 0.35
FREEZE_ACCEL_EPSILON = 0.4
FREEZE_VEL_EPSILON = 0.15
FREEZE_ANG_VEL_EPSILON = 0.06
ALLOWED_PENETRATION = 0.01
CONTACT_PENETRATION = 0.1
TRACKS_PENETRATION = 0.01
SUSPENSION_GEOMETRY_EPSILON = 0.01
HARD_CONTACT_YAW_DELTAS = (0.55, -0.55, 1.0, -1.0)
HARD_CONTACT_ENTRY_FACTOR = 0.6
HARD_CONTACT_SLIDE_DECAY = 0.85
HARD_CONTACT_BRAKE_DECAY = 0.35
HARD_CONTACT_STOP_SPEED = 0.05
HARD_CONTACT_GRIND_TICKS = 4
SLIDE_MAX = 7.0
SLIDE_DRAG = 1.5
SLIDE_HOLD_TAN = 0.5
SLIDE_KINETIC = 0.45
OVERSPEED_MAX_FACTOR = 1.05
OVERSPEED_DAMP = 2.0
OVERSPEED_BUILD = 0.2
_TUNABLE = {'gravity_factor': 'GRAVITY_FACTOR', 
   'cohesion': 'COHESION', 
   'drive_traction': 'DRIVE_TRACTION', 
   'slip_drag': 'SLIP_DRAG', 
   'slip_threshold_tan': 'SLIP_THRESHOLD_TAN', 
   'power_factor': 'POWER_FACTOR', 
   'bkwd_power_fraction': 'BKWD_POWER_FRACTION', 
   'traverse_accel_time': 'ANG_ACCELERATION_TIME', 
   'traverse_speed_cost': 'SPEED_AFFECT_ROT_DECREASE', 
   'coast_brake_share': 'COAST_BRAKE_SHARE', 
   'steer_resist_mult': 'STEER_RESIST_MULT', 
   'slide_max': 'SLIDE_MAX', 
   'slide_drag': 'SLIDE_DRAG', 
   'slide_hold_tan': 'SLIDE_HOLD_TAN', 
   'slide_kinetic': 'SLIDE_KINETIC', 
   'overspeed_max_factor': 'OVERSPEED_MAX_FACTOR', 
   'overspeed_damp': 'OVERSPEED_DAMP', 
   'overspeed_build': 'OVERSPEED_BUILD', 
   'slope_coh_decay': 'SLOPE_COH_DECAY', 
   'slope_coh_decay_y': 'SLOPE_COH_DECAY_Y', 
   'coh_decay_bound': 'COH_DECAY_BOUND', 
   'fall_safe_speed': 'FALL_SAFE_SPEED', 
   'fall_dmg_per_ms': 'FALL_DMG_PER_MS'}

def apply_tuning(overrides):
    """Overlay config.json "physics_tuning" onto the module constants. Returns
        the list of applied "key=value" strings (for logging). GRAVITY is derived
        from G*GRAVITY_FACTOR, so it is recomputed after any override."""
    applied = []
    g = globals()
    if isinstance(overrides, dict):
        for k, gname in _TUNABLE.items():
            if k in overrides:
                try:
                    g[gname] = float(overrides[k])
                    applied.append('%s=%s' % (k, overrides[k]))
                except (TypeError, ValueError):
                    pass

    g['GRAVITY'] = G * GRAVITY_FACTOR
    _DEFAULTS['brakeDecel'] = COHESION * GRAVITY
    return applied


def hard_contact_candidate_yaws(yaw):
    """Return the shared ordered glancing paths for one blocked hull heading."""
    return tuple(float(yaw) + delta for delta in HARD_CONTACT_YAW_DELTAS)


def hard_contact_step(speed, dt, grinding=False, slide_yaw=None):
    """Resolve one grounded hard-contact response without probing the world.

        Callers own their native/static collision queries and pass the first clear
        glancing yaw, if any. The returned tuple is ``(speed, dx, dz)`` so visible
        players and copied Bots cannot apply different damping or displacement after
        the same probe result.
        """
    speed = float(speed)
    dt = max(0.0, float(dt))
    if slide_yaw is None:
        speed *= HARD_CONTACT_BRAKE_DECAY ** (dt * 60.0)
        if abs(speed) < HARD_CONTACT_STOP_SPEED:
            speed = 0.0
        return (speed, 0.0, 0.0)
    else:
        if not grinding:
            speed *= HARD_CONTACT_ENTRY_FACTOR
        speed *= HARD_CONTACT_SLIDE_DECAY ** (dt * 60.0)
        yaw = float(slide_yaw)
        return (speed, math.sin(yaw) * speed * dt,
         math.cos(yaw) * speed * dt)


def snapshot(p, v, omega, throttle, slope_pitch, airborne, slide_speed, tank='', ground_kmh=None, pitch_deg=None, roll_deg=None, vert_ms=None, deflect=None, dy=None, slide_slope=None, dy_tick=None, y_src=None, terr_spread=None):
    """One telemetry row: the live physics state + the force balance that
        decides hold/climb/slide, PLUS the observable extras that the pure force
        numbers miss - ACTUAL over-ground speed vs commanded v (catches wall-slide
        sideways drift / clipping), hull pitch & roll (catches orientation glitches),
        vertical speed & height delta (catches float/sink/teleport), and whether the
        wall-slide deflection fired this frame. Returns (name, value) pairs."""
    grip = _grip_decel(p, slope_pitch)
    grav_a = GRAVITY * math.sin(slope_pitch)
    ef = engine_force(p, v, throttle, slope_pitch) / p['mass'] if throttle else 0.0
    rows = [
     (
      'tank', tank),
     (
      'mass_kg', round(p['mass'], 0)),
     (
      'power_hp', round(p['powerW'] / 735.49875, 0)),
     (
      'pw_ratio_hp_t', round(p['powerW'] / 735.49875 / max(p['mass'] / 1000.0, 0.01), 1)),
     (
      'speedFwd_kmh', round(p['speedFwd'] * 3.6, 1)),
     (
      'v_kmh', round(v * 3.6, 2)),
     (
      'throttle', throttle),
     (
      'slope_deg', round(math.degrees(slope_pitch), 1)),
     (
      'grip_ms2', round(grip, 2)),
     (
      'grav_along_ms2', round(grav_a, 2)),
     (
      'hold_margin_ms2', round(grip - abs(grav_a), 2)),
     (
      'drive_accel_ms2', round(ef, 2)),
     (
      'turn_degs', round(math.degrees(omega), 1)),
     (
      'rotSpd_max_degs', round(math.degrees(p['rotSpd']), 1)),
     (
      'airborne', 1 if airborne else 0),
     (
      'slide_ms', round(slide_speed, 2)),
     (
      'terrain_r0', p['terrainResist'][0]),
     (
      'spec_friction', round(p['specificFriction'], 3)),
     (
      'brake_ms2', round(p['brakeDecel'], 2))]
    if ground_kmh is not None:
        rows.append(('ground_kmh', round(ground_kmh, 2)))
        rows.append(('drift_kmh', round(ground_kmh - abs(v * 3.6), 2)))
    if pitch_deg is not None:
        rows.append(('hull_pitch_deg', round(pitch_deg, 1)))
    if roll_deg is not None:
        rows.append(('hull_roll_deg', round(roll_deg, 1)))
    if vert_ms is not None:
        rows.append(('vert_ms', round(vert_ms, 2)))
    if dy is not None:
        rows.append(('dy_m', round(dy, 3)))
    if slide_slope is not None:
        rows.append(('slide_slope_deg', round(math.degrees(math.atan(slide_slope)), 1)))
    if dy_tick is not None:
        rows.append(('dy_tick_m', round(dy_tick, 3)))
    if y_src is not None:
        rows.append(('y_src', y_src))
    if terr_spread is not None:
        rows.append(('terr_spread_m', round(terr_spread, 2)))
    if deflect is not None:
        rows.append(('wall_deflect', 1 if deflect else 0))
    return rows


_DEFAULTS = {'mass': 5730.0, 
   'powerW': 33097.44375, 
   'speedFwd': (32.0 / 3.6), 
   'speedBwd': (12.0 / 3.6), 
   'rotSpd': (math.radians(38.0)), 
   'terrainResist': (1.1, 1.4, 2.6), 
   'specificFriction': 0.6867, 
   'brakeDecel': (COHESION * GRAVITY), 
   'trackCenter': 1.5, 
   'minPlaneNormalY': (math.cos(math.radians(25.0))), 
   'nativePowerRatio': 1.0}

def _factor_list(factors, name):
    try:
        values = factors[name]
        return (float(values[0]), float(values[1]), float(values[2]))
    except (KeyError, IndexError, TypeError, ValueError):
        return (1.0, 1.0, 1.0)

    return


def _factor(factors, name):
    try:
        return max(0.0, float(factors[name]))
    except (KeyError, TypeError, ValueError):
        return 1.0

    return


def _native_power_ratio(td, power_w):
    """Read #1513's selected detailed-physics engine override.

        ``smplEnginePower`` is stored in the native tonnes-based configuration.
        The generic descriptor conversion would be ``enginePower * 0.00125``;
        the selected detailed entry replaces that value before the native physics
        is configured.  Return the exact replacement/base ratio so the copied SI
        integrator keeps the same per-engine override while retaining POWER_FACTOR
        as the live-tuning base.
        """
    try:
        projected = getattr(td, 'physics', {}).get('nativePowerRatio')
        projected = float(projected)
        if projected > 0.0 and not math.isnan(projected) and not math.isinf(projected):
            return projected
    except (AttributeError, TypeError, ValueError):
        pass

    try:
        engine_name = getattr(getattr(td, 'engine'), 'name')
        xphysics = getattr(getattr(td, 'type'), 'xphysics')
        detailed = xphysics['detailed']
        engine_cfg = detailed['engines'][engine_name]
        native_power = float(engine_cfg['smplEnginePower'])
        base_power = float(power_w) * 0.001 * GRAVITY_FACTOR
        if native_power > 0.0 and base_power > 0.0 and not math.isnan(native_power) and not math.isinf(native_power):
            return native_power / base_power
    except (AttributeError, KeyError, TypeError, ValueError):
        pass

    return 1.0


def descriptor_mass(td):
    """Read the same kilogram mass as derive_params without drive parameters.

        Contact bodies do not consume engine power, traverse or terrain factors.
        Read the mounted descriptor each time so an in-place equipment or Siege
        change cannot leave a cached weight behind.
        """
    try:
        physics = getattr(td, 'physics', None) or {}
        if 'weight' in physics:
            return float(physics['weight'])
    except Exception:
        pass

    return _DEFAULTS['mass']


@observed('physics.derive_params')
def derive_params(td, factors=None):
    """Real per-vehicle parameter set from a VehicleDescr. Every consumer
        (player tick, each bot) MUST source its numbers from here - this is the
        single place that knows the units of td.physics.

        ``factors`` is the #1513 attribute-factor dictionary the garage panel
        reads. With it the driver skills, the grousers and the engine consumables
        reach the physics exactly as VehicleParams composes them."""
    p = dict(_DEFAULTS)
    try:
        tdp = getattr(td, 'physics', None) or {}
    except Exception:
        tdp = {}

    try:
        if 'weight' in tdp:
            p['mass'] = float(tdp['weight'])
        if 'enginePower' in tdp:
            p['powerW'] = float(tdp['enginePower'])
        if 'speedLimits' in tdp:
            p['speedFwd'] = float(tdp['speedLimits'][0])
            p['speedBwd'] = float(tdp['speedLimits'][1])
        if 'terrainResistance' in tdp:
            tr = tdp['terrainResistance']
            p['terrainResist'] = (float(tr[0]), float(tr[1]), float(tr[2]))
        if 'specificFriction' in tdp:
            p['specificFriction'] = float(tdp['specificFriction'])
        if 'brakeForce' in tdp:
            raw_brake = float(tdp['brakeForce'])
            if raw_brake > 0.0:
                p['brakeDecel'] = min(COHESION * GRAVITY, raw_brake / max(p['mass'], 1.0))
        if 'trackCenterOffset' in tdp:
            tc = abs(float(tdp['trackCenterOffset']))
            if 0.3 <= tc <= 3.0:
                p['trackCenter'] = tc
        if 'minPlaneNormalY' in tdp:
            p['minPlaneNormalY'] = float(tdp['minPlaneNormalY'])
    except Exception:
        pass

    p['nativePowerRatio'] = _native_power_ratio(td, p['powerW'])
    try:
        ch = getattr(td, 'chassis', None)
        if ch is not None:
            raw_value = ch.get('rotationSpeed') if isinstance(ch, dict) else getattr(ch, 'rotationSpeed', None)
            if raw_value is None:
                raise RuntimeError('#1513 chassis rotation speed is unavailable')
            raw = float(raw_value)
            p['rotSpd'] = math.radians(raw) if raw > 6.3 else raw
    except (AttributeError, TypeError, ValueError) as error:
        raise RuntimeError('#1513 chassis rotation speed is invalid: %s' % error)

    rolling = (1.0, 1.0, 1.0)
    try:
        if 'rollingFrictionFactors' in tdp:
            values = tdp['rollingFrictionFactors']
            rolling = (float(values[0]), float(values[1]), float(values[2]))
    except (IndexError, TypeError, ValueError):
        rolling = (1.0, 1.0, 1.0)

    crew = _factor_list(factors or {}, 'chassis/terrainResistance')
    p['terrainResist'] = tuple(p['terrainResist'][index] * crew[index] * rolling[index] for index in range(3))
    if factors:
        p['rotSpd'] *= _factor(factors, 'vehicle/rotationSpeed')
        p['powerW'] *= _factor(factors, 'engine/power')
    return p


def _value(component, name, default=None):
    if isinstance(component, dict):
        return component.get(name, default)
    return getattr(component, name, default)


def _required_value(component, name, context):
    value = _value(component, name)
    if value is None:
        raise ValueError('%s is required by the contrib suspension trial' % context)
    return value


def _optional_factor(config, name):
    """Return one positive side-stiffness refinement, defaulting to uniform."""
    raw = _optional_value(config, name)
    if raw is None:
        return 1.0
    else:
        value = _finite_number(raw, 'detailed chassis %s' % name)
        if value <= 0.0:
            raise ValueError('detailed chassis stiffness must be positive')
        return value


def _optional_value(component, name):
    """Return one refinement value, or None when the client does not ship it."""
    if isinstance(component, dict):
        return component.get(name)
    else:
        return getattr(component, name, None)


def _finite_number(value, context):
    try:
        value = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError('%s is invalid: %s' % (context, error))

    if math.isnan(value) or math.isinf(value):
        raise ValueError('%s is not finite' % context)
    return value


def _number_tuple(values, context):
    try:
        return tuple(_finite_number(value, '%s[%d]' % (context, index)) for index, value in enumerate(values))
    except TypeError as error:
        raise ValueError('%s is invalid: %s' % (context, error))

    return


def _linear_interpolate(value, minimum, maximum, lower, upper):
    if maximum == minimum:
        return float(lower)
    ratio = (float(value) - float(minimum)) / (float(maximum) - float(minimum))
    ratio = max(0.0, min(1.0, ratio))
    return float(lower) + (float(upper) - float(lower)) * ratio


def _suspension_compression(mass_tons):
    return _linear_interpolate(mass_tons, SUSP_COMPRESSION_MIN_MASS, SUSP_COMPRESSION_MAX_MASS, SUSP_COMPRESSION_MIN, SUSP_COMPRESSION_MAX)


def _track_length(clearance, chassis_length):
    """Exact #1513 physics_shared._computeTrackLength."""
    ratio = float(clearance) / max(float(chassis_length), 0.01)
    length_ratio = _linear_interpolate(ratio, CLEARANCE_TO_LENGTH_MIN, CLEARANCE_TO_LENGTH_MAX, TRACK_LENGTH_MAX, TRACK_LENGTH_MIN)
    return length_ratio * float(chassis_length)


def _hard_ratio(clearance, chassis_length):
    ratio = float(clearance) / max(float(chassis_length), 0.01)
    return _linear_interpolate(ratio, CLEARANCE_TO_LENGTH_MIN, CLEARANCE_TO_LENGTH_MAX, HARD_RATIO_MIN, HARD_RATIO_MAX)


def _detailed_chassis_config(descriptor):
    """Return the optional richer chassis xphysics, or an empty mapping.

        Exact #1513 ``vehicles.VehicleType.__init__`` reads xphysics through
        ``_readXPhysics`` only under ``IS_CELLAPP``; every ``IS_CLIENT`` process
        goes through ``_readXPhysicsClient``, which returns a flat
        ``{'engines': ..., 'chassis': ...}`` mapping with no ``detailed`` level,
        and whose ``_xphysicsParseChassisClient`` fills each chassis entry with
        ``grounds`` alone.  Both this product's visible client and its hidden
        worker are real client processes, so ``roadWheelPositions``,
        ``stiffnessFactors``, ``stiffness0``, ``stiffness1``, ``damping``,
        ``bodyHeight`` and ``hullInertiaFactors`` are never present in production.
        They stay supported as refinements for a non-client descriptor, but the
        trial derives its layout from the client projection when they are absent.
        """
    try:
        tank_type = _required_value(descriptor, 'type', 'vehicle type descriptor')
        xphysics = _required_value(tank_type, 'xphysics', 'vehicle xphysics')
    except ValueError:
        return {}

    if not isinstance(xphysics, dict):
        return {}
    level = xphysics.get('detailed', xphysics)
    if not isinstance(level, dict):
        return {}
    configs = level.get('chassis')
    if not isinstance(configs, dict):
        return {}
    try:
        chassis = _required_value(descriptor, 'chassis', 'vehicle chassis descriptor')
        name = _required_value(chassis, 'name', 'selected chassis name')
    except ValueError:
        return {}

    config = configs.get(name)
    if isinstance(config, dict):
        return config
    return {}


def _bbox(component, context):
    tester = _required_value(component, 'hitTester', '%s hitTester' % context)
    bounds = _required_value(tester, 'bbox', '%s hitTester bbox' % context)
    try:
        minimum = bounds[0]
        maximum = bounds[1]
        dimensions = tuple(_finite_number(maximum[index], '%s bbox maximum' % context) - _finite_number(minimum[index], '%s bbox minimum' % context) for index in range(3))
    except (IndexError, TypeError) as error:
        raise ValueError('%s hitTester bbox is invalid: %s' % (
         context, error))

    if any(value <= 0.0 for value in dimensions):
        raise ValueError('%s hitTester bbox has no volume' % context)
    return (
     minimum, maximum, dimensions)


def _suspension_wheel_radius(chassis, config, spring_spacing):
    """Return the contact-memory radius: a wheel, else one spring spacing.

        The radius only sizes ``contact_memory_distance``, which bridges a single
        rail or sleeper gap between two ground samples.  One spring spacing is
        exactly that gap, so an unrefined descriptor without wheel groups keeps a
        bounded tolerance instead of retiring the whole trial.
        """
    raw = _optional_value(config, 'wheelRadius')
    if raw is not None:
        radius = _finite_number(raw, 'detailed chassis wheelRadius')
        if radius > 0.0:
            return radius
    try:
        radius = _finite_number(chassis.wheels.groups[0].radius, 'selected chassis wheel radius')
    except (AttributeError, IndexError, TypeError, ValueError):
        radius = 0.0

    if radius > 0.0:
        return radius
    else:
        return max(0.125, float(spring_spacing) * 0.5)


def suspension_trial_excluded(descriptor):
    """Return whether exact #1513 uses hydraulic hull-aiming suspension."""
    return bool(_value(descriptor, 'isPitchHullAimingAvailable', False))


def derive_suspension_params(descriptor):
    """Build the ten-spring rigid-body trial for one tank.

        The spring layout is the exact #1513 client projection.
        ``physics_shared.initVehiclePhysicsClient`` derives its five carrier pairs
        from the hull and chassis bboxes, ``chassis.hullPosition`` and
        ``physics['weight']`` alone, and every interpolation constant used here
        (``WEIGHT_SCALE``, ``CLEARANCE``, ``CLEARANCE_MIN``/``MAX``,
        ``SUSP_COMPRESSION_*``, ``CLEARANCE_TO_LENGTH_*``, ``TRACK_LENGTH_*``,
        ``HARD_RATIO_*``) is that module's own value.

        Per-spring stiffness, damping and the hull inertia tensor are not: the
        native solver owns them and no #1513 process is given them, so those are
        an explicit trial projection and are the reason this remains a trial.
        """
    if suspension_trial_excluded(descriptor):
        raise ValueError('#1513 hydraulic suspension is outside the contrib trial')
    physics = derive_params(descriptor)
    descriptor_physics = _required_value(descriptor, 'physics', 'vehicle physics descriptor')
    mass = _finite_number(_required_value(descriptor_physics, 'weight', 'vehicle physics weight'), 'vehicle physics weight')
    if mass <= 0.0:
        raise ValueError('vehicle physics weight must be positive')
    if abs(float(physics['mass']) - mass) > 1e-06:
        raise ValueError('vehicle physics mass projection is inconsistent')
    chassis = _required_value(descriptor, 'chassis', 'vehicle chassis descriptor')
    hull = _required_value(descriptor, 'hull', 'vehicle hull descriptor')
    unused_chassis_min, unused_chassis_max, chassis_size = _bbox(chassis, 'chassis')
    hull_minimum, unused_hull_max, unused_hull_size = _bbox(hull, 'hull')
    width, chassis_height, chassis_length = chassis_size
    hull_position = _required_value(chassis, 'hullPosition', 'selected chassis hullPosition')
    try:
        clearance_raw = _finite_number(hull_position[1], 'chassis hullPosition.y') + _finite_number(hull_minimum[1], 'hull bbox minimum.y')
    except (IndexError, TypeError) as error:
        raise ValueError('selected chassis hullPosition is invalid: %s' % error)

    if clearance_raw <= 0.0:
        raise ValueError('descriptor ground clearance must be positive')
    clearance = clearance_raw * CLEARANCE_SCALE
    clearance = max(CLEARANCE_MIN * chassis_height, min(CLEARANCE_MAX * chassis_height, clearance))
    mass_tons = mass * WEIGHT_SCALE
    compression_ratio = _suspension_compression(mass_tons)
    rest_length = clearance / max(compression_ratio, 0.01)
    static_compression = max(0.01, rest_length - clearance)
    hard_ratio = _hard_ratio(clearance, chassis_length)
    track_length = _track_length(clearance, chassis_length)
    step_z = track_length / float(NUM_SPRING_PAIRS - 1)
    config = _detailed_chassis_config(descriptor)
    raw_positions = _optional_value(config, 'roadWheelPositions')
    if raw_positions is None:
        positions = tuple(-track_length * 0.5 + step_z * float(index) for index in range(NUM_SPRING_PAIRS))
    else:
        positions = _number_tuple(raw_positions, 'detailed chassis roadWheelPositions')
        if len(positions) != NUM_SPRING_PAIRS:
            raise ValueError('contrib suspension trial requires five road-wheel positions')
        position_limit = chassis_length * 0.5
        if any(abs(value) > position_limit + SUSPENSION_GEOMETRY_EPSILON for value in positions):
            raise ValueError('roadWheelPositions extend beyond the chassis bbox')
    raw_stiffness_factors = _optional_value(config, 'stiffnessFactors')
    if raw_stiffness_factors is None:
        stiffness_factors = tuple(1.0 for unused in positions)
    else:
        stiffness_factors = _number_tuple(raw_stiffness_factors, 'detailed chassis stiffnessFactors')
        if len(stiffness_factors) != len(positions):
            raise ValueError('stiffnessFactors must match the five road-wheel positions')
        if any(value <= 0.0 for value in stiffness_factors):
            raise ValueError('stiffnessFactors must be positive')
    left_factor = _optional_factor(config, 'stiffness0')
    right_factor = _optional_factor(config, 'stiffness1')
    raw_damping = _optional_value(config, 'damping')
    if raw_damping is None:
        damping_value = 0.0
    else:
        damping_value = _finite_number(raw_damping, 'detailed chassis damping')
        if damping_value < 0.0:
            raise ValueError('detailed chassis damping must not be negative')
    damping_ratio = max(0.55, min(1.25, SERVER_PHYSICS_DAMPING_RATIO_BASE + SERVER_PHYSICS_DAMPING_RATIO_SCALE * damping_value))
    track_x = width * SPRING_TRACK_WIDTH_RATIO
    raw_springs = []
    for side, x, side_factor in (
     (
      'left', -track_x, left_factor),
     (
      'right', track_x, right_factor)):
        for index, z in enumerate(positions):
            raw_springs.append((
             side, x, z, stiffness_factors[index] * side_factor))

    weight_total = sum(row[3] for row in raw_springs)
    if weight_total <= 0.0:
        raise ValueError('suspension stiffness weights must be positive')
    springs = []
    for side, x, z, weight in raw_springs:
        sprung_mass = mass * weight / weight_total
        stiffness = sprung_mass * GRAVITY / static_compression
        damping = 2.0 * damping_ratio * math.sqrt(stiffness * sprung_mass)
        springs.append({'side': side, 
           'x': x, 'z': z, 'mass': sprung_mass, 
           'stiffness': stiffness, 'damping': damping, 
           'rest_length': rest_length, 
           'static_compression': static_compression, 
           'max_compression': (max(static_compression, rest_length - clearance * hard_ratio)), 
           'max_force': (sprung_mass * GRAVITY * SERVER_PHYSICS_MAX_SPRING_FORCE_FACTOR)})

    pseudo_contacts = []
    for side, x in (('left', -track_x), ('right', track_x)):
        for index in range(len(positions) - 1):
            pseudo_contacts.append({'side': side, 
               'kind': 'track', 'x': x, 'y': 0.0, 'z': ((positions[index] + positions[index + 1]) * 0.5), 
               'penetration': TRACKS_PENETRATION})

    for index in range(len(positions) - 1):
        pseudo_contacts.append({'side': None, 
           'kind': 'body', 'x': 0.0, 'y': clearance, 'z': ((positions[index] + positions[index + 1]) * 0.5), 
           'penetration': ALLOWED_PENETRATION})

    raw_body_height = _optional_value(config, 'bodyHeight')
    if raw_body_height is None:
        body_height = chassis_height
    else:
        body_height = _finite_number(raw_body_height, 'detailed chassis bodyHeight')
        if body_height <= 0.0:
            raise ValueError('detailed chassis bodyHeight must be positive')
    raw_inertia_factors = _optional_value(config, 'hullInertiaFactors')
    if raw_inertia_factors is None:
        inertia_factors = TRIAL_HULL_INERTIA_FACTORS
    else:
        inertia_factors = _number_tuple(raw_inertia_factors, 'detailed chassis hullInertiaFactors')
        if len(inertia_factors) != 3 or any(value <= 0.0 for value in inertia_factors):
            raise ValueError('hullInertiaFactors must contain three positive values')
    wheel_radius = _suspension_wheel_radius(chassis, config, step_z)
    pitch_inertia = max(1.0, mass * (body_height ** 2 + chassis_length ** 2) / 12.0 * inertia_factors[0])
    roll_inertia = max(1.0, mass * (body_height ** 2 + width ** 2) / 12.0 * inertia_factors[2])
    return {'mass': mass, 
       'width': width, 'length': chassis_length, 'clearance': clearance, 
       'rest_length': rest_length, 'static_compression': static_compression, 
       'hard_ratio': hard_ratio, 
       'contact_memory_distance': (max(0.25, min(0.9, wheel_radius * 2.0))), 
       'center_of_mass_height': max(.3,min(2.5,clearance+body_height*.5)),
       'pitch_inertia': pitch_inertia, 
       'roll_inertia': roll_inertia, 
       'springs': (tuple(springs)), 
       'pseudo_contacts': (tuple(pseudo_contacts)), 
       'fixed_step': SERVER_PHYSICS_STEP, 
       'constraint_iterations': SERVER_PHYSICS_CONSTRAINT_ITERATIONS}


def _suspension_rotation(pitch, roll):
    """Prepare one immutable pose; rebuild after each solver pose change."""
    sp, cp = math.sin(float(pitch)), math.cos(float(pitch))
    sr, cr = math.sin(float(roll)), math.cos(float(roll))
    return (sp, cp, sr, cr)


def _suspension_point_offset(point, rotation):
    x, y, z = float(point['x']), float(point.get('y', 0.0)), float(point['z'])
    sp, cp, sr, cr = rotation
    rolled_y = sr * x + cr * y
    return (cr * x - sr * y, cp * rolled_y - sp * z,
     sp * rolled_y + cp * z)


def suspension_point_offset(point, pitch=0.0, roll=0.0):
    """Rotate one local suspension point by the same YPR law as the hull."""
    return _suspension_point_offset(point, _suspension_rotation(pitch, roll))


def _suspension_world_points(points, position, yaw, pitch, roll):
    x, unused_y, z = map(float, position)
    sine, cosine = math.sin(float(yaw)), math.cos(float(yaw))
    rotation = _suspension_rotation(pitch, roll)
    result = []
    for point in points:
        local_x, unused_y, local_z = _suspension_point_offset(point, rotation)
        result.append((x + cosine * local_x + sine * local_z,
         z - sine * local_x + cosine * local_z))

    return tuple(result)


def suspension_world_points(params, position, yaw, pitch=0.0, roll=0.0):
    """Return the actual posed world x/z points of the damper springs."""
    return _suspension_world_points(params['springs'], position, yaw, pitch, roll)


def suspension_pseudo_world_points(params, position, yaw, pitch=0.0, roll=0.0):
    """Return the actual posed world x/z points of the track/belly contacts."""
    return _suspension_world_points(params.get('pseudo_contacts', ()), position, yaw, pitch, roll)


def ground_normal(gradient_x, gradient_z):
    """Return the upward unit normal of ``y = gx*x + gz*z + c``."""
    try:
        gradient_x = float(gradient_x)
        gradient_z = float(gradient_z)
    except (TypeError, ValueError, OverflowError):
        return

    if any(math.isnan(value) or math.isinf(value) for value in (gradient_x, gradient_z)):
        return
    else:
        scale = max(1.0, abs(gradient_x), abs(gradient_z))
        local_x = gradient_x / scale
        local_y = 1.0 / scale
        local_z = gradient_z / scale
        length = math.sqrt(local_x * local_x + local_y * local_y + local_z * local_z)
        if length <= 0.0 or math.isnan(length) or math.isinf(length):
            return
        normal = (
         -local_x / length, local_y / length, -local_z / length)
        if normal[1] <= 0.0:
            return
        return normal


def sampled_ground_plane(front_y, rear_y, right_y, left_y, center_y, yaw, length, width, maximum_residual):
    """Fit one ground plane from five actual suspension-height samples.

        The residual is measured across the fixed hull footprint. It is not an
        allowance paid once per simulation tick, so render cadence cannot grow it.
        """
    if None in (front_y, rear_y, right_y, left_y, center_y):
        return
    else:
        try:
            front_y = float(front_y)
            rear_y = float(rear_y)
            right_y = float(right_y)
            left_y = float(left_y)
            center_y = float(center_y)
            yaw = float(yaw)
            length = float(length)
            width = float(width)
            maximum_residual = float(maximum_residual)
        except (TypeError, ValueError, OverflowError):
            return

        values = (
         front_y, rear_y, right_y, left_y, center_y,
         yaw, length, width, maximum_residual)
        if any(math.isnan(value) or math.isinf(value) for value in values) or length <= 0.0 or width <= 0.0 or maximum_residual < 0.0:
            return
        long_mid = (front_y + rear_y) * 0.5
        side_mid = (right_y + left_y) * 0.5
        residual = max(abs(long_mid - side_mid), abs(center_y - long_mid), abs(center_y - side_mid))
        if residual > maximum_residual:
            return
        height_forward = (front_y - rear_y) / length
        height_right = (right_y - left_y) / width
        sine, cosine = math.sin(yaw), math.cos(yaw)
        gradient_x = height_forward * sine + height_right * cosine
        gradient_z = height_forward * cosine - height_right * sine
        normal = ground_normal(gradient_x, gradient_z)
        if normal is None:
            return
        slope_tangent = math.hypot(height_forward, height_right)
        if math.isnan(slope_tangent) or math.isinf(slope_tangent):
            return
        downhill_x = -gradient_x
        downhill_z = -gradient_z
        downhill_length = math.hypot(downhill_x, downhill_z)
        if downhill_length > 0.001:
            downhill_x /= downhill_length
            downhill_z /= downhill_length
        else:
            downhill_x = downhill_z = 0.0
        return {'center_y': center_y, 'gradient_x': gradient_x, 
           'gradient_z': gradient_z, 
           'normal': normal, 
           'pitch': (-math.atan2(front_y - rear_y, length)), 
           'roll': (math.atan2(height_right, math.hypot(1.0, height_forward))), 
           'slope_tangent': slope_tangent, 
           'up_cosine': (normal[1]), 
           'downhill': (
                      downhill_x, 0.0, downhill_z), 
           'residual': residual}


def suspension_ground_plane(params, ground_heights, maximum_residual=None, sample_points=None):
    """Fit terrain gradients from contacted springs, not body attitude.

        Suspension pitch and roll contain transient damper motion. Feeding that
        rocking back into slope grip would invent a hill on flat ground, so callers
        use this least-squares contact plane for terrain-only metadata.
        """
    try:
        if len(ground_heights) != len(params['springs']):
            return
    except (KeyError, TypeError):
        return

    rows = []
    for index, spring in enumerate(params['springs']):
        ground = ground_heights[index]
        if ground is None:
            continue
        try:
            x = float(spring['x'] if sample_points is None else sample_points[index][0])
            z = float(spring['z'] if sample_points is None else sample_points[index][1])
            y = float(ground)
        except (KeyError, TypeError, ValueError):
            return

        if any(math.isnan(value) or math.isinf(value) for value in (x, z, y)):
            return
        rows.append((x, z, y))

    if len(rows) < 3:
        return
    else:
        count = float(len(rows))
        mean_x = sum(row[0] for row in rows) / count
        mean_z = sum(row[1] for row in rows) / count
        mean_y = sum(row[2] for row in rows) / count
        xx = xz = zz = xy = zy = 0.0
        for x, z, y in rows:
            dx = x - mean_x
            dz = z - mean_z
            dy = y - mean_y
            xx += dx * dx
            xz += dx * dz
            zz += dz * dz
            xy += dx * dy
            zy += dz * dy

        determinant = xx * zz - xz * xz
        if determinant <= 1e-08:
            return
        x_gradient = (xy * zz - zy * xz) / determinant
        z_gradient = (zy * xx - xy * xz) / determinant
        center_y = mean_y - x_gradient * mean_x - z_gradient * mean_z
        residual = max(abs(y - (center_y + x_gradient * x + z_gradient * z)) for x, z, y in rows)
        if maximum_residual is not None:
            try:
                limit = max(0.0, float(maximum_residual))
            except (TypeError, ValueError):
                return

            if residual > limit:
                return
        return {'center_y': center_y, 
           'x_gradient': x_gradient, 
           'z_gradient': z_gradient, 
           'max_residual': residual, 
           'contact_count': (len(rows))}


def suspension_world_ground_plane(params, ground_heights, position, yaw, maximum_residual=None, pitch=0.0, roll=0.0):
    """Fit one suspension plane in stable world-space coordinates."""
    rotation = _suspension_rotation(pitch, roll)
    points = tuple(_suspension_point_offset(spring, rotation) for spring in params['springs'])
    local_plane = suspension_ground_plane(params, ground_heights, maximum_residual, tuple((point[0], point[2]) for point in points))
    if local_plane is None:
        return
    else:
        try:
            center_x = float(position[0])
            center_z = float(position[2])
            yaw = float(yaw)
        except (IndexError, TypeError, ValueError, OverflowError):
            return

        if any(math.isnan(value) or math.isinf(value) for value in (center_x, center_z, yaw)):
            return
        right_gradient = float(local_plane['x_gradient'])
        forward_gradient = float(local_plane['z_gradient'])
        sine, cosine = math.sin(yaw), math.cos(yaw)
        gradient_x = forward_gradient * sine + right_gradient * cosine
        gradient_z = forward_gradient * cosine - right_gradient * sine
        center_y = float(local_plane['center_y'])
        max_residual = float(local_plane['max_residual'])
        if any(math.isnan(value) or math.isinf(value) for value in (
         center_y, gradient_x, gradient_z, max_residual)):
            return
        normal = ground_normal(gradient_x, gradient_z)
        if normal is None:
            return
        return {'center_x': center_x, 'center_z': center_z, 
           'center_y': center_y, 
           'gradient_x': gradient_x, 
           'gradient_z': gradient_z, 
           'normal': normal, 
           'max_residual': max_residual, 
           'contact_count': (int(local_plane['contact_count']))}


def suspension_plane_height(plane, x, z):
    """Project a world-space ground plane to one horizontal position."""
    if not isinstance(plane, dict):
        return
    else:
        try:
            values = (
             float(plane['center_x']), float(plane['center_z']),
             float(plane['center_y']), float(plane['gradient_x']),
             float(plane['gradient_z']), float(x), float(z))
        except (KeyError, TypeError, ValueError, OverflowError):
            return

        if any(math.isnan(value) or math.isinf(value) for value in values):
            return
        center_x, center_z, center_y, gradient_x, gradient_z, x, z = values
        height = center_y + gradient_x * (x - center_x) + gradient_z * (z - center_z)
        if math.isnan(height) or math.isinf(height):
            return
        return height


def suspension_support_vertical_velocity(plane, velocity_x, velocity_z):
    """Return the vertical constraint speed induced by horizontal travel.

        The terrain is stationary in world space, but its height under a moving
        vehicle changes at ``gradient dot horizontal velocity``.  Keep this input
        geometric: the body's observed height delta is deliberately not accepted,
        so a suspension correction cannot feed back as next tick's support speed.
        """
    if not isinstance(plane, dict):
        return
    else:
        try:
            values = (
             float(plane['gradient_x']), float(plane['gradient_z']),
             float(velocity_x), float(velocity_z))
        except (KeyError, TypeError, ValueError, OverflowError):
            return

        if any(math.isnan(value) or math.isinf(value) for value in values):
            return
        gradient_x, gradient_z, velocity_x, velocity_z = values
        return gradient_x * velocity_x + gradient_z * velocity_z


def suspension_drive_pitch(plane, yaw):
    """Project contacted terrain onto the hull-forward drive axis."""
    try:
        yaw = float(yaw)
        if math.isnan(yaw) or math.isinf(yaw):
            return
    except (TypeError, ValueError, OverflowError):
        return

    tangent = suspension_support_vertical_velocity(plane, math.sin(yaw), math.cos(yaw))
    if tangent is None:
        return
    else:
        return -math.atan(tangent)


def landing_impact_speed(world_velocity, support_normal):
    """Return closing speed along one trustworthy upward support normal.

        If the plane normal or either horizontal velocity component is unavailable,
        the established vertical-only fall observation remains authoritative.
        """
    try:
        velocity_y = float(world_velocity[1])
    except (IndexError, TypeError, ValueError, OverflowError):
        return 0.0

    vertical = max(0.0, -velocity_y) if not math.isnan(velocity_y) and not math.isinf(velocity_y) else 0.0
    try:
        velocity_x = float(world_velocity[0])
        velocity_z = float(world_velocity[2])
    except (IndexError, TypeError, ValueError, OverflowError):
        return vertical

    if support_normal is None:
        return vertical
    else:
        try:
            normal_x = float(support_normal[0])
            normal_y = float(support_normal[1])
            normal_z = float(support_normal[2])
        except (IndexError, TypeError, ValueError, OverflowError):
            return vertical

        components = (
         normal_x, normal_y, normal_z)
        if any(math.isnan(value) or math.isinf(value) for value in components) or normal_y <= 0.0:
            return vertical
        scale = max(abs(normal_x), abs(normal_y), abs(normal_z))
        if scale <= 0.0:
            return vertical
        scaled_x = normal_x / scale
        scaled_y = normal_y / scale
        scaled_z = normal_z / scale
        length = math.sqrt(scaled_x * scaled_x + scaled_y * scaled_y + scaled_z * scaled_z)
        if length <= 0.0 or math.isnan(length) or math.isinf(length):
            return vertical
        if any(math.isnan(value) or math.isinf(value) for value in (
         velocity_x, velocity_y, velocity_z)):
            return vertical
        closing = -(velocity_x * scaled_x + velocity_y * scaled_y + velocity_z * scaled_z) / length
        if math.isnan(closing) or math.isinf(closing):
            return vertical
        return max(0.0, closing)


def suspension_ground_planes_continuous(previous, current, start_position, end_position, height_tolerance, gradient_tolerance):
    """Reject a layer jump or slope break between two world-space planes."""
    try:
        start_x = float(start_position[0])
        start_z = float(start_position[2])
        end_x = float(end_position[0])
        end_z = float(end_position[2])
        height_tolerance = float(height_tolerance)
        gradient_tolerance = float(gradient_tolerance)
    except (IndexError, TypeError, ValueError, OverflowError):
        return False

    values = (
     start_x, start_z, end_x, end_z,
     height_tolerance, gradient_tolerance)
    if any(math.isnan(value) or math.isinf(value) for value in values) or height_tolerance < 0.0 or gradient_tolerance < 0.0:
        return False
    previous_start = suspension_plane_height(previous, start_x, start_z)
    current_start = suspension_plane_height(current, start_x, start_z)
    previous_end = suspension_plane_height(previous, end_x, end_z)
    current_end = suspension_plane_height(current, end_x, end_z)
    if any(value is None for value in (
     previous_start, current_start, previous_end, current_end)):
        return False
    if abs(previous_start - current_start) > height_tolerance or abs(previous_end - current_end) > height_tolerance:
        return False
    try:
        difference_x = float(current['gradient_x']) - float(previous['gradient_x'])
        difference_z = float(current['gradient_z']) - float(previous['gradient_z'])
    except (KeyError, TypeError, ValueError, OverflowError):
        return False

    return difference_x * difference_x + difference_z * difference_z <= gradient_tolerance * gradient_tolerance + 1e-12


def suspension_path_probe_fractions(distance):
    """Return a fixed-budget set of interior continuity checkpoints."""
    try:
        distance = max(0.0, float(distance))
    except (TypeError, ValueError):
        return ()

    steps = min(SUSPENSION_PATH_MAX_PROBES, max(0, int(math.ceil(distance / SUSPENSION_PATH_PROBE_SPACING)) - 1))
    return tuple(float(index + 1) / float(steps + 1) for index in range(steps))


def suspension_support_allowed(height, normal_y, flat_maximum_y=None):
    """Validate spring travel and the incline-only penetration extension."""
    height = float(height)
    normal_y = float(normal_y)
    if math.isnan(height) or math.isinf(height) or math.isnan(normal_y) or math.isinf(normal_y):
        return False
    if normal_y <= 0.5:
        return False
    else:
        if flat_maximum_y is None or height <= float(flat_maximum_y) + 0.01:
            return True
        return normal_y < 0.995


def retained_ground_contact(point, ground, memory, maximum_distance, support_gradient=None):
    """Keep one recent ground contact across a short wheel-scale gap."""
    try:
        x, z = float(point[0]), float(point[1])
        distance = max(0.0, float(maximum_distance))
    except (IndexError, TypeError, ValueError, OverflowError):
        return (None, None)

    if any(math.isnan(value) or math.isinf(value) for value in (x, z, distance)):
        return (None, None)
    else:
        if ground is not None:
            try:
                ground = float(ground)
            except (TypeError, ValueError, OverflowError):
                return (None, None)

            if math.isnan(ground) or math.isinf(ground):
                return (None, None)
            return (ground, (x, z, ground, x, z, 0.0, False))
        if memory is None:
            return (None, None)
        try:
            origin_x = float(memory[0])
            origin_z = float(memory[1])
            height = float(memory[2])
            last_x = float(memory[3])
            last_z = float(memory[4])
            travelled = max(0.0, float(memory[5]))
            last_query_missed = bool(memory[6])
            values = (origin_x, origin_z, height, last_x, last_z, travelled)
            if any(math.isnan(value) or math.isinf(value) for value in values):
                return (None, None)
            step_x = x - last_x
            step_z = z - last_z
            step_sq = step_x * step_x + step_z * step_z
            if step_sq <= 1e-10:
                if last_query_missed:
                    return (None, None)
                return (height,
                 (
                  origin_x, origin_z, height, x, z, travelled, True))
            dx = x - origin_x
            dz = z - origin_z
            travelled += math.sqrt(step_sq)
            if dx * dx + dz * dz <= distance * distance + 1e-12 and travelled <= distance + 1e-09:
                retained_height = height
                if support_gradient is not None:
                    gradient_x = float(support_gradient[0])
                    gradient_z = float(support_gradient[1])
                    if any(math.isnan(value) or math.isinf(value) for value in (gradient_x, gradient_z)):
                        return (None, None)
                    retained_height += gradient_x * dx + gradient_z * dz
                return (retained_height,
                 (
                  origin_x, origin_z, height, x, z, travelled, True))
        except (IndexError, TypeError, ValueError, OverflowError):
            pass

        return (None, None)


def suspension_vertical_sweep_drop(vertical_speed, dt):
    """Cover the full downward semi-implicit travel before sampling support."""
    step = max(0.0, float(dt))
    return max(0.0, -float(vertical_speed) * step + GRAVITY * step * step)


def _rigid_point_height(state, point, rotation=None):
    if rotation is None:
        rotation = _suspension_rotation(state.get('pitch', 0.0), state.get('roll', 0.0))
    sp, cp, sr, cr = rotation
    x, y, z = float(point['x']), float(point.get('y', 0.0)), float(point['z'])
    return float(state['height']) + (cp * (sr * x + cr * y) - sp * z)


def _rigid_point_height_gradients(state, point, rotation=None):
    if rotation is None:
        rotation = _suspension_rotation(state.get('pitch', 0.0), state.get('roll', 0.0))
    x, y, z = float(point['x']), float(point.get('y', 0.0)), float(point['z'])
    sp, cp, sr, cr = rotation
    return (-sp * (sr * x + cr * y) - cp * z, cp * (cr * x - sr * y))


def _rigid_point_velocity(state, point):
    pitch_gradient, roll_gradient = _rigid_point_height_gradients(state, point)
    return float(state.get('vertical_velocity', 0.0)) + pitch_gradient * float(state.get('pitch_velocity', 0.0)) + roll_gradient * float(state.get('roll_velocity', 0.0))


def _spring_height(state, spring):
    return _rigid_point_height(state, spring)


def _spring_point_velocity(state, spring):
    return _rigid_point_velocity(state, spring)


def _suspension_contact_keys(params, state, ground_heights, pseudo_ground_heights):
    """Return final geometric contacts, separated from within-step impacts."""
    rotation = None
    contacts = set()
    left = set()
    right = set()
    for index, spring in enumerate(params['springs']):
        ground = ground_heights[index]
        if ground is None:
            continue
        if rotation is None:
            rotation = _suspension_rotation(state.get('pitch', 0.0), state.get('roll', 0.0))
        compression = spring['static_compression'] + float(ground) - _rigid_point_height(state, spring, rotation)
        if compression <= 0.0:
            continue
        key = (
         'spring', index)
        contacts.add(key)
        if spring['side'] == 'left':
            left.add(key)
        elif spring['side'] == 'right':
            right.add(key)

    for index, contact in enumerate(params.get('pseudo_contacts', ())):
        ground = pseudo_ground_heights[index]
        if ground is None:
            continue
        if rotation is None:
            rotation = _suspension_rotation(state.get('pitch', 0.0), state.get('roll', 0.0))
        gap = float(ground) - _rigid_point_height(state, contact, rotation)
        if gap < -CONTACT_PENETRATION:
            continue
        key = (
         'pseudo', index)
        contacts.add(key)
        if contact.get('side') == 'left':
            left.add(key)
        elif contact.get('side') == 'right':
            right.add(key)

    return (
     contacts, left, right)


def suspension_limit_excess(params, state, ground_heights):
    """Return the largest compression beyond a projected hard limit."""
    rotation = None
    maximum = 0.0
    for index, spring in enumerate(params['springs']):
        ground = ground_heights[index]
        if ground is None:
            continue
        if rotation is None:
            rotation = _suspension_rotation(state.get('pitch', 0.0), state.get('roll', 0.0))
        compression = spring['static_compression'] + float(ground) - _rigid_point_height(state, spring, rotation)
        maximum = max(maximum, compression - spring['max_compression'])

    return maximum


def _suspension_constraints(params, ground_heights, pseudo_ground_heights):
    """Prepare the fixed contacts of one immutable ground sample set."""
    constraints = []
    for index, spring in enumerate(params['springs']):
        ground = ground_heights[index]
        if ground is not None:
            constraints.append((
             (
              'spring', index), spring,
             float(ground),
             float(spring['max_compression']) - float(spring['static_compression'])))

    pseudo_ground_heights = pseudo_ground_heights or ()
    for index, contact in enumerate(params.get('pseudo_contacts', ())):
        ground = pseudo_ground_heights[index] if index < len(pseudo_ground_heights) else None
        if ground is not None:
            constraints.append((
             (
              'pseudo', index), contact,
             float(ground),
             float(contact.get('penetration', ALLOWED_PENETRATION))))

    return constraints


def _project_suspension_limits(params, state, ground_heights, pseudo_ground_heights=None, support_vertical_velocity=0.0, support_height_offset=0.0, constraints=None):
    """Resolve hard limits with an order-independent worst-contact projection."""
    inv_mass = 1.0 / params['mass']
    inv_pitch = 1.0 / params['pitch_inertia']
    inv_roll = 1.0 / params['roll_inertia']
    if constraints is None:
        constraints = _suspension_constraints(params, ground_heights, pseudo_ground_heights)
    if not constraints:
        return set()
    if support_height_offset:
        constraints = [(key, point, ground + support_height_offset, penetration) for key, point, ground, penetration in constraints]
    touched = set()
    for unused_iteration in range(params['constraint_iterations']):
        rotation = _suspension_rotation(state.get('pitch', 0.0), state.get('roll', 0.0))
        rows = []
        maximum_excess = 0.0
        for key, point, ground, penetration in constraints:
            excess = ground - _rigid_point_height(state, point, rotation) - penetration
            if excess <= 1e-05:
                continue
            touched.add(key)
            pitch_height, roll_height = _rigid_point_height_gradients(state, point, rotation)
            pitch_grad, roll_grad = -pitch_height, -roll_height
            denominator = inv_mass + pitch_grad * pitch_grad * inv_pitch + roll_grad * roll_grad * inv_roll
            if denominator <= 1e-12:
                continue
            rows.append((
             point, excess, pitch_grad, roll_grad, denominator))
            maximum_excess = max(maximum_excess, excess)

        if not rows:
            break
        tie_tolerance = max(1e-10, maximum_excess * 1e-08)
        selected = tuple(row for row in rows if maximum_excess - row[1] <= tie_tolerance)
        position_height = []
        position_pitch = []
        position_roll = []
        velocity_height = []
        velocity_pitch = []
        velocity_roll = []
        for point, excess, pitch_grad, roll_grad, denominator in selected:
            point_velocity = float(state.get('vertical_velocity', 0.0)) + -pitch_grad * float(state.get('pitch_velocity', 0.0)) + -roll_grad * float(state.get('roll_velocity', 0.0)) - support_vertical_velocity
            if point_velocity < 0.0:
                velocity_impulse = -point_velocity / denominator
                velocity_height.append(velocity_impulse * inv_mass)
                velocity_pitch.append(-velocity_impulse * pitch_grad * inv_pitch)
                velocity_roll.append(-velocity_impulse * roll_grad * inv_roll)
            else:
                velocity_height.append(0.0)
                velocity_pitch.append(0.0)
                velocity_roll.append(0.0)
            impulse = excess / denominator
            position_height.append(impulse * inv_mass)
            position_pitch.append(-impulse * pitch_grad * inv_pitch)
            position_roll.append(-impulse * roll_grad * inv_roll)

        scale = 1.0 / float(len(selected))
        state['vertical_velocity'] += math.fsum(velocity_height) * scale
        state['pitch_velocity'] += math.fsum(velocity_pitch) * scale
        state['roll_velocity'] += math.fsum(velocity_roll) * scale
        state['height'] += math.fsum(position_height) * scale
        state['pitch'] += math.fsum(position_pitch) * scale
        state['roll'] += math.fsum(position_roll) * scale

    remaining_excess = 0.0
    rotation = _suspension_rotation(state.get('pitch', 0.0), state.get('roll', 0.0))
    for key, point, ground, penetration in constraints:
        excess = ground - _rigid_point_height(state, point, rotation) - penetration
        if excess > 0.0:
            remaining_excess = max(remaining_excess, excess)
            touched.add(key)

    if remaining_excess > 0.0:
        state['height'] += remaining_excess + 1e-09
    return touched


def damper_suspension_step(params, state, ground_heights, dt, pseudo_ground_heights=None, support_vertical_velocity=0.0):
    """Advance the contrib ten-spring heave/pitch/roll trial."""
    if not isinstance(state, dict):
        raise ValueError('suspension state must be a dictionary')
    if len(ground_heights) != len(params['springs']):
        raise ValueError('suspension ground sample count mismatch')
    pseudo_contacts = params.get('pseudo_contacts', ())
    if pseudo_ground_heights is None:
        pseudo_ground_heights = (None, ) * len(pseudo_contacts)
    if len(pseudo_ground_heights) != len(pseudo_contacts):
        raise ValueError('pseudo-contact ground sample count mismatch')
    constraints = _suspension_constraints(params, ground_heights, pseudo_ground_heights)
    try:
        support_vertical_velocity = float(support_vertical_velocity)
    except (TypeError, ValueError, OverflowError):
        raise ValueError('support vertical velocity is invalid')

    if math.isnan(support_vertical_velocity) or math.isinf(support_vertical_velocity):
        raise ValueError('support vertical velocity is not finite')
    result = {'height': (float(state.get('height', 0.0))), 'vertical_velocity': (float(state.get('vertical_velocity', 0.0))), 
       'pitch': (float(state.get('pitch', 0.0))), 
       'pitch_velocity': (float(state.get('pitch_velocity', 0.0))), 
       'roll': (float(state.get('roll', 0.0))), 
       'roll_velocity': (float(state.get('roll_velocity', 0.0)))}
    total = max(0.0, min(0.2, float(dt)))
    steps = min(SERVER_PHYSICS_MAX_SUBSTEPS, max(1, int(math.ceil(total / params['fixed_step']))))
    step = total / float(steps) if steps else 0.0
    touched_keys = set()
    maximum_compression = 0.0
    impact_speed = None
    contact_transition_seen = False
    vertical_acceleration = 0.0
    pitch_acceleration = 0.0
    roll_acceleration = 0.0
    for substep_index in range(steps):
        rotation = _suspension_rotation(result['pitch'], result['roll']) if constraints else None
        support_force_offset = -support_vertical_velocity * max(0.0, total - step * float(substep_index))
        support_projection_offset = -support_vertical_velocity * max(0.0, total - step * float(substep_index + 1))
        total_force = -params['mass'] * GRAVITY
        lever=float(params.get('center_of_mass_height',params.get('clearance',.5)))
        # Positive pitch lowers the nose; drive raises it, braking lowers it.
        # Positive roll raises the right track: turn reaction leans outward.
        supported=any(h is not None for h in ground_heights)
        pitch_torque = -params['mass']*lever*max(-8.,min(8.,float(state.get('drive_acceleration',0.)))) if supported else 0.0
        roll_torque = params['mass']*lever*max(-6.,min(6.,float(state.get('lateral_acceleration',0.)))) if supported else 0.0
        substep_contacts = 0
        substep_vertical_speed = result['vertical_velocity']
        substep_relative_speed = substep_vertical_speed - support_vertical_velocity
        for index, spring in enumerate(params['springs']):
            ground = ground_heights[index]
            if ground is None:
                continue
            ground = float(ground) + support_force_offset
            compression = spring['static_compression'] + ground - _rigid_point_height(result, spring, rotation)
            if compression <= 0.0:
                continue
            maximum_compression = max(maximum_compression, compression)
            key = ('spring', index)
            touched_keys.add(key)
            substep_contacts += 1
            if not contact_transition_seen and substep_relative_speed < 0.0:
                impact_speed = substep_vertical_speed if impact_speed is None else min(impact_speed, substep_vertical_speed)
            pitch_gradient, roll_gradient = _rigid_point_height_gradients(result, spring, rotation)
            relative_point_velocity = float(result['vertical_velocity']) + pitch_gradient * float(result['pitch_velocity']) + roll_gradient * float(result['roll_velocity']) - support_vertical_velocity
            force = spring['stiffness'] * compression - spring['damping'] * relative_point_velocity
            if compression > spring['max_compression']:
                excess = compression - spring['max_compression']
                force += spring['stiffness'] * 8.0 * excess * (1.0 + excess / max(spring['max_compression'], 0.01))
            force = max(0.0, min(spring['max_force'], force))
            total_force += force
            pitch_torque += pitch_gradient * force
            roll_torque += roll_gradient * force

        for index, contact in enumerate(pseudo_contacts):
            ground = pseudo_ground_heights[index]
            if ground is None:
                continue
            ground = float(ground) + support_force_offset
            gap = ground - _rigid_point_height(result, contact, rotation)
            if gap < -CONTACT_PENETRATION:
                continue
            key = (
             'pseudo', index)
            touched_keys.add(key)
            substep_contacts += 1
            if not contact_transition_seen and substep_relative_speed < 0.0:
                impact_speed = substep_vertical_speed if impact_speed is None else min(impact_speed, substep_vertical_speed)

        if substep_contacts:
            contact_transition_seen = True
        if substep_contacts == 0:
            decay = math.exp(-AIRBORNE_ANGULAR_DAMPING * step)
            result['pitch_velocity'] = max(-AIRBORNE_ANGULAR_SPEED_LIMIT, min(AIRBORNE_ANGULAR_SPEED_LIMIT, result['pitch_velocity'])) * decay
            result['roll_velocity'] = max(-AIRBORNE_ANGULAR_SPEED_LIMIT, min(AIRBORNE_ANGULAR_SPEED_LIMIT, result['roll_velocity'])) * decay
        vertical_acceleration = total_force / params['mass']
        pitch_acceleration = pitch_torque / params['pitch_inertia']
        roll_acceleration = roll_torque / params['roll_inertia']
        result['vertical_velocity'] += vertical_acceleration * step
        result['pitch_velocity'] += pitch_acceleration * step
        result['roll_velocity'] += roll_acceleration * step
        result['height'] += result['vertical_velocity'] * step
        result['pitch'] += result['pitch_velocity'] * step
        result['roll'] += result['roll_velocity'] * step
        pre_projection_speed = result['vertical_velocity']
        projected = _project_suspension_limits(params, result, ground_heights, pseudo_ground_heights, support_vertical_velocity, support_projection_offset, constraints)
        if projected:
            if not contact_transition_seen and pre_projection_speed - support_vertical_velocity < 0.0:
                impact_speed = pre_projection_speed if impact_speed is None else min(impact_speed, pre_projection_speed)
            contact_transition_seen = True
            touched_keys.update(projected)

    contact_keys, left_contact_keys, right_contact_keys = _suspension_contact_keys(params, result, ground_heights, pseudo_ground_heights)
    contact_count = len(contact_keys)
    if contact_keys and not contact_transition_seen:
        if result['vertical_velocity'] - support_vertical_velocity < 0.0:
            impact_speed = result['vertical_velocity']
        contact_transition_seen = True
    touched_keys.update(contact_keys)
    if contact_count:
        if abs(vertical_acceleration) < FREEZE_ACCEL_EPSILON and abs(result['vertical_velocity'] - support_vertical_velocity) < FREEZE_VEL_EPSILON:
            result['vertical_velocity'] = support_vertical_velocity
        if abs(pitch_acceleration) < FREEZE_ANG_ACCEL_EPSILON and abs(result['pitch_velocity']) < FREEZE_ANG_VEL_EPSILON:
            result['pitch_velocity'] = 0.0
        if abs(roll_acceleration) < FREEZE_ANG_ACCEL_EPSILON and abs(result['roll_velocity']) < FREEZE_ANG_VEL_EPSILON:
            result['roll_velocity'] = 0.0
    result['contact_count'] = contact_count
    result['airborne'] = contact_count == 0
    result['left_flying'] = not bool(left_contact_keys)
    result['right_flying'] = not bool(right_contact_keys)
    result['contacted_this_step'] = bool(touched_keys)
    result['touched_contact_count'] = len(touched_keys)
    result['impact_speed'] = impact_speed
    result['max_compression'] = maximum_compression
    result['max_limit_excess'] = max(0.0, suspension_limit_excess(params, result, ground_heights))
    rotation = _suspension_rotation(result['pitch'], result['roll']) if constraints else None
    for index, contact in enumerate(pseudo_contacts):
        ground = pseudo_ground_heights[index]
        if ground is None:
            continue
        result['max_limit_excess'] = max(result['max_limit_excess'], float(ground) - _rigid_point_height(result, contact, rotation) - float(contact.get('penetration', ALLOWED_PENETRATION)))

    return result


def longitudinal_slope_grip(slope_pitch):
    """Return #1513's terrain pulling grip for this fore/aft slope.

        The native configuration stores the curve as ``(normalY, grip)`` pairs and
        the #1513 executable evaluates those pairs with clamped linear
        interpolation. Ground flatter than 27.5 degrees therefore keeps grip 1.0;
        ground at or beyond 32 degrees keeps only 0.1. ``DRIVE_TRACTION`` is an
        explicit tuning multiplier around that recovered stock curve.
        """
    ny = math.cos(slope_pitch)
    if ny >= SLOPE_GRIP_LNG_FULL_Y:
        grip = SLOPE_GRIP_LNG_FULL
    elif ny <= SLOPE_GRIP_LNG_MIN_Y:
        grip = SLOPE_GRIP_LNG_MIN
    else:
        span = SLOPE_GRIP_LNG_FULL_Y - SLOPE_GRIP_LNG_MIN_Y
        progress = (ny - SLOPE_GRIP_LNG_MIN_Y) / span
        grip = SLOPE_GRIP_LNG_MIN + progress * (SLOPE_GRIP_LNG_FULL - SLOPE_GRIP_LNG_MIN)
    return grip * DRIVE_TRACTION


def lateral_slope_grip(normal_y):
    """Return the contrib trial's low-cost side-grip interpolation."""
    normal_y = max(0.0, min(1.0, float(normal_y)))
    if normal_y >= SLOPE_GRIP_SDW_FULL_Y:
        return SLOPE_GRIP_SDW_FULL
    if normal_y <= SLOPE_GRIP_SDW_MIN_Y:
        return SLOPE_GRIP_SDW_MIN
    span = SLOPE_GRIP_SDW_FULL_Y - SLOPE_GRIP_SDW_MIN_Y
    progress = (normal_y - SLOPE_GRIP_SDW_MIN_Y) / span
    return SLOPE_GRIP_SDW_MIN + progress * (SLOPE_GRIP_SDW_FULL - SLOPE_GRIP_SDW_MIN)


def engine_force(p, v, throttle, slope_pitch=0.0):
    """F = P_eff / max(|v|, v_min), TRACTION-capped. P_eff = powerW x
        POWER_FACTOR (WG scales engine power by GRAVITY_FACTOR). Reverse gets
        BKWD_POWER_FRACTION (1.0 = full power).

        Drive force can never exceed the #1513 longitudinal terrain-grip curve
        times the current normal force. The curve stays at 1.0 through 27.5 degrees
        and releases to 0.1 at 32 degrees, so the selected engine and installed
        mass govern ordinary climbs while very steep faces still lose drive."""
    if throttle == 0:
        return 0.0
    pw = p['powerW'] * POWER_FACTOR * p.get('nativePowerRatio', 1.0)
    if throttle < 0:
        pw *= BKWD_POWER_FRACTION
    f = pw / max(abs(v), ENGINE_MIN_V)
    ny = math.cos(slope_pitch)
    fmax = longitudinal_slope_grip(slope_pitch) * p['mass'] * GRAVITY * (ny if ny > 0.1 else 0.1)
    if f > fmax:
        f = fmax
    return f * throttle


def rolling_resist_force(p, terrainIdx=0, steering=False):
    """Rolling drag = mu * N. The descriptor bakes mu*9.81 into
        specificFriction; the WG sim applies mu against the 1.25 g normal force,
        so the stored value gets the GRAVITY_FACTOR back. terrainResistance
        scales it; steering adds track-differential drag."""
    f = p['mass'] * p['specificFriction'] * GRAVITY_FACTOR * p['terrainResist'][terrainIdx]
    if steering:
        f *= STEER_RESIST_MULT
    return f


def brake_force(p, active, terrainIdx=0, slope_pitch=0.0):
    """Braking is GRIP-limited, like drive traction: the locked tracks can
        only hold cohesion x normal force, and the normal force shrinks with slope
        (cos theta) while cohesion decays on steep ground. So a hull braking on a
        slope past the grip limit CANNOT hold and slides - the same ~50 deg limit
        as the lateral fall-line slip, kept consistent on purpose.
        active=True: opposite-throttle / hold lock-up. active=False: the established
        flat-ground drivetrain coast drag; longitudinal_step relieves that drag only
        near the static perch tangent, where gravity owns the descent."""
    ny = math.cos(slope_pitch)
    grip_decel = slope_cohesion(ny) * GRAVITY * (ny if ny > 0.1 else 0.1)
    brake = p['brakeDecel'] if p['brakeDecel'] < grip_decel else grip_decel
    if active:
        return p['mass'] * brake
    return rolling_resist_force(p, terrainIdx, False) + p['mass'] * COAST_BRAKE_SHARE * brake


def contact_push_decel(p, rolling, terrainIdx=0, normal_y=1.0):
    """Return the (longitudinal, lateral) m/s^2 the tracks oppose an EXTERNAL
        push with. This is the ground reaction to another hull shoving this one, so
        it is deliberately anisotropic: a track rolls along the hull and scrubs
        across it.

        rolling=True means this hull's own drivetrain is already turning (it has
        throttle or road speed), so a shove along the hull only fights
        rolling_resist_force. rolling=False is the parked/wrecked hull whose tracks
        are held; it resists with the same static perch limit longitudinal_step uses
        for a parked hull on a slope. Sideways there is no rolling case at all - the
        tracks always scrub - so the lateral axis keeps the fall-line hold
        slope_slide_speed already applies, scaled by the #1513 side-grip curve.

        No constant here is new: the whole point is that being pushed uses the same
        track laws as driving, braking and sliding."""
    ny = normal_y if normal_y > 0.1 else 0.1
    roll = rolling_resist_force(p, terrainIdx, False) / (p['mass'] if p['mass'] > 1.0 else 1.0)
    hold = SLIDE_HOLD_TAN * GRAVITY * ny
    longitudinal = roll if rolling else hold if hold > roll else roll
    lateral = SLIDE_HOLD_TAN * lateral_slope_grip(normal_y) * GRAVITY * ny
    if lateral < roll:
        lateral = roll
    return (
     longitudinal, lateral)


def _bleed(value, budget):
    """Coulomb bleed: remove up to budget, never crossing zero."""
    if budget <= 0.0:
        return value
    if value > budget:
        return value - budget
    if value < -budget:
        return value + budget
    return 0.0


def contact_push_step(p, push_x, push_z, yaw, dt, rolling=False, terrainIdx=0, normal_y=1.0):
    """Advance one hull's external contact-push velocity by dt.

        The push is a world-frame velocity a contact impulse gave this hull. Resolve
        it into the hull frame, spend the matching track budget on each axis, and
        rotate back. Dry friction removes a fixed amount of speed per second and
        stops the hull dead, which is why a shove no longer creeps forever the way
        an exponential decay did."""
    dt = float(dt)
    if dt <= 0.0:
        return (float(push_x), float(push_z))
    longitudinal, lateral = contact_push_decel(p, rolling, terrainIdx, normal_y)
    sine = math.sin(yaw)
    cosine = math.cos(yaw)
    forward = push_x * sine + push_z * cosine
    right = push_x * cosine - push_z * sine
    forward = _bleed(forward, longitudinal * dt)
    right = _bleed(right, lateral * dt)
    return (forward * sine + right * cosine,
     forward * cosine - right * sine)


def contact_push_is_held(p, push_x, push_z, yaw, dt, rolling=False, terrainIdx=0, normal_y=1.0):
    """Return whether the tracks absorb this whole push within one slice.

        The static Coulomb test, expressed through the same budget contact_push_step
        spends, so the predicate and the integration can never disagree."""
    return contact_push_step(p, push_x, push_z, yaw, dt, rolling, terrainIdx, normal_y) == (0.0,
                                                                                            0.0)


def _grip_decel(p, slope_pitch):
    """Max track hold as a deceleration (m/s^2): cohesion x normal-force,
        both shrinking with slope. This is the single grip limit that caps drive
        traction, braking AND the static parked hold, so climb/brake/slide all
        share one consistent ~50 deg threshold."""
    ny = math.cos(slope_pitch)
    return slope_cohesion(ny) * GRAVITY * (ny if ny > 0.1 else 0.1)


@observed('physics.longitudinal')
def longitudinal_step(p, v, throttle, steering, slope_pitch, dt, airborne=False, terrainIdx=0, handbrake=False):
    """One integration step of forward (along-hull) speed. Returns the new v.
        slope_pitch: fore/aft ground pitch (BigWorld: nose-up negative).

        Gravity along the slope ALWAYS acts when grounded (even parked at v=0), so
        a hull pointed up/down a slope too steep for its tracks slides off from a
        standstill - the fix for "stuck where it should slide". The tracks resist
        up to the grip limit (_grip_decel): below it they hold, past it the excess
        drives the slide. The climb limit is emergent (grip-capped engine force vs
        slope gravity), so there is no dead can-neither-climb-nor-slide band."""
    if airborne:
        return v
    grav_a = GRAVITY * math.sin(slope_pitch)
    if handbrake and not airborne:
        _hb_grip = _grip_decel(p, slope_pitch)
        if abs(v) < 0.05:
            if abs(grav_a) <= _hb_grip:
                return 0.0
            return v + (grav_a - (_hb_grip if grav_a > 0.0 else -_hb_grip)) * dt
        _hb_a = grav_a - (_hb_grip if v > 0.0 else -_hb_grip)
        _hb_nv = v + _hb_a * dt
        if (v > 0.0) != (_hb_nv > 0.0):
            return 0.0
        return _hb_nv
    grip = _grip_decel(p, slope_pitch)
    rr = rolling_resist_force(p, terrainIdx, steering) / p['mass']
    if throttle != 0:
        _ef = engine_force(p, v, throttle, slope_pitch) / p['mass']
        _ny_c = math.cos(slope_pitch)
        _max_climb = longitudinal_slope_grip(slope_pitch) * GRAVITY * (_ny_c if _ny_c > 0.1 else 0.1)
        _cant_climb = throttle * grav_a < 0.0 and _max_climb < abs(grav_a) + rr
        if _cant_climb:
            _ef = 0.0
        accel = _ef + grav_a
        _rrf = v / 0.08
        if _rrf > 1.0:
            _rrf = 1.0
        elif _rrf < -1.0:
            _rrf = -1.0
        accel -= rr * _rrf
        if _cant_climb:
            if abs(v) > 0.05:
                _kin = SLIDE_KINETIC * GRAVITY * (_ny_c if _ny_c > 0.1 else 0.1)
                accel += _kin if v < 0.0 else -_kin
        elif throttle > 0 and v < -0.1 or throttle < 0 and v > 0.1:
            _need = -v / dt - accel
            accel += _need if abs(_need) < grip else grip if _need > 0.0 else -grip
    elif abs(v) < 0.02:
        _ny_h = math.cos(slope_pitch)
        _hold = SLIDE_HOLD_TAN * GRAVITY * (_ny_h if _ny_h > 0.1 else 0.1)
        if abs(grav_a) <= _hold:
            return 0.0
        accel = grav_a - (_hold if grav_a > 0.0 else -_hold)
    else:
        motion_sign = 1.0 if v > 0.0 else -1.0
        downhill_tangent = max(0.0, math.tan(slope_pitch) * motion_sign)
        fade_start = 0.8 * SLIDE_HOLD_TAN
        fade = min(1.0, max(0.0, (downhill_tangent - fade_start) / (SLIDE_HOLD_TAN - fade_start)))
        resist = rr + COAST_BRAKE_SHARE * (1.0 - fade) * grip
        accel = grav_a - (resist if v > 0.0 else -resist)
    _grade = -slope_pitch if v > 0.0 else slope_pitch
    if not airborne and abs(v) > 0.5 and _grade > 0.0:
        _tan = math.tan(_grade)
        if _tan > SLIP_THRESHOLD_TAN:
            _slip = SLIP_DRAG * (_tan - SLIP_THRESHOLD_TAN) * GRAVITY
            accel -= _slip if v > 0.0 else -_slip
    nv = v + accel * dt
    if throttle == 0 and abs(grav_a) <= grip and v != 0.0 and (v > 0.0) != (nv > 0.0):
        nv = 0.0
    _dir = 1.0 if nv >= 0.0 else -1.0
    _lim = p['speedFwd'] if nv >= 0.0 else p['speedBwd']
    if abs(nv) > _lim:
        _cap = _lim * (OVERSPEED_MAX_FACTOR - 1.0)
        _prev_ex = abs(v) - _lim
        if _prev_ex < 0.0:
            _prev_ex = 0.0
        if throttle * _dir > 0.0 and grav_a * _dir > 0.05:
            _excess = _prev_ex + OVERSPEED_BUILD * math.sin(abs(slope_pitch)) * dt
        else:
            _excess = _prev_ex - (rr + OVERSPEED_DAMP) * dt
        if _excess < 0.0:
            _excess = 0.0
        if _excess > _cap:
            _excess = _cap
        nv = _dir * (_lim + _excess)
    return nv


@observed('physics.traverse')
def traverse_step(p, omega, steer_dir, v, dt, terrainIdx=0, drive_intent=0.0):
    """One integration step of hull rotation speed (rad/s). WG 0.8.2: driving
        speed does NOT slow the traverse (SPEED_AFFECT_ROT_DECREASE = 0.0) and the
        rate ramps to full in ANG_ACCELERATION_TIME (50 ms). Medium/soft ground
        scales by the terrain-resistance ratio (the sim couples the limit to
        terrainResistance)."""
    speed_ratio = abs(v) / max(p['speedFwd'], 0.1)
    rot_mod = 1.0 / (1.0 + speed_ratio * SPEED_AFFECT_ROT_DECREASE)
    ter_mod = p['terrainResist'][0] / p['terrainResist'][terrainIdx]
    max_rot = p['rotSpd'] * rot_mod * ter_mod
    intent_sign = -1.0 if drive_intent < 0.0 else 1.0
    target = steer_dir * intent_sign * max_rot
    diff = target - omega
    ramp = max_rot / ANG_ACCELERATION_TIME
    if abs(diff) < ramp * dt:
        omega = target
    else:
        omega += ramp * dt * (1 if diff > 0 else -1)
    if steer_dir == 0 and abs(omega) < 0.01:
        omega = 0.0
    return omega


def track_scroll(p, v, omega):
    """Per-track surface speeds for WGVehicleFashion.movementInfo:
        v_track = v -/+ omega * halfGauge, clamped strictly below maxMovement."""
    tls = v - omega * p['trackCenter']
    trs = v + omega * p['trackCenter']
    cap = p['speedFwd'] * SCROLL_CAP
    if tls > cap:
        tls = cap
    elif tls < -cap:
        tls = -cap
    if trs > cap:
        trs = cap
    elif trs < -cap:
        trs = -cap
    return (
     tls, trs)


def slope_cohesion(ny):
    """Effective track cohesion for a ground normal.y (WG physics_shared slope
        decay): full COHESION until normal.y drops below COH_DECAY_Y (~14 deg), then a
        cubic decay COH_DECAY_FACTOR*(COH_DECAY_Y-ny)**COH_DECAY_POW, plus an extra
        SLOPE_COH_DECAY step below SLOPE_COH_DECAY_Y (~44 deg), floored at
        COH_DECAY_BOUND. The cubic term smooths the old single 44 deg grip cliff so
        grip falls off gradually on steepening ground, as WG does."""
    coh = COHESION
    if ny < COH_DECAY_Y:
        coh -= COH_DECAY_FACTOR * (COH_DECAY_Y - ny) ** COH_DECAY_POW
    if ny < SLOPE_COH_DECAY_Y:
        coh -= SLOPE_COH_DECAY
    if coh > COH_DECAY_BOUND:
        return coh
    return COH_DECAY_BOUND


def slope_slide_speed(cur, slope_tan, dt):
    """Advance the existing passive slope slide along the fall line."""
    theta = math.atan(slope_tan)
    if slope_tan <= SLIDE_HOLD_TAN:
        cur -= COHESION * GRAVITY * dt
        if cur > 0.0:
            return cur
        return 0.0
    cur += (GRAVITY * (math.sin(theta) - SLIDE_HOLD_TAN * math.cos(theta)) - SLIDE_DRAG * cur) * dt
    if cur < 0.0:
        cur = 0.0
    elif cur > SLIDE_MAX:
        cur = SLIDE_MAX
    return cur


def suspension_slope_slide_speed(cur, slope_tan, dt):
    """Apply the contrib trial's unproved lateral-grip projection."""
    theta = math.atan(slope_tan)
    hold_tangent = SLIDE_HOLD_TAN * lateral_slope_grip(math.cos(theta))
    if slope_tan <= hold_tangent:
        cur -= COHESION * GRAVITY * dt
        if cur > 0.0:
            return cur
        return 0.0
    cur += (GRAVITY * (math.sin(theta) - hold_tangent * math.cos(theta)) - SLIDE_DRAG * cur) * dt
    if cur < 0.0:
        cur = 0.0
    elif cur > SLIDE_MAX:
        cur = SLIDE_MAX
    return cur


def ground_follow_gap(speed, slope_pitch, dt):
    """Maximum supported drop for one grounded copied-pose step.

        ``speed`` is signed along the same axis used by ``slope_pitch`` and the pose
        integrator moves x/z by ``speed * dt``. The old surface contributes
        ``speed * tan(pitch) * dt`` only when travel is downhill. Gravity adds the
        same semi-implicit one-step sag used by the airborne integrator.
        """
    step = max(0.0, float(dt))
    pitch = max(-GROUND_PITCH_LIMIT, min(GROUND_PITCH_LIMIT, float(slope_pitch)))
    tangent_drop = max(0.0, float(speed) * math.tan(pitch) * step)
    gap = GROUND_FOLLOW_BASE + tangent_drop + GRAVITY * step * step
    return max(GROUND_FOLLOW_MIN, min(GROUND_FOLLOW_MAX, gap))


def launch_vertical_speed(speed, slope_pitch):
    """Upward velocity retained when signed travel loses ground support."""
    vertical = float(speed) * math.sin(-float(slope_pitch))
    if vertical > 0.0:
        return vertical
    return 0.0


def overturn_level_from_up_cosine(up_cosine, warning_cosine=None, danger_cosine=None):
    """Return 0=safe, 1=caution or 2=danger from hull world-up cosine."""
    warning = OVERTURN_WARNING_COSINE if warning_cosine is None else float(warning_cosine)
    danger = OVERTURN_DANGER_COSINE if danger_cosine is None else float(danger_cosine)
    up_cosine = max(-1.0, min(1.0, float(up_cosine)))
    if up_cosine <= danger:
        return 2
    else:
        if up_cosine <= warning:
            return 1
        return 0


def overturn_level(pitch, roll, warning_cosine=None, danger_cosine=None):
    """Classify an Euler hull pose when a world-up cosine is unavailable."""
    return overturn_level_from_up_cosine(math.cos(float(pitch)) * math.cos(float(roll)), warning_cosine, danger_cosine)


def fall_damage(maxHealth, impact_speed):
    """HP cost of a landing. 0 below FALL_SAFE_SPEED (~4 m drop)."""
    iv = abs(impact_speed)
    if iv <= FALL_SAFE_SPEED:
        return 0
    return int(maxHealth * (iv - FALL_SAFE_SPEED) * FALL_DMG_PER_MS)



# okay decompiling /data/mod_audit/wotmod/res/scripts/client/gui/mods/offline_lan_0922/vehicle_physics.pyc
