# -*- coding: utf-8 -*-
from __future__ import print_function
import sys,os,math,random,unittest,types,ast
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import test_m0704 as F
from trial146 import contact_cache146 as K,combat146 as M,geometry146 as G
class Obj(object):
 def __init__(self,**kw):self.__dict__.update(kw)
class AmmoTests(unittest.TestCase):
 def mag(self):return F.C.Magazine({1:2,2:5,3:9},1,1,8.44,0.)
 def test_first_press_queues_not_reload(self):
  m=self.mag();m.select(2,3.,immediate=False);self.assertEqual((m.selected,m.next_shell,m.pending,m.loaded,m.ready_at),(1,2,None,1,0.));self.assertTrue(m.can_fire(3.))
 def test_second_press_reloads_and_selects_gold_immediately(self):
  m=self.mag();m.select(2,3.,immediate=False);m.select(2,3.1,immediate=True);self.assertEqual((m.selected,m.pending,m.loaded),(2,2,0));self.assertAlmostEqual(m.ready_at,11.54)
 def test_repeat_current_does_not_restart_timer(self):
  m=self.mag();m.select(2,3.);m.select(2,4.);self.assertAlmostEqual(m.ready_at,11.44)
 def test_prebattle_has_no_reload(self):
  m=self.mag();m.select(2,3.,prebattle=True);self.assertEqual((m.selected,m.next_shell,m.pending,m.ready_at),(2,2,None,0.));self.assertTrue(m.can_fire(0.))
 def test_queued_after_shot(self):
  m=self.mag();m.select(2,1.,immediate=False);m.fire(2.);self.assertEqual((m.selected,m.pending,m.counts[1]),(2,2,1));self.assertFalse(m.can_fire(10.43));self.assertTrue(m.can_fire(10.44))
 def test_exhaustion_chooses_largest_count(self):
  m=self.mag();m.counts[1]=1;m.fire(0.);self.assertEqual((m.selected,m.pending),(3,3));self.assertEqual(m.counts[1],0)
 def test_all_empty_does_not_reload_ghost_ammo(self):
  m=F.C.Magazine({1:1,2:0},1,1,8.,0.);m.fire(0.);self.assertIsNone(m.pending);self.assertFalse(m.can_fire(100.));self.assertEqual(m.loaded,0)
 def test_empty_type_cannot_be_selected(self):
  m=self.mag();m.counts[2]=0;self.assertFalse(m.select(2,1.));self.assertEqual(m.selected,1)
 def test_clip_queue_waits_until_clip_empty(self):
  m=F.C.Magazine({1:7,2:5},1,3,8.,1.);m.select(2,0.,immediate=False);m.fire(0.);self.assertEqual((m.selected,m.loaded,m.pending),(1,2,None));m.fire(1.);m.fire(2.);self.assertEqual((m.selected,m.loaded,m.pending),(2,0,2))
 def test_changing_queue_during_reload_preserves_current_load(self):
  m=self.mag();m.fire(0.);m.select(2,1.,immediate=False);m.update(8.44);self.assertEqual((m.selected,m.next_shell,m.loaded),(1,2,1));m.fire(9.);self.assertEqual(m.selected,2)

class CacheTests(unittest.TestCase):
 def bank(self):return K.Bank('/nonexistent/contact-cache')
 def row(self,x=0.,z=0.,lo=-1.,hi=1.,flat=None):return (x,z,lo,hi,flat)
 def probe(self,b,rows,t=0.,ttl=.033333333,radius=.25,gx=0.,gz=0.,ny=1.,cast=None,owner=1):
  return b.batch(owner,0,rows,t,ttl,radius,gx,gz,ny,cast or (lambda *r:0.))
 def test_missing_dll_falls_back(self):
  b=self.bank();self.assertIsNone(b.native);self.assertTrue(b.error);self.assertEqual(self.probe(b,[self.row()]),[0.])
 def test_hit_avoids_engine_call(self):
  b=self.bank();self.probe(b,[self.row()]);self.assertEqual(self.probe(b,[self.row()],t=.016,cast=lambda *r:self.fail('unexpected cast')),[0.]);self.assertEqual((b.hits,b.misses),(1,1))
 def test_expiry_is_not_extended_by_hit(self):
  b=self.bank();self.probe(b,[self.row()]);self.probe(b,[self.row()],t=.016);self.probe(b,[self.row()],t=1./30.);self.assertEqual((b.hits,b.misses),(1,2))
 def test_reprojects_on_slope(self):
  b=self.bank();self.probe(b,[self.row()],gx=.1);out=self.probe(b,[self.row(.1)],t=.01,gx=.1);self.assertAlmostEqual(out[0],.01)
 def test_cross_layer_window_requires_fresh_query(self):
  b=self.bank();self.probe(b,[self.row()]);self.probe(b,[self.row(lo=4.,hi=6.)],t=.01,cast=lambda *r:5.);self.assertEqual(b.misses,2)
 def test_cliff_or_out_of_radius_requires_fresh_query(self):
  b=self.bank();self.probe(b,[self.row()]);self.probe(b,[self.row(1.)],t=.01);self.assertEqual(b.misses,2)
 def test_failed_query_is_not_reused(self):
  b=self.bank();self.probe(b,[self.row()],cast=lambda *r:None);self.probe(b,[self.row()],t=.01);self.assertEqual(b.misses,2)
 def test_urgent_ttl_zero_requires_query(self):
  b=self.bank();self.probe(b,[self.row()]);self.probe(b,[self.row()],t=.01,ttl=0.);self.assertEqual(b.misses,2)
 def test_generation_does_not_reuse_old_contact(self):
  b=self.bank();self.probe(b,[self.row()],owner=1);self.probe(b,[self.row()],t=.01,owner=65);self.assertEqual(b.misses,2)
 def test_native_matches_fallback_randomized(self):
  path=os.environ.get('H146_NATIVE_TEST_LIB')
  if not path:self.skipTest('native platform build not supplied')
  native=K.Bank(path);self.assertIsNotNone(native.native,native.error);fallback=self.bank();rng=random.Random(146)
  for frame in range(300):
   owner=1+frame//75;t=frame/60.;rows=[self.row(i*.02+rng.uniform(-.05,.05),rng.uniform(-.05,.05)) for i in range(10)]
   kwargs=dict(t=t,owner=owner,gx=.1,gz=.03,cast=lambda x,z,*r:.1*x+.03*z)
   a=self.probe(native,rows,**kwargs);b=self.probe(fallback,rows,**kwargs)
   for x,y in zip(a,b):self.assertAlmostEqual(x,y)
  self.assertEqual((native.hits,native.misses),(fallback.hits,fallback.misses));self.assertGreater(native.hits,1000)

class RuntimeTests(unittest.TestCase):
 def runtime(self):
  r=M.Runtime.__new__(M.Runtime);r.round=F.C.Round([F.actor(1,1),F.actor(2,2,pos=(100.,0.,0.))]);r.player_id=1;r.s=Obj();return r
 def test_sleep_stable_then_wake_on_input(self):
  r=self.runtime();a=r.round.actors[1];a.body.update(contact_count=10,airborne=False);a.rest_time=0.
  for i in range(50):r.can_sleep(a,1./60.)
  self.assertTrue(a.sleeping);a.flags=1;self.assertFalse(r.can_sleep(a,1./60.));self.assertFalse(a.sleeping);self.assertEqual(a.contact_epoch,1);self.assertEqual(a.solver_generation,1)
 def test_airborne_does_not_sleep(self):
  r=self.runtime();a=r.round.actors[1];a.body.update(contact_count=0,airborne=True);a.rest_time=2.;self.assertFalse(r.can_sleep(a,1./60.))
 def test_nearby_moving_tank_wakes_sleeper(self):
  r=self.runtime();a=r.round.actors[1];b=r.round.actors[2];a.radius=b.radius=2.;b.position=(2.,0.,0.);b.v=1.;a.sleeping=True;a.body.update(contact_count=10,airborne=False);self.assertFalse(r.can_sleep(a,1./60.));self.assertFalse(a.sleeping)
 def test_minimap_indices_follow_sorted_full_roster(self):
  r=self.runtime();r.round.actors[2].health=0;updates=[];r.s.avatar=Obj(arena=Obj(vehicles={2:None,1:None},updatePositions=lambda *v:updates.append(v)));r.warn=lambda k:self.fail(k);r.publish_positions();self.assertEqual(updates,[([0],[0.,0.])])
 def test_finish_sound_once(self):
  old=sys.modules.get('SoundGroups');events=[];sys.modules['SoundGroups']=Obj(g_instance=Obj(playSound2D=events.append))
  try:
   r=self.runtime();r.warn=lambda k:self.fail(k);r.finish_sound('capture');r.finish_sound('timeout');self.assertEqual(events,['end_battle_capture_base'])
  finally:
   if old is None:sys.modules.pop('SoundGroups',None)
   else:sys.modules['SoundGroups']=old
 def test_artificial_command_delay_disabled(self):
  saved={k:sys.modules.get(k) for k in ('BigWorld','trial146.native_match')};old=M.current;calls=[]
  sys.modules['BigWorld']=Obj(callback=lambda delay,fn:calls.append((delay,fn)));sys.modules['trial146.native_match']=Obj(local_avatar=lambda a:True,_GENERATION=1,_RETURNING=False)
  pkg=sys.modules['trial146'];old_attr=getattr(pkg,'native_match',None);pkg.native_match=sys.modules['trial146.native_match']
  M.current=lambda:Obj(started=True)
  try:self.assertTrue(M.enqueue(Obj(),'vehicle_moveWith',(1,)));self.assertEqual(calls[0][0],0.)
  finally:
   M.current=old
   if old_attr is None:del pkg.native_match
   else:pkg.native_match=old_attr
   for k,v in saved.items():
    if v is None:sys.modules.pop(k,None)
    else:sys.modules[k]=v
 def test_cheap_empty_ray_never_calls_material_api(self):
  g=G.Geometry(Obj(ray=lambda *a:None));g.query=lambda *a:self.fail('expensive material query');self.assertIsNone(g.ray((0,0,0),(1,0,0),True));self.assertEqual(g.cheap_queries,1)
 def test_minimap_keeps_provider_created_before_runtime(self):
  old=sys.modules.get('Math');sys.modules['Math']=Obj(Matrix=lambda m:Obj(value=m))
  try:
   vehicle=Obj(_hangar146_vehicle=True,matrix='native');matrix=M.minimap_matrix(vehicle)
   vehicle._hangar146_pose={'matrix':matrix};matrix.value='moved'
   self.assertIs(M.minimap_matrix(vehicle),matrix);self.assertEqual(matrix.value,'moved')
  finally:
   if old is None:sys.modules.pop('Math',None)
   else:sys.modules['Math']=old
 def test_minimap_leaves_online_vehicle_untouched(self):
  self.assertIsNone(M.minimap_matrix(Obj(matrix='online')))
 def test_cheap_terrain_hit_keeps_steep_wall_normal(self):
  hit=G.Hit((0.,0.,0.),(1.,0.,0.),0,'terrain-wall')
  g=G.Geometry(Obj(ray=lambda *a:Obj(isTerrain=True)));g.enabled=True;g.supports_terrain=True;g.query=lambda *a:hit
  r=self.runtime();r.geometry=g;self.assertIs(r.solid_hit((0,0,0),(1,0,0)),hit)
 def test_native_minimap_factory_hooks_present(self):
  tree=ast.parse(open(F.P+'/combat146.py').read());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='install');names=set(n.name for n in fn.body if isinstance(n,ast.FunctionDef));self.assertTrue({'vehicle_mp','entity_mp','vehicle_location','vehicle_location_mp'}.issubset(names))

if __name__=='__main__':unittest.main(verbosity=2)
