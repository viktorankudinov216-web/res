# -*- coding: utf-8 -*-
"""Read-only verification of supplied Tanki.exe. No execution, writes or hooks.
Set TANKI_EXE to the exact supplied x64 #2304 executable to reproduce.
"""
from __future__ import print_function
import unittest,os,struct,hashlib
PATH=os.environ.get('TANKI_EXE','')
SHA='571b59a0449cec88aa74880b67f14600187ba328fdc532a9ba4de1800ff1d39b'
class BinaryTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  if not PATH or not os.path.isfile(PATH):raise unittest.SkipTest('Set TANKI_EXE to supplied #2304 binary')
  with open(PATH,'rb') as f:cls.raw=f.read()
  offset=struct.unpack_from('<I',cls.raw,0x3c)[0];count=struct.unpack_from('<H',cls.raw,offset+6)[0];optional=struct.unpack_from('<H',cls.raw,offset+20)[0]
  cls.base=struct.unpack_from('<Q',cls.raw,offset+24+24)[0];cls.sections=[]
  for i in range(count):
   p=offset+24+optional+i*40;size,rva,rawsize,position=struct.unpack_from('<IIII',cls.raw,p+8)
   cls.sections.append((rva,max(size,rawsize),position))
 @classmethod
 def data(cls,va,n):
  rva=va-cls.base
  for start,size,position in cls.sections:
   if start<=rva<start+size:return cls.raw[position+rva-start:position+rva-start+n]
  raise AssertionError('VA outside sections')
 def test_exact_supplied_binary(self):self.assertEqual(hashlib.sha256(self.raw).hexdigest(),SHA)
 def test_stop_animating_two_boolean_mask_bits(self):
  # xor eax,eax; [rcx+128]=0; test dl,dl; ... test r8b,r8b
  data=self.data(0x14253eaa0,38)
  self.assertTrue(data.startswith(b'\x33\xc0\x89\x81\x28\x01\x00\x00\x84\xd2'))
  self.assertIn(b'\x45\x84\xc0',data)
 def test_native_tick_reads_yz_and_inverse_radius(self):
  data=self.data(0x14253ef8a,40)
  self.assertIn(b'\xf3\x0f\x10\x44\x24\x24',data) # Y: [rsp+24]
  self.assertIn(b'\xf3\x0f\x10\x44\x24\x28',data) # Z: [rsp+28]
  self.assertIn(b'\xf3\x0f\x59\x43\x6c',data) # inverse radius
  # The angle-advance section multiplies by blend xmm1, not frame dt xmm8.
  self.assertIn(b'\xf3\x0f\x59\xc1',data)
 def test_filter_speed_and_output_are_different_fields(self):
  data=self.data(0x1424d8160,350)
  self.assertIn(b'\x20\x05\x00\x00',data);self.assertIn(b'\x24\x05\x00\x00',data)
  data=self.data(0x1424d5b53,650)
  self.assertIn(b'\x04\x05\x00\x00',data)
 def test_suspension_stop_uses_own_two_boolean_mask(self):
  data=self.data(0x142538f70,115)
  self.assertIn(b'\x41\x0f\xb6\xf0',data) # movzx esi,r8b
  self.assertIn(b'\x0f\xb6\xda',data) # movzx ebx,dl
  self.assertIn(b'\x44\x8b\x90\xa8\x00\x00\x00',data)
  self.assertIn(b'\x83\xe1\xfd',data) # and ecx,~2
 def test_correction_recalculation_only_sets_dirty_flag(self):
  self.assertEqual(self.data(0x1425386dd,7),b'\xc6\x80\xc6\x00\x00\x00\x01')
 def test_clear_ground_nodes_dispatches_unregister_path(self):
  import struct
  data=self.data(0x142538d60,0x46)
  self.assertIn(b'\xff\x60\x18',data) # jmp [rax+18], not only vector clear
  self.assertEqual(struct.unpack('<Q',self.data(0x142f2e8d0+0x18,8))[0],0x142538640)
  self.assertIn(b'\xe8',self.data(0x142538640,0x84))
 def test_constructor_force_flag_and_renderer_gate(self):
  self.assertIn(b'\x88\x98\xc5\x00\x00\x00',self.data(0x142537631,0x14))
  self.assertIn(b'\x80\xbc\x3e\xc5\x00\x00\x00\x00',self.data(0x1425391b0,0x20))
  self.assertIn(b'\xe8',self.data(0x1425391b0,0x20))
if __name__=='__main__':unittest.main(verbosity=2)
