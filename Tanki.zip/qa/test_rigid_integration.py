# -*- coding: utf-8 -*-
from __future__ import print_function
import unittest,sys,os,types,math,json,tempfile,shutil
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import test_m0704 as F
from trial146 import combat146 as M
from trial146.physics_rigid146 import Actor,IdleBridge
from trial146.physics_rigid146 import geometry as G,visual
from trial146.physics_rigid146.math3 import *
class Obj(object):
 def __init__(self,**kw):self.__dict__.update(kw)
def actor(vid=1,team=1):
 params=dict(mass=30000.,powerW=300000.,speedFwd=15.,speedBwd=5.,rotSpd=.7,trackCenter=1.3,specificFriction=.8)
 a=Actor(vid,team,(0.,0.,0.),0.,100,params,F.suspension(),{},F.C.Magazine({1:10},1,1,8.,0.))
 a.configure_rigid(((-1.5,0.,-3.),(1.5,2.,3.)));a.sleeping=False;a.rest_time=0.;a.contact_epoch=0;a.radius=1.5
 return a
class IntegrationTests(unittest.TestCase):
 def test_legacy_is_separate_type(self):self.assertIsNot(Actor,F.C.Actor);self.assertIs(Actor.__bases__[0],F.C.Actor)
 def test_configure_has_no_external_solver(self):
  a=actor();self.assertIsNone(a.rigid_cast);self.assertEqual(a.rigid_layout,'descriptor_legacy_carrier_fallback')
 def test_fixed_tick_adapter(self):
  a=actor();a.flags=1
  for i in range(180):a.step(1./60.,lambda *args:0.,lambda *args:(_ for _ in ()).throw(AssertionError('Kinematic clear called')))
  self.assertGreater(a.position[2],1.);self.assertGreater(a.body['contact_count'],0);self.assertGreater(a.track_speeds[0],0.)
 def test_static_target_frozen(self):
  a=actor();a.rigid_static=True;a.flags=9;a.rigid.b.v=(0.,0.,2.);p=a.position
  a.step(1./60.,None,None);self.assertEqual(a.position,p);self.assertEqual(a.flags,0);self.assertEqual(a.rigid.b.v,ZERO)
 def test_interpolation_same_endpoints(self):
  a=actor();a.rigid.b.q=quat(.3,.1,.2);a.position=(2.,3.,4.)
  p,angles=a.render_pose(1.);self.assertEqual(p,a.position)
  for actual,expected in zip(angles,(.3,.1,.2)):self.assertAlmostEqual(actual,expected)
 def test_helper_disabled(self):
  b=IdleBridge();b.poll();b.reset();b.flush([actor()]);self.assertFalse(b.ready);self.assertIsNone(b.failed)
  with self.assertRaises(RuntimeError):b.solve()
 def test_runtime_never_calls_bot_ai_or_step_when_disabled(self):
  player=actor();target=actor(2,2);calls=[];player.step=lambda *args:calls.append('player');target.step=lambda *args:(_ for _ in ()).throw(AssertionError('Target integrated'))
  player.magazine.update=lambda now:False;target.magazine.update=lambda now:False
  player.think_at=target.think_at=0.;player.native_at=target.native_at=100.
  r=M.Runtime.__new__(M.Runtime);r.round=Obj(actors={1:player,2:target},now=1.,shots=[],capture_step=lambda dt:None)
  r.player_id=1;r.bots_active=False;r.ai=lambda *args:(_ for _ in ()).throw(AssertionError('AI enabled'))
  r.can_sleep=lambda *args:False;r.ground=None;r.clear=None;r.bounds=None;r.present_pose=lambda *args:None;r.publish_capture=lambda:None
  r.stage_ms={};r.recent_physics_ms=0.;r.physics_ms=0.;r.physics_max_ms=0.;r.physics_steps=0
  r.step(1./60.);self.assertEqual(calls,['player']);self.assertEqual(target.flags,0)
 def test_config_defaults_preserve_existing_fields(self):
  root=tempfile.mkdtemp();folder=root+'/mods/configs/hangar146';os.makedirs(folder)
  data={'auto_login':False,'unknown_user_key':{'keep':1}}
  with open(folder+'/config.json','w') as f:json.dump(data,f)
  old=sys.modules.get('trial146.runtime_data');sys.modules['trial146.runtime_data']=Obj(game_root=lambda:root)
  try:
   env={'__name__':'trial146.config_test','__package__':'trial146'}
   exec(compile(open(F.P+'/config.py').read(),'<config>','exec'),env)
   self.assertEqual(env['PHYSICS_MODEL'],'rigid_v1');self.assertFalse(env['BOTS_ACTIVE']);self.assertFalse(env['AUTO_LOGIN'])
   saved=json.load(open(folder+'/config.json'));self.assertEqual(saved['unknown_user_key'],data['unknown_user_key']);self.assertEqual(saved['physics_model'],'rigid_v1')
  finally:
   if old is None:sys.modules.pop('trial146.runtime_data',None)
   else:sys.modules['trial146.runtime_data']=old
   shutil.rmtree(root)
 def test_roof_contact_obb(self):
  a=actor();b=a.rigid.b;b.q=quat(0.,0.,math.pi);self.assertLess(b.support((0.,1.,0.))[1],b.p[1])
 def test_native_rebind_uses_owned_distance_provider(self):
  calls=[];old=sys.modules.get('Math')
  class Animation(object):pass
  sys.modules['Math']=Obj(Vector4Animation=Animation,Vector4=lambda *v:v)
  animator=Obj(scrollLinksRequired=True,setMovementInfo=lambda p:calls.append(('provider',p)),stopAnimatingWheels=lambda l,r:calls.append(('stops',l,r)))
  tracks=Obj(collectConnectedWheels=lambda p:calls.append(('collect',p)),sendWheelScrollLinks=lambda p:calls.append(('send',p)))
  nodes=Obj(setWheelsDataProvider=lambda p:calls.append(('nodes',p)))
  vehicle=Obj(id=1,typeDescriptor=Obj(type=Obj(isWheeledVehicle=False)),appearance=Obj(wheelsAnimator=animator,tracks=tracks,trackNodesAnimator=nodes))
  try:
   a=actor();visual.bind(vehicle,a,lambda *args,**kw:None)
   self.assertIs(calls[0][1],a._rigid_wheel_provider);self.assertIsInstance(calls[0][1],Animation)
   self.assertEqual([x[0] for x in calls],['provider','stops','collect','send','nodes']);self.assertEqual(calls[1],('stops',False,False))
  finally:
   if old is None:sys.modules.pop('Math',None)
   else:sys.modules['Math']=old
 def test_world_contact_normal(self):
  calls=[]
  rt=Obj(ray_count=0,geometry=Obj(ray=lambda a,b,c:Obj(closestPoint=(0.,0.,0.),normal=(0.,1.,0.))))
  hit=G.contact(rt,(0.,1.,0.),(0.,-1.,0.));self.assertEqual(hit,((0.,0.,0.),(0.,1.,0.)));self.assertEqual(rt.ray_count,1)
 def test_rigid_sleep_requires_full_support(self):
  a=actor();a.rigid.contacts=1;a.rigid.b.v=ZERO;a.rigid.b.w=ZERO;a.rest_time=2.
  r=M.Runtime.__new__(M.Runtime);r.wake=lambda x:None
  self.assertFalse(r.can_sleep(a,1./60.))
if __name__=='__main__':unittest.main(verbosity=2)
