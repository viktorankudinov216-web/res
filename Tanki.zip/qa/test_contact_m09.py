# -*- coding: utf-8 -*-
from __future__ import print_function
import unittest,sys,math,types
import test_rigid_integration as I
from test_rigid146 import vehicle,flat,Wheel,Body,Vehicle,PARAMS
from trial146.physics_rigid146 import visual,layout
from trial146.physics_rigid146.math3 import *
Obj=I.Obj
class V4(tuple):
 def __new__(cls,*args):return tuple.__new__(cls,args)
class Animation(object):
 @property
 def value(self):return self.keyframes[0][1]
class Matrix(object):
 def __init__(self,value):self.translation=tuple(value.translation);self.inverse=False
 def invert(self):self.inverse=True
 def applyPoint(self,p):return sub(p,self.translation) if self.inverse else add(p,self.translation)
class MathMixin(object):
 def setUp(self):
  self.old_math=sys.modules.get('Math');sys.modules['Math']=Obj(Vector4=V4,Vector4Animation=Animation,Matrix=Matrix)
 def tearDown(self):
  if self.old_math is None:sys.modules.pop('Math',None)
  else:sys.modules['Math']=self.old_math
class DrivetrainTests(unittest.TestCase):
 def test_pivot_reaches_descriptor_rate(self):
  v=flat(vehicle(),seconds=2.);flat(v,flags=8,seconds=2.)
  self.assertGreater(v.b.w[1],.7*.8);self.assertLess(abs(v.b.w[1]-.7),.04);self.assertLess(length(v.b.v),.01)
 def test_grip_is_not_disabled_while_steering(self):
  v=flat(vehicle(),seconds=2.);v.b.v=(3.,0.,0.);flat(v,flags=8,seconds=.6)
  self.assertLess(abs(dot(v.b.v,rotate(v.b.q,(1.,0.,0.)))),.20)
 def test_yaw_brakes_without_engine_power_budget(self):
  v=flat(vehicle(),seconds=2.);flat(v,flags=8,seconds=2.);v.params['powerW']=0.
  flat(v,seconds=.4);self.assertLess(abs(v.b.w[1]),.08)
 def test_moving_turn_has_grip_not_drift(self):
  v=flat(vehicle(),seconds=2.);flat(v,flags=1,seconds=3.);flat(v,flags=9,seconds=3.)
  vf=dot(v.b.v,rotate(v.b.q,(0.,0.,1.)));vr=dot(v.b.v,rotate(v.b.q,(1.,0.,0.)))
  self.assertGreater(vf,3.);self.assertGreater(v.b.w[1],.35);self.assertLess(abs(math.atan2(vr,vf)),math.radians(4.))
 def test_track_path_uses_actual_carrier_gauge(self):
  v=flat(vehicle(),seconds=2.);flat(v,flags=8,seconds=2.)
  # Deliberately different descriptor trackCenter=2.6, actual carriers +/-1.2.
  self.assertAlmostEqual(v.tracks[0],v.b.w[1]*1.2,delta=.06)
  self.assertAlmostEqual(v.tracks[1],-v.b.w[1]*1.2,delta=.06)
 def test_left_right_symmetry(self):
  a=flat(vehicle(),seconds=2.);b=flat(vehicle(),seconds=2.)
  flat(a,flags=9,seconds=2.);flat(b,flags=5,seconds=2.)
  self.assertAlmostEqual(a.b.w[1],-b.b.w[1],delta=.01);self.assertAlmostEqual(a.b.v[2],b.b.v[2],delta=.02)
 def test_total_engine_effort_is_not_duplicated(self):
  v=flat(vehicle(),seconds=2.);flat(v,flags=9,seconds=.2)
  lateral,longitudinal,torque=v.grip_force
  gauge=1.2;vf=dot(v.b.v,rotate(v.b.q,(0.,0.,1.)))
  from trial146.physics_rigid146 import grip0922
  cap=grip0922.steering_effort(v.drive_params,vf,0.,sum(w.load for w in v.wheels))
  self.assertLessEqual(abs(longitudinal)+abs(torque)/gauge,cap*1.02)
 def test_airborne_has_no_ground_steering(self):
  v=vehicle(y=100.);flat(v,flags=9,seconds=.6,cliff=-1000.)
  self.assertAlmostEqual(v.b.w[1],0.);self.assertAlmostEqual(v.b.v[2],0.)
 def test_friction_limit_remains_finite_at_full_side_slip(self):
  v=flat(vehicle(),seconds=2.);v.b.v=(30.,0.,0.);flat(v,flags=9,seconds=.1)
  self.assertLessEqual(abs(v.grip_force[0]),sum(w.load for w in v.wheels)*v.grip_coefficients[1]*1.01)
class SuspensionTests(unittest.TestCase):
 def test_configured_spring_sag_is_mass_based(self):
  a=I.actor();w=a.rigid.wheels[0]
  self.assertAlmostEqual(w.mass*9.81/w.k,max(.07,min(.24,a.suspension['static_compression'])),places=5)
  sample=a.suspension['springs'][0];ratio=sample['damping']/(2.*math.sqrt(sample['stiffness']*sample['mass']))
  self.assertAlmostEqual(w.c/(2.*math.sqrt(w.k*w.mass)),max(1.20,min(1.65,ratio)),places=5)
 def test_new_springs_support_weight_at_loaded_model_height(self):
  a=I.actor()
  for i in range(360):a.step(1./60.,lambda *args:0.,None)
  self.assertLess(abs(a.position[1]),.015);self.assertLess(abs(a.rigid.b.v[1]),.01)
  self.assertAlmostEqual(sum(w.load for w in a.rigid.wheels)/(a.rigid.b.mass*9.81),1.,delta=.02)
 def test_one_track_step_creates_unequal_compression_and_roll(self):
  a=I.actor()
  for i in range(180):a.step(1./60.,lambda *args:0.,None)
  def step_ground(actor,x,z,*args):return .10 if x<0. else 0.
  for i in range(25):a.step(1./60.,step_ground,None)
  self.assertGreater(abs(a.body['roll']),.015)
  self.assertGreater(max(w.compression for w in a.rigid.wheels)-min(w.compression for w in a.rigid.wheels),.001)
 def test_landing_damps_without_pose_oscillator(self):
  a=I.actor();a.rigid.b.p=add(a.rigid.b.p,(0.,1.3,0.));peak=0.
  for i in range(480):
   a.step(1./60.,lambda *args:0.,None);peak=max(peak,max(w.compression for w in a.rigid.wheels))
  self.assertGreater(peak,.08);self.assertLess(abs(a.position[1]),.02);self.assertLess(length(a.rigid.b.v),.02)
 def test_wall_force_compresses_front_rear_differently(self):
  a=I.actor()
  for i in range(120):a.step(1./60.,lambda *args:0.,None)
  a.flags=1;a.rigid_hull=lambda a,dt:[((0.,0.,3.05),(0.,0.,-1.),0)]
  for i in range(90):a.step(1./60.,lambda *args:0.,None)
  self.assertGreater(max(w.compression for w in a.rigid.wheels)-min(w.compression for w in a.rigid.wheels),.003)
 def test_independent_turret_shape_preserves_hull_inertia(self):
  b=vehicle().b;before=b.inertia;b.add_shape((-3.,0.,-1.),(3.,1.,1.),(0.,2.,0.))
  self.assertEqual(b.inertia,before);self.assertEqual(b.lo[0],-1.5);self.assertLess(b.support((1.,0.,0.))[0],b.support((1.,0.,0.),0)[0])
class AnimationTests(MathMixin,unittest.TestCase):
 def test_binding_owns_distance_provider_and_clears_stop_bits(self):
  calls=[];a=I.actor()
  anim=Obj(scrollLinksRequired=True,setMovementInfo=lambda p:calls.append(('provider',p)),stopAnimatingWheels=lambda l,r:calls.append(('stops',l,r)))
  tracks=Obj(collectConnectedWheels=lambda p:calls.append(('collect',p)),sendWheelScrollLinks=lambda p:calls.append(('send',p)))
  nodes=Obj(setWheelsDataProvider=lambda p:calls.append(('nodes',p)))
  v=Obj(typeDescriptor=Obj(type=Obj(isWheeledVehicle=False)),appearance=Obj(wheelsAnimator=anim,tracks=tracks,trackNodesAnimator=nodes))
  visual.bind(v,a,lambda *args,**kw:None)
  self.assertIs(calls[0][1],a._rigid_wheel_provider);self.assertIsInstance(calls[0][1],Animation)
  self.assertEqual(calls[1],('stops',False,False));self.assertEqual([c[0] for c in calls],['provider','stops','collect','send','nodes'])
 def test_distance_integral_independent_of_render_rate(self):
  for fps in (30,60,120):
   total=[0.,0.]
   for i in range(fps*2):
    value=visual.frame_value(6.,-3.,1./fps);total[0]+=value[1];total[1]+=value[2]
   self.assertAlmostEqual(total[0],12.);self.assertAlmostEqual(total[1],-6.)
 def test_native_yz_are_distance_not_speed(self):
  self.assertEqual(visual.frame_value(6.,-3.,1./60.),(.025,.1,-.05,0.))
 def test_drive_duplicate_frame_not_integrated_twice(self):
  a=I.actor();a._rigid_wheel_provider=Animation();a._rigid_wheel_total=[0.,0.];a.track_speeds=(6.,3.)
  visual.drive(Obj(appearance=Obj(wheelsAnimator=Obj(stopAnimatingWheels=lambda *args:None))),a,0.);visual.drive(Obj(appearance=Obj(wheelsAnimator=Obj(stopAnimatingWheels=lambda *args:None))),a,1./60.);visual.drive(Obj(appearance=Obj(wheelsAnimator=Obj(stopAnimatingWheels=lambda *args:None))),a,1./60.)
  self.assertAlmostEqual(a._rigid_wheel_total[0],.1);self.assertAlmostEqual(a._rigid_wheel_total[1],.05)
 def test_death_and_end_stop_native_input(self):
  a=I.actor();a._rigid_wheel_provider=Animation();a._rigid_wheel_total=[0.,0.];a.track_speeds=(6.,3.)
  visual.drive(Obj(appearance=Obj(wheelsAnimator=Obj(stopAnimatingWheels=lambda *args:None))),a,0.);visual.drive(Obj(appearance=Obj(wheelsAnimator=Obj(stopAnimatingWheels=lambda *args:None))),a,.1,False);self.assertEqual(a._rigid_wheel_value,(0.,0.,0.,0.))
  a.health=0;visual.drive(Obj(appearance=Obj(wheelsAnimator=Obj(stopAnimatingWheels=lambda *args:None))),a,.2);self.assertEqual(a._rigid_wheel_value,(0.,0.,0.,0.))
class LayoutTests(MathMixin,unittest.TestCase):
 def objects(self):
  groups=[Obj(template=t,startIndex=0,count=6,isLeft=l,radius=.35) for t,l in (('L',True),('R',False))]
  ground=[Obj(affectedWheelsTemplate=t,startIndex=0,nodesCount=6) for t in ('L','R')]
  positions=dict((t+str(i),Obj(translation=(100.+x,10.+.35,200.+(i-2.5)*.8))) for t,x in (('L',-1.2),('R',1.2)) for i in range(6))
  positions['upper']=Obj(translation=(100.,13.,200.))
  wheels=Obj(groups=groups,wheels=[Obj(nodeName='upper',isLeft=True,radius=.15,isLeading=False)])
  descriptor=Obj(chassis=Obj(wheels=wheels,groundNodes=Obj(groups=ground,nodes=[])))
  model=Obj(matrix=Obj(translation=(100.,10.,200.)),node=lambda name:positions.get(name))
  vehicle=Obj(matrix=Obj(translation=(0.,0.,0.)),appearance=Obj(compoundModel=model))
  return descriptor,vehicle,positions
 def test_compound_root_not_stale_vehicle_root(self):
  d,v,p=self.objects();rows,detail=layout.collect(d,v,dict(width=3.,length=6.,clearance=.3))
  self.assertEqual(len(rows),12);self.assertEqual(detail['accepted_count'],12);self.assertAlmostEqual(rows[0][0],-1.2);self.assertAlmostEqual(rows[0][3],.35)
 def test_ground_nodes_exclude_upper_rollers(self):
  d,v,p=self.objects();rows,detail=layout.collect(d,v,dict(width=3.,length=6.,clearance=.3))
  self.assertNotIn('upper',[row[-1] for row in rows]);self.assertEqual(detail['selected_count'],12)
 def test_invalid_bones_report_reasons(self):
  d,v,p=self.objects();p['L0'].translation=(100.,1000.,200.)
  rows,detail=layout.collect(d,v,dict(width=3.,length=6.,clearance=.3));self.assertEqual(len(rows),11)
  self.assertEqual(detail['rejected'][0]['name'],'L0');self.assertEqual(detail['rejected'][0]['reason'],'upper roller')
 def test_missing_model_bones_explicit_fallback(self):
  d,v,p=self.objects();p.clear();rows,detail=layout.collect(d,v,dict(width=3.,length=6.,clearance=.3))
  self.assertEqual(rows,[]);self.assertEqual(detail['accepted_count'],0);self.assertEqual(detail['rejected'][0]['reason'],'node not found')
if __name__=='__main__':unittest.main(verbosity=2)
