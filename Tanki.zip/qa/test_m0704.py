# -*- coding: utf-8 -*-
from __future__ import print_function
import unittest,sys,types,os,math,json,time,subprocess
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'));P=ROOT+'/res_mods/1.46.0.0/scripts/client/gui/mods/hangar146'
pkg=types.ModuleType('trial146');pkg.__path__=[P];sys.modules['trial146']=pkg
from trial146 import combat_core146 as C,geometry146 as G,process_bridge146 as B
from trial146.legacy0922 import vehicle_physics as V

def actor(vid=1,team=1,hp=100,pos=(0.,0.,0.)):
 return C.Actor(vid,team,pos,0.,hp,{}, {},{},C.Magazine({1:20},1,1,8.44,0.))

def suspension():
 class Obj(object):
  def __init__(self,**kw):self.__dict__.update(kw)
 d=Obj(physics={'weight':30000.},chassis=Obj(name='test',hitTester=Obj(bbox=((-1.5,0.,-3.),(1.5,1.,3.))),hullPosition=(0.,.7,0.)),hull=Obj(hitTester=Obj(bbox=((-1.,0.,-2.5),(1.,1.5,2.5)))))
 old=V.derive_params;V.derive_params=lambda d:{'mass':30000.}
 try:return V.derive_suspension_params(d)
 finally:V.derive_params=old

class RoundTests(unittest.TestCase):
 def test_no_finish_with_both_teams(self):
  r=C.Round([actor(1,1),actor(2,2)]);r.now=4;r.check();self.assertIsNone(r.pending)
 def test_kill_starts_grace(self):
  r=C.Round([actor(1,1),actor(2,2)]);r.now=10;r.damage(2,1,100);r.check();self.assertIsNone(r.result);self.assertEqual(r.pending['deadline'],15.)
  r.now=14.99;r.check();self.assertIsNone(r.result);r.now=15;r.check();self.assertEqual(r.result,1)
 def test_kill_extends_and_double_ko_draw(self):
  r=C.Round([actor(1,1),actor(2,2)]);r.damage(2,1,100);r.check();r.now=4.;r.damage(1,2,100);r.check();self.assertEqual(r.pending['deadline'],9.);r.now=8.;r.check();self.assertIsNone(r.result);r.now=9.;r.check();self.assertEqual(r.result,0)
 def test_nonlethal_does_not_extend(self):
  r=C.Round([actor(1,1),actor(2,2)]);r.damage(2,1,100);r.check();r.now=4.;r.damage(1,2,1);r.check();self.assertEqual(r.pending['deadline'],5.)
 def test_dead_actor_no_repeat_kill(self):
  r=C.Round([actor(1,1),actor(2,2)]);r.damage(2,1,100);r.check();r.now=4.;r.damage(2,1,100);r.check();self.assertEqual(r.pending['deadline'],5.)
 def test_timeout_grace(self):
  r=C.Round([actor(1,1),actor(2,2)]);r.now=900.;r.check();self.assertEqual(r.pending['reason'],'timeout');self.assertIsNone(r.result);r.now=905.;r.check();self.assertEqual(r.result,0)
 def test_finished_damage_ignored(self):
  r=C.Round([actor(1,1),actor(2,2)]);r.finish(1,'manual');self.assertEqual(r.damage(1,2,100),0)
 def test_fixed_sixty(self):
  r=C.Round([actor(1,1),actor(2,2)]);steps=[]
  for i in range(30):r.advance(1./30.,lambda dt:steps.append(dt))
  self.assertEqual(len(steps),60);self.assertTrue(all(abs(x-1./60.)<1e-10 for x in steps))
 def test_catchup_bounded(self):
  r=C.Round([actor(1,1),actor(2,2)]);steps=[];r.advance(10.,lambda dt:steps.append(dt));self.assertEqual(len(steps),12);self.assertAlmostEqual(r.dropped_time,9.8)
 def test_capture_waits_five(self):
  r=C.Round([actor(1,1),actor(2,2,pos=(200.,0.,0.))]);r.configure_bases([(2,0,(0.,0.))]);r.capture_step(100.);r.now=100.;r.check();self.assertEqual(r.pending['reason'],'capture');self.assertIsNone(r.result);r.now=105.;r.check();self.assertEqual(r.result,1)
 def test_defender_blocks_capture(self):
  r=C.Round([actor(1,1),actor(2,2)]);r.configure_bases([(2,0,(0.,0.))]);r.capture_step(100.);self.assertEqual(r.bases[0]['points'],0.)
 def test_damage_resets_personal_capture(self):
  r=C.Round([actor(1,1),actor(2,2,pos=(200.,0.,0.))]);r.configure_bases([(2,0,(0.,0.))]);r.capture_step(50.);r.damage(1,2,1);r.capture_step(0.);self.assertEqual(r.bases[0]['points'],0.)
 def test_departure_resets_capture(self):
  r=C.Round([actor(1,1),actor(2,2,pos=(200.,0.,0.))]);r.configure_bases([(2,0,(0.,0.))]);r.capture_step(50.);r.actors[1].position=(100.,0.,0.);r.capture_step(0.);self.assertEqual(r.bases[0]['points'],0.)
 def test_capture_rate_capped_three(self):
  r=C.Round([actor(i,1) for i in range(1,6)]+[actor(6,2,pos=(200.,0.,0.))]);r.configure_bases([(2,0,(0.,0.))]);r.capture_step(10.);self.assertAlmostEqual(r.bases[0]['points'],30.)
 def test_magazine_effective_reload(self):
  m=C.Magazine({1:10},1,1,8.44,0.);self.assertTrue(m.fire(0.));self.assertFalse(m.can_fire(8.43));self.assertTrue(m.can_fire(8.44))

class GeometryTests(unittest.TestCase):
 def test_valid_payload(self):
  h=G.decode((True,(0.,0.,0.),(0.,1.,0.),7,'terrain'),(0.,1.,0.),(0.,-1.,0.));self.assertEqual(h.matKind,7)
 def test_no_collision_flag(self):self.assertIsNone(G.decode((False,(0.,0.,0.),(0.,0.,0.),0,''),(0.,1.,0.),(0.,-1.,0.)))
 def test_reject_legacy_seven(self):
  with self.assertRaises(ValueError):G.decode((True,0,0,0,0,0,0),(0,0,0),(0,1,0))
 def test_reject_nonfinite(self):
  with self.assertRaises(ValueError):G.decode((True,(0.,float('nan'),0.),(0.,1.,0.),0,''),(0,1,0),(0,-1,0))
 def test_reject_off_ray(self):
  with self.assertRaises(ValueError):G.decode((True,(1.,0.,0.),(0.,1.,0.),0,''),(0,1,0),(0,-1,0))
 def test_reject_nonunit_normal(self):
  with self.assertRaises(ValueError):G.decode((True,(0.,0.,0.),(0.,0.,0.),0,''),(0,1,0),(0,-1,0))
 def test_ignore_policy_callback(self):
  g=G.Geometry(None);self.assertTrue(g.broken(12,7,71,'fence'));self.assertEqual(g.filtered_callbacks,1)

class SolverTests(unittest.TestCase):
 def test_ten_springs_twelve_contacts(self):
  p=suspension();self.assertEqual(len(p['springs']),10);self.assertEqual(len(p['pseudo_contacts']),12)
 def test_rest_state_finite(self):
  p=suspension();s=dict(height=0.,pitch=0.,roll=0.)
  for i in range(120):s=V.damper_suspension_step(p,s,[0.]*10,C.STEP,[0.]*12)
  self.assertTrue(all(not math.isnan(s[k]) and not math.isinf(s[k]) for k in ('height','pitch','roll')))
 def test_slope_rotates_body(self):
  p=suspension();heights=[-.15*a['z'] for a in p['springs']];pseudo=[-.15*a['z'] for a in p['pseudo_contacts']];s=dict(height=0.,pitch=0.,roll=0.)
  for i in range(120):s=V.damper_suspension_step(p,s,heights,C.STEP,pseudo)
  self.assertGreater(abs(s['pitch']),.02)

class BridgeTests(unittest.TestCase):
 def test_startup_failure_local_fallback(self):
  b=B.Bridge(ROOT,executable='/missing/python');self.assertIsNotNone(b.failed);self.assertFalse(b.ready)
 def test_protocol_rejects_nan(self):
  with self.assertRaises(ValueError):B.encode({'x':float('nan')})
 def test_engine_free_worker_contract(self):
  text=open(ROOT+'/mods/hangar146_helper/worker_main.py').read();self.assertNotIn('import BigWorld',text);self.assertIn('MAX_ACTORS=64',text)

class AdditionalRegressionTests(unittest.TestCase):
 def test_same_worker_snapshot_not_integrated_twice(self):
  a=actor();a.suspension=suspension();b=B.Bridge.__new__(B.Bridge)
  b.contact_rows={};b.initialized=set();b.states={a.id:dict(generation=0,body=dict(height=.1,pitch=.02,roll=0.))};b.ready=True;b.failed=None;b.received=time.time();b.stats={'steps':10}
  first=b.solve(a,a.body,[0.]*10,C.STEP,[0.]*12,0.)
  old=V.damper_suspension_step
  def forbidden(*args):raise AssertionError('Main-thread double spring step')
  V.damper_suspension_step=forbidden
  try:second=b.solve(a,first,[0.]*10,C.STEP,[0.]*12,0.)
  finally:V.damper_suspension_step=old
  self.assertEqual(first,second);self.assertTrue(a.solver_remote)
 def test_finish_freezes_drive(self):
  a=actor();a.v=5.;a.omega=1.;a.flags=9;r=C.Round([a,actor(2,2)]);r.finish(1,'annihilation');self.assertEqual((a.v,a.omega,a.flags),(0.,0.,0))

if __name__=='__main__':unittest.main(verbosity=2)
