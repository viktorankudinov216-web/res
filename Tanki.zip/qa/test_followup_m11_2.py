# -*- coding: utf-8 -*-
"""Regression tests for lifecycle and contact grip. NOT an in-game renderer test."""
from __future__ import print_function
import sys,math,ast,unittest,os
import test_rigid_integration as I
import test_suspension_m11 as S
import test_rigid146 as T
from trial146.physics_rigid146.math3 import *
from trial146.physics_rigid146 import native_tracks,visual
class GripTests(unittest.TestCase):
 def test_sustained_turn_no_one_substep_side_slide(self):
  for speed in (5.,10.,13.):
   for direction in (4,8):
    v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,0.,speed)
    for i in range(90):
     T.flat(v,flags=1|direction,seconds=1./60.)
     vr=dot(v.b.v,rotate(v.b.q,(1.,0.,0.)))
     self.assertLess(abs(vr),.02)
 def test_front_rear_scrub_brakes_released_turn(self):
  for speed in (0.,5.,10.,13.):
   v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,0.,speed)
   T.flat(v,flags=9 if speed else 8,seconds=1.5)
   yaw=euler(v.b.q)[0];T.flat(v,flags=1 if speed else 0,seconds=.2)
   self.assertLess(abs(v.b.w[1]),.02)
   self.assertLess(abs(euler(v.b.q)[0]-yaw),math.radians(4.))
 def test_reversing_turn_keeps_small_side_slip(self):
  v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,0.,10.)
  for direction in (8,4,8,4):
   for i in range(30):
    T.flat(v,flags=1|direction,seconds=1./60.)
    self.assertLess(abs(dot(v.b.v,rotate(v.b.q,(1.,0.,0.)))),.04)
    self.assertLess(abs(euler(v.b.q)[2]),math.radians(12.))
 def test_airborne_lateral_velocity_is_not_clamped(self):
  v=T.vehicle(y=100.);v.b.v=(3.,0.,7.);T.flat(v,flags=9,seconds=.5,cliff=-1000.)
  self.assertAlmostEqual(v.b.v[0],3.,delta=.02)
 def test_short_wide_and_tall_tanks_finite(self):
  for com in (.65,1.,1.7):
   v=T.vehicle();v.b.com=(0.,com,0.);v.b.p=(0.,com,0.);T.flat(v,seconds=3.);v.b.v=(0.,0.,10.)
   T.flat(v,flags=9,seconds=2.);T.flat(v,flags=1,seconds=.3)
   self.assertLess(abs(v.b.w[1]),.03)
   self.assertGreater(rotate(v.b.q,(0.,1.,0.))[1],.9)
class OwnershipTests(unittest.TestCase):
 def test_no_active_ground_clear_in_native_path(self):
  tree=ast.parse(open(I.F.P+'/physics_rigid146/native_tracks.py').read())
  self.assertFalse(any(isinstance(n,ast.Attribute) and n.attr=='removeGroundNodes' for n in ast.walk(tree)))
 def test_native_replacement_only_in_bind_not_tick(self):
  tree=ast.parse(open(I.F.P+'/physics_rigid146/native_tracks.py').read());tick=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='tick')
  self.assertFalse(any(isinstance(n,ast.Attribute) and n.attr in ('createComponent','removeComponent','addGroundNode','addGroundNodesGroup') for n in ast.walk(tick)))
 def test_hull_decoration_detach_is_reasserted_after_stock_rebind(self):
  import types
  saved={k:sys.modules.get(k) for k in ('Math','vehicle_systems','vehicle_systems.tankStructure')}
  try:
   class Animation(object):pass
   sys.modules['Math']=I.Obj(Vector4=lambda *v:v,Vector4Animation=Animation)
   sys.modules['vehicle_systems']=I.Obj();sys.modules['vehicle_systems.tankStructure']=I.Obj(TankPartNames=I.Obj(HULL='Hull'))
   a=I.actor();a._rigid_wheel_provider=Animation();a._rigid_wheel_total=[0.,0.];a._rigid_hull_basis=object();calls=[]
   model=I.Obj(node=lambda *args:calls.append(args))
   app=I.Obj(compoundModel=model,wheelsAnimator=I.Obj(stopAnimatingWheels=lambda *args:None),suspension=None)
   v=I.Obj(appearance=app)
   visual.drive(v,a,1.);visual.drive(v,a,1.02)
   self.assertEqual(calls,[('Hull',a._rigid_hull_basis),('Hull',a._rigid_hull_basis)])
  finally:
   for k,v in saved.items():
    if v is None:sys.modules.pop(k,None)
    else:sys.modules[k]=v
if __name__=='__main__':unittest.main(verbosity=2)
