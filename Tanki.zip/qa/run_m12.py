# -*- coding: utf-8 -*-
"""Run portable regression tests with Python 3; game uses its own Python 2.
Only the TEST PROCESS receives the removed time.clock compatibility alias.
No BigWorld emulation here can certify native rendering/ABI in a client.
"""
from __future__ import print_function
import os,sys,time,unittest,ast
try:import builtins
except ImportError:import __builtin__ as builtins
original_compile=builtins.compile
def portable_compile(source,filename,mode,*args,**kwargs):
 if isinstance(source,ast.Module) and not hasattr(source,'type_ignores'):source.type_ignores=[]
 return original_compile(source,filename,mode,*args,**kwargs)
builtins.compile=portable_compile
if not hasattr(time,'clock'):time.clock=time.perf_counter
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
if __name__=='__main__':
 suite=unittest.defaultTestLoader.discover(os.path.dirname(__file__),'test_*.py')
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 sys.exit(0 if result.wasSuccessful() else 1)
