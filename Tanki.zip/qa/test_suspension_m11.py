# -*- coding: utf-8 -*-
"""M11 offline numerical and scene-provider tests. Not a game/render test."""
from __future__ import print_function
import sys,unittest,math,types,os,json
import test_rigid_integration as I
import test_rigid146 as T
from trial146.physics_rigid146 import visual,wheel_scene
from trial146.physics_rigid146.math3 import *
Obj=I.Obj
class NumericalTests(unittest.TestCase):
 def test_handbrake_36kph_does_not_somersault(self):
  v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,0.,10.);peak=0.
  for i in range(240):
   T.flat(v,flags=64,seconds=1./60.);peak=max(peak,abs(euler(v.b.q)[1]))
  self.assertLess(peak,math.radians(15.));self.assertGreater(rotate(v.b.q,(0.,1.,0.))[1],.95)
  self.assertLess(abs(v.b.v[2]),.05)
 def test_handbrake_turn_36kph_not_a_rollover(self):
  v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,0.,10.);peak=0.
  for i in range(180):
   T.flat(v,flags=64|4,seconds=1./60.);peak=max(peak,abs(euler(v.b.q)[1]),abs(euler(v.b.q)[2]))
  self.assertLess(peak,math.radians(23.))
 def test_turn_at_36kph_reaches_rate_and_holds_side_grip(self):
  v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,0.,10.)
  T.flat(v,flags=9,seconds=.6)
  self.assertGreater(v.b.w[1],.50)
  f=rotate(v.b.q,(0.,0.,1.));r=rotate(v.b.q,(1.,0.,0.))
  self.assertLess(abs(math.atan2(dot(v.b.v,r),dot(v.b.v,f))),math.radians(4.))
 def test_releasing_pivot_has_no_yaw_coast(self):
  v=T.flat(T.vehicle(),seconds=3.);T.flat(v,flags=8,seconds=1.);start=euler(v.b.q)[0]
  T.flat(v,seconds=.2)
  self.assertLess(abs(v.b.w[1]),.015);self.assertLess(abs(euler(v.b.q)[0]-start),math.radians(3.2))
 def test_acceleration_not_delayed_by_brake_smoothing(self):
  v=T.flat(T.vehicle(),seconds=3.);T.flat(v,flags=1,seconds=.3)
  self.assertGreater(v.b.v[2],.7)
 def test_reverse_then_release_has_no_force_creep(self):
  v=T.flat(T.vehicle(),seconds=3.);T.flat(v,flags=1,seconds=2.);T.flat(v,flags=2,seconds=3.)
  T.flat(v,seconds=1.);origin=v.b.origin();T.flat(v,seconds=2.)
  self.assertLess(length(sub(v.b.origin(),origin)),.025)
 def test_rebound_preserves_geometric_compression_even_zero_load(self):
  v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,5.,0.)
  T.flat(v,seconds=1./60.)
  self.assertTrue(any(w.compression>0. and w.load==0. for w in v.wheels))
 def test_offcentre_cupola_support_tips_under_gravity(self):
  v=T.vehicle(roll=math.pi);b=v.b
  b.add_shape((-1.,0.,-1.),(1.,1.5,1.),(0.,2.,0.))
  b.clouds[1]=[(-1.,.0,-1.),(1.,.0,1.),(-.8,1.,-.8),(.8,1.,.8),(.65,1.5,.1),(.70,1.5,.1),(.70,1.5,.2)]
  b.p=add(b.p,(0.,-b.support((0.,1.,0.))[1],0.))
  self.assertGreater(abs(b.support((0.,1.,0.),1)[0]-b.p[0]),.5)
  for i in range(30):v.tick(1./60.,0,[None]*len(v.wheels),[((0.,0.,0.),(0.,1.,0.),1)])
  self.assertGreater(abs(b.w[2]),.1)
 def test_wheel_offset_is_strut_travel_not_speed_or_fake_pitch(self):
  w=T.vehicle().wheels[0];sag=w.mass*9.81/w.k
  w.compression=sag;self.assertAlmostEqual(wheel_scene.physical_offset(w),0.)
  w.compression=sag+.08;self.assertAlmostEqual(wheel_scene.physical_offset(w),.08)
  w.compression=0.;self.assertAlmostEqual(wheel_scene.physical_offset(w),-sag)
class AnimationTests(unittest.TestCase):
 def setUp(self):
  self.old=sys.modules.get('Math');self.stops=[]
  class Anim(object):pass
  sys.modules['Math']=Obj(Vector4=lambda *v:v,Vector4Animation=Anim)
  self.a=I.actor();self.a._rigid_wheel_provider=Anim();self.a._rigid_wheel_total=[0.,0.]
  suspension=Obj(stopAnimating=lambda *v:self.stops.append(('susp',v)),forceCorrectionRecalculation=lambda:(_ for _ in ()).throw(AssertionError('Expensive reset per-frame')))
  self.v=Obj(appearance=Obj(wheelsAnimator=Obj(stopAnimatingWheels=lambda *v:self.stops.append(('wheel',v))),suspension=suspension))
 def tearDown(self):
  if self.old is None:sys.modules.pop('Math',None)
  else:sys.modules['Math']=self.old
 def test_reverse_resume_resets_both_independent_stop_masks(self):
  for now,speed in ((0.,5.),(.1,5.),(.2,0.),(.3,-3.),(.4,4.)):
   self.a.track_speeds=(speed,speed);visual.drive(self.v,self.a,now)
   self.assertEqual(self.stops[-2:],[('wheel',(False,False)),('susp',(False,False))])
   if now:self.assertAlmostEqual(self.a._rigid_wheel_value[1],speed*.1)
 def test_dead_model_receives_no_native_animator_calls(self):
  self.a.health=0;visual.drive(self.v,self.a,1.);self.assertEqual(self.stops,[])
 def test_duplicate_frame_does_not_repeat_provider_or_native_calls(self):
  visual.drive(self.v,self.a,1.);visual.drive(self.v,self.a,1.)
  self.assertEqual(len(self.stops),2)
class DiagnosticTests(unittest.TestCase):
 def test_periodic_state_excludes_static_layout_and_spring_constants(self):
  a=I.actor();small=a.diagnostics();full=a.diagnostics(full=True)
  for k in ('layout_detail','spring_k','spring_c','spring_travel'):
   self.assertNotIn(k,small);self.assertIn(k,full)
  self.assertLess(len(json.dumps(small)),2500)

# A row-vector affine Matrix/MatrixProduct mock with live provider evaluation.
# It exercises composition, mirrored parents, native freeze and native motion.
class Vec(tuple):
 def __new__(cls,*v):return tuple.__new__(cls,v)
 x=property(lambda s:s[0]);y=property(lambda s:s[1]);z=property(lambda s:s[2])
class Mat(object):
 def __init__(self,value=None):
  if value is None:self.setIdentity()
  else:self.rows=[list(row) for row in evaluate(value)]
 def setIdentity(self):self.rows=[[float(i==j) for j in range(4)] for i in range(4)]
 @property
 def translation(self):return Vec(*self.rows[3][:3])
 @translation.setter
 def translation(self,v):self.rows[3][:3]=v
 def applyPoint(self,v):return Vec(*(sum(v[k]*self.rows[k][j] for k in range(3))+self.rows[3][j] for j in range(3)))
 def applyVector(self,v):return Vec(*(sum(v[k]*self.rows[k][j] for k in range(3)) for j in range(3)))
 def applyToAxis(self,i):return Vec(*self.rows[i][:3])
 def invert(self):
  old=self.rows;out=[[old[j][i] for j in range(3)]+[0.] for i in range(3)]
  out.append([-sum(old[3][k]*out[k][j] for k in range(3)) for j in range(3)]+[1.]);self.rows=out
 def setRotateX(self,a):
  self.setIdentity();self.rows[1][1]=self.rows[2][2]=math.cos(a);self.rows[1][2]=math.sin(a);self.rows[2][1]=-math.sin(a)
class Product(object):pass
class Node(object):
 def __init__(self,model,local):self.model=model;self.source=local;self.bound=None
 @property
 def localMatrix(self):return self.source
 @property
 def rows(self):return matmul(evaluate(self.bound or self.source),evaluate(self.model.matrix))
class Model(object):
 def __init__(self,rows):self.matrix=Mat();self.nodes=dict((name,Node(self,local)) for name,local in rows.items())
 def node(self,name,provider=None):
  node=self.nodes.get(name)
  if node is not None and provider is not None:node.bound=provider
  return node

def matmul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
def evaluate(value):
 if isinstance(value,Product):return matmul(evaluate(value.a),evaluate(value.b))
 return value.rows
class SceneTests(unittest.TestCase):
 def setUp(self):
  self.old=sys.modules.get('Math');sys.modules['Math']=Obj(Matrix=Mat,MatrixProduct=Product,Vector3=Vec)
  self.a=I.actor();self.a.rigid.wheels=self.a.rigid.wheels[:1];w=self.a.rigid.wheels[0];w.name='L0';w.radius=.4;w.side='left';w.compression=w.mass*9.81/w.k
  self.local=Mat();self.local.translation=(0.,.4,0.);self.model=Model({'L0':self.local})
  d=Obj(chassis=Obj(groundNodes=Obj(groups=[],nodes=[])))
  self.v=Obj(typeDescriptor=d,appearance=Obj(compoundModel=self.model));wheel_scene.attach(self.v,self.a)
 def tearDown(self):
  if self.old is None:sys.modules.pop('Math',None)
  else:sys.modules['Math']=self.old
 def pose(self):return Mat(self.model.node('L0'))
 def angle(self):
  axis=self.pose().applyToAxis(1);return math.atan2(axis.z,axis.y)
 def test_frozen_native_rotates_from_measured_distance(self):
  wheel_scene.update(self.a,(0.,.2,.2,0.));self.assertAlmostEqual(self.angle(),.5)
  wheel_scene.update(self.a,(0.,-.4,-.4,0.));self.assertAlmostEqual(self.angle(),-.5)
 def test_native_rotation_is_not_double_applied(self):
  self.local.setRotateX(.5);self.local.translation=(0.,.4,0.)
  wheel_scene.update(self.a,(0.,.2,.2,0.));self.assertAlmostEqual(self.angle(),.5)
 def test_spring_moves_visible_wheel_without_hull_pitch(self):
  self.a.rigid.wheels[0].compression+=.08;wheel_scene.update(self.a)
  self.assertAlmostEqual(self.pose().translation.y,.48);self.assertEqual(self.model.matrix.translation,(0.,0.,0.))
 def test_native_travel_is_not_double_applied(self):
  self.local.translation=(0.,.44,0.);self.a.rigid.wheels[0].compression+=.08
  wheel_scene.update(self.a);self.assertAlmostEqual(self.pose().translation.y,.48)
 def test_repeated_updates_do_not_accumulate_translation(self):
  self.a.rigid.wheels[0].compression+=.06
  for i in range(300):wheel_scene.update(self.a)
  self.assertAlmostEqual(self.pose().translation.y,.46)
 def test_rotation_and_travel_continue_together_after_reversing(self):
  for i in range(50):
   self.a.rigid.wheels[0].compression=self.a.rigid.wheels[0].mass*9.81/self.a.rigid.wheels[0].k+.03*math.sin(i)
   path=.02 if i<20 else -.03
   wheel_scene.update(self.a,(0.,path,path,0.))
  self.assertAlmostEqual(self.angle(),(20*.02-30*.03)/.4)
  self.assertAlmostEqual(self.pose().translation.y,.4+.03*math.sin(49))
 def test_attach_twice_does_not_nest_providers(self):
  old=self.model.node('L0').bound;wheel_scene.attach(self.v,self.a)
  self.assertIs(self.model.node('L0').bound,old)


class HullBindingTests(unittest.TestCase):
 def test_hull_basis_replaces_swing_output_and_suspension_is_resumed(self):
  saved={k:sys.modules.get(k) for k in ('Math','vehicle_systems','vehicle_systems.tankStructure')}
  calls=[]
  try:
   class Animation(object):pass
   sys.modules['Math']=Obj(Matrix=Mat,Vector4Animation=Animation,Vector4=lambda *v:v)
   sys.modules['vehicle_systems']=types.ModuleType('vehicle_systems')
   sys.modules['vehicle_systems.tankStructure']=Obj(TankPartNames=Obj(HULL='actual_hull_name'))
   model=Model({'actual_hull_name':Mat()});swing=Obj(basisMatrix=Mat(),accelSwingingPeriod=5.)
   app=Obj(compoundModel=model,swingingAnimator=swing,wheelsAnimator=Obj(setMovementInfo=lambda p:None,stopAnimatingWheels=lambda *v:None,scrollLinksRequired=False))
   app.suspension=Obj(reattachCompound=lambda m:calls.append('reattach'),setCollisionObstaclesCollector=lambda c:calls.append('collector'),stopAnimating=lambda *v:calls.append(v),forceCorrectionRecalculation=lambda:calls.append('dirty'))
   app.collisionObstaclesCollector=Obj()
   a=I.actor();v=Obj(appearance=app,typeDescriptor=Obj(type=Obj(isWheeledVehicle=False)))
   visual.bind(v,a,lambda *v,**kw:None)
   self.assertTrue(a._rigid_hull_detached);self.assertIsInstance(model.node('actual_hull_name').bound,Mat)
   self.assertEqual(swing.accelSwingingPeriod,0.)
   self.assertEqual(calls,['reattach','collector',(False,False),'dirty'])
  finally:
   for k,v in saved.items():
    if v is None:sys.modules.pop(k,None)
    else:sys.modules[k]=v

if __name__=='__main__':unittest.main(verbosity=2)
