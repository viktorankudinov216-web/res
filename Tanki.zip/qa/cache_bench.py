# Synthetic cache throughput only, NOT game FPS or native raycast timings.
from __future__ import print_function
import sys,os,time,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import test_m0704
from trial146.contact_cache146 import Bank
path=os.environ.get('H146_NATIVE_TEST_LIB')
results=[]
for count in (4,30):
 b=Bank(path) if path else Bank('/unavailable');calls=[0];started=time.time();frames=600
 def cast(x,z,*unused):calls[0]+=1;return .02*x+.01*z
 for frame in range(frames):
  now=frame/60.
  for actor in range(count):
   for offset,n in ((0,10),(10,12)):
    req=[(actor*10.+i*.05+now*.1,0.,-1.,10.,None) for i in range(n)]
    b.batch(actor+1,offset,req,now,1./30. if actor==0 else 1./15.,.25,.02,.01,1.,cast)
 results.append(dict(actors=count,frames=frames,native=b.native is not None,synthetic_exact_queries=calls[0],uncached_queries=count*22*frames,hits=b.hits,wall_ms=(time.time()-started)*1000.))
print(json.dumps(results,indent=2))
