from __future__ import print_function
import sys,os,types,ast,unittest,traceback
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import test_m0704 as F
class Obj(object):
 def __init__(self,**kw):self.__dict__.update(kw)
class AvatarLoadingTests(unittest.TestCase):
 def run_create(self,bot_count,actual_count):
  saved={};marks=[];failures=[]
  def module(name,**kwargs):
   saved[name]=sys.modules.get(name);m=types.ModuleType(name);m.__dict__.update(kwargs);sys.modules[name]=m;return m
  arena=None if actual_count is None else Obj(vehicles=dict((i,{}) for i in range(actual_count)))
  avatar=Obj(arena=arena,_hangar146_become_complete=True,_hangar146_arena_load_ctrl=Obj(invalidateArenaInfo=lambda:marks.append('invalidated')))
  module('BigWorld',createSpace=lambda:5,createEntity=lambda *a:7,entities={7:avatar},player=lambda a:None,callback=lambda *a:None)
  module('constants',ARENA_BONUS_TYPE=Obj(REGULAR=1),ARENA_GUI_TYPE=Obj(RANDOM=1))
  module('trial146._constants',OFFLINE_DBID=1,OFFLINE_NICKNAME='Local')
  module('helpers',dependency=Obj(instance=lambda t:Obj(getDefBattleApp=lambda:object())))
  module('skeletons');module('skeletons.gui');module('skeletons.gui.app_loader',IAppLoader=object)
  module('gui');module('gui.app_loader',spaces=Obj())
  # Parse only the function under test: unrelated hooks contain valid Python 2 raise syntax.
  with open(F.P+'/native_match.py') as f:source=f.read()
  start=source.index('\ndef create_avatar(')+1;end=source.find('\ndef ',start+1)
  tree=ast.parse(source[start:end if end>=0 else len(source)]);fn=tree.body[0]
  ns={'__name__':'trial146.loading_test','__package__':'trial146','_GENERATION':3,'_PLAN':dict(roundID=1,arenaTypeID=2,bots=[{}]*bot_count),'mark':lambda stage,**kw:marks.append(stage),'fail':lambda stage:failures.append((stage,traceback.format_exc())),'world_enabled':lambda:True,'local_avatar':lambda a:True}
  try:
   exec(compile(ast.Module(body=[fn]),'<actual create_avatar>','exec'),ns);ns['create_avatar'](3)
   return marks,failures
  finally:
   for k,v in saved.items():
    if v is None:sys.modules.pop(k,None)
    else:sys.modules[k]=v
 def test_duel_roster_reaches_native_loading(self):
  marks,failures=self.run_create(1,2);self.assertFalse(failures,failures);self.assertIn('native_loading_requested',marks)
 def test_four_actor_roster_is_still_valid_for_four_actor_plan(self):
  marks,failures=self.run_create(3,4);self.assertFalse(failures,failures);self.assertIn('native_loading_requested',marks)
 def test_incomplete_duel_roster_is_rejected(self):
  marks,failures=self.run_create(1,1);self.assertTrue(failures);self.assertIn('Native arena roster was not installed',failures[0][1]);self.assertNotIn('native_loading_requested',marks)
 def test_missing_arena_is_rejected(self):
  marks,failures=self.run_create(1,None);self.assertTrue(failures);self.assertNotIn('native_loading_requested',marks)
if __name__=='__main__':unittest.main(verbosity=2)
