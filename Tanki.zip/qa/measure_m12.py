from __future__ import print_function
import sys,json,math,os
root=sys.argv[1] if len(sys.argv)>1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,os.path.join(root,'qa'))
import test_rigid146 as T
from trial146.physics_rigid146.math3 import *
result={}
for drop in (.4,1.5,3.):
 v=T.vehicle(y=drop);land=None;peak=0.;minimum=drop;lastair=False;max_second_flight=0.;second_start=None
 for i in range(360):
  T.flat(v,seconds=1./60.);y=v.b.origin()[1]
  if v.contacts and land is None:land=i
  if land is not None:
   minimum=min(minimum,y);peak=max(peak,v.b.v[1])
   if v.contacts==0:
    if second_start is None:second_start=y
    max_second_flight=max(max_second_flight,y-second_start)
   else:second_start=None
 result[str(drop)]={'first_contact_s':land/60.,'minimum_root_y_m':minimum,'peak_up_m_s':peak,'second_flight_rise_m':max_second_flight,'final_root_y_m':y}
print(json.dumps(result,indent=2))
