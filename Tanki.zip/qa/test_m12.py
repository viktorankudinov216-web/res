# -*- coding: utf-8 -*-
"""M12 engine-free regression. Matrix mocks are NOT client-render validation."""
from __future__ import print_function
import unittest,math,sys
import test_rigid146 as T
import test_rigid_integration as I
import test_suspension_m11 as S
from trial146.physics_rigid146 import wheel_scene,native_tracks
from trial146.physics_rigid146.math3 import *

class ContactTests(unittest.TestCase):
 def test_hard_landings_do_not_launch_a_second_jump(self):
  for height in (.4,1.5,3.):
   v=T.vehicle(y=height);landed=False;peak_up=0.;late_height=-100.
   for i in range(360):
    T.flat(v,seconds=1./60.)
    if v.contacts:landed=True
    if landed:
     peak_up=max(peak_up,v.b.v[1])
     if i>100:late_height=max(late_height,v.b.origin()[1])
   self.assertLess(peak_up,.85)
   self.assertLess(late_height,.04)
   self.assertLess(length(v.b.v),.03)
 def test_one_stone_moves_one_strut_then_the_body(self):
  v=T.flat(T.vehicle(),seconds=3.);q=v.b.q;origin=v.b.origin()
  for i in range(90):
   hits=[]
   for j,w in enumerate(v.wheels):
    a,c=w.ray(v.b);y=.10 if j==0 else 0.
    hits.append(((a[0],y,a[2]),(0.,1.,0.)))
   v.tick(1./60.,0,hits,[])
  self.assertGreater(v.wheels[0].compression-v.wheels[1].compression,.035)
  self.assertGreater(length(sub(v.b.origin(),origin)),.002)
  self.assertGreater(length(sub(rotate(v.b.q,(0.,1.,0.)),rotate(q,(0.,1.,0.)))),.002)
 def test_lateral_adhesion_in_fast_turn_and_counterbraking(self):
  for speed in (10.,15.,22.):
   for flags in (9,5,10,6,64|8):
    v=T.flat(T.vehicle(),seconds=2.);v.params['speedFwd']=25.;v.b.v=(0.,0.,speed)
    worst=0.
    for i in range(100):
     T.flat(v,flags=flags,seconds=1./60.)
     if i>10:worst=max(worst,abs(dot(v.b.v,rotate(v.b.q,(1.,0.,0.)))))
    self.assertLess(worst,.18)
    self.assertGreater(rotate(v.b.q,(0.,1.,0.))[1],.9)
 def test_loaded_pad_geometry_agrees_with_wheel_center(self):
  a=I.actor();v=a.rigid
  # Nonzero bottom rim from the provided Waffentrager model (~7 cm).
  for w in v.wheels:
   w.reference_y=.566;w.radius=.495;w.support_radius=.566
   w.rest=w.local[1]-.566+w.mass*9.81/w.k
  for i in range(240):a.step(1./60.,lambda *args:0.,lambda *args:True)
  for w in v.wheels:
   rendered=w.reference_y+wheel_scene.physical_offset(w)
   physical=w.local[1]-w.rest+w.compression
   self.assertAlmostEqual(rendered,physical,places=8)
  self.assertLess(abs(v.b.origin()[1]),.02)
 def test_no_contact_retains_lateral_momentum_and_spin(self):
  v=T.vehicle(y=30.);v.b.v=(4.,0.,8.);v.b.w=(.2,.3,.1)
  for i in range(30):v.tick(1./60.,9,[None]*len(v.wheels),[])
  self.assertAlmostEqual(v.b.v[0],4.,delta=.03)
  self.assertGreater(length(v.b.w),.30)

class SceneTests(S.SceneTests):
 def test_native_longitudinal_drift_is_cancelled(self):
  self.local.translation=(.03,.47,.29)
  w=self.a.rigid.wheels[0];w.compression=w.mass*9.81/w.k+.06
  wheel_scene.update(self.a)
  self.assertAlmostEqual(self.pose().translation.x,0.)
  self.assertAlmostEqual(self.pose().translation.z,0.)
  self.assertAlmostEqual(self.pose().translation.y,.46)
 def test_independent_carriers_and_ground_nodes_use_same_stroke(self):
  w=self.a.rigid.wheels[0]
  n=S.Mat();n.translation=(0.,0.,0.)
  self.model.nodes['ground']=S.Node(self.model,n)
  self.v.typeDescriptor.chassis.groundNodes.nodes=[I.Obj(nodeName='ground',affectedWheelName='L0')]
  self.a._wheel_scene=[];wheel_scene.attach(self.v,self.a)
  w.compression=w.mass*9.81/w.k+.07;wheel_scene.update(self.a)
  self.assertAlmostEqual(S.Mat(self.model.node('ground')).translation.y,.07)
  self.assertAlmostEqual(self.pose().translation.y,.47)
 def test_model_reference_cancels_native_motion_of_parent_and_node(self):
  w=self.a.rigid.wheels[0];w.local=(0.,.7,0.);w.reference_y=.4
  self.a.rigid_layout='model_roadwheels_compound_local'
  parent=S.Mat();parent.translation=(0.,.15,.20)
  class Parented(S.Node):
   @property
   def rows(node):return S.matmul(S.matmul(S.evaluate(node.bound or node.source),S.evaluate(parent)),S.evaluate(node.model.matrix))
  self.model.nodes['L0']=Parented(self.model,self.local)
  self.a._wheel_scene=[];wheel_scene.attach(self.v,self.a)
  w.compression=w.mass*9.81/w.k+.06
  for i in range(20):
   parent.translation=(.02,.15+i*.003,.20+i*.002)
   self.local.translation=(.03,.35,.04)
   wheel_scene.update(self.a,(0.,.02,.02,0.))
   self.assertAlmostEqual(self.pose().translation.x,0.)
   self.assertAlmostEqual(self.pose().translation.z,0.)
   self.assertAlmostEqual(self.pose().translation.y,.46)
 def test_rotating_reversed_axle_uses_correct_sign(self):
  self.local.rows[0][0]=-1.;self.local.rows[2][2]=-1.
  self.a._wheel_scene=[];wheel_scene.attach(self.v,self.a)
  wheel_scene.update(self.a,(0.,.2,.2,0.))
  # X axis points against chassis X; local spin must reverse.
  self.assertEqual(self.a._wheel_scene[0]['spin_sign'],-1.)
  self.assertAlmostEqual(self.a._wheel_scene[0]['angle'],-.5)

if __name__=='__main__':unittest.main(verbosity=2)
