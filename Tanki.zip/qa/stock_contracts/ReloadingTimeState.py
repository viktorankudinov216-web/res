# Exact 1.46 reload-state classes for isolated contract tests.
class ReloadingTimeSnapshot(IGunReloadingSnapshot):
    __slots__ = ('_actualTime', '_baseTime', '_startTime', '_updateTime', '_waitReloadingStartResponse')

    def __init__(self, actualTime=0.0, baseTime=0.0, startTime=0.0, updateTime=0.0, waitReloadingStartResponse=False):
        super(ReloadingTimeSnapshot, self).__init__()
        self._actualTime = actualTime
        self._baseTime = baseTime
        self._startTime = startTime
        self._updateTime = updateTime
        self._waitReloadingStartResponse = waitReloadingStartResponse
        return

    def clear(self):
        self._actualTime = 0.0
        self._baseTime = 0.0
        self._startTime = 0.0
        self._updateTime = 0.0
        self._waitReloadingStartResponse = False
        return

    def isReloading(self):
        if self._waitReloadingStartResponse:
            return True
        return self._actualTime > 0

    def isReloadingFinished(self):
        if self._waitReloadingStartResponse:
            return False
        return self._actualTime == 0

    def getActualValue(self):
        return self._actualTime

    def getBaseValue(self):
        return self._baseTime

    def getTimePassed(self):
        return self.__getTimePassedFrom(self._startTime)

    def getTimeLeft(self):
        if not self.isReloadingFinished():
            return max(0.0, self._actualTime - self.__getTimePassedFrom(self._updateTime))
        return 0.0

    def __getTimePassedFrom(self, specifiedTime):
        if not self.isReloadingFinished():
            return max(0.0, BigWorld.timeExact() - specifiedTime)
        return 0.0

class ReloadingTimeState(ReloadingTimeSnapshot, IGunReloadingState):
    __slots__ = ('_startTime', '_baseTime', '_actualTime', '_updateTime', '_waitReloadingStartResponse')

    def getSnapshot(self):
        return ReloadingTimeSnapshot(actualTime=self._actualTime, baseTime=self._baseTime, startTime=self._startTime, updateTime=self._updateTime, waitReloadingStartResponse=self._waitReloadingStartResponse)

    def startPredictedReloading(self, gunSettings):
        self._waitReloadingStartResponse = not gunSettings.hasAutoShoot()
        return

    def stopPredicateReloading(self):
        self._waitReloadingStartResponse = False
        return

    def setTimes(self, actualTime, baseTime):
        if actualTime > 0:
            correction = baseTime - actualTime
            if correction > _TIME_CORRECTION_THRESHOLD:
                self._startTime = BigWorld.timeExact() - correction
            else:
                self._startTime = BigWorld.timeExact()
            self._updateTime = BigWorld.timeExact()
        else:
            self._startTime = 0.0
            self._updateTime = 0.0
        if actualTime == 0:
            self.stopPredicateReloading()
        self._actualTime = actualTime
        self._baseTime = baseTime
        return
