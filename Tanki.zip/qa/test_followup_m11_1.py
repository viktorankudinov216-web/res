# -*- coding: utf-8 -*-
# NativeChain expectations updated in M12: scene owns struts; stock component stays alive.
from __future__ import print_function
import unittest,sys,os,math,types,ast,json
import test_suspension_m11 as S
import test_rigid_integration as I
import test_rigid146 as T
from trial146.physics_rigid146 import handling,native_tracks,wheel_scene
from trial146.physics_rigid146.math3 import *
Obj=I.Obj
class HandlingTests(unittest.TestCase):
 def stop(self,speed,flags):
  v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,0.,speed);distance=0.;peak=0.
  start=v.b.origin()
  for i in range(600):
   T.flat(v,flags=flags,seconds=1./60.);peak=max(peak,abs(euler(v.b.q)[1]))
   if abs(dot(v.b.v,rotate(v.b.q,(0.,0.,1.))))<.06:return ((i+1)/60.,length(sub(v.b.origin(),start)),peak)
  self.fail('Did not stop')
 def test_reverse_release_eighteen_kph_stops_quickly(self):
  t,d,p=self.stop(-5.,0);self.assertLess(t,.85);self.assertLess(d,2.)
 def test_reverse_counter_is_quicker_than_release(self):
  release=self.stop(-5.,0);counter=self.stop(-5.,1)
  self.assertLess(counter[0],release[0]);self.assertLess(counter[0],.75)
 def test_handbrake_stronger_than_counter_and_release(self):
  release=self.stop(10.,0);counter=self.stop(10.,2);brake=self.stop(10.,64)
  self.assertLess(brake[0],counter[0]);self.assertLess(counter[0],release[0]);self.assertLess(brake[0],1.3)
  self.assertLess(brake[2],math.radians(20.))
 def test_six_kph_forward_and_reverse_no_long_coast(self):
  for speed in (-6./3.6,6./3.6):
   t,d,p=self.stop(speed,0);self.assertLess(t,.4);self.assertLess(d,.30)
 def test_brake_target_does_not_push_through_zero(self):
  for speed in (-.001,-.03,.001,.03):
   target=handling.brake_target(speed,0.,1./60.,10.5)
   self.assertGreaterEqual(speed*target,0.)
 def test_modes_distinguish_counter_from_engine_drive(self):
  self.assertEqual(handling.brake_mode(-3.,1.,False),'counter')
  self.assertEqual(handling.brake_mode(3.,1.,False),'drive')
  self.assertEqual(handling.brake_mode(3.,1.,True),'handbrake')
 def test_tall_body_sudden_turn_does_not_roll_over(self):
  for direction in (4,8):
   v=T.vehicle();v.b.com=(0.,1.7,0.);v.b.p=(0.,1.7,0.);T.flat(v,seconds=3.);v.b.v=(0.,0.,13.)
   peak=0.
   for i in range(180):
    T.flat(v,flags=1|direction,seconds=1./60.);peak=max(peak,abs(euler(v.b.q)[2]))
   self.assertLess(peak,math.radians(25.));self.assertGreater(rotate(v.b.q,(0.,1.,0.))[1],.9)
 def test_steering_does_not_charge_uncapped_requested_torque(self):
  v=T.flat(T.vehicle(),seconds=3.);v.b.v=(0.,0.,10.)
  T.flat(v,flags=9,seconds=.15)
  self.assertGreater(dot(v.b.v,rotate(v.b.q,(0.,0.,1.))),9.5)
 def test_airborne_brake_does_not_change_linear_momentum(self):
  v=T.vehicle(y=100.);v.b.v=(0.,0.,-5.);T.flat(v,flags=64,seconds=.5,cliff=-1000.)
  self.assertLess(abs(v.b.v[2]+5.),.03)

class NativeChainTests(unittest.TestCase):
 def setUp(self):
  self.saved={k:sys.modules.get(k) for k in ('Math','Vehicular','vehicle_systems','vehicle_systems.tankStructure')};self.calls=[]
  sys.modules['Math']=Obj(Matrix=S.Mat,MatrixProduct=S.Product,Vector3=S.Vec)
  self.link=Obj();sys.modules['Vehicular']=Obj(getDummyLodLink=lambda:self.link,Suspension='native_suspension')
  sys.modules['vehicle_systems']=Obj();sys.modules['vehicle_systems.tankStructure']=Obj(TankPartIndexes=Obj(CHASSIS=0))
  self.a=I.actor();self.a._rigid_wheel_provider=Obj()
  self.a.rigid.wheels=self.a.rigid.wheels[:1];self.a.rigid.wheels[0].name='L0'
  local=S.Mat();local.translation=(0.,.4,0.);upper=S.Mat();upper.translation=(0.,1.2,0.)
  model=S.Model({'L0':local,'upper':upper})
  group=Obj(nodesTemplate='Track_L',affectedWheelsTemplate='L',startIndex=0,nodesCount=1,isLeft=True,minOffset=-.1,maxOffset=.08,collisionSamplesCount=1,hasLiftMode=False,trackPairIdx=0)
  chassis=Obj(groundNodes=Obj(groups=[group],nodes=[],activePostmortem=False),trackSplineParams=None,wheels=Obj(groups=[],wheels=[Obj(nodeName='upper',isLeft=True,radius=.2)]))
  def call(name):return lambda *v:self.calls.append((name,v))
  suspension=Obj(**dict((name,call(name)) for name in ('reattachCompound','removeGroundNodes','addGroundNodesGroup','addGroundNode','setParameters','setCollisionObstaclesCollector','stopAnimating','forceCorrectionRecalculation','setLodLink')))
  anim=Obj(removeScrollProcessors=call('removeScrollProcessors'),setMovementInfo=call('setMovementInfo'),stopAnimatingWheels=call('stopAnimatingWheels'),setLodLink=call('anim_lod'))
  sensor=Obj(reattachCompound=call('sensor_reattach'),setLodLink=call('sensor_lod'))
  collector=Obj(reattachCompound=call('collector_reattach'),setLodLink=call('collector_lod'))
  self.v=Obj(id=1,typeDescriptor=Obj(chassis=chassis,type=Obj(siegeModeParams=None,isWheeledVehicle=False)),_hangar146_combat_runtime=Obj(player_id=1),appearance=Obj(compoundModel=model,suspension=suspension,wheelsAnimator=anim,collisionObstaclesCollector=collector,tessellationCollisionSensor=sensor,tracks=Obj(setLodLink=call('tracks_lod')),trackNodesAnimator=Obj(setWheelsDataProvider=call('node_provider'),setLodLink=call('node_lod'))))
  self.old=suspension
  def create(*args):
   self.calls.append(('create',args))
   return Obj(**dict((name,call(name)) for name in ('addGroundNodesGroup','addGroundNode','setParameters','setCollisionObstaclesCollector','stopAnimating','forceCorrectionRecalculation','setLodLink')))
  self.v.appearance.createComponent=create;self.v.appearance.removeComponent=call('remove_failed')
 def tearDown(self):
  for k,v in self.saved.items():
   if v is None:sys.modules.pop(k,None)
   else:sys.modules[k]=v
 def bind(self):native_tracks.bind(self.v,self.a,lambda *a,**kw:None)
 def test_roadwheel_transform_is_owned_by_physical_strut(self):
  self.bind();self.assertIsNotNone(self.v.appearance.compoundModel.node('L0').bound)
  self.assertTrue(self.a._rigid_native_visual);self.assertIsNotNone(self.v.appearance.compoundModel.node('upper').bound)
  self.assertTrue(next(r for r in self.a._wheel_scene if r['name']=='L0')['travel_owner'])
 def test_all_chain_members_share_native_wheel_provider(self):
  self.bind();self.assertIn(('node_provider',(self.v.appearance.wheelsAnimator,)),self.calls)
  self.assertIn(('removeScrollProcessors',()),self.calls)
  self.assertIn(('setMovementInfo',(self.a._rigid_wheel_provider,)),self.calls)
 def test_scene_stroke_covers_physical_strut_range_without_native_recreation(self):
  self.bind();w=self.a.rigid.wheels[0];w.compression=w.travel
  wheel_scene.update(self.a)
  self.assertAlmostEqual(next(r for r in self.a._wheel_scene if r['name']=='L0')['offset'],w.travel-w.mass*9.81/w.k)
  self.assertFalse(any(n in ('create','addGroundNodesGroup','removeGroundNodes') for n,v in self.calls))
 def test_player_lod_pinned_including_tracks_and_sensor(self):
  self.bind()
  for name in ('anim_lod','sensor_lod','collector_lod','tracks_lod','node_lod'):
   self.assertIn((name,(self.link,)),self.calls)
 def test_upper_roller_rotates_but_has_no_fake_spring_translation(self):
  self.bind();wheel_scene.update(self.a,(0.,.1,.1,0.));m=S.Mat(self.v.appearance.compoundModel.node('upper'))
  self.assertAlmostEqual(m.translation.y,1.2);axis=m.applyToAxis(1);self.assertAlmostEqual(math.atan2(axis.z,axis.y),.5)
 def test_suspension_cache_invalidated_but_not_rebuilt_per_frame(self):
  self.bind();self.calls[:]=[];self.a.sleeping=False;native_tracks.tick(self.v,self.a)
  self.assertIn(('forceCorrectionRecalculation',()),self.calls)
  self.assertNotIn('removeGroundNodes',[name for name,v in self.calls])
 def test_missing_suspension_is_reported_without_native_recreation(self):
  self.v.appearance.suspension=None
  self.assertRaises(RuntimeError,self.bind)
  self.assertFalse(any(n in ('create','removeGroundNodes') for n,v in self.calls))
 def test_scene_setup_failure_keeps_original_native_component_alive(self):
  def fail(*args):raise RuntimeError('injected scene provider failure')
  self.v.appearance.compoundModel.node=fail
  self.assertRaises(RuntimeError,self.bind)
  self.assertIs(self.v.appearance.suspension,self.old)
  self.assertFalse(self.a._rigid_native_visual)
  self.assertNotIn('create',[n for n,args in self.calls])
 def test_active_native_suspension_is_neither_cleared_nor_replaced(self):
  self.bind();self.assertIs(self.v.appearance.suspension,self.old)
  self.a.sleeping=False
  for i in range(180):native_tracks.tick(self.v,self.a)
  self.assertFalse(any(n in ('create','removeGroundNodes','remove_failed') for n,v in self.calls))
 def test_dead_body_never_calls_native_components(self):
  self.bind();self.calls[:]=[];self.a.health=0;native_tracks.tick(self.v,self.a);self.assertEqual(self.calls,[])

class AimTests(unittest.TestCase):
 def test_only_local_avatar_bypasses_stale_server_yaw(self):
  tree=ast.parse(open(I.F.P+'/combat146.py').read());install=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='install')
  fn=next(n for n in install.body if isinstance(n,ast.FunctionDef) and n.name=='local_yaw');fn.decorator_list=[]
  ns={'local_avatar':lambda a:a=='local'};exec(compile(ast.Module(body=[fn]),'<local-only aim hook>','exec'),ns)
  self.assertEqual(ns['local_yaw'](lambda s,y:99.,Obj(_avatar='local'),.4),.4)
  self.assertEqual(ns['local_yaw'](lambda s,y:99.,Obj(_avatar='online'),.4),99.)
if __name__=='__main__':unittest.main(verbosity=2)
