# -*- coding: utf-8 -*-
from __future__ import print_function
import unittest,math,sys
import test_rigid_integration as I
import test_contact_m09 as C
import test_rigid146 as T
from trial146.physics_rigid146 import grip0922 as G,layout
from trial146.physics_rigid146.math3 import *
from trial146.legacy0922 import vehicle_physics as D
class DonorTests(unittest.TestCase):
 def test_donor_not_123_and_specific_friction_is_not_adhesion(self):
  p=G.parameters(T.PARAMS);p['specificFriction']=.6867
  lng,lat=G.coefficients(p,1.,False)
  self.assertAlmostEqual(lng,D.COHESION*D.GRAVITY/9.81)
  self.assertGreater(lng,p['specificFriction']*2.)
 def test_bridge_calls_exact_donor_law(self):
  p=G.parameters(T.PARAMS)
  for speed in (0.,1.,-1.,7.,-3.):
   for throttle in (-1.,0.,1.):
    for pitch in (-.25,0.,.25):
     actual=G.next_speed(p,speed,throttle,False,pitch,1./120.)
     expected=D.longitudinal_step(p,speed,throttle,False,pitch,1./120.)
     self.assertAlmostEqual(actual,max(-p['speedBwd'],min(p['speedFwd'],expected)))
 def test_no_double_slope_gravity_and_static_hold(self):
  v=T.flat(T.vehicle(),seconds=5.,gradient=(0.,.12));start=v.b.origin()
  T.flat(v,seconds=2.,gradient=(0.,.12))
  self.assertLess(abs(dot(v.b.v,rotate(v.b.q,(0.,0.,1.)))),.025)
  self.assertLess(length(sub(v.b.origin(),start)),.04)
 def test_hard_governor_not_donor_105_percent(self):
  p=G.parameters(T.PARAMS);v=p['speedFwd']*1.04
  self.assertEqual(G.next_speed(p,v,1.,False,.3,1./60.),p['speedFwd'])
class HandlingTests(unittest.TestCase):
 def test_six_kph_stops_within_half_second(self):
  v=T.flat(T.vehicle(),seconds=2.);v.b.v=(0.,0.,6./3.6);start=v.b.origin()
  T.flat(v,seconds=.5)
  self.assertLess(abs(v.b.v[2]),.025);self.assertLess(v.b.origin()[2]-start[2],.40) # M11 bounded jerk: <=40 cm, still fully stopped in .5s
 def test_six_kph_does_not_creep_for_ten_seconds(self):
  v=T.flat(T.vehicle(),seconds=2.);v.b.v=(0.,0.,6./3.6)
  T.flat(v,seconds=.5);start=v.b.origin();T.flat(v,seconds=3.)
  self.assertLess(length(sub(v.b.origin(),start)),.02)
 def test_reverse_coast_also_stops(self):
  v=T.flat(T.vehicle(),seconds=2.);v.b.v=(0.,0.,-6./3.6);T.flat(v,seconds=.5)
  self.assertLess(abs(v.b.v[2]),.025)
 def test_braking_not_limited_by_zero_engine_power(self):
  v=T.flat(T.vehicle(),seconds=2.);v.params['powerW']=0.;v.b.v=(0.,0.,2.);T.flat(v,seconds=.5)
  self.assertLess(abs(v.b.v[2]),.025)
 def test_governor_stops_90_kph_on_ground(self):
  v=T.flat(T.vehicle(),seconds=2.);v.b.v=(0.,0.,90./3.6);T.flat(v,flags=1,seconds=1./60.)
  self.assertLessEqual(dot(v.b.v,rotate(v.b.q,(0.,0.,1.))),v.params['speedFwd']+.03)
 def test_downhill_never_runs_away_under_throttle(self):
  v=T.flat(T.vehicle(),seconds=3.,gradient=(0.,-.20));v.params['speedFwd']=10.;peak=0.
  for i in range(600):
   T.flat(v,flags=1,seconds=1./60.,gradient=(0.,-.20))
   if v.contacts:peak=max(peak,dot(v.b.v,rotate(v.b.q,(0.,0.,1.))))
  self.assertGreater(peak,9.);self.assertLessEqual(peak,10.08)
 def test_downhill_release_does_not_accelerate_past_limit(self):
  v=T.flat(T.vehicle(),seconds=3.,gradient=(0.,-.20));v.params['speedFwd']=10.;v.b.v=mul(rotate(v.b.q,(0.,0.,1.)),10.)
  for i in range(120):
   T.flat(v,seconds=1./60.,gradient=(0.,-.20))
   if v.contacts:self.assertLessEqual(dot(v.b.v,rotate(v.b.q,(0.,0.,1.))),10.08)
 def test_reverse_governor(self):
  v=T.flat(T.vehicle(),seconds=2.);v.b.v=(0.,0.,-20.);T.flat(v,flags=2,seconds=.1)
  self.assertGreaterEqual(dot(v.b.v,rotate(v.b.q,(0.,0.,1.))),-v.params['speedBwd']-.03)
 def test_airborne_speed_not_clamped(self):
  v=T.vehicle(y=100.);v.b.v=(0.,-4.,30.);T.flat(v,seconds=.1,cliff=-1000.)
  self.assertGreater(v.b.v[2],29.);self.assertLess(v.b.v[1],-4.)
 def test_handbrake_left_outside_right_moves_forward(self):
  self.assertEqual(T.track_targets(64|4,0.,T.PARAMS,1.2),(0.,1.68))
  v=T.flat(T.vehicle(),seconds=2.);T.flat(v,flags=64|4,seconds=1.)
  self.assertEqual(v.tracks[0],0.);self.assertGreater(v.tracks[1],0.);self.assertLess(v.b.w[1],-.15)
 def test_handbrake_right_outside_left_moves_forward(self):
  v=T.flat(T.vehicle(),seconds=2.);T.flat(v,flags=64|8,seconds=1.)
  self.assertGreater(v.tracks[0],0.);self.assertEqual(v.tracks[1],0.);self.assertGreater(v.b.w[1],.15)
class OneTrackTests(unittest.TestCase):
 def one_tick(self,side='right',light_contact=False):
  v=T.flat(T.vehicle(),seconds=2.);v.b.w=(0.,.8 if side=='left' else -.8,0.)
  hits=[]
  for w in v.wheels:
   a,c=w.ray(v.b);point=(a[0],0.,a[2])
   if w.side==side:hits.append((point,(0.,1.,0.)))
   elif light_contact:hits.append(((a[0],-.095,a[2]),(0.,1.,0.)))
   else:hits.append(None)
  v.tick(1./60.,1,hits,[]);return v
 def test_right_track_can_pull_with_left_airborne(self):
  v=self.one_tick('right');self.assertGreater(v.b.v[2],.03);self.assertGreater(v.side_forces[1],1000.);self.assertEqual(v.side_loads[0],0.)
 def test_left_track_can_pull_with_right_airborne(self):
  v=self.one_tick('left');self.assertGreater(v.b.v[2],.03);self.assertGreater(v.side_forces[0],1000.);self.assertEqual(v.side_loads[1],0.)
 def test_yaw_hold_does_not_cancel_only_track_force(self):
  v=self.one_tick('right');self.assertEqual(v.grip_force[2],0.);self.assertGreater(v.grip_force[1],0.)
 def test_weak_other_track_cannot_steal_propulsion(self):
  v=self.one_tick('right',True);self.assertGreater(v.b.v[2],.03)
class CarrierTests(C.MathMixin,unittest.TestCase):
 def test_return_rollers_in_ground_mapping_are_not_supports(self):
  d,v,positions=C.LayoutTests('test_compound_root_not_stale_vehicle_root').objects()
  # Original loose clearance check admitted this upper roller.
  d.chassis.wheels.wheels.append(I.Obj(nodeName='return',isLeft=True,radius=.15,isLeading=False))
  d.chassis.groundNodes.nodes.append(I.Obj(affectedWheelName='return'))
  positions['return']=I.Obj(translation=(98.8,10.65,200.))
  rows,detail=layout.collect(d,v,dict(width=3.,length=6.,clearance=.8))
  self.assertNotIn('return',[r[-1] for r in rows]);self.assertTrue(any(r['reason']=='return roller above carrying plane' for r in detail['rejected']))
 def test_leading_sprocket_in_ground_mapping_is_not_support(self):
  d,v,positions=C.LayoutTests('test_compound_root_not_stale_vehicle_root').objects()
  d.chassis.wheels.wheels.append(I.Obj(nodeName='drive',isLeft=True,radius=.35,isLeading=True));d.chassis.groundNodes.nodes.append(I.Obj(affectedWheelName='drive'))
  positions['drive']=I.Obj(translation=(98.8,10.35,200.))
  rows,detail=layout.collect(d,v,dict(width=3.,length=6.,clearance=.8))
  self.assertNotIn('drive',[r[-1] for r in rows])
 def test_full_donor_sag_not_four_centimetres(self):
  a=I.actor();w=a.rigid.wheels[0]
  self.assertGreater(w.mass*9.81/w.k,.075);self.assertGreater(w.travel,.15)
 def test_damper_opposes_vertical_motion(self):
  a=I.actor();b=I.actor();a.rigid.b.v=(0.,-1.,0.);b.rigid.b.v=(0.,1.,0.)
  a.step(1./60.,lambda *args:0.,None);b.step(1./60.,lambda *args:0.,None)
  self.assertGreater(sum(w.load for w in a.rigid.wheels),sum(w.load for w in b.rigid.wheels))
if __name__=='__main__':unittest.main(verbosity=2)
