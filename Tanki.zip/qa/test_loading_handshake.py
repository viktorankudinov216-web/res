from __future__ import print_function
import os,sys,types,unittest
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import test_m0704 as F
from trial146 import loading_ui as U,utils
class Obj(object):
 def __init__(self,**kw):self.__dict__.update(kw)
class LoadingHandshakeTests(unittest.TestCase):
 def setUp(self):
  self.saved={};self.queue=[];self.started=[];self.marks=[];self.checkpoint=len(utils._PATCHES);self.pkg=sys.modules['trial146'];self.old_n=getattr(self.pkg,'native_match',None)
  def module(name,**kwargs):
   parts=name.split('.')
   for i in range(1,len(parts)+1):
    key='.'.join(parts[:i])
    if key=='trial146':continue
    if key not in self.saved:
     self.saved[key]=sys.modules.get(key);m=types.ModuleType(key);m.__path__=[];sys.modules[key]=m
   sys.modules[name].__dict__.update(kwargs);return sys.modules[name]
  self.N=module('trial146.native_match',_GENERATION=1,_PLAN={'bots':[{}]},_RETURNING=False,_RETURN_SCHEDULED=False,local_avatar=lambda *a:True,start_world=lambda:self.started.append('world'),mark=lambda s,**k:self.marks.append((s,k)),request_return=lambda:self.fail('unexpected return'))
  self.pkg.native_match=self.N
  self.owner=object();module('BigWorld',player=lambda:self.owner,callback=lambda delay,fn:self.queue.append(fn))
  class Page(object):
   def __init__(self):self._isBattleLoading=False;self.ready=True
   def _populate(self):pass
   def _isDAAPIInited(self):return self.ready
   def as_getComponentsVisibilityS(self):return []
  class Stats(object):
   def __init__(self):self.ready=True;self._battleCtx=object()
   def _populate(self):pass
   def _isDAAPIInited(self):return self.ready
   def invalidateArenaInfo(self):pass
   def as_setVehiclesDataS(self,data):return 'base_result'
  self.page=Page();self.stats=Stats()
  self.changes=[]
  def changed(space):self.changes.append(space);self.page._isBattleLoading=True
  module('gui.Scaleform.daapi.view.battle.shared.page',SharedPage=Page)
  module('gui.Scaleform.daapi.view.battle.shared.stats_exchange.stats_ctrl',BattleStatisticsDataController=Stats)
  module('helpers',dependency=Obj(instance=lambda t:Obj(getSpaceID=lambda:4,changeSpace=changed)))
  module('skeletons.gui.app_loader',IAppLoader=object)
  module('gui.app_loader.spaces',BattleLoadingSpace=lambda arenaType:Obj(getSpaceID=lambda:4))
  module('constants',ARENA_GUI_TYPE=Obj(RANDOM=1));U.install()
 def tearDown(self):
  utils.restore(self.checkpoint)
  for k,v in self.saved.items():
   if v is None:sys.modules.pop(k,None)
   else:sys.modules[k]=v
  if self.old_n is None:del self.pkg.native_match
  else:self.pkg.native_match=self.old_n
 def payload(self,count):
  return {'leftItems':[{'vehicleID':900001}],'rightItems':[{'vehicleID':900002+i} for i in range(count-1)],'leftItemsIDs':[900001],'rightItemsIDs':[900002+i for i in range(count-1)]}
 def drain(self):
  for i in range(30):
   if not self.queue:return
   self.queue.pop(0)()
  self.fail('callback loop')
 def test_duel_page_then_payload_starts_world(self):
  self.page._populate();self.drain();self.assertFalse(self.started);self.stats.as_setVehiclesDataS(self.payload(2));self.drain();self.assertEqual(self.started,['world']);self.assertTrue(self.page._isBattleLoading)
 def test_duel_payload_then_page_starts_world(self):
  self.stats.as_setVehiclesDataS(self.payload(2));self.drain();self.page._populate();self.drain();self.assertEqual(self.started,['world'])
 def test_duplicate_payload_starts_world_only_once(self):
  self.page._populate();self.stats.as_setVehiclesDataS(self.payload(2));self.stats.as_setVehiclesDataS(self.payload(2));self.drain();self.assertEqual(self.started,['world']);self.assertEqual(len(self.changes),1)
 def test_partial_payload_does_not_start(self):
  self.page._populate();self.stats.as_setVehiclesDataS(self.payload(1));self.drain();self.assertFalse(self.started)
 def test_not_ready_payload_does_not_start(self):
  self.page._populate();self.stats.ready=False;self.stats.as_setVehiclesDataS(self.payload(2));self.drain();self.assertFalse(self.started)
 def test_four_actor_plan_also_starts(self):
  self.N._PLAN={'bots':[{}, {}, {}]};self.page._populate();self.stats.as_setVehiclesDataS(self.payload(4));self.drain();self.assertEqual(self.started,['world'])
 def test_wrong_four_actor_payload_for_duel_does_not_start(self):
  self.page._populate();self.stats.as_setVehiclesDataS(self.payload(4));self.drain();self.assertFalse(self.started)
if __name__=='__main__':unittest.main(verbosity=2)
