# -*- coding: utf-8 -*-
from __future__ import print_function
import sys,os,math,types,unittest,ast
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import test_m0704 as F
from trial146 import combat146 as M,contact_cache146 as K,spawn146 as S
class Obj(object):
 def __init__(self,**kw):self.__dict__.update(kw)
class DuelTests(unittest.TestCase):
 def test_two_spawned_tanks_have_opposing_teams(self):
  old={k:getattr(S,k) for k in ('bases','footprint','candidates','corners','outside_base','support','separated')}
  S.bases=lambda a:[[(0.,0.)],[(100.,100.)]];S.footprint=lambda d:((-1,0,-1),(1,2,1));S.candidates=lambda a,t,h,r:[(20.,20.)] if t==1 else [(80.,80.)];S.corners=lambda *a:[(20,20)]
  S.outside_base=lambda *a:True;S.separated=lambda *a:True;S.support=lambda x,z,*a:dict(position=(x,0.,z),footprint=[(x,z)])
  try:
   poses=S.plan(Obj(boundingBox=((-100,-100),(200,200))),[None,None],None,None,lambda p:True,None)
   self.assertEqual([p['team'] for p in poses],[1,2]);self.assertNotEqual(poses[0]['position'],poses[1]['position'])
  finally:
   for k,v in old.items():setattr(S,k,v)
 def test_selection_is_one_bot(self):
  source=open(F.P+'/match_plan.py').read();self.assertIn('if len(bots)==1:break',source);self.assertIn('if len(bots)!=1:',source);self.assertNotIn('index<2',source)
 def test_entity_public_team_rule_is_not_old_two_allies(self):
  source=open(F.P+'/world146.py').read();self.assertIn('team=1 if index==0 else 2',source)

class ReloadTests(unittest.TestCase):
 def setUp(self):
  self.old=sys.modules.get('constants');sys.modules['constants']=Obj(VEHICLE_SETTING=Obj(CURRENT_SHELLS=1,NEXT_SHELLS=2));self.events=[]
  avatar=Obj(updateVehicleAmmo=lambda *a:self.events.append(('ammo',a)),updateVehicleSetting=lambda *a:self.events.append(('setting',a)),updateVehicleGunReloadTime=lambda *a:self.events.append(('time',a)))
  self.r=M.Runtime.__new__(M.Runtime);self.r.player_id=1;self.r.s=Obj(avatar=avatar);self.a=F.actor();self.a.magazine=F.C.Magazine({1:5,2:5,3:5},1,1,8.44,0.);self.r.round=F.C.Round([self.a]);self.r.round.now=3.;self.r.shot_types={1:{1:None,2:None,3:None}}
 def tearDown(self):
  if self.old is None:sys.modules.pop('constants',None)
  else:sys.modules['constants']=self.old
 def test_forced_shell_change_sends_zero_then_full_time(self):
  m=self.a.magazine;m.select(2,0.);self.r.round.now=3.;m.select(3,3.);self.r.publish_ammo(self.a,reset_prediction=True)
  times=[a for k,a in self.events if k=='time'];self.assertEqual(len(times),2);self.assertEqual(times[0],(1,0.,8.44));self.assertAlmostEqual(times[1][1],8.44);self.assertFalse(m.can_fire(8.44));self.assertTrue(m.can_fire(11.44))
 def test_queue_does_not_zero_out_reload(self):
  self.a.magazine.fire(0.);self.a.magazine.select(2,3.,immediate=False);self.r.publish_ammo(self.a)
  times=[a for k,a in self.events if k=='time'];self.assertEqual(len(times),1);self.assertAlmostEqual(times[0][1],5.44)
 def test_prebattle_never_starts_a_new_timer(self):
  self.a.magazine.select(2,0.,prebattle=True);self.r.publish_ammo(self.a,reset_prediction=True);self.assertEqual([a[1] for k,a in self.events if k=='time'],[0.])
 def test_zero_releases_stock_prediction_latch(self):
  tree=ast.parse(open(os.path.join(os.path.dirname(__file__),'stock_contracts','ReloadingTimeState.py')).read());classes=[n for n in tree.body if isinstance(n,ast.ClassDef)]
  for n in classes:n.decorator_list=[]
  ns=dict(IGunReloadingSnapshot=object,IGunReloadingState=object,BigWorld=Obj(timeExact=lambda:123.),_TIME_CORRECTION_THRESHOLD=.1)
  exec(compile(ast.Module(body=classes),'<1.46 reload state>','exec'),ns)
  state=ns['ReloadingTimeState'](5.,8.44,100.,100.,True);self.assertTrue(state._waitReloadingStartResponse);state.setTimes(8.44,8.44);self.assertTrue(state._waitReloadingStartResponse);state.setTimes(0.,8.44);state.setTimes(8.44,8.44);self.assertFalse(state._waitReloadingStartResponse);self.assertEqual(state.getTimeLeft(),8.44)

class ContactTests(unittest.TestCase):
 def runtime(self):
  r=M.Runtime.__new__(M.Runtime);a=F.actor();a.v=12.8;a.body['airborne']=False;a.ground_plane=dict(gradient_x=.02,gradient_z=.01,max_residual=.08);r.player_id=1;r.round=F.C.Round([a]);r.contact_modes={};r.contact_bank=K.Bank('/no-library');r.ground=lambda actor,x,z,*args:.02*x+.01*z;return r,a
 def test_normal_road_speed_does_not_disable_cache(self):
  r,a=self.runtime();r.ground_batch(a,[(0.,0.,-1.,1.,None)]);r.round.now=1./60.;r.ground_batch(a,[(.21,0.,-1.,1.,None)]);self.assertEqual(r.contact_bank.hits,1);self.assertEqual(r.contact_modes.get('reusable'),2)
 def test_airborne_always_refreshes(self):
  r,a=self.runtime();a.body['airborne']=True;r.ground_batch(a,[(0.,0.,-1.,1.,None)]);r.round.now=1./60.;r.ground_batch(a,[(0.,0.,-1.,1.,None)]);self.assertEqual(r.contact_bank.hits,0);self.assertEqual(r.contact_modes['airborne'],2)
 def test_stationary_hull_does_not_cast_perimeter(self):
  r,a=self.runtime();r.solid_hit=lambda *a:self.fail('stationary perimeter query');self.assertTrue(r.clear(a,a.position,a.yaw))

class TransferTests(unittest.TestCase):
 def solve(self,drive=0.,lateral=0.):
  p=F.suspension();state=dict(height=0.,pitch=0.,roll=0.,vertical_velocity=0.,pitch_velocity=0.,roll_velocity=0.)
  for i in range(120):
   state['drive_acceleration']=drive;state['lateral_acceleration']=lateral;state=F.V.damper_suspension_step(p,state,[0.]*10,1./60.,[0.]*12,0.)
  return state
 def test_drive_raises_nose(self):self.assertLess(self.solve(drive=3.)['pitch'],-.0001)
 def test_braking_lowers_nose(self):self.assertGreater(self.solve(drive=-3.)['pitch'],.0001)
 def test_turn_leans_outward(self):self.assertGreater(self.solve(lateral=3.)['roll'],.0001)
 def test_zero_force_stays_level(self):
  b=self.solve();self.assertAlmostEqual(b['pitch'],0.,places=6);self.assertAlmostEqual(b['roll'],0.,places=6)
 def test_force_is_bounded_and_pose_finite(self):
  b=self.solve(1e6,1e6);self.assertTrue(all(not(math.isnan(b[k]) or math.isinf(b[k])) for k in ('height','pitch','roll')));self.assertLess(abs(b['pitch']),.5);self.assertLess(abs(b['roll']),.5)

if __name__=='__main__':unittest.main(verbosity=2)
