# -*- coding: utf-8 -*-
from __future__ import print_function
import unittest,sys,os,types,math,random
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'));P=ROOT+'/res_mods/1.46.0.0/scripts/client/gui/mods/hangar146'
if 'trial146' not in sys.modules:
 pkg=types.ModuleType('trial146');pkg.__path__=[P];sys.modules['trial146']=pkg
from trial146.physics_rigid146.math3 import *
from trial146.physics_rigid146.solver import Body,Wheel,Vehicle,track_targets
from trial146.physics_rigid146.shots import near_segment
PARAMS=dict(mass=30000.,speedFwd=15.,speedBwd=5.,rotSpd=.7,powerW=300000.,trackCenter=2.6,specificFriction=.8)
def vehicle(y=0.,pitch=0.,roll=0.,yaw=0.):
 b=Body((0.,y,0.),(yaw,pitch,roll),30000.,(-1.5,.35,-3.),(1.5,1.8,3.),(0.,1.,0.))
 static=9.81/(2.*math.pi*1.55)**2
 wheels=[Wheel(x,z,.65,.30+static,.34,3000.,side,.35) for side,x in (('left',-1.2),('right',1.2)) for z in (-2.4,-1.2,0.,1.2,2.4)]
 return Vehicle(b,wheels,dict(PARAMS))
def flat(v,flags=0,seconds=1.,height=0.,gradient=(0.,0.),cliff=None,wall=None):
 for i in range(int(seconds*60)):
  hits=[];b=v.b
  normal=unit((-gradient[0],1.,-gradient[1]))
  for wheel in v.wheels:
   a,c=wheel.ray(b);d=sub(c,a);point=(0.,height,0.);den=dot(d,normal)
   t=dot(sub(point,a),normal)/den if abs(den)>1e-9 else -1.
   hit=add(a,mul(d,t))
   hits.append((hit,normal) if 0.<=t<=1. and (cliff is None or hit[2]<cliff) else None)
  planes=[]
  if wall is not None:planes=[((0.,0.,wall),(0.,0.,-1.))]
  # Flat body belly constraint only once close; same OBB proxy as native adapter.
  if dot(sub(b.support(normal),(0.,height,0.)),normal)<.05 and (cliff is None or b.support(normal)[2]<cliff):planes.append(((0.,height,0.),normal))
  v.tick(1./60.,flags,hits,planes)
 return v
class MathTests(unittest.TestCase):
 def test_ypr_roundtrip(self):
  for y,p,r in ((.9,.4,-.3),(-2.,-.8,.7),(2.9,0.,1.2)):
   values=euler(quat(y,p,r))
   for a,b in zip(values,(y,p,r)):self.assertAlmostEqual(a,b,places=10)
 def test_gimbal_pose_is_same_rotation(self):
  for pitch in (-math.pi*.5,math.pi*.5):
   a=quat(.7,pitch,.4);b=quat(*euler(a))
   for axis in ((1.,0.,0.),(0.,1.,0.),(0.,0.,1.)):self.assertLess(length(sub(rotate(a,axis),rotate(b,axis))),1e-7)
 def test_vector_rotation_length(self):
  self.assertAlmostEqual(length(rotate(quat(2.,1.,.7),(1.,2.,3.))),math.sqrt(14.))
 def test_slerp_antipodal(self):
  q=quat(.7,.4,.2);self.assertAlmostEqual(abs(dot(slerp(q,tuple(-x for x in q),.5)[1:],q[1:])),dot(q[1:],q[1:]))
 def test_free_spin_normalized(self):
  q=quat(.2,.3,.4)
  for i in range(1200):q=advance(q,(.3,.7,.2),1./120.)
  self.assertAlmostEqual(sum(x*x for x in q),1.,places=10)
 def test_no_axis_clamp(self):
  b=vehicle().b;b.w=(0.,0.,2.)
  for i in range(120):b.integrate_pose(1./120.)
  self.assertLess(rotate(b.q,(0.,1.,0.))[1],0.)
class ForceTests(unittest.TestCase):
 def test_rest_settles(self):
  v=flat(vehicle(),seconds=8.)
  self.assertLess(abs(v.b.origin()[1]),.025);self.assertLess(length(v.b.v),.03)
  self.assertEqual(v.contacts,10)
 def test_suspension_supports_weight(self):
  v=flat(vehicle(),seconds=6.)
  self.assertAlmostEqual(sum(w.load for w in v.wheels)/(v.b.mass*9.81),1.,delta=.02)
 def test_pitch_slope(self):
  v=flat(vehicle(),seconds=8.,gradient=(0.,.12));self.assertLess(euler(v.b.q)[1],-.07)
 def test_roll_slope(self):
  v=flat(vehicle(),seconds=8.,gradient=(.12,0.));self.assertGreater(euler(v.b.q)[2],.07)
 def test_drive_accelerates(self):
  v=flat(vehicle(),flags=1,seconds=4.);self.assertGreater(v.b.v[2],2.)
 def test_reverse(self):
  v=flat(vehicle(),flags=2,seconds=3.);self.assertLess(v.b.v[2],-1.)
 def test_air_has_no_engine_acceleration(self):
  v=vehicle(y=100.);v.tick(1./60.,1,[None]*10,[]);self.assertAlmostEqual(v.b.v[2],0.)
 def test_free_fall(self):
  v=vehicle(y=100.);flat(v,seconds=1.,cliff=-1000.)
  self.assertAlmostEqual(v.b.v[1],-9.81,delta=.1)
 def test_flight_keeps_orientation_without_spin(self):
  v=vehicle(y=100.,pitch=.4,roll=.3,yaw=1.);before=v.b.q
  for i in range(120):v.tick(1./60.,0,[None]*10,[])
  self.assertEqual(v.b.q,before)
 def test_flight_keeps_spin(self):
  v=vehicle(y=100.);v.b.w=(.3,.2,.4)
  for i in range(60):v.tick(1./60.,0,[None]*10,[])
  self.assertGreater(length(v.b.w),.3);self.assertGreater(abs(euler(v.b.q)[1]),.1)
 def test_landing_damped(self):
  v=flat(vehicle(y=1.5),seconds=8.)
  self.assertLess(abs(v.b.origin()[1]),.03);self.assertLess(length(v.b.v),.04)
 def test_cliff_tipping(self):
  v=flat(vehicle(),seconds=3.);v.b.p=add(v.b.p,(0.,0.,2.))
  flat(v,seconds=.7,cliff=.4)
  self.assertGreater(euler(v.b.q)[1],.04)
 def test_pivot_yaw(self):
  v=flat(vehicle(),seconds=1.);flat(v,flags=8,seconds=2.)
  self.assertGreater(euler(v.b.q)[0],.1)
 def test_wall_no_tunnel(self):
  v=flat(vehicle(),seconds=1.);v.b.v=(0.,0.,8.)
  flat(v,flags=1,seconds=2.,wall=6.)
  self.assertLess(v.b.support((0.,0.,-1.))[2],6.15)
 def test_wall_suspension_changes(self):
  v=flat(vehicle(),seconds=2.);v.b.v=(0.,0.,5.)
  flat(v,flags=1,seconds=.6,wall=4.)
  self.assertGreater(max(w.compression for w in v.wheels)-min(w.compression for w in v.wheels),.003)
 def test_all_face_support(self):
  b=vehicle().b
  self.assertAlmostEqual(b.support((0.,1.,0.))[1],.35)
  self.assertAlmostEqual(b.support((0.,-1.,0.))[1],1.8)
  self.assertAlmostEqual(b.support((1.,0.,0.))[0],-1.5)
  self.assertAlmostEqual(b.support((0.,0.,-1.))[2],3.)
 def test_point_impulse_rotates(self):
  b=vehicle().b;b.impulse((0.,0.,-30000.),(0.,.4,3.));self.assertGreater(b.w[0],0.)
 def test_energy_bounded_on_bumps(self):
  v=vehicle()
  for i in range(1200):flat(v,flags=1,seconds=1./60.,height=.05*math.sin(i*.03))
  self.assertLess(length(v.b.v),25.);self.assertLess(length(v.b.w),5.)
 def test_no_grip_without_load(self):
  v=vehicle(y=50.);v.b.v=(2.,0.,1.);v.tick(1./60.,64,[None]*10,[])
  self.assertGreater(v.b.v[0],1.99)
 def test_wall_can_slide(self):
  b=vehicle().b;b.v=(3.,0.,4.);v=Vehicle(b,[],PARAMS)
  v.tick(1./60.,0,[],[((0.,0.,3.),(0.,0.,-1.))])
  self.assertGreater(b.v[0],.5)
 def test_handbrake_right(self):
  left,right=track_targets(64|8,0.,PARAMS,1.3);self.assertGreater(left,0.);self.assertEqual(right,0.)
 def test_handbrake_left(self):
  left,right=track_targets(64|4,0.,PARAMS,1.3);self.assertEqual(left,0.);self.assertGreater(right,0.)
 def test_normal_pivot(self):
  l,r=track_targets(8,0.,PARAMS,1.3);self.assertGreater(l,0.);self.assertLess(r,0.)
 def test_low_power_slower(self):
  a=vehicle();b=vehicle();a.params['powerW']=1000.
  flat(a,flags=1,seconds=4.);flat(b,flags=1,seconds=4.);self.assertLess(a.b.v[2],b.b.v[2])
class ShotTests(unittest.TestCase):
 def test_point_blank_not_culled(self):self.assertTrue(near_segment((0.,0.,0.),(0.,0.,0.),(0.,0.,20.),18.))
 def test_crossing_not_culled(self):self.assertTrue(near_segment((0.,0.,10.),(0.,0.,0.),(0.,0.,20.),18.))
 def test_distant_culled(self):self.assertFalse(near_segment((100.,0.,0.),(0.,0.,0.),(0.,0.,20.),18.))
 def test_zero_segment(self):self.assertTrue(near_segment((0.,0.,0.),(0.,0.,0.),(0.,0.,0.),18.))
if __name__=='__main__':unittest.main(verbosity=2)
