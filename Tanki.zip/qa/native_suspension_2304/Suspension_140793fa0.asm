0000000140793fa0 mov       qword ptr [rsp + 0x10], rbx
0000000140793fa5 mov       qword ptr [rsp + 0x18], rsi
0000000140793faa mov       qword ptr [rsp + 0x20], rdi
0000000140793faf push      rbp
0000000140793fb0 push      r12
0000000140793fb2 push      r13
0000000140793fb4 push      r14
0000000140793fb6 push      r15
0000000140793fb8 lea       rbp, [rsp - 0xa0]
0000000140793fc0 sub       rsp, 0x1a0
0000000140793fc7 mov       rax, qword ptr [rip + 0x31cc52a]
0000000140793fce xor       rax, rsp
0000000140793fd1 mov       qword ptr [rbp + 0x90], rax
0000000140793fd8 lea       rax, [rip + 0x94881]
0000000140793fdf mov       qword ptr [rsp + 0x40], rax
0000000140793fe4 xor       edi, edi
0000000140793fe6 mov       dword ptr [rsp + 0x48], edi
0000000140793fea movaps    xmm0, xmmword ptr [rsp + 0x40]
0000000140793fef movdqa    xmmword ptr [rbp - 0x30], xmm0
0000000140793ff4 lea       rax, [rip + 0x94885]
0000000140793ffb mov       qword ptr [rsp + 0x40], rax
0000000140794000 mov       dword ptr [rsp + 0x48], edi
0000000140794004 movaps    xmm0, xmmword ptr [rsp + 0x40]
0000000140794009 movdqa    xmmword ptr [rbp - 0x20], xmm0
000000014079400e lea       rax, [rip + 0x9590b]
0000000140794015 mov       qword ptr [rsp + 0x40], rax
000000014079401a mov       dword ptr [rsp + 0x48], edi
000000014079401e movaps    xmm0, xmmword ptr [rsp + 0x40]
0000000140794023 movdqa    xmmword ptr [rbp - 0x10], xmm0
0000000140794028 lea       rax, [rip + 0x95881]
000000014079402f mov       qword ptr [rsp + 0x40], rax
0000000140794034 mov       dword ptr [rsp + 0x48], edi
0000000140794038 movaps    xmm0, xmmword ptr [rsp + 0x40]
000000014079403d movdqa    xmmword ptr [rbp], xmm0
0000000140794042 lea       rax, [rip + 0x958c7]
0000000140794049 mov       qword ptr [rsp + 0x40], rax
000000014079404e mov       dword ptr [rsp + 0x48], edi
0000000140794052 movaps    xmm0, xmmword ptr [rsp + 0x40]
0000000140794057 movdqa    xmmword ptr [rbp + 0x10], xmm0
000000014079405c lea       rax, [rip + 0x1b4fd]
0000000140794063 mov       qword ptr [rsp + 0x40], rax
0000000140794068 mov       dword ptr [rsp + 0x48], edi
000000014079406c movaps    xmm0, xmmword ptr [rsp + 0x40]
0000000140794071 movdqa    xmmword ptr [rbp + 0x20], xmm0
0000000140794076 lea       rax, [rip + 0x1b513]
000000014079407d mov       qword ptr [rsp + 0x40], rax
0000000140794082 mov       dword ptr [rsp + 0x48], edi
0000000140794086 movaps    xmm0, xmmword ptr [rsp + 0x40]
000000014079408b movdqa    xmmword ptr [rbp + 0x30], xmm0
0000000140794090 lea       rax, [rip + 0x95849]
0000000140794097 mov       qword ptr [rsp + 0x40], rax
000000014079409c mov       dword ptr [rsp + 0x48], edi
00000001407940a0 movaps    xmm0, xmmword ptr [rsp + 0x40]
00000001407940a5 movdqa    xmmword ptr [rbp + 0x40], xmm0
00000001407940aa lea       rax, [rip + 0x9584f]
00000001407940b1 mov       qword ptr [rsp + 0x40], rax
00000001407940b6 mov       dword ptr [rsp + 0x48], edi
00000001407940ba movaps    xmm0, xmmword ptr [rsp + 0x40]
00000001407940bf movdqa    xmmword ptr [rbp + 0x50], xmm0
00000001407940c4 lea       rax, [rip + 0x95805]
00000001407940cb mov       qword ptr [rsp + 0x40], rax
00000001407940d0 mov       dword ptr [rsp + 0x48], edi
00000001407940d4 movaps    xmm0, xmmword ptr [rsp + 0x40]
00000001407940d9 movdqa    xmmword ptr [rbp + 0x60], xmm0
00000001407940de lea       rax, [rip + 0x957db]
00000001407940e5 mov       qword ptr [rsp + 0x40], rax
00000001407940ea mov       dword ptr [rsp + 0x48], edi
00000001407940ee movaps    xmm0, xmmword ptr [rsp + 0x40]
00000001407940f3 movdqa    xmmword ptr [rbp + 0x70], xmm0
00000001407940f8 lea       rax, [rip + 0x95441]
00000001407940ff mov       qword ptr [rsp + 0x40], rax
0000000140794104 mov       dword ptr [rsp + 0x48], edi
0000000140794108 movaps    xmm0, xmmword ptr [rsp + 0x40]
000000014079410d movdqa    xmmword ptr [rsp + 0x40], xmm0
0000000140794113 mov       rbx, qword ptr [rcx]
0000000140794116 mov       qword ptr [rsp + 0x58], rdi
000000014079411b lea       rcx, [rsp + 0x60]
0000000140794120 call      0x14031e9d0
0000000140794125 nop       
0000000140794126 mov       qword ptr [rsp + 0x60], rbx
000000014079412b lea       rax, [rip + 0x24327e6]
0000000140794132 mov       qword ptr [rsp + 0x68], rax
0000000140794137 lea       r12, [rip + 0x33f4d4a]
000000014079413e mov       qword ptr [rsp + 0x70], r12
0000000140794143 mov       qword ptr [rsp + 0x78], 0x20
000000014079414c mov       qword ptr [rbp - 0x80], 8
0000000140794154 mov       qword ptr [rbp - 0x78], 8
000000014079415c lea       rax, [rip + 0xa8d]
0000000140794163 mov       qword ptr [rbp - 0x68], rax
0000000140794167 lea       rax, [rip - 0x46554e]
000000014079416e mov       qword ptr [rbp - 0x60], rax
0000000140794172 and       byte ptr [rbp - 0x38], 0xf7
0000000140794176 lea       rax, [rip + 0x36847c3]
000000014079417d mov       qword ptr [rbp - 0x40], rax
0000000140794181 lea       rcx, [rsp + 0x60]
0000000140794186 call      0x14031e710
000000014079418b lea       r9, [rip - 0x48fb32]
0000000140794192 lea       r8, [rip + 0x33e9dff]
0000000140794199 mov       rdx, qword ptr [rip + 0x3683580]
00000001407941a0 lea       rcx, [rsp + 0x60]
00000001407941a5 call      0x14032e9a0
00000001407941aa lea       rdx, [rsp + 0x60]
00000001407941af lea       rcx, [rsp + 0x58]
00000001407941b4 call      0x140329430
00000001407941b9 nop       
00000001407941ba mov       rcx, qword ptr [rbp - 0x58]
00000001407941be test      rcx, rcx
00000001407941c1 je        0x1407941e1
00000001407941c3 call      0x142263ff0
00000001407941c8 mov       rax, qword ptr [rbp - 0x58]
00000001407941cc sub       qword ptr [rax], 1
00000001407941d0 mov       rcx, qword ptr [rbp - 0x58]
00000001407941d4 jne       0x1407941e1
00000001407941d6 mov       rax, qword ptr [rcx + 8]
00000001407941da mov       rdx, qword ptr [rax + 0x30]
00000001407941de call      rdx
00000001407941e0 nop       
00000001407941e1 lea       rax, [rip + 0x94728]
00000001407941e8 mov       qword ptr [rsp + 0x30], rax
00000001407941ed lea       r9, [rsp + 0x50]
00000001407941f2 lea       r8, [rsp + 0x30]
00000001407941f7 lea       rdx, [rip + 0x23ec8f2]
00000001407941fe lea       rcx, [rsp + 0x58]
0000000140794203 call      0x140791a20
0000000140794208 lea       r8, [rbp - 0x30]
000000014079420c lea       rdx, [rip + 0x2432715]
0000000140794213 lea       rcx, [rsp + 0x58]
0000000140794218 call      0x140791240
000000014079421d lea       r8, [rbp - 0x20]
0000000140794221 lea       rdx, [rip + 0x2432710]
0000000140794228 mov       rcx, rax
000000014079422b call      0x1407914e0
0000000140794230 lea       r8, [rbp - 0x10]
0000000140794234 lea       rdx, [rip + 0x2432715]
000000014079423b mov       rcx, rax
000000014079423e call      0x140790d00
0000000140794243 lea       r8, [rbp]
0000000140794247 lea       rdx, [rip + 0x2432712]
000000014079424e mov       rcx, rax
0000000140794251 call      0x140791780
0000000140794256 lea       r8, [rbp + 0x10]
000000014079425a lea       rdx, [rip + 0x2432717]
0000000140794261 mov       rcx, rax
0000000140794264 call      0x140790280
0000000140794269 lea       r8, [rbp + 0x20]
000000014079426d lea       rdx, [rip + 0x24319ac]
0000000140794274 mov       rcx, rax
0000000140794277 call      0x14078ffe0
000000014079427c lea       r8, [rbp + 0x30]
0000000140794280 lea       rdx, [rip + 0x24319a9]
0000000140794287 mov       rcx, rax
000000014079428a call      0x14078fd40
000000014079428f lea       r8, [rbp + 0x40]
0000000140794293 lea       rdx, [rip + 0x24326ee]
000000014079429a mov       rcx, rax
000000014079429d call      0x1407907c0
00000001407942a2 lea       r8, [rbp + 0x50]
00000001407942a6 lea       rdx, [rip + 0x2431ea3]
00000001407942ad mov       rcx, rax
00000001407942b0 call      0x140790fa0
00000001407942b5 lea       r8, [rbp + 0x60]
00000001407942b9 lea       rdx, [rip + 0x24326e8]
00000001407942c0 mov       rcx, rax
00000001407942c3 call      0x140790a60
00000001407942c8 lea       r8, [rbp + 0x70]
00000001407942cc lea       rdx, [rip + 0x2431e8d]
00000001407942d3 mov       rcx, rax
00000001407942d6 call      0x140790520
00000001407942db lea       r8, [rsp + 0x40]
00000001407942e0 lea       rdx, [rip + 0x24326d9]
00000001407942e7 mov       rcx, rax
00000001407942ea call      0x140790a60
00000001407942ef mov       r15, rax
00000001407942f2 mov       qword ptr [rsp + 0x30], rdi
00000001407942f7 lea       rcx, [rsp + 0x30]
00000001407942fc call      0x14030bac0
0000000140794301 lea       rcx, [rip - 0x4718]
0000000140794308 mov       qword ptr [rax + 0x30], rcx
000000014079430c mov       qword ptr [rbp + 0x70], r12
0000000140794310 lea       r13, [rip - 0x23d7]
0000000140794317 mov       qword ptr [rbp + 0x78], r13
000000014079431b xorps     xmm0, xmm0
000000014079431e movdqu    xmmword ptr [rbp + 0x80], xmm0
0000000140794326 mov       qword ptr [rsp + 0x20], 1
000000014079432f lea       r9, [rbp + 0x70]
0000000140794333 lea       r8, [rip + 0x2432a36]
000000014079433a mov       rdx, rax
000000014079433d lea       rcx, [rsp + 0x30]
0000000140794342 call      0x140309c90
0000000140794347 nop       
0000000140794348 mov       qword ptr [rsp + 0x40], rdi
000000014079434d mov       rsi, qword ptr [r15]
0000000140794350 mov       rbx, qword ptr [rsp + 0x30]
0000000140794355 mov       rcx, rbx
0000000140794358 call      0x140328ed0
000000014079435d mov       r14, rax
0000000140794360 mov       rcx, rdi
0000000140794363 call      0x140328ed0
0000000140794368 test      r14, r14
000000014079436b je        0x14079437b
000000014079436d or        byte ptr [r14 + 0x59], 0x40
0000000140794372 mov       qword ptr [r14 + 0x68], rsi
0000000140794376 mov       byte ptr [r14 + 0x58], 6
000000014079437b test      rax, rax
000000014079437e je        0x140794393
0000000140794380 or        byte ptr [rax + 0x59], 0x40
0000000140794384 mov       qword ptr [rax + 0x68], rsi
0000000140794388 mov       byte ptr [rax + 0x58], 6
000000014079438c test      r14, r14
000000014079438f cmove     r14, rax
0000000140794393 mov       qword ptr [rsp + 0x20], r14
0000000140794398 mov       r9, rdi
000000014079439b mov       r8, rbx
000000014079439e lea       rdx, [rip + 0x243263b]
00000001407943a5 mov       rcx, r15
00000001407943a8 call      0x140328b40
00000001407943ad nop       
00000001407943ae test      rbx, rbx
00000001407943b1 je        0x1407943cf
00000001407943b3 mov       rcx, rbx
00000001407943b6 call      0x142263ff0
00000001407943bb sub       qword ptr [rbx], 1
00000001407943bf jne       0x1407943cf
00000001407943c1 mov       rax, qword ptr [rbx + 8]
00000001407943c5 mov       rdx, qword ptr [rax + 0x30]
00000001407943c9 mov       rcx, rbx
00000001407943cc call      rdx
00000001407943ce nop       
00000001407943cf mov       qword ptr [rsp + 0x30], rdi
00000001407943d4 lea       rcx, [rsp + 0x30]
00000001407943d9 call      0x14030bac0
00000001407943de lea       rcx, [rip - 0x4915]
00000001407943e5 mov       qword ptr [rax + 0x30], rcx
00000001407943e9 mov       qword ptr [rbp + 0x70], r12
00000001407943ed mov       qword ptr [rbp + 0x78], r13
00000001407943f1 xorps     xmm0, xmm0
00000001407943f4 movdqu    xmmword ptr [rbp + 0x80], xmm0
00000001407943fc mov       qword ptr [rsp + 0x20], 1
0000000140794405 lea       r9, [rbp + 0x70]
0000000140794409 lea       r8, [rip + 0x2432970]
0000000140794410 mov       rdx, rax
0000000140794413 lea       rcx, [rsp + 0x30]
0000000140794418 call      0x140309c90
000000014079441d nop       
000000014079441e mov       qword ptr [rsp + 0x40], rdi
0000000140794423 mov       rsi, qword ptr [r15]
0000000140794426 mov       rbx, qword ptr [rsp + 0x30]
000000014079442b mov       rcx, rbx
000000014079442e call      0x140328ed0
0000000140794433 mov       r14, rax
0000000140794436 mov       rcx, rdi
0000000140794439 call      0x140328ed0
000000014079443e test      r14, r14
0000000140794441 je        0x140794451
0000000140794443 or        byte ptr [r14 + 0x59], 0x40
0000000140794448 mov       qword ptr [r14 + 0x68], rsi
000000014079444c mov       byte ptr [r14 + 0x58], 6
0000000140794451 test      rax, rax
0000000140794454 je        0x140794469
0000000140794456 or        byte ptr [rax + 0x59], 0x40
000000014079445a mov       qword ptr [rax + 0x68], rsi
000000014079445e mov       byte ptr [rax + 0x58], 6
0000000140794462 test      r14, r14
0000000140794465 cmove     r14, rax
0000000140794469 mov       qword ptr [rsp + 0x20], r14
000000014079446e mov       r9, rdi
0000000140794471 mov       r8, rbx
0000000140794474 lea       rdx, [rip + 0x2432575]
000000014079447b mov       rcx, r15
000000014079447e call      0x140328b40
0000000140794483 nop       
0000000140794484 test      rbx, rbx
0000000140794487 je        0x1407944a5
0000000140794489 mov       rcx, rbx
000000014079448c call      0x142263ff0
0000000140794491 sub       qword ptr [rbx], 1
0000000140794495 jne       0x1407944a5
0000000140794497 mov       rax, qword ptr [rbx + 8]
000000014079449b mov       rdx, qword ptr [rax + 0x30]
000000014079449f mov       rcx, rbx
00000001407944a2 call      rdx
00000001407944a4 nop       
00000001407944a5 mov       qword ptr [rsp + 0x30], rdi
00000001407944aa lea       rcx, [rsp + 0x30]
00000001407944af call      0x14030bac0
00000001407944b4 lea       rcx, [rip - 0x496b]
00000001407944bb mov       qword ptr [rax + 0x30], rcx
00000001407944bf mov       qword ptr [rbp + 0x70], r12
00000001407944c3 mov       qword ptr [rbp + 0x78], r13
00000001407944c7 xorps     xmm0, xmm0
00000001407944ca movdqu    xmmword ptr [rbp + 0x80], xmm0
00000001407944d2 mov       qword ptr [rsp + 0x20], 1
00000001407944db lea       r9, [rbp + 0x70]
00000001407944df lea       r8, [rip + 0x24328aa]
00000001407944e6 mov       rdx, rax
00000001407944e9 lea       rcx, [rsp + 0x30]
00000001407944ee call      0x140309c90
00000001407944f3 nop       
00000001407944f4 mov       qword ptr [rsp + 0x40], rdi
00000001407944f9 mov       rsi, qword ptr [r15]
00000001407944fc mov       rbx, qword ptr [rsp + 0x30]
0000000140794501 mov       rcx, rbx
0000000140794504 call      0x140328ed0
0000000140794509 mov       r14, rax
000000014079450c mov       rcx, rdi
000000014079450f call      0x140328ed0
0000000140794514 test      r14, r14
0000000140794517 je        0x140794527
0000000140794519 or        byte ptr [r14 + 0x59], 0x40
000000014079451e mov       qword ptr [r14 + 0x68], rsi
0000000140794522 mov       byte ptr [r14 + 0x58], 6
0000000140794527 test      rax, rax
000000014079452a je        0x14079453f
000000014079452c or        byte ptr [rax + 0x59], 0x40
0000000140794530 mov       qword ptr [rax + 0x68], rsi
0000000140794534 mov       byte ptr [rax + 0x58], 6
0000000140794538 test      r14, r14
000000014079453b cmove     r14, rax
000000014079453f mov       qword ptr [rsp + 0x20], r14
0000000140794544 mov       r9, rdi
0000000140794547 mov       r8, rbx
000000014079454a lea       rdx, [rip + 0x24324af]
0000000140794551 mov       rcx, r15
0000000140794554 call      0x140328b40
0000000140794559 nop       
000000014079455a test      rbx, rbx
000000014079455d je        0x14079457b
000000014079455f mov       rcx, rbx
0000000140794562 call      0x142263ff0
0000000140794567 sub       qword ptr [rbx], 1
000000014079456b jne       0x14079457b
000000014079456d mov       rax, qword ptr [rbx + 8]
0000000140794571 mov       rdx, qword ptr [rax + 0x30]
0000000140794575 mov       rcx, rbx
0000000140794578 call      rdx
000000014079457a nop       
000000014079457b mov       qword ptr [rsp + 0x30], rdi
0000000140794580 lea       rcx, [rsp + 0x30]
0000000140794585 call      0x14030bac0
000000014079458a lea       rcx, [rip - 0x4961]
0000000140794591 mov       qword ptr [rax + 0x30], rcx
0000000140794595 mov       qword ptr [rbp + 0x70], r12
0000000140794599 mov       qword ptr [rbp + 0x78], r13
000000014079459d xorps     xmm0, xmm0
00000001407945a0 movdqu    xmmword ptr [rbp + 0x80], xmm0
00000001407945a8 mov       qword ptr [rsp + 0x20], 1
00000001407945b1 lea       r9, [rbp + 0x70]
00000001407945b5 lea       r8, [rip + 0x24327e4]
00000001407945bc mov       rdx, rax
00000001407945bf lea       rcx, [rsp + 0x30]
00000001407945c4 call      0x140309c90
00000001407945c9 nop       
00000001407945ca mov       qword ptr [rsp + 0x40], rdi
00000001407945cf mov       rsi, qword ptr [r15]
00000001407945d2 mov       rbx, qword ptr [rsp + 0x30]
00000001407945d7 mov       rcx, rbx
00000001407945da call      0x140328ed0
00000001407945df mov       r14, rax
00000001407945e2 mov       rcx, rdi
00000001407945e5 call      0x140328ed0
00000001407945ea test      r14, r14
00000001407945ed je        0x1407945fd
00000001407945ef or        byte ptr [r14 + 0x59], 0x40
00000001407945f4 mov       qword ptr [r14 + 0x68], rsi
00000001407945f8 mov       byte ptr [r14 + 0x58], 6
00000001407945fd test      rax, rax
0000000140794600 je        0x140794615
0000000140794602 or        byte ptr [rax + 0x59], 0x40
0000000140794606 mov       qword ptr [rax + 0x68], rsi
000000014079460a mov       byte ptr [rax + 0x58], 6
000000014079460e test      r14, r14
0000000140794611 cmove     r14, rax
0000000140794615 mov       qword ptr [rsp + 0x20], r14
000000014079461a mov       r9, rdi
000000014079461d mov       r8, rbx
0000000140794620 lea       rdx, [rip + 0x24323f1]
0000000140794627 mov       rcx, r15
000000014079462a call      0x140328b40
000000014079462f nop       
0000000140794630 test      rbx, rbx
0000000140794633 je        0x140794651
0000000140794635 mov       rcx, rbx
0000000140794638 call      0x142263ff0
000000014079463d sub       qword ptr [rbx], 1
0000000140794641 jne       0x140794651
0000000140794643 mov       rax, qword ptr [rbx + 8]
0000000140794647 mov       rdx, qword ptr [rax + 0x30]
000000014079464b mov       rcx, rbx
000000014079464e call      rdx
0000000140794650 nop       
0000000140794651 mov       qword ptr [rsp + 0x30], rdi
0000000140794656 lea       rcx, [rsp + 0x30]
000000014079465b call      0x14030bac0
0000000140794660 lea       rcx, [rip - 0x49b7]
0000000140794667 mov       qword ptr [rax + 0x30], rcx
000000014079466b mov       qword ptr [rbp + 0x70], r12
000000014079466f mov       qword ptr [rbp + 0x78], r13
0000000140794673 xorps     xmm0, xmm0
0000000140794676 movdqu    xmmword ptr [rbp + 0x80], xmm0
000000014079467e mov       qword ptr [rsp + 0x20], 1
0000000140794687 lea       r9, [rbp + 0x70]
000000014079468b lea       r8, [rip + 0x243271e]
0000000140794692 mov       rdx, rax
0000000140794695 lea       rcx, [rsp + 0x30]
000000014079469a call      0x140309c90
000000014079469f nop       
00000001407946a0 mov       qword ptr [rsp + 0x40], rdi
00000001407946a5 mov       rsi, qword ptr [r15]
00000001407946a8 mov       rbx, qword ptr [rsp + 0x30]
00000001407946ad mov       rcx, rbx
00000001407946b0 call      0x140328ed0
00000001407946b5 mov       r14, rax
00000001407946b8 mov       rcx, rdi
00000001407946bb call      0x140328ed0
00000001407946c0 test      r14, r14
00000001407946c3 je        0x1407946d3
00000001407946c5 or        byte ptr [r14 + 0x59], 0x40
00000001407946ca mov       qword ptr [r14 + 0x68], rsi
00000001407946ce mov       byte ptr [r14 + 0x58], 6
00000001407946d3 test      rax, rax
00000001407946d6 je        0x1407946eb
00000001407946d8 or        byte ptr [rax + 0x59], 0x40
00000001407946dc mov       qword ptr [rax + 0x68], rsi
00000001407946e0 mov       byte ptr [rax + 0x58], 6
00000001407946e4 test      r14, r14
00000001407946e7 cmove     r14, rax
00000001407946eb mov       qword ptr [rsp + 0x20], r14
00000001407946f0 mov       r9, rdi
00000001407946f3 mov       r8, rbx
00000001407946f6 lea       rdx, [rip + 0x2431613]
00000001407946fd mov       rcx, r15
0000000140794700 call      0x140328b40
0000000140794705 nop       
0000000140794706 test      rbx, rbx
0000000140794709 je        0x140794727
000000014079470b mov       rcx, rbx
000000014079470e call      0x142263ff0
0000000140794713 sub       qword ptr [rbx], 1
0000000140794717 jne       0x140794727
0000000140794719 mov       rax, qword ptr [rbx + 8]
000000014079471d mov       rdx, qword ptr [rax + 0x30]
0000000140794721 mov       rcx, rbx
0000000140794724 call      rdx
0000000140794726 nop       
0000000140794727 lea       rax, [rip + 0x1c2]
000000014079472e mov       qword ptr [rsp + 0x30], rax
0000000140794733 lea       r8, [rsp + 0x30]
0000000140794738 lea       rdx, [rip + 0x24322f1]
000000014079473f mov       rcx, r15
0000000140794742 call      0x140779350
0000000140794747 lea       rcx, [rip + 0x262]
000000014079474e mov       qword ptr [rsp + 0x30], rcx
0000000140794753 lea       r8, [rsp + 0x30]
0000000140794758 lea       rdx, [rip + 0x24322e9]
000000014079475f mov       rcx, rax
0000000140794762 call      0x140779350
0000000140794767 lea       rcx, [rip + 0x302]
000000014079476e mov       qword ptr [rsp + 0x30], rcx
0000000140794773 lea       r8, [rsp + 0x30]
0000000140794778 lea       rdx, [rip + 0x24322d9]
000000014079477f mov       rcx, rax
0000000140794782 call      0x140779350
0000000140794787 lea       rcx, [rip + 0x3a2]
000000014079478e mov       qword ptr [rsp + 0x30], rcx
0000000140794793 lea       r8, [rsp + 0x30]
0000000140794798 lea       rdx, [rip + 0x24322d1]
000000014079479f mov       rcx, rax
00000001407947a2 call      0x140779350
00000001407947a7 lea       rcx, [rip + 0x82]
00000001407947ae mov       qword ptr [rsp + 0x30], rcx
00000001407947b3 lea       r8, [rsp + 0x30]
00000001407947b8 lea       rdx, [rip + 0x2431581]
00000001407947bf mov       rcx, rax
00000001407947c2 call      0x140779350
00000001407947c7 nop       
00000001407947c8 mov       rcx, qword ptr [rsp + 0x58]
00000001407947cd test      rcx, rcx
00000001407947d0 je        0x1407947f2
00000001407947d2 call      0x142263ff0
00000001407947d7 mov       rax, qword ptr [rsp + 0x58]
00000001407947dc sub       qword ptr [rax], 1
00000001407947e0 mov       rcx, qword ptr [rsp + 0x58]
00000001407947e5 jne       0x1407947f2
00000001407947e7 mov       rax, qword ptr [rcx + 8]
00000001407947eb mov       rdx, qword ptr [rax + 0x30]
00000001407947ef call      rdx
00000001407947f1 nop       
00000001407947f2 mov       rcx, qword ptr [rbp + 0x90]
00000001407947f9 xor       rcx, rsp
00000001407947fc call      0x1424b0f50
0000000140794801 lea       r11, [rsp + 0x1a0]
0000000140794809 mov       rbx, qword ptr [r11 + 0x38]
000000014079480d mov       rsi, qword ptr [r11 + 0x40]
0000000140794811 mov       rdi, qword ptr [r11 + 0x48]
0000000140794815 mov       rsp, r11
0000000140794818 pop       r15
000000014079481a pop       r14
000000014079481c pop       r13
000000014079481e pop       r12
0000000140794820 pop       rbp
0000000140794821 ret       