0000000142538d60 mov       qword ptr [rsp + 8], rbx
0000000142538d65 push      rdi
0000000142538d66 sub       rsp, 0x20
0000000142538d6a mov       rdi, rcx
0000000142538d6d add       rcx, 0x20
0000000142538d71 call      0x140792660
0000000142538d76 mov       rbx, rax
0000000142538d79 mov       rdx, qword ptr [rax + 0x58]
0000000142538d7d lea       r8, [rax + 0x50]
0000000142538d81 mov       rcx, qword ptr [rax + 0x50]
0000000142538d85 call      0x1408268b0
0000000142538d8a mov       rdx, qword ptr [rbx + 0x50]
0000000142538d8e mov       rcx, rdi
0000000142538d91 mov       qword ptr [rbx + 0x58], rdx
0000000142538d95 mov       rax, qword ptr [rdi]
0000000142538d98 mov       rbx, qword ptr [rsp + 0x30]
0000000142538d9d add       rsp, 0x20
0000000142538da1 pop       rdi
0000000142538da2 jmp       qword ptr [rax + 0x18]

0000000142538640 mov       qword ptr [rsp + 8], rbx
0000000142538645 mov       qword ptr [rsp + 0x10], rsi
000000014253864a push      rdi
000000014253864b sub       rsp, 0x20
000000014253864f mov       rdx, rcx
0000000142538652 xor       eax, eax
0000000142538654 mov       rbx, rcx
0000000142538657 add       rcx, 0x18
000000014253865b cmove     rdx, rax
000000014253865f mov       rcx, qword ptr [rcx]
0000000142538662 call      0x1406b1ca0
0000000142538667 mov       rsi, qword ptr [rbx + 0x20]
000000014253866b mov       rbx, qword ptr [rbx + 0x28]
000000014253866f mov       r8, qword ptr [rsi + 0x20]
0000000142538673 mov       rax, qword ptr [rsi + 0x28]
0000000142538677 sub       rax, r8
000000014253867a sar       rax, 3
000000014253867e cmp       rbx, rax
0000000142538681 jb        0x142538698
0000000142538683 lea       r8, [rsi + 0x38]
0000000142538687 lea       rdx, [rbx + 1]
000000014253868b lea       rcx, [rsi + 0x20]
000000014253868f call      0x14058aef0
0000000142538694 mov       r8, qword ptr [rsi + 0x20]
0000000142538698 mov       r8, qword ptr [r8 + rbx*8]
000000014253869c mov       rdx, qword ptr [rsi + 0x18]
00000001425386a0 cmp       r8, rdx
00000001425386a3 jae       0x1425386b4
00000001425386a5 dec       rdx
00000001425386a8 mov       rcx, rsi
00000001425386ab mov       qword ptr [rsi + 0x18], rdx
00000001425386af call      0x140829710
00000001425386b4 mov       rbx, qword ptr [rsp + 0x30]
00000001425386b9 mov       rsi, qword ptr [rsp + 0x38]
00000001425386be add       rsp, 0x20
00000001425386c2 pop       rdi
00000001425386c3 ret       

0000000140792660 mov       qword ptr [rsp + 8], rbx
0000000140792665 push      rdi
0000000140792666 sub       rsp, 0x20
000000014079266a mov       rdi, qword ptr [rcx]
000000014079266d mov       rdx, qword ptr [rcx + 8]
0000000140792671 mov       rbx, qword ptr [rdi + 0x28]
0000000140792675 mov       rcx, qword ptr [rdi + 0x20]
0000000140792679 mov       rax, rbx
000000014079267c sub       rax, rcx
000000014079267f sar       rax, 3
0000000140792683 cmp       rdx, rax
0000000140792686 jae       0x14079268c
0000000140792688 lea       rbx, [rcx + rdx*8]
000000014079268c cmp       rbx, qword ptr [rdi + 0x28]
0000000140792690 je        0x1407926b6
0000000140792692 lea       rcx, [rdi + 0x20]
0000000140792696 call      0x1407925b0
000000014079269b cmp       qword ptr [rax], 0
000000014079269f jl        0x1407926b6
00000001407926a1 imul      rax, qword ptr [rbx], 0xc8
00000001407926a8 add       rax, qword ptr [rdi]
00000001407926ab mov       rbx, qword ptr [rsp + 0x30]
00000001407926b0 add       rsp, 0x20
00000001407926b4 pop       rdi
00000001407926b5 ret       
00000001407926b6 mov       rbx, qword ptr [rsp + 0x30]
00000001407926bb xor       eax, eax
00000001407926bd add       rsp, 0x20
00000001407926c1 pop       rdi
00000001407926c2 ret       

000000014253761d movzx     ebx, byte ptr [r14 + 0x24]
0000000142537622 lea       rcx, [r15 + 0x20]
0000000142537626 call      0x140792660
000000014253762b mov       byte ptr [rax + 0xc4], bl
0000000142537631 movzx     ebx, byte ptr [r14 + 0x25]
0000000142537636 lea       rcx, [r15 + 0x20]
000000014253763a call      0x140792660
000000014253763f mov       byte ptr [rax + 0xc5], bl

00000001425391b0 mov       rdi, qword ptr [r14 + 0x30]
00000001425391b4 cmp       byte ptr [rsi + rdi + 0xc5], 0
00000001425391bc jne       0x1425391cb
00000001425391be call      0x140fdd5d0
00000001425391c3 mov       rdi, qword ptr [r14 + 0x30]
00000001425391c7 test      al, al
00000001425391c9 jne       0x142539212
00000001425391cb lea       rbx, [rsi + rdi]
00000001425391cf mov       rax, qword ptr [rbx + 0x58]
00000001425391d3 cmp       qword ptr [rbx + 0x50], rax
00000001425391d7 je        0x142539361
00000001425391dd mov       rcx, rbx
00000001425391e0 call      0x140669ea0
00000001425391e5 test      al, al
00000001425391e7 setne     cl
00000001425391ea movzx     eax, byte ptr [rbx + 0x48]
00000001425391ee add       al, al
00000001425391f0 or        cl, al
00000001425391f2 mov       byte ptr [rbx + 0x48], cl
00000001425391f5 test      cl, 1
00000001425391f8 je        0x142539361
00000001425391fe movaps    xmm2, xmm14
0000000142539202 mov       rdx, rbx
0000000142539205 mov       rcx, r13
0000000142539208 call      0x1425393e0
000000014253920d jmp       0x142539361
0000000142539212 cmp       byte ptr [rsi + rdi + 0xc6], 0
000000014253921a je        0x142539361