0000000142538f70 mov       qword ptr [rsp + 8], rbx
0000000142538f75 mov       qword ptr [rsp + 0x10], rsi
0000000142538f7a push      rdi
0000000142538f7b sub       rsp, 0x20
0000000142538f7f lea       rdi, [rcx + 0x20]
0000000142538f83 movzx     esi, r8b
0000000142538f87 mov       rcx, rdi
0000000142538f8a movzx     ebx, dl
0000000142538f8d call      0x140792660
0000000142538f92 mov       rcx, rdi
0000000142538f95 mov       r10d, dword ptr [rax + 0xa8]
0000000142538f9c mov       r9d, r10d
0000000142538f9f and       r9d, 0xfffffffe
0000000142538fa3 or        r10d, 1
0000000142538fa7 test      bl, bl
0000000142538fa9 cmove     r10d, r9d
0000000142538fad mov       dword ptr [rax + 0xa8], r10d
0000000142538fb4 call      0x140792660
0000000142538fb9 mov       rbx, qword ptr [rsp + 0x30]
0000000142538fbe mov       edx, dword ptr [rax + 0xa8]
0000000142538fc4 mov       ecx, edx
0000000142538fc6 and       ecx, 0xfffffffd
0000000142538fc9 or        edx, 2
0000000142538fcc test      sil, sil
0000000142538fcf mov       rsi, qword ptr [rsp + 0x38]
0000000142538fd4 cmove     edx, ecx
0000000142538fd7 mov       dword ptr [rax + 0xa8], edx
0000000142538fdd add       rsp, 0x20
0000000142538fe1 pop       rdi
0000000142538fe2 ret       
0000000142538fe3 int3      
0000000142538fe4 int3      
0000000142538fe5 int3      
0000000142538fe6 int3      
0000000142538fe7 int3      
0000000142538fe8 int3      
0000000142538fe9 int3      
0000000142538fea int3      
0000000142538feb int3      
0000000142538fec int3      
0000000142538fed int3      
0000000142538fee int3      
0000000142538fef int3      
0000000142538ff0 mov       rax, rsp
0000000142538ff3 mov       qword ptr [rax + 0x10], rbx
0000000142538ff7 mov       qword ptr [rax + 0x18], rbp
0000000142538ffb mov       qword ptr [rax + 0x20], rsi
0000000142538fff push      rdi
0000000142539000 push      r12
0000000142539002 push      r13
0000000142539004 push      r14
0000000142539006 push      r15
0000000142539008 sub       rsp, 0x120
000000014253900f movaps    xmmword ptr [rax - 0x38], xmm6
0000000142539013 movaps    xmmword ptr [rax - 0x48], xmm7
0000000142539017 movaps    xmmword ptr [rax - 0x58], xmm8
000000014253901c movaps    xmmword ptr [rax - 0x68], xmm9