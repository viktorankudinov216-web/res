import sys,time,json,math,pathlib,unittest,importlib.util,os
spec=importlib.util.spec_from_file_location('fixtures',os.path.join(os.path.dirname(__file__),'test_m0704.py'));fixtures=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixtures)
B=fixtures.B;V=fixtures.V
ROOT=fixtures.ROOT

def run(count,seconds=2.):
 b=B.Bridge(ROOT,executable=sys.executable)
 try:
  until=time.time()+5.
  while not b.ready and not b.failed and time.time()<until:b.poll();time.sleep(.005)
  assert b.ready,(b.failed,'not ready')
  b.reset();p=fixtures.suspension();actors=[fixtures.actor(i+1,1 if i<count//2 else 2) for i in range(count)]
  for a in actors:a.suspension=p
  started=time.time();frames=0;remote=0;peak_poll=0.;all_body=[]
  while time.time()-started<seconds:
   tick=time.perf_counter();b.poll()
   for a in actors:
    a.body=b.solve(a,a.body,[0.]*10,1./60.,[0.]*12,0.)
    remote+=int(getattr(a,'solver_remote',False))
    assert all(math.isfinite(float(a.body[k])) for k in ('height','pitch','roll'))
   b.flush(actors);peak_poll=max(peak_poll,(time.perf_counter()-tick)*1000.);frames+=1
   time.sleep(max(0.,1./60.-(time.perf_counter()-tick)))
  assert not b.failed,b.failed
  assert remote>count*frames*.4,(remote,frames,count,b.stats)
  return dict(actors=count,frames=frames,remote_frame_actor_samples=remote,total_frame_actor_samples=count*frames,worker_stats=dict(b.stats),parent_peak_ms=peak_poll,bytes_sent=b.tx_bytes,bytes_received=b.rx_bytes,process_id=b.process.pid)
 finally:
  process=b.process;b.close()
  if process is not None:process.wait(timeout=5)

class ProcessTests(unittest.TestCase):
 def test_four_actor_real_process(self):self.assertGreater(run(4)['worker_stats']['steps'],30)
 def test_drive_torque_crosses_real_process_bridge(self):
  b=B.Bridge(ROOT,executable=sys.executable)
  try:
   until=time.time()+5.
   while not b.ready and not b.failed and time.time()<until:b.poll();time.sleep(.005)
   self.assertTrue(b.ready,b.failed);b.reset();a=fixtures.actor();a.suspension=fixtures.suspension();until=time.time()+.8
   while time.time()<until:
    b.poll();state=dict(a.body,drive_acceleration=3.,lateral_acceleration=0.);a.body=b.solve(a,state,[0.]*10,1./60.,[0.]*12,0.);b.flush([a]);time.sleep(1./60.)
   self.assertFalse(b.failed);self.assertTrue(a.solver_remote);self.assertLess(a.body['pitch'],-.0001)
  finally:
   process=b.process;b.close()
   if process is not None:process.wait(timeout=5)
 def test_reset_and_crash_fallback(self):
  b=B.Bridge(ROOT,executable=sys.executable)
  try:
   until=time.time()+5.
   while not b.ready and not b.failed and time.time()<until:b.poll();time.sleep(.005)
   self.assertTrue(b.ready,b.failed);old=b.epoch;b.reset();self.assertNotEqual(b.epoch,old)
   b.process.terminate();b.process.wait(timeout=5);b.poll();self.assertIsNotNone(b.failed);self.assertFalse(b.ready)
   a=fixtures.actor();a.suspension=fixtures.suspension();body=b.solve(a,a.body,[0.]*10,1./60.,[0.]*12,0.);self.assertTrue(math.isfinite(body['height']))
  finally:
   process=b.process;b.close()
   if process is not None:process.wait(timeout=5)

if __name__=='__main__':
 if '--bench' in sys.argv:
  result=[run(4,3.),run(30,3.)];pathlib.Path(os.path.join(os.path.dirname(__file__),'worker_bench.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
 else:unittest.main(verbosity=2)
