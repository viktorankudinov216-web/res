00000001424d5d5f mulss     xmm7, dword ptr [rcx + 0x524]
00000001424d5d67 movss     dword ptr [rcx + 0x508], xmm7
00000001424d5d6f movss     xmm0, dword ptr [rcx + 0x4f8]
00000001424d5d77 mulss     xmm0, dword ptr [rip + 0x6b1831]
00000001424d5d7f movaps    xmm3, xmm0
00000001424d5d82 movss     xmm0, dword ptr [rbp - 0x3d]
00000001424d5d87 unpcklps  xmm3, xmm0
00000001424d5d8a movss     xmm0, dword ptr [rbp - 0x39]
00000001424d5d8f movlhps   xmm3, xmm0
00000001424d5d92 movups    xmm0, xmmword ptr [r9 + 0x10]
00000001424d5d97 movaps    xmm2, xmm3
00000001424d5d9a movaps    xmm1, xmm3
00000001424d5d9d shufps    xmm2, xmm3, 0x55
00000001424d5da1 mulps     xmm2, xmm0
00000001424d5da4 movups    xmm0, xmmword ptr [r9]
00000001424d5da8 shufps    xmm1, xmm3, 0
00000001424d5dac mulps     xmm1, xmm0
00000001424d5daf movups    xmm0, xmmword ptr [r9 + 0x20]
00000001424d5db4 shufps    xmm3, xmm3, 0xaa
00000001424d5db8 addps     xmm2, xmm1
00000001424d5dbb mulps     xmm3, xmm0
00000001424d5dbe addps     xmm2, xmm3
00000001424d5dc1 movaps    xmm0, xmm2
00000001424d5dc4 movaps    xmm1, xmm2
00000001424d5dc7 addss     xmm0, dword ptr [rcx + 0x53c]
00000001424d5dcf shufps    xmm1, xmm2, 0x55
00000001424d5dd3 addss     xmm1, dword ptr [rcx + 0x540]
00000001424d5ddb shufps    xmm2, xmm2, 0xaa
00000001424d5ddf addss     xmm2, dword ptr [rcx + 0x544]
00000001424d5de7 unpcklps  xmm0, xmm1
00000001424d5dea movsd     qword ptr [rcx + 0x554], xmm0
00000001424d5df2 movss     dword ptr [rbp - 0x39], xmm2
00000001424d5df7 mov       eax, dword ptr [rbp - 0x39]
00000001424d5dfa mov       dword ptr [rcx + 0x55c], eax
00000001424d5e00 jmp       0x1424d5f49
00000001424d5e05 movss     xmm0, dword ptr [rcx + 0x4f8]
00000001424d5e0d xorps     xmm3, xmm3
00000001424d5e10 mulss     xmm0, dword ptr [rip + 0x6b1798]
00000001424d5e18 movaps    xmm2, xmm0
00000001424d5e1b movss     xmm0, dword ptr [rbp - 0x3d]
00000001424d5e20 unpcklps  xmm2, xmm0
00000001424d5e23 movss     xmm0, dword ptr [rbp - 0x39]
00000001424d5e28 movlhps   xmm2, xmm0
00000001424d5e2b movups    xmm0, xmmword ptr [r9 + 0x10]
00000001424d5e30 movaps    xmm4, xmm2
00000001424d5e33 movaps    xmm1, xmm2
00000001424d5e36 shufps    xmm1, xmm2, 0
00000001424d5e3a shufps    xmm4, xmm2, 0x55
00000001424d5e3e mulps     xmm4, xmm0
00000001424d5e41 movups    xmm0, xmmword ptr [r9]
00000001424d5e45 shufps    xmm2, xmm2, 0xaa
00000001424d5e49 mulps     xmm1, xmm0
00000001424d5e4c movups    xmm0, xmmword ptr [r9 + 0x20]
00000001424d5e51 mulps     xmm2, xmm0
00000001424d5e54 addps     xmm4, xmm1
00000001424d5e57 addps     xmm4, xmm2
00000001424d5e5a movaps    xmm8, xmm4
00000001424d5e5e movaps    xmm6, xmm4
00000001424d5e61 addss     xmm8, dword ptr [rcx + 0x53c]
00000001424d5e6a shufps    xmm6, xmm4, 0x55
00000001424d5e6e addss     xmm6, dword ptr [rcx + 0x540]
00000001424d5e76 shufps    xmm4, xmm4, 0xaa
00000001424d5e7a addss     xmm4, dword ptr [rcx + 0x544]
00000001424d5e82 movaps    xmm0, xmm8
00000001424d5e86 subss     xmm0, dword ptr [rcx + 0x554]
00000001424d5e8e movaps    xmm1, xmm6
00000001424d5e91 subss     xmm1, dword ptr [rcx + 0x558]
00000001424d5e99 movaps    xmm2, xmm4
00000001424d5e9c subss     xmm2, dword ptr [rcx + 0x55c]
00000001424d5ea4 movss     xmm3, xmm0
00000001424d5ea8 xorps     xmm0, xmm0
00000001424d5eab movss     xmm0, xmm1
00000001424d5eaf xorps     xmm1, xmm1
00000001424d5eb2 unpcklps  xmm3, xmm0
00000001424d5eb5 movss     xmm1, xmm13
00000001424d5eba xorps     xmm0, xmm0
00000001424d5ebd movss     xmm0, xmm2
00000001424d5ec1 xorps     xmm2, xmm2
00000001424d5ec4 movlhps   xmm3, xmm0
00000001424d5ec7 movss     xmm2, xmm11
00000001424d5ecc xorps     xmm0, xmm0
00000001424d5ecf movss     xmm0, xmm12
00000001424d5ed4 unpcklps  xmm2, xmm0
00000001424d5ed7 movlhps   xmm2, xmm1
00000001424d5eda mulps     xmm2, xmm3
00000001424d5edd mulps     xmm3, xmm3
00000001424d5ee0 movaps    xmm1, xmm2
00000001424d5ee3 shufps    xmm1, xmm2, 0x99
00000001424d5ee7 movaps    xmm0, xmm1
00000001424d5eea addss     xmm2, xmm1
00000001424d5eee shufps    xmm0, xmm1, 0x55
00000001424d5ef2 movaps    xmm1, xmm3
00000001424d5ef5 shufps    xmm1, xmm3, 0x66
00000001424d5ef9 addss     xmm3, xmm1
00000001424d5efd addss     xmm2, xmm0
00000001424d5f01 movaps    xmm0, xmm1
00000001424d5f04 shufps    xmm0, xmm1, 0x55
00000001424d5f08 addss     xmm3, xmm0
00000001424d5f0c comiss    xmm2, xmm9
00000001424d5f10 shufps    xmm3, xmm3, 0
00000001424d5f14 sqrtps    xmm0, xmm3
00000001424d5f17 jae       0x1424d5f1c
00000001424d5f19 xorps     xmm0, xmm5
00000001424d5f1c movss     dword ptr [rcx + 0x508], xmm0
00000001424d5f24 divss     xmm0, xmm7
00000001424d5f28 movss     dword ptr [rcx + 0x524], xmm0
00000001424d5f30 movss     dword ptr [rcx + 0x554], xmm8
00000001424d5f39 movss     dword ptr [rcx + 0x558], xmm6
00000001424d5f41 movss     dword ptr [rcx + 0x55c], xmm4
00000001424d5f49 movss     xmm3, dword ptr [rbp + 0x7f]
00000001424d5f4e movaps    xmm13, xmmword ptr [rsp + 0x10]
00000001424d5f54 movaps    xmm1, xmm3
00000001424d5f57 subss     xmm1, dword ptr [rcx + 0x560]
00000001424d5f5f movaps    xmm12, xmmword ptr [rsp + 0x20]
00000001424d5f65 movaps    xmm11, xmmword ptr [rsp + 0x30]
00000001424d5f6b movaps    xmm8, xmmword ptr [rsp + 0x60]
00000001424d5f71 movaps    xmm7, xmmword ptr [rsp + 0x70]
00000001424d5f76 movaps    xmm6, xmmword ptr [rsp + 0x80]
00000001424d5f7e movaps    xmm2, xmm1
00000001424d5f81 comiss    xmm1, xmm9
00000001424d5f85 movaps    xmm9, xmmword ptr [rsp + 0x50]
00000001424d5f8b jae       0x1424d5f97