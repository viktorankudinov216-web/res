000000014253ee80 mov       qword ptr [rsp + 0x20], rbx
000000014253ee85 push      rdi
000000014253ee86 sub       rsp, 0x60
000000014253ee8a movups    xmm0, xmmword ptr [rip + 0x1986d77]
000000014253ee91 mov       rdi, rcx
000000014253ee94 mov       qword ptr [rsp + 0x78], rsi
000000014253ee99 mov       rcx, qword ptr [rcx + 0x98]
000000014253eea0 movaps    xmmword ptr [rsp + 0x30], xmm8
000000014253eea6 movaps    xmm8, xmm1
000000014253eeaa movups    xmmword ptr [rsp + 0x20], xmm0
000000014253eeaf test      rcx, rcx
000000014253eeb2 je        0x14253eebf
000000014253eeb4 mov       rax, qword ptr [rcx]
000000014253eeb7 lea       rdx, [rsp + 0x20]
000000014253eebc call      qword ptr [rax + 0x10]
000000014253eebf mov       rbx, qword ptr [rdi + 0x38]
000000014253eec3 mov       rsi, qword ptr [rdi + 0x40]
000000014253eec7 cmp       rbx, rsi
000000014253eeca je        0x14253efdb
000000014253eed0 mov       qword ptr [rsp + 0x70], rbp
000000014253eed5 xor       ebp, ebp
000000014253eed7 mov       qword ptr [rsp + 0x80], r14
000000014253eedf mov       r14d, 0x120
000000014253eee5 movaps    xmmword ptr [rsp + 0x50], xmm6
000000014253eeea movss     xmm6, dword ptr [rip + 0x645742]
000000014253eef2 movaps    xmmword ptr [rsp + 0x40], xmm7
000000014253eef7 movss     xmm7, dword ptr [rip + 0x64d7e1]
000000014253eeff nop       
000000014253ef00 movzx     ecx, byte ptr [rbx + 0x74]
000000014253ef04 test      cl, cl
000000014253ef06 je        0x14253ef11
000000014253ef08 test      byte ptr [rdi + 0x128], 1
000000014253ef0f jmp       0x14253ef1b
000000014253ef11 mov       eax, dword ptr [rdi + 0x128]
000000014253ef17 shr       eax, 1
000000014253ef19 test      al, 1
000000014253ef1b jne       0x14253efb7
000000014253ef21 cmp       byte ptr [rdi + 0x140], bpl
000000014253ef28 jne       0x14253ef54
000000014253ef2a cmp       byte ptr [rbx + 0x75], bpl
000000014253ef2e je        0x14253ef54
000000014253ef30 test      cl, cl
000000014253ef32 mov       eax, 0xe0
000000014253ef37 cmove     rax, r14
000000014253ef3b mov       rdx, qword ptr [rax + rdi]
000000014253ef3f test      rdx, rdx
000000014253ef42 je        0x14253ef54
000000014253ef44 mov       rax, qword ptr [rdx]
000000014253ef47 mov       rcx, rdx
000000014253ef4a call      qword ptr [rax + 0x10]
000000014253ef4d mulss     xmm0, dword ptr [rbx + 0x70]
000000014253ef52 jmp       0x14253efb2
000000014253ef54 movaps    xmm1, xmm6
000000014253ef57 cmp       byte ptr [rbx + 0x76], bpl
000000014253ef5b je        0x14253ef87
000000014253ef5d movss     xmm0, dword ptr [rbx + 0x78]
000000014253ef62 call      qword ptr [rip + 0x628058]
000000014253ef68 movzx     ecx, byte ptr [rbx + 0x74]
000000014253ef6c movaps    xmm1, xmm6
000000014253ef6f subss     xmm1, xmm0
000000014253ef73 mov       byte ptr [rbx + 0x76], bpl
000000014253ef77 movaps    xmm0, xmm8
000000014253ef7b addss     xmm0, dword ptr [rbx + 0x78]
000000014253ef80 movss     dword ptr [rbx + 0x78], xmm0
000000014253ef85 jmp       0x14253ef8a
000000014253ef87 mov       dword ptr [rbx + 0x78], ebp
000000014253ef8a test      cl, cl
000000014253ef8c je        0x14253ef96
000000014253ef8e movss     xmm0, dword ptr [rsp + 0x24]
000000014253ef94 jmp       0x14253ef9c
000000014253ef96 movss     xmm0, dword ptr [rsp + 0x28]
000000014253ef9c mulss     xmm0, dword ptr [rbx + 0x6c]
000000014253efa1 mulss     xmm0, xmm1
000000014253efa5 movaps    xmm1, xmm7
000000014253efa8 addss     xmm0, dword ptr [rbx + 0x64]
000000014253efad call      0x1424b553e
000000014253efb2 movss     dword ptr [rbx + 0x64], xmm0
000000014253efb7 sub       rbx, -0x80
000000014253efbb cmp       rbx, rsi
000000014253efbe jne       0x14253ef00
000000014253efc4 movaps    xmm7, xmmword ptr [rsp + 0x40]
000000014253efc9 movaps    xmm6, xmmword ptr [rsp + 0x50]
000000014253efce mov       r14, qword ptr [rsp + 0x80]
000000014253efd6 mov       rbp, qword ptr [rsp + 0x70]
000000014253efdb lea       rcx, [rdi + 0x148]
000000014253efe2 call      qword ptr [rip + 0x6269c0]
000000014253efe8 movaps    xmm8, xmmword ptr [rsp + 0x30]
000000014253efee mov       rsi, qword ptr [rsp + 0x78]
000000014253eff3 mov       byte ptr [rdi + 0x170], 1
000000014253effa cmp       byte ptr [rdi + 0x12c], 0
000000014253f001 je        0x14253f08c
000000014253f007 mov       rax, qword ptr [rdi + 0x130]
000000014253f00e mov       rax, qword ptr [rax]
000000014253f011 cmp       byte ptr [rax + 0x19], 0
000000014253f015 jne       0x14253f085
000000014253f017 mov       r8, qword ptr [rdi + 0x38]
000000014253f01b nop       dword ptr [rax + rax]
000000014253f020 mov       rdx, qword ptr [rax + 0x20]
000000014253f024 mov       ecx, dword ptr [rax + 0x28]
000000014253f027 shl       rdx, 7
000000014253f02b mov       dword ptr [rdx + r8 + 0x64], ecx
000000014253f030 mov       rcx, qword ptr [rax + 0x10]
000000014253f034 cmp       byte ptr [rcx + 0x19], 0
000000014253f038 je        0x14253f05c
000000014253f03a mov       rcx, qword ptr [rax + 8]
000000014253f03e cmp       byte ptr [rcx + 0x19], 0
000000014253f042 jne       0x14253f057
000000014253f044 cmp       rax, qword ptr [rcx + 0x10]
000000014253f048 jne       0x14253f057
000000014253f04a mov       rax, rcx
000000014253f04d mov       rcx, qword ptr [rcx + 8]
000000014253f051 cmp       byte ptr [rcx + 0x19], 0
000000014253f055 je        0x14253f044
000000014253f057 mov       rax, rcx
000000014253f05a jmp       0x14253f07f
000000014253f05c mov       rdx, qword ptr [rcx]
000000014253f05f mov       rax, rcx
000000014253f062 cmp       byte ptr [rdx + 0x19], 0
000000014253f066 jne       0x14253f07f
000000014253f068 nop       dword ptr [rax + rax]
000000014253f070 mov       rcx, qword ptr [rdx]
000000014253f073 mov       rax, rdx
000000014253f076 mov       rdx, rcx
000000014253f079 cmp       byte ptr [rcx + 0x19], 0
000000014253f07d je        0x14253f070
000000014253f07f cmp       byte ptr [rax + 0x19], 0
000000014253f083 je        0x14253f020
000000014253f085 mov       byte ptr [rdi + 0x12c], 0
000000014253f08c mov       byte ptr [rdi + 0x140], 0
000000014253f093 lea       rcx, [rdi + 0x148]
000000014253f09a mov       byte ptr [rdi + 0x170], 0
000000014253f0a1 call      qword ptr [rip + 0x626909]
000000014253f0a7 mov       rbx, qword ptr [rsp + 0x88]
000000014253f0af add       rsp, 0x60
000000014253f0b3 pop       rdi
000000014253f0b4 ret       
000000014253f0b5 int3      
000000014253f0b6 int3      
000000014253f0b7 int3      
000000014253f0b8 int3      
000000014253f0b9 int3      
000000014253f0ba int3      
000000014253f0bb int3      
000000014253f0bc int3      
000000014253f0bd int3      
000000014253f0be int3      
000000014253f0bf int3      
000000014253f0c0 shl       rdx, 7
000000014253f0c4 add       rdx, qword ptr [rcx + 0x18]
000000014253f0c8 mov       rax, rdx
000000014253f0cb ret       
000000014253f0cc int3      
000000014253f0cd int3      
000000014253f0ce int3      
000000014253f0cf int3      
000000014253f0d0 lea       rax, [rip + 0x9f0019]
000000014253f0d7 mov       qword ptr [rdx], rax
000000014253f0da mov       rax, rdx
000000014253f0dd ret       
000000014253f0de int3      
000000014253f0df int3      
000000014253f0e0 push      rbx
000000014253f0e2 sub       rsp, 0x20
000000014253f0e6 mov       ecx, 0x18
000000014253f0eb mov       rbx, rdx