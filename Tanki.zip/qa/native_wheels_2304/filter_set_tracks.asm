00000001424d8160 mov       qword ptr [rsp + 8], rbx
00000001424d8165 push      rdi
00000001424d8166 sub       rsp, 0x80
00000001424d816d mov       rax, qword ptr [rcx]
00000001424d8170 movzx     edi, r8b
00000001424d8174 movaps    xmmword ptr [rsp + 0x70], xmm6
00000001424d8179 mov       rbx, rcx
00000001424d817c movaps    xmmword ptr [rsp + 0x60], xmm7
00000001424d8181 movaps    xmm6, xmm3
00000001424d8184 movaps    xmm7, xmm1
00000001424d8187 call      qword ptr [rax + 0x10]
00000001424d818a test      rax, rax
00000001424d818d jne       0x1424d81db
00000001424d818f lea       rcx, [rsp + 0x20]
00000001424d8194 call      0x1403e3b80
00000001424d8199 lea       rcx, [rip + 0x6e06e8]
00000001424d81a0 mov       dword ptr [rsp + 0x50], 0x15e
00000001424d81a8 mov       qword ptr [rsp + 0x38], rcx
00000001424d81ad lea       r8, [rip + 0x6e06ac]
00000001424d81b4 lea       rcx, [rip + 0xa510f5]
00000001424d81bb mov       qword ptr [rsp + 0x40], rcx
00000001424d81c0 lea       rdx, [rsp + 0x38]
00000001424d81c5 lea       rcx, [rip + 0x6a7e54]
00000001424d81cc mov       qword ptr [rsp + 0x48], rcx
00000001424d81d1 mov       rcx, rax
00000001424d81d4 call      0x1403e42f0
00000001424d81d9 jmp       0x1424d8209
00000001424d81db mov       rax, qword ptr [rbx]
00000001424d81de mov       rcx, rbx
00000001424d81e1 call      qword ptr [rax + 0x10]
00000001424d81e4 movzx     ecx, byte ptr [rsp + 0xb0]
00000001424d81ec movss     dword ptr [rax + 0x520], xmm7
00000001424d81f4 movss     dword ptr [rax + 0x524], xmm6
00000001424d81fc mov       byte ptr [rax + 0x528], dil
00000001424d8203 mov       byte ptr [rax + 0x529], cl
00000001424d8209 mov       rbx, qword ptr [rsp + 0x90]
00000001424d8211 movaps    xmm6, xmmword ptr [rsp + 0x70]
00000001424d8216 movaps    xmm7, xmmword ptr [rsp + 0x60]
00000001424d821b add       rsp, 0x80
00000001424d8222 pop       rdi
00000001424d8223 ret       