00000001424d7df0 mov       qword ptr [rsp + 8], rbx
00000001424d7df5 push      rdi
00000001424d7df6 sub       rsp, 0x20
00000001424d7dfa mov       rdi, rcx
00000001424d7dfd mov       rbx, rdx
00000001424d7e00 mov       rcx, qword ptr [rcx + 0x10]
00000001424d7e04 mov       rax, qword ptr [rcx]
00000001424d7e07 call      qword ptr [rax + 0x10]
00000001424d7e0a test      rax, rax
00000001424d7e0d je        0x1424d7e29
00000001424d7e0f movsxd    rcx, dword ptr [rdi + 0x20]
00000001424d7e13 movups    xmm0, xmmword ptr [rcx + rax + 0x4f8]
00000001424d7e1b movups    xmmword ptr [rbx], xmm0
00000001424d7e1e mov       rbx, qword ptr [rsp + 0x30]
00000001424d7e23 add       rsp, 0x20
00000001424d7e27 pop       rdi
00000001424d7e28 ret       
00000001424d7e29 mov       qword ptr [rbx], rax
00000001424d7e2c mov       qword ptr [rbx + 8], rax
00000001424d7e30 mov       rbx, qword ptr [rsp + 0x30]
00000001424d7e35 add       rsp, 0x20
00000001424d7e39 pop       rdi
00000001424d7e3a ret       
00000001424d7e3b int3      
00000001424d7e3c int3      
00000001424d7e3d int3      
00000001424d7e3e int3      
00000001424d7e3f int3      
00000001424d7e40 mov       qword ptr [rsp + 0x10], rbx
00000001424d7e45 mov       qword ptr [rsp + 0x18], rbp
00000001424d7e4a mov       qword ptr [rsp + 0x20], rsi
00000001424d7e4f push      rdi
00000001424d7e50 push      r14
00000001424d7e52 push      r15
00000001424d7e54 sub       rsp, 0x40
00000001424d7e58 mov       rsi, rdx
00000001424d7e5b mov       rbx, rcx
00000001424d7e5e xorps     xmm0, xmm0
00000001424d7e61 movdqu    xmmword ptr [rsp + 0x30], xmm0
00000001424d7e67 mov       r8, qword ptr [rcx + 0x10]
00000001424d7e6b test      r8, r8
00000001424d7e6e je        0x1424d7f88
00000001424d7e74 mov       eax, dword ptr [r8 + 8]
00000001424d7e78 test      eax, eax
00000001424d7e7a je        0x1424d7f88
00000001424d7e80 lea       ecx, [rax + 1]
00000001424d7e83 lock cmpxchg dword ptr [r8 + 8], ecx
00000001424d7e89 je        0x1424d7e95
00000001424d7e8b test      eax, eax
00000001424d7e8d je        0x1424d7f88
00000001424d7e93 jmp       0x1424d7e80
00000001424d7e95 mov       r15, qword ptr [rbx + 8]
00000001424d7e99 mov       rbx, qword ptr [rbx + 0x10]
00000001424d7e9d mov       qword ptr [rsp + 0x20], r15
00000001424d7ea2 mov       rbp, rbx
00000001424d7ea5 mov       qword ptr [rsp + 0x28], rbx
00000001424d7eaa xorps     xmm0, xmm0
00000001424d7ead movdqu    xmmword ptr [rsp + 0x30], xmm0
00000001424d7eb3 mov       ecx, 0x38
00000001424d7eb8 call      0x1424b0e74
00000001424d7ebd mov       rdi, rax
00000001424d7ec0 mov       qword ptr [rsp + 0x60], rax
00000001424d7ec5 test      rax, rax
00000001424d7ec8 je        0x1424d7f2d
00000001424d7eca xorps     xmm0, xmm0
00000001424d7ecd movups    xmmword ptr [rax], xmm0
00000001424d7ed0 mov       dword ptr [rax + 8], 1
00000001424d7ed7 mov       dword ptr [rax + 0xc], 1
00000001424d7ede lea       rax, [rip + 0xa5147b]
00000001424d7ee5 mov       qword ptr [rdi], rax
00000001424d7ee8 xor       edx, edx
00000001424d7eea lea       rcx, [rdi + 0x10]