000000014253eaa0 xor       eax, eax
000000014253eaa2 mov       dword ptr [rcx + 0x128], eax
000000014253eaa8 test      dl, dl
000000014253eaaa je        0x14253eab7
000000014253eaac mov       eax, 1
000000014253eab1 mov       dword ptr [rcx + 0x128], eax
000000014253eab7 test      r8b, r8b
000000014253eaba je        0x14253eac5
000000014253eabc or        eax, 2
000000014253eabf mov       dword ptr [rcx + 0x128], eax
000000014253eac5 ret       
000000014253eac6 int3      
000000014253eac7 int3      
000000014253eac8 int3      
000000014253eac9 int3      
000000014253eaca int3      
000000014253eacb int3      
000000014253eacc int3      
000000014253eacd int3      
000000014253eace int3      
000000014253eacf int3      
000000014253ead0 movzx     eax, word ptr [rip + 0x18d9ee1]
000000014253ead7 ret       
000000014253ead8 int3      
000000014253ead9 int3      
000000014253eada int3      
000000014253eadb int3      
000000014253eadc int3      
000000014253eadd int3      
000000014253eade int3      
000000014253eadf int3      
000000014253eae0 mov       rax, rsp
000000014253eae3 push      rbp
000000014253eae4 push      rsi
000000014253eae5 push      r14
000000014253eae7 sub       rsp, 0xe0
000000014253eaee mov       r14, qword ptr [rcx + 0x40]
000000014253eaf2 xorps     xmm0, xmm0
000000014253eaf5 mov       rsi, qword ptr [rcx + 0x38]
000000014253eaf9 mov       rbp, rcx
000000014253eafc movaps    xmmword ptr [rax - 0x28], xmm6
000000014253eb00 xorps     xmm6, xmm6
000000014253eb03 movaps    xmmword ptr [rax - 0x68], xmm10
000000014253eb08 xorps     xmm10, xmm10
000000014253eb0c movaps    xmmword ptr [rax - 0x78], xmm11
000000014253eb11 xorps     xmm11, xmm11
000000014253eb15 movaps    xmmword ptr [rsp + 0x70], xmm12
000000014253eb1b xorps     xmm12, xmm12
000000014253eb1f movaps    xmmword ptr [rsp + 0x60], xmm13
000000014253eb25 xorps     xmm13, xmm13
000000014253eb29 movups    xmmword ptr [rsp + 0x30], xmm6
000000014253eb2e movups    xmmword ptr [rsp + 0x20], xmm0
000000014253eb33 cmp       rsi, r14
000000014253eb36 je        0x14253ee57
000000014253eb3c movss     xmm1, dword ptr [rip + 0x648a78]
000000014253eb44 mov       qword ptr [rax + 0x10], rbx
000000014253eb48 mov       qword ptr [rax + 0x18], rdi
000000014253eb4c lea       rdi, [rsi + 0x44]
000000014253eb50 movaps    xmmword ptr [rax - 0x38], xmm7
000000014253eb54 movaps    xmmword ptr [rax - 0x48], xmm8
000000014253eb59 movaps    xmmword ptr [rax - 0x58], xmm9
000000014253eb5e movaps    xmmword ptr [rsp + 0x50], xmm14
000000014253eb64 movss     xmm14, dword ptr [rip + 0x648a43]
000000014253eb6d movaps    xmmword ptr [rsp + 0x40], xmm15
000000014253eb73 movss     xmm15, dword ptr [rip + 0x645ab8]
000000014253eb7c nop       dword ptr [rax]
000000014253eb80 ucomiss   xmm10, xmm11
000000014253eb84 je        0x14253eb91
000000014253eb86 ucomiss   xmm10, dword ptr [rdi + 0x20]
000000014253eb8b je        0x14253ece8
000000014253eb91 movss     xmm10, dword ptr [rdi + 0x20]
000000014253eb97 comiss    xmm10, xmm11
000000014253eb9b movaps    xmm0, xmm10
000000014253eb9f mulss     xmm0, dword ptr [rip + 0x64db21]
000000014253eba7 jb        0x14253ebb0
000000014253eba9 addss     xmm0, xmm14
000000014253ebae jmp       0x14253ebb5
000000014253ebb0 subss     xmm0, xmm14
000000014253ebb5 cvttss2si eax, xmm0
000000014253ebb9 movaps    xmm2, xmm10
000000014253ebbd movd      xmm0, eax
000000014253ebc1 cvtdq2ps  xmm0, xmm0
000000014253ebc4 mulss     xmm0, dword ptr [rip + 0x64db14]
000000014253ebcc subss     xmm2, xmm0
000000014253ebd0 comiss    xmm2, dword ptr [rip + 0x64db05]
000000014253ebd7 jbe       0x14253ebed
000000014253ebd9 movss     xmm0, dword ptr [rip + 0x64b6c3]
000000014253ebe1 movaps    xmm3, xmm1
000000014253ebe4 subss     xmm0, xmm2
000000014253ebe8 movaps    xmm2, xmm0
000000014253ebeb jmp       0x14253ec0e
000000014253ebed comiss    xmm2, dword ptr [rip + 0x64dafc]
000000014253ebf4 jae       0x14253ec0a
000000014253ebf6 movss     xmm0, dword ptr [rip + 0x64daf6]
000000014253ebfe movaps    xmm3, xmm1
000000014253ec01 subss     xmm0, xmm2
000000014253ec05 movaps    xmm2, xmm0
000000014253ec08 jmp       0x14253ec0e
000000014253ec0a movaps    xmm3, xmm15
000000014253ec0e movss     xmm4, dword ptr [rip + 0x64da9e]
000000014253ec16 movaps    xmm1, xmm2
000000014253ec19 movaps    xmm6, xmmword ptr [rip + 0x641510]
000000014253ec20 movaps    xmm13, xmm11
000000014253ec24 mulss     xmm1, xmm2
000000014253ec28 movaps    xmm12, xmm11
000000014253ec2c movups    xmmword ptr [rsp + 0x30], xmm6
000000014253ec31 movaps    xmm0, xmm1
000000014253ec34 mulss     xmm0, dword ptr [rip + 0x64da70]
000000014253ec3c subss     xmm4, xmm0
000000014253ec40 movaps    xmm0, xmm1
000000014253ec43 mulss     xmm0, dword ptr [rip + 0x64da5d]
000000014253ec4b mulss     xmm4, xmm1
000000014253ec4f subss     xmm4, dword ptr [rip + 0x64da65]
000000014253ec57 mulss     xmm4, xmm1
000000014253ec5b addss     xmm4, dword ptr [rip + 0x64da61]
000000014253ec63 mulss     xmm4, xmm1
000000014253ec67 subss     xmm4, xmm14
000000014253ec6c mulss     xmm4, xmm1
000000014253ec70 addss     xmm4, xmm15
000000014253ec75 mulss     xmm4, xmm3
000000014253ec79 movss     xmm3, dword ptr [rip + 0x64da2f]
000000014253ec81 subss     xmm3, xmm0
000000014253ec85 movaps    xmm0, xmmword ptr [rip + 0x6414d4]
000000014253ec8c unpcklps  xmm13, xmm4