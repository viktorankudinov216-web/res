# Проверенный контракт TankWheelsAnimator / #2304 x64

Исходный Tanki.exe только прочитан и дизассемблирован. В клиент не записываются адреса,
не устанавливаются хуки и не выполняются машинные инструкции из этих файлов.
SHA-256: `571b59a0449cec88aa74880b67f14600187ba328fdc532a9ba4de1800ff1d39b`.

- Python-обёртка `setMovementInfo`: 0x1407aa070 → 0x14253e7f0.
  Нативный shared Vector4Provider сохраняется в компоненте по +0x98.
- Tick 0x14253ee80 вызывает provider.value; для левого катка берёт Vector4.y,
  для правого Vector4.z; умножает на обратный радиус и добавляет к углу.
  На этой ветке НЕТ умножения на dt. Это путь за кадр, а не скорость м/с.
- `stopAnimatingWheels`: 0x1407aa100 → 0x14253eaa0, два bool;
  `(False, False)` обнуляет оба бита остановки +0x128.
- `getWheelsSpeed` не является методом TankWheelsAnimator (это другой animator).
- `setTracksSpeed` 0x1424d8160 пишет +0x520/+0x524. Штатный movementInfo
  читает другую область: +0x500/+0x504/+0x508/+0x50c. Нативное обновление фильтра
  отдельно вычисляет speed*dt в +0x504/+0x508. При внешней матрице/локальной
  симуляции просто записать setTracksSpeed недостаточно для этого канала.

В M09 подключён стандартный Math.Vector4Animation с одинаковыми ключами,
который передаёт (meanDistance, leftSpeed*frameDt, rightSpeed*frameDt, 0).
Подача каждый render frame; scroll links, spline links и штатный TrackNodesAnimator
сохранены. При смерти/завершении/выходе значение обнуляется.
Штатные Suspension и tessellation collision sensor сохранены.

Повторить проверки: `TANKI_EXE=/path/Tanki.exe python2.7 qa/test_native_wheel_binary.py`.
В Windows задать переменную окружения соответствующим способом. Сам EXE в архив
не включён. Проверки PE и mock-тесты не означают визуальную проверку в игре.
