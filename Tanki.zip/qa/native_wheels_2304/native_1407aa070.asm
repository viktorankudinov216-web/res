00000001407aa070 sub       rsp, 0x38
00000001407aa074 mov       r8, qword ptr [rdx + 8]
00000001407aa078 xorps     xmm0, xmm0
00000001407aa07b mov       rcx, qword ptr [rcx + 0x18]
00000001407aa07f movdqu    xmmword ptr [rsp + 0x20], xmm0
00000001407aa085 test      r8, r8
00000001407aa088 je        0x1407aa093
00000001407aa08a lock inc  dword ptr [r8 + 8]
00000001407aa08f mov       r8, qword ptr [rdx + 8]
00000001407aa093 mov       rax, qword ptr [rdx]
00000001407aa096 lea       rdx, [rsp + 0x20]
00000001407aa09b mov       qword ptr [rsp + 0x20], rax
00000001407aa0a0 mov       qword ptr [rsp + 0x28], r8
00000001407aa0a5 call      0x14253e7f0
00000001407aa0aa add       rsp, 0x38
00000001407aa0ae ret       