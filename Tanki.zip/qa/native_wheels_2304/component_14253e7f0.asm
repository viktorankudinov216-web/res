000000014253e7f0 mov       qword ptr [rsp + 8], rbx
000000014253e7f5 mov       qword ptr [rsp + 0x10], rsi
000000014253e7fa push      rdi
000000014253e7fb sub       rsp, 0x20
000000014253e7ff mov       rax, qword ptr [rdx]
000000014253e802 mov       rsi, rdx
000000014253e805 mov       r8, qword ptr [rdx + 8]
000000014253e809 xor       edx, edx
000000014253e80b mov       qword ptr [rsi], rdx
000000014253e80e mov       qword ptr [rsi + 8], rdx
000000014253e812 lea       edi, [rdx - 1]
000000014253e815 mov       rbx, qword ptr [rcx + 0xa0]
000000014253e81c mov       qword ptr [rcx + 0x98], rax
000000014253e823 mov       qword ptr [rcx + 0xa0], r8
000000014253e82a test      rbx, rbx
000000014253e82d je        0x14253e858
000000014253e82f mov       eax, edi
000000014253e831 lock xadd dword ptr [rbx + 8], eax
000000014253e836 cmp       eax, 1
000000014253e839 jne       0x14253e858
000000014253e83b mov       rax, qword ptr [rbx]
000000014253e83e mov       rcx, rbx
000000014253e841 call      qword ptr [rax]
000000014253e843 mov       eax, edi
000000014253e845 lock xadd dword ptr [rbx + 0xc], eax
000000014253e84a cmp       eax, 1
000000014253e84d jne       0x14253e858
000000014253e84f mov       rax, qword ptr [rbx]
000000014253e852 mov       rcx, rbx
000000014253e855 call      qword ptr [rax + 8]
000000014253e858 mov       rbx, qword ptr [rsi + 8]
000000014253e85c test      rbx, rbx
000000014253e85f je        0x14253e888
000000014253e861 mov       eax, edi
000000014253e863 lock xadd dword ptr [rbx + 8], eax
000000014253e868 cmp       eax, 1
000000014253e86b jne       0x14253e888
000000014253e86d mov       rax, qword ptr [rbx]
000000014253e870 mov       rcx, rbx
000000014253e873 call      qword ptr [rax]
000000014253e875 lock xadd dword ptr [rbx + 0xc], edi
000000014253e87a cmp       edi, 1
000000014253e87d jne       0x14253e888
000000014253e87f mov       rax, qword ptr [rbx]
000000014253e882 mov       rcx, rbx
000000014253e885 call      qword ptr [rax + 8]
000000014253e888 mov       rbx, qword ptr [rsp + 0x30]
000000014253e88d mov       rsi, qword ptr [rsp + 0x38]
000000014253e892 add       rsp, 0x20
000000014253e896 pop       rdi
000000014253e897 ret       