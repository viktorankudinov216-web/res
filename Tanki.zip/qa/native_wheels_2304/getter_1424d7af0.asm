00000001424d7af0 mov       qword ptr [rsp + 0x10], rbx
00000001424d7af5 mov       qword ptr [rsp + 0x18], rbp
00000001424d7afa mov       qword ptr [rsp + 0x20], rsi
00000001424d7aff push      rdi
00000001424d7b00 push      r14
00000001424d7b02 push      r15
00000001424d7b04 sub       rsp, 0x40
00000001424d7b08 mov       rsi, rdx
00000001424d7b0b mov       rbx, rcx
00000001424d7b0e xorps     xmm0, xmm0
00000001424d7b11 movdqu    xmmword ptr [rsp + 0x30], xmm0
00000001424d7b17 mov       r8, qword ptr [rcx + 0x10]
00000001424d7b1b test      r8, r8
00000001424d7b1e je        0x1424d7c38
00000001424d7b24 mov       eax, dword ptr [r8 + 8]
00000001424d7b28 test      eax, eax
00000001424d7b2a je        0x1424d7c38
00000001424d7b30 lea       ecx, [rax + 1]
00000001424d7b33 lock cmpxchg dword ptr [r8 + 8], ecx
00000001424d7b39 je        0x1424d7b45
00000001424d7b3b test      eax, eax
00000001424d7b3d je        0x1424d7c38
00000001424d7b43 jmp       0x1424d7b30
00000001424d7b45 mov       r15, qword ptr [rbx + 8]
00000001424d7b49 mov       rbx, qword ptr [rbx + 0x10]
00000001424d7b4d mov       qword ptr [rsp + 0x20], r15
00000001424d7b52 mov       rbp, rbx
00000001424d7b55 mov       qword ptr [rsp + 0x28], rbx
00000001424d7b5a xorps     xmm0, xmm0
00000001424d7b5d movdqu    xmmword ptr [rsp + 0x30], xmm0
00000001424d7b63 mov       ecx, 0x38
00000001424d7b68 call      0x1424b0e74
00000001424d7b6d mov       rdi, rax
00000001424d7b70 mov       qword ptr [rsp + 0x60], rax
00000001424d7b75 test      rax, rax
00000001424d7b78 je        0x1424d7bdd
00000001424d7b7a xorps     xmm0, xmm0
00000001424d7b7d movups    xmmword ptr [rax], xmm0
00000001424d7b80 mov       dword ptr [rax + 8], 1
00000001424d7b87 mov       dword ptr [rax + 0xc], 1
00000001424d7b8e lea       rax, [rip + 0xa517cb]
00000001424d7b95 mov       qword ptr [rdi], rax
00000001424d7b98 xor       edx, edx
00000001424d7b9a lea       rcx, [rdi + 0x10]
00000001424d7b9e call      0x1423fcd40
00000001424d7ba3 lea       rax, [rip + 0xa5166e]
00000001424d7baa mov       qword ptr [rdi + 0x10], rax
00000001424d7bae mov       qword ptr [rdi + 0x20], 0
00000001424d7bb6 mov       qword ptr [rdi + 0x28], 0
00000001424d7bbe test      rbx, rbx
00000001424d7bc1 je        0x1424d7bcc
00000001424d7bc3 lock inc  dword ptr [rbx + 8]
00000001424d7bc7 mov       rbp, qword ptr [rsp + 0x28]
00000001424d7bcc mov       qword ptr [rdi + 0x20], r15
00000001424d7bd0 mov       qword ptr [rdi + 0x28], rbx
00000001424d7bd4 mov       dword ptr [rdi + 0x30], 8
00000001424d7bdb jmp       0x1424d7bdf
00000001424d7bdd xor       edi, edi
00000001424d7bdf lea       rax, [rdi + 0x10]
00000001424d7be3 mov       qword ptr [rsi], rax
00000001424d7be6 mov       qword ptr [rsi + 8], rdi
00000001424d7bea test      rbp, rbp
00000001424d7bed je        0x1424d7c1c
00000001424d7bef mov       edi, 0xffffffff
00000001424d7bf4 mov       eax, edi
00000001424d7bf6 lock xadd dword ptr [rbx + 8], eax
00000001424d7bfb cmp       eax, 1
00000001424d7bfe jne       0x1424d7c1c
00000001424d7c00 mov       rax, qword ptr [rbx]
00000001424d7c03 mov       rcx, rbx
00000001424d7c06 call      qword ptr [rax]
00000001424d7c08 lock xadd dword ptr [rbx + 0xc], edi
00000001424d7c0d cmp       edi, 1
00000001424d7c10 jne       0x1424d7c1c
00000001424d7c12 mov       rax, qword ptr [rbx]
00000001424d7c15 mov       rcx, rbx
00000001424d7c18 call      qword ptr [rax + 8]
00000001424d7c1b nop       
00000001424d7c1c mov       rax, rsi
00000001424d7c1f mov       rbx, qword ptr [rsp + 0x68]
00000001424d7c24 mov       rbp, qword ptr [rsp + 0x70]
00000001424d7c29 mov       rsi, qword ptr [rsp + 0x78]
00000001424d7c2e add       rsp, 0x40
00000001424d7c32 pop       r15
00000001424d7c34 pop       r14
00000001424d7c36 pop       rdi
00000001424d7c37 ret       
00000001424d7c38 call      0x140335990
00000001424d7c3d int3      