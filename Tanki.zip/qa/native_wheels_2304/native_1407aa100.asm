00000001407aa0c0 add       ecx, dword ptr [rax - 0x75]
00000001407aa0c3 ror       byte ptr [rax - 0x7d], 1