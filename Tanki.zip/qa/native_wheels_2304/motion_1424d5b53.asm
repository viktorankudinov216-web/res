00000001424d5b53 movaps    xmmword ptr [rsp + 0x60], xmm8
00000001424d5b59 mov       qword ptr [rbp - 0x3d], 0
00000001424d5b61 je        0x1424d5c10
00000001424d5b67 movaps    xmm0, xmm7
00000001424d5b6a mulss     xmm0, dword ptr [rcx + 0x520]
00000001424d5b72 movss     dword ptr [rcx + 0x504], xmm0
00000001424d5b7a movss     xmm1, dword ptr [rcx + 0x4f8]
00000001424d5b82 mulss     xmm1, dword ptr [rip + 0x6b6b62]
00000001424d5b8a movss     xmm0, dword ptr [rbp - 0x3d]
00000001424d5b8f movaps    xmm3, xmm1
00000001424d5b92 unpcklps  xmm3, xmm0
00000001424d5b95 movss     xmm0, dword ptr [rbp - 0x39]
00000001424d5b9a movlhps   xmm3, xmm0
00000001424d5b9d movups    xmm0, xmmword ptr [r9]
00000001424d5ba1 movaps    xmm2, xmm3
00000001424d5ba4 movaps    xmm1, xmm3
00000001424d5ba7 shufps    xmm2, xmm3, 0
00000001424d5bab mulps     xmm2, xmm0
00000001424d5bae movups    xmm0, xmmword ptr [r9 + 0x10]
00000001424d5bb3 shufps    xmm1, xmm3, 0x55
00000001424d5bb7 mulps     xmm1, xmm0
00000001424d5bba movups    xmm0, xmmword ptr [r9 + 0x20]
00000001424d5bbf shufps    xmm3, xmm3, 0xaa
00000001424d5bc3 addps     xmm2, xmm1
00000001424d5bc6 mulps     xmm3, xmm0
00000001424d5bc9 addps     xmm2, xmm3
00000001424d5bcc movaps    xmm0, xmm2
00000001424d5bcf movaps    xmm1, xmm2
00000001424d5bd2 addss     xmm0, dword ptr [rcx + 0x53c]
00000001424d5bda shufps    xmm1, xmm2, 0x55
00000001424d5bde addss     xmm1, dword ptr [rcx + 0x540]
00000001424d5be6 shufps    xmm2, xmm2, 0xaa
00000001424d5bea addss     xmm2, dword ptr [rcx + 0x544]
00000001424d5bf2 unpcklps  xmm0, xmm1
00000001424d5bf5 movsd     qword ptr [rcx + 0x548], xmm0
00000001424d5bfd movss     dword ptr [rbp - 0x39], xmm2
00000001424d5c02 mov       eax, dword ptr [rbp - 0x39]
00000001424d5c05 mov       dword ptr [rcx + 0x550], eax
00000001424d5c0b jmp       0x1424d5d44
00000001424d5c10 movss     xmm0, dword ptr [rcx + 0x4f8]
00000001424d5c18 xorps     xmm3, xmm3
00000001424d5c1b mulss     xmm0, dword ptr [rip + 0x6b6ac9]
00000001424d5c23 movaps    xmm2, xmm0
00000001424d5c26 movss     xmm0, dword ptr [rbp - 0x3d]
00000001424d5c2b unpcklps  xmm2, xmm0
00000001424d5c2e movss     xmm0, dword ptr [rbp - 0x39]
00000001424d5c33 movlhps   xmm2, xmm0
00000001424d5c36 movups    xmm0, xmmword ptr [r9]
00000001424d5c3a movaps    xmm4, xmm2
00000001424d5c3d movaps    xmm1, xmm2
00000001424d5c40 shufps    xmm1, xmm2, 0x55
00000001424d5c44 shufps    xmm4, xmm2, 0
00000001424d5c48 mulps     xmm4, xmm0
00000001424d5c4b movups    xmm0, xmmword ptr [r9 + 0x10]
00000001424d5c50 shufps    xmm2, xmm2, 0xaa
00000001424d5c54 mulps     xmm1, xmm0
00000001424d5c57 movups    xmm0, xmmword ptr [r9 + 0x20]
00000001424d5c5c mulps     xmm2, xmm0
00000001424d5c5f addps     xmm4, xmm1
00000001424d5c62 addps     xmm4, xmm2
00000001424d5c65 movaps    xmm8, xmm4
00000001424d5c69 movaps    xmm6, xmm4
00000001424d5c6c addss     xmm8, dword ptr [rcx + 0x53c]
00000001424d5c75 shufps    xmm6, xmm4, 0x55
00000001424d5c79 addss     xmm6, dword ptr [rcx + 0x540]
00000001424d5c81 shufps    xmm4, xmm4, 0xaa
00000001424d5c85 addss     xmm4, dword ptr [rcx + 0x544]
00000001424d5c8d movaps    xmm0, xmm8
00000001424d5c91 subss     xmm0, dword ptr [rcx + 0x548]
00000001424d5c99 movaps    xmm1, xmm6
00000001424d5c9c subss     xmm1, dword ptr [rcx + 0x54c]
00000001424d5ca4 movaps    xmm2, xmm4
00000001424d5ca7 subss     xmm2, dword ptr [rcx + 0x550]
00000001424d5caf movss     xmm3, xmm0
00000001424d5cb3 xorps     xmm0, xmm0
00000001424d5cb6 movss     xmm0, xmm1
00000001424d5cba movss     dword ptr [rbp - 0x3d], xmm1
00000001424d5cbf unpcklps  xmm3, xmm0
00000001424d5cc2 xorps     xmm0, xmm0
00000001424d5cc5 movss     xmm0, xmm2
00000001424d5cc9 movss     dword ptr [rbp - 0x39], xmm2
00000001424d5cce movlhps   xmm3, xmm0
00000001424d5cd1 movaps    xmm2, xmm3
00000001424d5cd4 mulps     xmm3, xmm3
00000001424d5cd7 mulps     xmm2, xmm10
00000001424d5cdb movaps    xmm1, xmm2
00000001424d5cde shufps    xmm1, xmm2, 0x99
00000001424d5ce2 movaps    xmm0, xmm1
00000001424d5ce5 addss     xmm2, xmm1
00000001424d5ce9 shufps    xmm0, xmm1, 0x55
00000001424d5ced movaps    xmm1, xmm3
00000001424d5cf0 shufps    xmm1, xmm3, 0x66
00000001424d5cf4 addss     xmm3, xmm1
00000001424d5cf8 addss     xmm2, xmm0
00000001424d5cfc movaps    xmm0, xmm1
00000001424d5cff shufps    xmm0, xmm1, 0x55
00000001424d5d03 addss     xmm3, xmm0
00000001424d5d07 comiss    xmm2, xmm9
00000001424d5d0b shufps    xmm3, xmm3, 0
00000001424d5d0f sqrtps    xmm0, xmm3
00000001424d5d12 jae       0x1424d5d17
00000001424d5d14 xorps     xmm0, xmm5
00000001424d5d17 movss     dword ptr [rcx + 0x504], xmm0
00000001424d5d1f divss     xmm0, xmm7
00000001424d5d23 movss     dword ptr [rcx + 0x520], xmm0
00000001424d5d2b movss     dword ptr [rcx + 0x548], xmm8
00000001424d5d34 movss     dword ptr [rcx + 0x54c], xmm6
00000001424d5d3c movss     dword ptr [rcx + 0x550], xmm4
00000001424d5d44 cmp       byte ptr [rcx + 0x529], 0
00000001424d5d4b movaps    xmm10, xmmword ptr [rsp + 0x40]
00000001424d5d51 mov       qword ptr [rbp - 0x3d], 0
00000001424d5d59 je        0x1424d5e05