# -*- coding: utf-8 -*-
from __future__ import print_function
import sys,types,unittest,math,ast,pickle,zlib,collections,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import test_m0704 as F
from trial146 import combat146 as M
class Obj(object):
 def __init__(self,**kw):self.__dict__.update(kw)
class NativeContractTests(unittest.TestCase):
 def setUp(self):
  self.saved={k:sys.modules.get(k) for k in ('constants','BattleFeedbackCommon','BigWorld')}
  reasons=Obj(NONE='none',SHOT='shot',WORLD_COLLISION='world',MINEFIELD_EQ='mine',FIRE_CIRCLE='fire',CORRODING_SHOT='corrode',THUNDER_STRIKE='thunder')
  constants=types.ModuleType('constants');constants.ATTACK_REASON=reasons;constants.ATTACK_REASON_INDICES=collections.defaultdict(int,shot=1,world=2);constants.ARENA_UPDATE=Obj(PERIOD=3);constants.ARENA_PERIOD=Obj(AFTERBATTLE=4)
  sys.modules['constants']=constants
  tree=ast.parse(open(os.path.join(os.path.dirname(__file__),'stock_contracts','BattleFeedbackCommon.py')).read());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='BATTLE_EVENT_TYPE')
  module=types.ModuleType('BattleFeedbackCommon');module.ATTACK_REASON=reasons;module.ATTACK_REASON_INDICES=constants.ATTACK_REASON_INDICES;module.NONE_SHELL_TYPE=127
  code=compile(ast.Module(body=[cls]),'<stock BattleFeedbackCommon>','exec');exec(code,module.__dict__);sys.modules['BattleFeedbackCommon']=module
  self.events=[];self.summaries=[];self.arrows=[]
  avatar=Obj(onBattleEvents=lambda events:self.events.extend(events),battleEventsSummary=lambda x:self.summaries.append(x),showOwnVehicleHitDirection=lambda *args:self.arrows.append(args))
  self.runtime=M.Runtime.__new__(M.Runtime);self.runtime.s=Obj(avatar=avatar);self.runtime.player_id=1
  self.runtime.round=F.C.Round([F.actor(1,1,pos=(0,0,0)),F.actor(2,2,pos=(10,0,0))])
  self.runtime.summary=dict(damage=0,trackAssist=0,radioAssist=0,tankings=0,stunAssist=0,lastKillerID=0,lastDeathReasonID=0)
  self.shot={'actor':2,'type':Obj(shell=Obj(kind='ARMOR_PIERCING',damage=(320.,)))}
  self.contact={'layer':'structural','result':1}
 def tearDown(self):
  for k,v in self.saved.items():
   if v is None:sys.modules.pop(k,None)
   else:sys.modules[k]=v
 def test_incoming_arrow_uses_incoming_trajectory(self):
  self.runtime.hit_direction(self.runtime.round.actors[1],self.shot,self.contact,60)
  self.assertAlmostEqual(self.arrows[0][0],-math.pi/2);self.assertEqual(self.arrows[0][2],60);self.assertFalse(self.arrows[0][4])
 def test_trajectory_overrides_shooter_current_position(self):
  self.shot['velocity']=(0.,-2.,100.)
  self.runtime.hit_direction(self.runtime.round.actors[1],self.shot,self.contact,60)
  self.assertAlmostEqual(self.arrows[0][0],0.)
 def test_four_incoming_cardinal_directions(self):
  for vector,expected in [((0,0,1),0.),((1,0,0),math.pi/2),((0,0,-1),math.pi),((-1,0,0),-math.pi/2)]:
   self.shot['velocity']=vector;self.runtime.hit_direction(self.runtime.round.actors[1],self.shot,self.contact,60);self.assertAlmostEqual(self.arrows[-1][0],expected)
 def test_blocked_arrow_amount(self):
  self.runtime.hit_direction(self.runtime.round.actors[1],self.shot,self.contact,0)
  self.assertTrue(self.arrows[0][4]);self.assertEqual(self.arrows[0][2],320)
 def test_blocked_summary_accumulates(self):
  for i in range(2):self.runtime.shell_feedback(self.runtime.round.actors[1],self.shot,self.contact,0)
  self.assertEqual(self.summaries[-1]['tankings'],640);self.assertEqual(len(self.events),2)
 def test_received_damage_packed_stock_roundtrip(self):
  self.runtime.shell_feedback(self.runtime.round.actors[1],self.shot,self.contact,70)
  from BattleFeedbackCommon import BATTLE_EVENT_TYPE as E
  e=self.events[0];self.assertEqual(e['eventType'],E.RECEIVED_DAMAGE);self.assertEqual(E.unpackDamage(e['details'])[0],70)
 def test_outgoing_damage_and_kill(self):
  self.shot['actor']=1;victim=self.runtime.round.actors[2];victim.health=0
  self.runtime.shell_feedback(victim,self.shot,self.contact,55)
  from BattleFeedbackCommon import BATTLE_EVENT_TYPE as E
  self.assertEqual(self.summaries[-1]['damage'],55);self.assertEqual([e['eventType'] for e in self.events],[E.DAMAGE,E.KILL])
 def test_friendly_damage_not_added(self):
  self.shot['actor']=1;victim=self.runtime.round.actors[2];victim.team=1
  self.runtime.shell_feedback(victim,self.shot,self.contact,10);self.assertEqual(self.runtime.summary['damage'],0)
 def test_he_does_not_pad_blocked_total(self):
  self.shot['type'].shell.kind='HIGH_EXPLOSIVE';self.runtime.shell_feedback(self.runtime.round.actors[1],self.shot,self.contact,0);self.assertEqual(self.runtime.summary['tankings'],0)
 def test_period_packs_winner_reason(self):
  tree=ast.parse(open(F.P+'/world146.py').read());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Session');fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='period')
  space={'zlib':zlib,'pickle':pickle};exec(compile(ast.Module(body=[fn]),'<actual Session.period>','exec'),space)
  bw=types.ModuleType('BigWorld');bw.serverTime=lambda:100.;sys.modules['BigWorld']=bw;updates=[]
  s=Obj(avatar=Obj(arena=Obj(update=lambda *a:updates.append(a))),mark=lambda *a,**kw:None)
  space['period'](s,'AFTERBATTLE',5.,(1,1));period,end,length,additional=pickle.loads(zlib.decompress(updates[0][1]));winner,reason=additional
  self.assertEqual((period,end,length,winner,reason),(4,105.,5.,1,1))

class ClearanceTests(unittest.TestCase):
 def runtime(self,position):
  from trial146.geometry146 import Hit
  r=M.Runtime.__new__(M.Runtime);a=F.actor(pos=position);a.suspension={'clearance':.3};r.old_bounds={1:((-1.,0.,-1.),(1.,2.,1.))};r.clear_cache={};r.round=F.C.Round([a])
  def rotate(q,angles):
   yaw=angles[0];return (q[0]*math.cos(yaw)+q[2]*math.sin(yaw),q[1],-q[0]*math.sin(yaw)+q[2]*math.cos(yaw))
  def ray(start,end,cheap=False):
   if abs(end[0]-start[0])<1e-12:return None
   t=(2.5-start[0])/(end[0]-start[0])
   return Hit(tuple(start[i]+t*(end[i]-start[i]) for i in range(3)),(-1.,0.,0.),0,'house') if 0<=t<=1 else None
  r.s=Obj(rotate=rotate);r.geometry=Obj(ray=ray);return r,a
 def test_new_wall_blocks(self):
  r,a=self.runtime((0.,0.,0.));self.assertFalse(r.clear(a,(1.6,0.,0.),0.))
 def test_existing_overlap_can_back_out(self):
  r,a=self.runtime((2.,0.,0.));self.assertTrue(r.clear(a,(1.9,0.,0.),0.))
 def test_existing_overlap_cannot_deepen(self):
  r,a=self.runtime((2.,0.,0.));self.assertFalse(r.clear(a,(2.1,0.,0.),0.))
 def test_parallel_slide_allowed(self):
  r,a=self.runtime((2.,0.,0.));self.assertTrue(r.clear(a,(2.,0.,.1),0.))
 def test_ground_not_wall(self):
  from trial146.geometry146 import Hit
  r,a=self.runtime((0.,0.,0.));r.geometry.ray=lambda *x:Hit((0,0,0),(0,1,0),0,'floor');self.assertIsNone(r.solid_hit((0,1,0),(1,1,0)))

class GeometryAdapterTests(unittest.TestCase):
 def setUp(self):
  from trial146 import geometry146
  self.G=geometry146;self.old={k:sys.modules.get(k) for k in ('BigWorld','Math')}
  m=types.ModuleType('Math');m.Vector3=lambda *x:tuple(x);sys.modules['Math']=m
  self.bw=types.ModuleType('BigWorld');sys.modules['BigWorld']=self.bw
  self.log=[]
 def tearDown(self):
  for k,v in self.old.items():
   if v is None:sys.modules.pop(k,None)
   else:sys.modules[k]=v
 def session(self,ray):return Obj(avatar=Obj(spaceID=3),ray=ray,mark=lambda *a,**kw:self.log.append((a,kw)))
 def test_native_normal_path(self):
  self.bw.getMatInfoNearPoint=lambda *args:(True,(0.,0.,0.),(0.,1.,0.),1,'terrain')
  g=self.G.Geometry(self.session(lambda *a:Obj(closestPoint=(0.,0.,0.),isTerrain=True)))
  h=g.ray((0.,1.,0.),(0.,-1.,0.));self.assertTrue(g.enabled);self.assertTrue(g.supports_terrain);self.assertEqual(h.normal,(0.,1.,0.))
 def test_native_collector_without_terrain_preserves_support(self):
  self.bw.getMatInfoNearPoint=lambda *args:(False,(0.,0.,0.),(0.,0.,0.),0,'')
  ground=Obj(closestPoint=(0.,0.,0.),isTerrain=True)
  g=self.G.Geometry(self.session(lambda *a:ground));self.assertIs(g.ray((0.,1.,0.),(0.,-1.,0.)),ground);self.assertTrue(g.enabled);self.assertFalse(g.supports_terrain)
 def test_bad_abi_falls_back(self):
  self.bw.getMatInfoNearPoint=lambda *args:(True,0,0,0,0,0,0)
  known=Obj(closestPoint=(0.,0.,0.),isTerrain=False)
  g=self.G.Geometry(self.session(lambda *a:known));self.assertIs(g.ray((0.,1.,0.),(0.,-1.,0.)),known);self.assertFalse(g.enabled)
 def test_filtered_fence_reveals_terrain(self):
  fence=Obj(closestPoint=(0.,.5,0.),isTerrain=False);ground=Obj(closestPoint=(0.,0.,0.),isTerrain=True)
  def material(*args):
   ignore=args[4](12,7,71,'fence')
   return (False,(0.,0.,0.),(0.,0.,0.),0,'') if ignore else (True,(0.,.5,0.),(0.,1.,0.),71,'fence')
  self.bw.getMatInfoNearPoint=material
  g=self.G.Geometry(self.session(lambda a,b,terrain=False:ground if terrain else fence))
  h=g.ray((0.,1.,0.),(0.,-1.,0.));self.assertIs(h,ground);self.assertEqual(g.filtered_callbacks,1)
 def test_query_never_patches_global_world_collision(self):
  sentinel=lambda *a:None;self.bw.collideSegment=sentinel
  self.bw.getMatInfoNearPoint=lambda *a:(False,(0.,0.,0.),(0.,0.,0.),0,'')
  g=self.G.Geometry(self.session(lambda *a:None));g.ray((0,1,0),(0,-1,0));self.assertIs(self.bw.collideSegment,sentinel)

if __name__=='__main__':unittest.main(verbosity=2)
