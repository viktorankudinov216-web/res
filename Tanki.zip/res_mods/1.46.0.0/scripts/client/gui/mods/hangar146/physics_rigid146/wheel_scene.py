# -*- coding: utf-8 -*-
"""Measured belt path and strut travel drive explicit scene providers.
Native rotation is retained when correct; delta correction prevents a frozen
CGF wheel from freezing the rendered wheel after a direction change.
Uses stock MatrixProduct/node-provider API. No guessed wheel setter or memory writes.
"""
import math
from .math3 import *

def physical_offset(wheel):
 sag=wheel.mass*9.81/wheel.k
 return clamp(wheel.compression-sag,-sag,wheel.travel-sag)

def ground_names(descriptor):
 result={};ground=descriptor.chassis.groundNodes
 for group in ground.groups:
  if not group.affectedWheelsTemplate:continue
  for i in range(group.startIndex,group.startIndex+group.nodesCount):
   result['%s%d'%(group.nodesTemplate,i)]='%s%d'%(group.affectedWheelsTemplate,i)
 for node in ground.nodes:
  if node.affectedWheelName:result[node.nodeName]=node.affectedWheelName
 return result

def attach(vehicle,actor):
 import Math
 model=vehicle.appearance.compoundModel
 if getattr(actor,'_wheel_scene_model',None) is model and getattr(actor,'_wheel_scene',None):return
 root=Math.Matrix(model.matrix)
 wheels=dict((w.name,w) for w in actor.rigid.wheels if w.name)
 carrier_names=set(wheels)
 # Every descriptor wheel rotates; only physical carriers have spring travel.
 config=getattr(vehicle.typeDescriptor.chassis,'wheels',None)
 class FixedWheel(object):pass
 def add(name,radius,is_left):
  if name in wheels:return
  wheel=FixedWheel();wheel.name=name;wheel.radius=radius;wheel.side='left' if is_left else 'right';wheels[name]=wheel
 if config is not None:
  for group in config.groups:
   for i in range(group.startIndex,group.startIndex+group.count):add('%s%d'%(group.template,i),group.radius,group.isLeft)
  for wheel in config.wheels:add(wheel.nodeName,wheel.radius,wheel.isLeft)
 names=dict((name,name) for name in wheels)
 names.update((name,wheel) for name,wheel in ground_names(vehicle.typeDescriptor).items() if wheel in carrier_names and name not in names)
 bindings=[];missing=[]
 for name,wheel_name in sorted(names.items(),key=lambda item:(item[0] not in wheels,item[0])):
  node=model.node(name)
  if node is None:
   missing.append(name);continue
  native=node.localMatrix
  local=Math.Matrix(native);inverse=Math.Matrix(node);inverse.invert()
  parent_inverse=Math.MatrixProduct();parent_inverse.a=inverse;parent_inverse.b=local
  axis=tuple(Math.Matrix(parent_inverse).applyVector(root.applyVector(Math.Vector3(0.,1.,0.))))
  size=length(axis)
  if not .25<size<4.:continue
  axis=mul(axis,1./size)
  baseline=tuple(local.translation);reference=None
  if name in carrier_names and getattr(actor,'rigid_layout',None)=='model_roadwheels_compound_local':
   wheel=wheels[wheel_name]
   reference=(wheel.local[0],wheel.reference_y,wheel.local[2])
  elif name not in wheels:
   reference=getattr(actor,'rigid_layout_detail',{}).get('ground_reference',{}).get(name)
  if reference is not None:
   baseline=tuple(Math.Matrix(parent_inverse).applyPoint(root.applyPoint(Math.Vector3(*reference))))
  axle=tuple(Math.Matrix(node).applyToAxis(0))
  right=tuple(root.applyVector(Math.Vector3(1.,0.,0.)))
  spin_sign=1. if dot(axle,right)>=0. else -1.
  correction=Math.Matrix();correction.setIdentity()
  spin=Math.Matrix();spin.setIdentity()
  spun=Math.MatrixProduct();spun.a=spin;spun.b=native
  inverse_basis=Math.Matrix(local);inverse_basis.invert()
  relative=Math.MatrixProduct();relative.a=native;relative.b=inverse_basis
  composed=Math.MatrixProduct();composed.a=spun;composed.b=correction
  model.node(name,composed)
  bindings.append(dict(name=name,wheel=wheels[wheel_name],native=native,node=node,reference=reference,baseline=baseline,axis=axis,correction=correction,provider=composed,spun=spun,spin=spin,relative=relative,spin_sign=spin_sign,angle=0.,is_wheel=name in wheels,travel_owner=wheel_name in carrier_names,offset=0.))
 if not bindings:raise RuntimeError('No roadwheel scene nodes; physical suspension cannot be rendered')
 actor._wheel_scene_model=model;actor._wheel_scene=bindings
 actor._wheel_scene_missing=missing;actor._wheel_scene_expected=len(names)
 actor._wheel_scene_error=None
 return len(bindings)

def update(actor,distances=(0.,0.,0.,0.)):
 import Math
 for row in getattr(actor,'_wheel_scene',()):
  # Stock activation/LOD may rebind a node after our initial installation.
  actor._wheel_scene_model.node(row['name'],row['provider'])
  wheel=row['wheel'];native_translation=tuple(Math.Matrix(row['native']).translation)
  owns=row.get('travel_owner',True)
  offset=physical_offset(wheel) if owns else 0.
  if owns:
   # Cancel ALL native positional drift, not just Y. The old native solver
   # also moved carrier centres longitudinally while our struts stayed fixed.
   reference=row.get('reference')
   if reference is not None:
    # Derive CURRENT parent space from world node and our local provider.
    # This cancels native animated-parent motion instead of double-applying
    # travel when a ground node is parented below a carrier.
    inverse=Math.Matrix(row['node']);inverse.invert()
    parent_inverse=Math.MatrixProduct();parent_inverse.a=inverse;parent_inverse.b=row['provider']
    root=Math.Matrix(actor._wheel_scene_model.matrix)
    target=(reference[0],reference[1]+offset,reference[2])
    wanted=Math.Matrix(parent_inverse).applyPoint(root.applyPoint(Math.Vector3(*target)))
    correction=sub(tuple(wanted),native_translation)
   else:correction=sub(add(row['baseline'],mul(row['axis'],offset)),native_translation)
  else:correction=ZERO
  row['correction'].translation=Math.Vector3(*correction);row['offset']=offset
  if row['is_wheel']:
   side=1 if wheel.side=='left' else 2
   row['angle']=(row['angle']+row['spin_sign']*distances[side]/max(.04,wheel.radius)+math.pi)%(2.*math.pi)-math.pi
   axis=Math.Matrix(row['relative']).applyToAxis(1)
   native_angle=math.atan2(axis.z,axis.y)
   delta=(row['angle']-native_angle+math.pi)%(2.*math.pi)-math.pi
   row['spin'].setRotateX(delta)

