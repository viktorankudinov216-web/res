# -*- coding: utf-8 -*-
from __future__ import absolute_import
import functools,inspect,json
_PATCHES=[]

def jsonParse(data):return json.loads(data.decode('utf-8-sig') if isinstance(data,str) else data)
def deepUpdate(obj,new):
    for key,value in new.items():
        if isinstance(value,dict):obj[key]=deepUpdate(obj.get(key,{}),value)
        else:obj[key]=value
    return obj

def override(obj,prop):
    def decorate(handler):
        own=prop in obj.__dict__;raw=obj.__dict__.get(prop);original=getattr(obj,prop)
        def patched(*args,**kwargs):return handler(original,*args,**kwargs)
        functools.update_wrapper(patched,handler,updated=[])
        setattr(obj,prop,patched);_PATCHES.append((obj,prop,own,raw,patched));return handler
    return decorate

def restore(checkpoint=0):
    while len(_PATCHES)>checkpoint:
        obj,name,own,raw,patched=_PATCHES.pop()
        if obj.__dict__.get(name) is not patched:continue
        if own:setattr(obj,name,raw)
        else:delattr(obj,name)

def local_session_id(round_id,dbid):
    """Local UI identifier, not an authentication token or account DBID."""
    return 'local146:%d:%d'%(dbid,round_id)
