# -*- coding: utf-8 -*-
"""Isolated M12 rigid body with 0.9.22 track laws; legacy0922 files are deliberately unchanged."""
from __future__ import absolute_import
import math
from ..combat_core146 import Actor as LegacyActor
from .math3 import *
from .solver import Body,Wheel,Vehicle

class IdleBridge(object):
 """Same lifecycle surface; no unused helper process in rigid mode."""
 ready=False;failed=None;stats={'mode':'rigid_mainthread','steps':0}
 def reset(self):pass
 def poll(self):pass
 def flush(self,actors):pass
 def solve(self,*args):raise RuntimeError('Legacy spring helper used by rigid mode')

class Actor(LegacyActor):
 def configure_rigid(self,bounds,descriptor=None,vehicle=None):
  lo,hi=tuple(bounds[0]),tuple(bounds[1]);p=self.suspension
  # Inertia is based on chassis/hull dimensions, not an inflated circular
  # turret envelope. A separate selected-turret OBB supplies roof contacts.
  lo=(lo[0],max(lo[1],p['clearance']*.85),lo[2])
  hi=(hi[0],max(hi[1],lo[1]+.3),hi[2])
  com=((lo[0]+hi[0])*.5,clamp(p['center_of_mass_height'],lo[1]+.1,hi[1]-.1),(lo[2]+hi[2])*.5)
  b=Body(self.position,(self.yaw,self.body['pitch'],self.body['roll']),self.params['mass'],lo,hi,com)
  self.rigid_roof_source='chassis_hull_obb'
  if descriptor is not None:
   try:
    from ..client_bounds import part_bounds
    tlo,thi=part_bounds(descriptor.turret)
    offset=add(tuple(descriptor.chassis.hullPosition),tuple(descriptor.hull.turretPositions[0]))
    b.add_shape(tlo,thi,offset);self.rigid_roof_source='separate_turret_obb'
   except (AttributeError,IndexError,TypeError,ValueError):pass
  rows=[];source='descriptor_legacy_carrier_fallback';self.rigid_layout_detail={};self.rigid_layout_error=None
  if vehicle is not None and descriptor is not None:
   try:
    from .layout import collect
    rows,self.rigid_layout_detail=collect(descriptor,vehicle,p)
    if rows:source='model_roadwheels_compound_local'
   except Exception as error:self.rigid_layout_error=str(error)
  if not rows:
   for spring in p['springs']:rows.append((spring['x'],spring['z'],.35,.35,spring['side'],''))
  mass=self.params['mass']/len(rows)
  # Stiffness follows supported mass and static spring sag, not a decorative
  # pitch oscillator. Real node centre/radius define the loaded ride height.
  static=clamp(float(p.get('static_compression',.15)),.07,.24)
  ride=clamp(p['clearance']*.55,.15,.32);wheels=[]
  for x,z,radius,center,side,name in rows:
   mount=max(center+ride,radius+.08);rest=mount-center+static
   # Common loaded ground plane includes pad thickness / nonzero wheel rim.
   rim=min(row[3]-row[2] for row in rows)
   wheel=Wheel(x,z,mount,rest,static+min(.18,ride*.65),mass,side,radius,name,static)
   # Use donor damping ratio, with gravity-normalized per-carrier stiffness.
   sample=p['springs'][0];ratio=sample['damping']/(2.*math.sqrt(sample['stiffness']*sample['mass']))
   wheel.c=2.*max(1.20,min(1.65,ratio))*math.sqrt(wheel.k*mass);wheel.support_radius=radius+rim;wheel.reference_y=center;wheels.append(wheel)
  self.rigid=Vehicle(b,wheels,self.params);self.rigid_layout=source;self.rigid_previous_q=b.q
  self.rigid_cast=None;self.rigid_hull=None;self.rigid_static=False;self.rigid_time=0.
  self.track_speeds=(0.,0.);self.rigid_probes=0;self.rigid_reused=0
  self.rigid_roof_error=None
  if vehicle is not None:self.refine_roof(vehicle)
 def refine_roof(self,vehicle):
  b=self.rigid.b
  if len(b.shapes)<2 or b.clouds.get(1):return
  try:
   from .roof import surface
   cached=getattr(self,'_turret_surface',None)
   if not cached:cached=surface(vehicle,b.shapes[1][0],b.shapes[1][1])
   if cached:
    self._turret_surface=cached;b.clouds[1]=cached
    self.rigid_roof_source='sampled_native_turret_bsp';self.rigid_roof_error=None
   else:self.rigid_roof_error='Native turret sampling returned insufficient points'
  except Exception as error:self.rigid_roof_error=str(error)
 def render_pose(self,alpha):
  old=self.previous_pose;position=tuple(old[0][i]+(self.position[i]-old[0][i])*alpha for i in range(3))
  return position,euler(slerp(self.rigid_previous_q,self.rigid.b.q,alpha))
 def step(self,dt,ground,clear,bounds=None):
  self.previous_pose=self.snapshot();self.rigid_previous_q=self.rigid.b.q;self.landing_speed=None
  if self.health<=0 or self.rigid_static:
   self.flags=0;self.v=0.;self.omega=0.;self.rigid.b.v=ZERO;self.rigid.b.w=ZERO;self.track_speeds=(0.,0.);return
  self.rigid_time+=dt;b=self.rigid.b;hits=[]
  for wheel in self.rigid.wheels:
   start,end=wheel.ray(b);self.rigid_probes+=1
   hit=self.rigid_cast(start,end) if self.rigid_cast is not None else None
   if self.rigid_cast is None:
    y=ground(self,start[0],start[2],end[1],start[1],None)
    if y is not None:hit=((start[0],y,start[2]),(0.,1.,0.))
   hits.append(hit)
  if len(b.shapes)>1:
   lo,hi,offset,unused=b.shapes[1];b.shapes[1]=(lo,hi,offset,quat(self.gun_yaw,0.,0.))
  planes=self.rigid_hull(self,dt) if self.rigid_hull is not None else []
  self.rigid.tick(dt,self.flags,hits,planes)
  self.position=b.origin();self.yaw,pitch,roll=euler(b.q)
  self.v=dot(b.v,rotate(b.q,(0.,0.,1.)));self.omega=b.w[1];self.track_speeds=self.rigid.tracks
  self.body.update(height=self.position[1],pitch=pitch,roll=roll,vertical_velocity=b.v[1],pitch_velocity=b.w[0],roll_velocity=b.w[2],airborne=self.rigid.contacts==0,contact_count=self.rigid.contacts,
   left_flying=not any(w.contact for w in self.rigid.wheels if w.side=='left'),right_flying=not any(w.contact for w in self.rigid.wheels if w.side=='right'))
  self.landing_speed=self.rigid.last_landing
  values=tuple(b.p)+tuple(b.v)+tuple(b.w)+tuple(b.q)
  if any(math.isnan(x) or math.isinf(x) for x in values):raise RuntimeError('Rigid state became non-finite')
 def diagnostics(self,full=False):
  result=dict(revision='M12_contact_suspension_test',input_flags=self.flags,brake_mode=getattr(self.rigid,'brake_mode',None),applied_longitudinal_force=getattr(self.rigid,'last_longitudinal',None),speed_limits=(self.params['speedFwd'],self.params['speedBwd']),side_loads=getattr(self.rigid,'side_loads',None),side_forces=getattr(self.rigid,'side_forces',None),grip_coefficients=getattr(self.rigid,'grip_coefficients',None),governor_impulse=getattr(self.rigid,'governor_impulse',None),spring_rest=[w.rest for w in self.rigid.wheels],spring_travel=[w.travel for w in self.rigid.wheels],spring_k=[w.k for w in self.rigid.wheels],spring_c=[w.c for w in self.rigid.wheels],layout_detail=self.rigid_layout_detail,grip_force=getattr(self.rigid,'grip_force',None),lateral_slip=getattr(self.rigid,'slip_lateral',None),yaw_target=getattr(self.rigid,'yaw_target',None),inertia=self.rigid.b.inertia,roof_source=self.rigid_roof_source,roof_error=getattr(self,'rigid_roof_error',None),roof_points=len(self.rigid.b.clouds.get(1,())),layout=self.rigid_layout,layout_error=getattr(self,'rigid_layout_error',None),wheel_count=len(self.rigid.wheels),wheel_compression=[round(w.compression,4) for w in self.rigid.wheels],wheel_load=[round(w.load,1) for w in self.rigid.wheels],linear_velocity=self.rigid.b.v,angular_velocity=self.rigid.b.w,quaternion=self.rigid.b.q,track_speeds=self.track_speeds,probes=self.rigid_probes,reused=self.rigid_reused,stationary_target=self.rigid_static)
  if not full:
   for key in ('spring_rest','spring_travel','spring_k','spring_c','layout_detail','inertia','speed_limits','side_forces','wheel_load','quaternion'):
    result.pop(key,None)
  return result
