# -*- coding: utf-8 -*-
"""Native loading page handshake; no overlay, texture or render delay."""
from __future__ import absolute_import
import traceback
from .utils import override

def payload_summary(data):
    result={}
    for side in ('left','right'):
        rows=data.get(side+'Items',[])
        result[side+'_vehicle_ids']=[int(row['vehicleID']) for row in rows]
        result[side+'_sorted_ids']=[int(value) for value in data.get(side+'ItemsIDs',[])]
    result['vehicles_sent']=len(result['left_vehicle_ids'])+len(result['right_vehicle_ids'])
    return result

def deferred(component,action):
    import BigWorld
    from . import native_match as N
    owner=BigWorld.player();generation=N._GENERATION
    def run():
        if generation!=N._GENERATION or N._RETURNING or N._RETURN_SCHEDULED:return
        if BigWorld.player() is not owner or not N.local_avatar(owner):return
        if not component._isDAAPIInited():return
        try:action()
        except Exception:
            N.mark('loading_ui_handshake_failed',error=traceback.format_exc())
            N.request_return()
    BigWorld.callback(0.,run)

def install():
    from . import native_match as N
    from gui.Scaleform.daapi.view.battle.shared.page import SharedPage
    from gui.Scaleform.daapi.view.battle.shared.stats_exchange.stats_ctrl import BattleStatisticsDataController
    state={}
    def current():
        if state.get('generation')!=N._GENERATION:
            state.clear();state.update(generation=N._GENERATION,page=None,payload=False,shown=False)
        return state
    def show_loading():
        st=current();page=st['page']
        if st['shown'] or page is None or not st['payload']:return
        from helpers import dependency
        from skeletons.gui.app_loader import IAppLoader
        from gui.app_loader.spaces import BattleLoadingSpace
        from constants import ARENA_GUI_TYPE
        loader=dependency.instance(IAppLoader);space=BattleLoadingSpace(ARENA_GUI_TYPE.RANDOM)
        if loader.getSpaceID()!=space.getSpaceID():
            raise RuntimeError('Native loading handshake outside BattleLoadingSpace')
        # Initial space switch is owned by BattleLoadingObserver. Updating the
        # same space sends BATTLE_LOADING after the native page listener exists.
        st['shown']=True;loader.changeSpace(space)
        visible=bool(page._isBattleLoading)
        N.mark('native_loading_visibility',loading_event_received=visible,
               visible_components=list(page.as_getComponentsVisibilityS()),team_payload_ready=True)
        if not visible:raise RuntimeError('Native page did not receive BATTLE_LOADING')
        deferred(page,N.start_world)
    @override(SharedPage,'_populate')
    def page_populated(base,self):
        result=base(self)
        if N.local_avatar():
            current()['page']=self;N.mark('battle_page_populated')
            deferred(self,show_loading)
        return result
    @override(BattleStatisticsDataController,'_populate')
    def statistics_populated(base,self):
        result=base(self)
        if N.local_avatar():
            N.mark('team_statistics_populated',daapi_ready=bool(self._isDAAPIInited()))
            def refresh():
                if self._battleCtx is None:return
                self.invalidateArenaInfo()
                N.mark('team_statistics_resynced',daapi_ready=bool(self._isDAAPIInited()))
            deferred(self,refresh)
        return result
    @override(BattleStatisticsDataController,'as_setVehiclesDataS')
    def vehicles_sent(base,self,data):
        ready=bool(self._isDAAPIInited());result=base(self,data)
        if N.local_avatar():
            details=payload_summary(data);details['daapi_ready']=ready
            N.mark('native_team_payload',**details)
            st=current()
            if ready and N._PLAN is not None and details['vehicles_sent']==1+len(N._PLAN['bots']):
                st['payload']=True
                if st['page'] is not None:deferred(st['page'],show_loading)
        return result
