# -*- coding: utf-8 -*-
from __future__ import absolute_import
import pickle,zlib,copy
from .runtime_data import read_resource
from .utils import jsonParse
OFFLINE_SERVER_ADDRES='offline146.local.invalid'
OFFLINE_NICKNAME='Local146'
OFFLINE_LOGIN='Local146@offline146.local.invalid'
OFFLINE_PWD='local-only-not-a-real-password'
OFFLINE_DBID=1462304
REQUEST_CALLBACK_TIME=0.1
OFFLINE_GUI_CTX=pickle.dumps({'databaseID':OFFLINE_DBID,'logUXEvents':False,'aogasStartedAt':0,'sessionStartedAt':0,'isAogasEnabled':False,'collectUiStats':False,'isLongDisconnectedFromCenter':False,'currentVehInvID':1,'bootcampCompletedCount':1},2)

def _normalize(value):
    if isinstance(value,dict):
        out={}
        for k,v in value.items():
            key=k.encode('utf-8').strip() if isinstance(k,unicode) else k.strip()
            if key in out:raise ValueError('Duplicate settings key after normalization')
            out[key]=_normalize(v)
        return out
    if isinstance(value,list):return [_normalize(v) for v in value]
    if isinstance(value,unicode):return value.encode('utf-8')
    return value

_settings=_normalize(jsonParse(read_resource('initialServerSettings.json')))
# Historical offhangar additions; full validation against installed extension
# packages still needs the first real-client test. Do not enable debug/admin.
for k in ('vehicle_post_progression_config','comp7_config','fun_random_config','battle_context_hints_config','comp7_skills_config','tank_academy_config','craft_machine_config'):_settings.setdefault(k,{})
_settings.setdefault('story_mode_settings',{'enabled':False,'hideGameLoadingTimeout':1,'joinToQueueFromLogin':False,'quotums':[1,1,1],'waitTimeQueue':1})
if not isinstance(_settings.get('lootBoxes_config'),dict) or not all(isinstance(v,dict) for v in _settings.get('lootBoxes_config',{}).values()):_settings['lootBoxes_config']={}
for k in ('isOffersEnabled','isGlobalMapEnabled','isReferralProgramEnabled','isTutorialEnabled','isBootcampEnabled','xmpp_enabled','xmpp_muc_enabled'):_settings[k]=False
# Offhangar historically suppresses the related notification chain too.
_settings.setdefault('achievements20_config',{'isWTREnabled':False,'isLayoutEnabled':False,'isSummaryEnabled':False,'requiredCountOfBattles':0})
def normalize_runtime_sets(settings):
    # JSON preserves values but loses the Python set type required by native
    # AvatarInputHandler.__identifyVehicleType: magneticAutoAimTags & type.tags.
    config=settings.setdefault('magnetic_auto_aim_config',{})
    if not isinstance(config,dict):raise ValueError('magnetic_auto_aim_config must be a dictionary')
    for key in ('enableForTags','enabledForTags'):
        if key not in config and key!='enableForTags':continue
        tags=config.get(key,())
        if not isinstance(tags,(list,tuple,set,frozenset)):
            raise ValueError('magnetic_auto_aim_config.%s must be a tag collection'%key)
        if any(not isinstance(tag,basestring) for tag in tags):
            raise ValueError('magnetic_auto_aim_config.%s contains a non-string tag'%key)
        config[key]=frozenset(tags)
    return settings

def build_server_settings():
    # Extensions in other .pkg files append keys (e.g. portal_config) to this
    # list. Read the live list when creating Account, not just at mod import.
    from constants import INBATTLE_CONFIGS
    settings=normalize_runtime_sets(copy.deepcopy(_settings))
    # No SPG or stun mechanics in this local mode, including native HUD gates.
    settings.setdefault('spgRedesignFeatures',{}).update(stunEnabled=False,markTargetAreaEnabled=False)
    # An absent 1.44 config defaults to zero allowed levels in 1.46.
    settings['random_battles_config']={'isEnabled':True,'levels':list(range(1,12))}
    settings['vehicle_post_progression_config']={'isPostProgressionEnabled':True,'enabledFeatures':frozenset(['roleSlot','shells_consumables_switch','opt_dev_boosters_switch']),'forbiddenVehicles':frozenset(),'enabledRentedVehicles':frozenset()}
    from .bonds import native_keys,LIMIT
    settings['crystal_rewards_config']=native_keys(settings.get('crystal_rewards_config',{}))
    settings['crystal_rewards_config'].setdefault('limits',{}).setdefault('level',{})[10]=LIMIT
    added=[]
    for name in INBATTLE_CONFIGS:
        if name not in settings:
            settings[name]={}
            added.append(name)
    # Supply all BoosterCategory names, not only PERSONAL from the 1.44 seed.
    from goodies.goodie_constants import BoosterCategory
    reserves=settings.setdefault('personal_reserves_config',{})
    supported=reserves.setdefault('supportedQueueTypes',{})
    for category in BoosterCategory:supported.setdefault(category.name,[])
    # 1.46 preferred_maps.LayoutSlotTypeIterator expects the new slots map.
    from preferred_maps import DefaultSlot,PremiumSlot
    preferred=settings.setdefault('preferredMaps_config',{})
    preferred.setdefault('slots',{1:(1,DefaultSlot.kind.value,float('inf')),2:(2,PremiumSlot.kind.value,0)})
    preferred.setdefault('slotCooldown',14400)
    reactive=settings.setdefault('reactiveCommunicationConfig',{})
    if not reactive.get('url'):reactive['isEnabled']=False
    return zlib.compress(pickle.dumps(settings,2)),added

OFFLINE_SERVER_SETTINGS,_INITIAL_ADDED_CONFIGS=build_server_settings()
