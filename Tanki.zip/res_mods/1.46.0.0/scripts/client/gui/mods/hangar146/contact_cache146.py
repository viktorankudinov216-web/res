# -*- coding: utf-8 -*-
"""Batched, layer-window-aware, short-lived contact reuse; optional native C ABI.
Not a permanent 2-D heightmap. No native engine pointers or background raycasts.
"""
from __future__ import absolute_import
import os,math
NAN=float('nan')

def usable(entry,row,now,ttl,radius,gx,gz,ny):
    if entry is None:return None
    x,z,h,lo,hi,t,oldx,oldz=entry;dx=row[0]-x;dz=row[1]-z;value=h+gx*dx+gz*dz
    if not (ttl>0 and 0<=now-t<ttl-1e-9 and dx*dx+dz*dz<=radius*radius and ny>.5 and abs(gx-oldx)<.12 and abs(gz-oldz)<.12):return None
    if row[3]>hi+.15 or row[2]<lo-.15 or not row[2]-.001<=value<=row[3]+.001:return None
    if row[4] is not None and value>row[4]+.01 and ny>=.995:return None
    return value

class Bank(object):
    def __init__(self,path=None):
        self.native=None;self.error=None;self.rows={};self.buffers={};self.hits=0;self.misses=0
        try:
            import ctypes as ct
            if path is None:
                from .runtime_data import game_root
                path=os.path.join(game_root(),'mods','hangar146_helper','native','contact_cache146.dll')
            lib=ct.CDLL(path);lib.h146_abi.restype=ct.c_uint32
            if lib.h146_abi()!=0x1460005:raise RuntimeError('Contact cache ABI mismatch')
            U,D,P=ct.c_uint32,ct.c_double,ct.POINTER(ct.c_double)
            lib.h146_probe.argtypes=[U,U,U,P,D,D,D,D,D,D,P];lib.h146_probe.restype=U
            lib.h146_store.argtypes=[U,U,U,P,D,P,U,D,D,D];lib.h146_store.restype=None
            lib.h146_reset.argtypes=[];lib.h146_reset.restype=None;lib.h146_reset()
            self.native=lib;self.ct=ct
        except Exception as e:self.error=str(e)
    def invalidate(self,owner):
        for key in list(self.rows):
            if key[0]==owner:self.rows.pop(key,None)
        # Generations are part of the caller key; unrelated actors keep their cache.
    def batch(self,owner,offset,requests,now,ttl,radius,gx,gz,ny,cast):
        n=len(requests);values=[];mask=0
        if self.native is not None:
            key=(owner,offset,n)
            buffers=self.buffers.get(key)
            if buffers is None:
                buffers=((self.ct.c_double*(n*5))(),(self.ct.c_double*n)());self.buffers[key]=buffers
                if len(self.buffers)>128:self.buffers.clear();self.buffers[key]=buffers
            req,out=buffers
            for i,row in enumerate(requests):
                for j,value in enumerate(row):req[i*5+j]=NAN if value is None else value
            mask=int(self.native.h146_probe(owner,offset,n,req,now,ttl,radius,gx,gz,ny,out))
            values=[None if mask&(1<<i) else float(out[i]) for i in range(n)]
        else:
            for i,row in enumerate(requests):
                value=usable(self.rows.get((owner,offset+i)),row,now,ttl,radius,gx,gz,ny)
                values.append(value)
                if value is None:mask|=1<<i
        for i,row in enumerate(requests):
            if mask&(1<<i):
                value=cast(*row);values[i]=value;self.misses+=1
                if self.native is None:
                    self.rows[(owner,offset+i)]=None if value is None else (row[0],row[1],value,row[2],row[3],now,gx,gz)
            else:self.hits+=1
        if self.native is not None:
            for i,value in enumerate(values):out[i]=NAN if value is None else value
            self.native.h146_store(owner,offset,n,req,now,out,mask,gx,gz,ny)
        if len(self.rows)>2048:self.rows.clear()
        return values
