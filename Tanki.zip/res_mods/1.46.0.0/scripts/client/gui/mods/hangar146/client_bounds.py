# -*- coding: utf-8 -*-
"""Client resource bounds; never call the server-only BspCollisionModel API."""
from __future__ import absolute_import
import math,posixpath
_CACHE={}

def clean(box):
    if box is None:return None
    # HitTester bbox may contain (min,max,radius), not just (min,max).
    lo,hi=box[0],box[1]
    result=tuple(tuple(float(v[i]) for i in range(3)) for v in (lo,hi))
    if any(math.isnan(x) or math.isinf(x) for v in result for x in v):raise ValueError('Nonfinite model bounds')
    if any(not .01<result[1][i]-result[0][i]<50. for i in range(3)):raise ValueError('Invalid model bounds')
    return result

def section_bounds(section):
    if section is None:return None
    bb=section['boundingBox']
    if bb is not None and bb['min'] is not None and bb['max'] is not None:
        return clean((bb.readVector3('min'),bb.readVector3('max')))
    return None

def resource_bounds(path,seen=None):
    import ResMgr
    if not path:return None
    path=path.replace('\\','/')
    if path in _CACHE:return _CACHE[path]
    seen=set() if seen is None else seen
    if path in seen or len(seen)>12:return None
    seen.add(path)
    section=ResMgr.openSection(path)
    if section is None:return None
    result=section_bounds(section)
    if result is not None:_CACHE[path]=result;return result
    if path.lower().endswith('.model'):
        for key in ('nodelessVisual','nodefullVisual','billboardVisual'):
            name=section.readString(key)
            if not name:continue
            name=name.replace('\\','/')
            stem=posixpath.splitext(name)[0] if name.endswith(('.visual','.visual_processed')) else name
            for visual in (stem+'.visual_processed',stem+'.visual'):
                result=resource_bounds(visual,seen)
                if result is not None:_CACHE[path]=result;return result
        parent=section.readString('parent')
        if parent:
            if not parent.endswith('.model'):parent+='.model'
            result=resource_bounds(parent,seen)
            if result is not None:_CACHE[path]=result;return result
    return None

def part_bounds(part):
    manager=getattr(part,'bboxManager',None)
    if manager is not None:
        box=getattr(manager,'normalBBox',None)
        if box is not None:return clean(box)
    tester=getattr(part,'hitTester',None)
    tester=getattr(tester,'modelHitTester',tester)
    if tester is not None and getattr(tester,'bbox',None) is not None:return clean(tester.bbox)
    paths=[]
    if tester is not None:paths.append(getattr(tester,'bspModelName',None))
    models=getattr(part,'models',None)
    if models is None:models=getattr(part,'modelsSets',{}).get('default')
    if models is not None:paths.append(getattr(models,'undamaged',None))
    for path in paths:
        box=resource_bounds(path)
        if box is not None:return box
    raise ValueError('Client model boundingBox unavailable: %r'%paths)
