# -*- coding: utf-8 -*-
"""Experimental native 3D spawn + round clock. Static tanks, no combat simulation."""
from __future__ import absolute_import
import base64,math,pickle,random,time,traceback,zlib
from . import spawn146
_SESSION=None
_CREATING=False


def allowed(kind='ready'):
    s=_SESSION
    return bool(s and s.active and (s.geometry_ready if kind=='space' else s.ready))


def start():
    global _SESSION
    from . import native_match as N,config
    import BigWorld
    if not config.ENABLE_WORLD or _SESSION is not None or not N.local_avatar() or N._RETURNING:return
    if N._PLAN is None:return
    _SESSION=Session(BigWorld.player(),N._PLAN,N._GENERATION)
    _SESSION.later(0.,_SESSION.map_geometry)


def stop():
    global _SESSION
    s=_SESSION;_SESSION=None
    if s is not None:s.stop()


def prepare_avatar_space(avatar,plan,generation):
    """1.23 ordering, using 1.46 APIs: map + mask BEFORE original Avatar init.

    Space owns the mapping; normal clearEntitiesAndSpaces handles teardown even
    if Avatar construction fails. Session adopts this exact mapping, never maps
    it again. No extra space or renderer/native-memory patch is created.
    """
    import BigWorld,ArenaType
    from . import native_match as N
    from .map146 import validate_map,resource_exists
    if getattr(avatar,'_hangar146_early_geometry',None) is not None:
        raise RuntimeError('Avatar geometry was already prepared')
    arena=ArenaType.g_cache[plan['arenaTypeID']]
    geometry=validate_map(arena,resource_exists)
    mask=int(ArenaType.getVisibilityMask(plan['arenaTypeID']))
    if not 0<mask<1<<20:raise ValueError('Invalid native CTF visibility mask')
    sid=int(avatar.spaceID)
    # Both APIs are present in the supplied native 1.46 Avatar implementation.
    before=int(BigWorld.getSpaceItemsVisibilityMask(sid))&0xffffffff
    N.mark('early_avatar_geometry_before',spaceID=sid,visibility_mask=mask,
        geometry_load_phase='before_avatar_base_init',geometry=geometry,
        space_items_mask_before=before)
    mapping=BigWorld.addSpaceGeometryMapping(sid,None,geometry,mask,'')
    if not mapping:raise RuntimeError('Early geometry mapping returned no mapping ID')
    record=dict(spaceID=sid,generation=generation,geometry=geometry,
        visibility_mask=mask,mapping_id=mapping,adopted=False)
    avatar._hangar146_early_geometry=record
    # Match old map -> cameraSpaceID -> runtime items mask ordering. Never call
    # cameraSpaceID without an argument: its native default is a ZERO setter.
    selected=int(BigWorld.cameraSpaceID(sid))
    if selected!=sid:raise RuntimeError('Early Avatar camera space selection failed')
    # Seed only server/gameplay bits; stock ClientVisibilityFlags later owns
    # client/observer bits. Mapping's visMask is not a substitute for this call.
    requested=(before&0xfff00000)|mask
    BigWorld.setSpaceItemsVisibilityMask(sid,requested)
    after=int(BigWorld.getSpaceItemsVisibilityMask(sid))&0xffffffff
    if after!=requested:raise RuntimeError('Early space items mask readback differs')
    record.update(items_mask_before=before,items_mask_after=after)
    N.mark('early_avatar_geometry_ready',early_mapping_id=int(mapping),
        early_geometry_space_id=sid,early_geometry=geometry,
        early_geometry_before_avatar_init=True,early_geometry_visibility_mask=mask,
        early_space_items_mask_before=before,early_space_items_mask_after=after,
        early_camera_space_id=selected)
    return record


def properties(rec,descr,index,avatar):
    from .progression import ext
    data=ext(rec) if index==0 else {}
    hp=int(getattr(descr,'maxHealth',None) or descr.type.maxHealth)
    if not 1<=hp<=32767:raise ValueError('Vehicle health outside native INT16 range')
    from constants import VEHICLE_SIEGE_STATE
    from gun_rotation_shared import encodeGunAngles
    neutral_angles=encodeGunAngles(0.,0.,descr.gun.pitchLimits['absolute'])
    public=dict(name=avatar.name if index==0 else 'LocalBot_%d'%index,
        compDescr=base64.b64decode(rec['compactDescr_b64']),outfit=base64.b64decode(rec.get('outfit_b64','')) if index==0 else '',index=index,
        team=1 if index==0 else 2,prebattleID=0,marksOnGun=0,crewGroups=[],commanderSkinID=0,maxHealth=hp)
    return dict(publicInfo=public,health=hp,isCrewActive=True,isHidden=False,
        physicsMode=0,siegeState=VEHICLE_SIEGE_STATE.DISABLED,gunAnglesPacked=neutral_angles,
        engineMode=(0,0),avatarID=avatar.id,crewCompactDescrs=tuple(base64.b64decode(v) for v in rec.get('crew',[]) if v),
        vehPostProgression=data.get('vehPostProgression',[]),customRoleSlotTypeId=data.get('customRoleSlotTypeId',0),
        arenaTypeID=avatar.arenaTypeID,arenaBonusType=avatar.arenaBonusType,arenaUniqueID=avatar.arenaUniqueID)


class Session(object):
    def __init__(self,avatar,plan,generation):
        self.avatar=avatar;self.plan=plan;self.generation=generation
        self.active=True;self.geometry_ready=False;self.ready=False;self.callbacks=set()
        self.mapping=None;self.entities=[];self.descriptors=[];self.poses=[]
        self.started=time.time();self.phase='mapping';self.temporary_camera=None;self.geometry_settle_until=None
    def mark(self,stage,**kw):
        from . import native_match as N
        kw.update(geometry_loaded=self.geometry_ready,world_phase=self.phase)
        kw.setdefault('combat_enabled',bool(getattr(self,'combat',None) and self.combat.started and not self.combat.stopped))
        kw.setdefault('simulation',getattr(self.combat,'physics_model','legacy0922_fixed_step') if getattr(self,'combat',None) else 'static_spawn_clock')
        N.mark(stage,**kw)
    def valid(self):
        import BigWorld
        from . import native_match as N
        return self.active and N._GENERATION==self.generation and not N._RETURNING and BigWorld.player() is self.avatar
    def later(self,delay,fn):
        import BigWorld
        holder=[None]
        def run():
            self.callbacks.discard(holder[0])
            if not self.valid():return
            try:fn()
            except Exception:
                self.mark('world_failed',error=traceback.format_exc())
                from . import native_match as N
                N.request_return()
        holder[0]=BigWorld.callback(delay,run);self.callbacks.add(holder[0])
    def stop(self):
        import BigWorld
        self.active=False
        if getattr(self,'combat',None) is not None:self.combat.stop()
        from . import battle_state146
        try:battle_state146.restore_visibility(self)
        except Exception:self.mark('far_clip_restore_warning',warning=traceback.format_exc())
        for token in list(self.callbacks):
            try:BigWorld.cancelCallback(token)
            except ValueError:pass
        self.callbacks.clear()
        from . import sky_probe146
        sky_probe146.restore_camera_binding(self)
        sky_probe146.restore_sky(self)
        self.sky_probe_refs=None
    def map_geometry(self):
        import BigWorld,ArenaType,Math
        self.arena=ArenaType.g_cache[self.plan['arenaTypeID']]
        from .map146 import validate_map,resource_exists
        geometry=validate_map(self.arena,resource_exists)
        home=spawn146.bases(self.arena)[0][0]
        mask=int(ArenaType.getVisibilityMask(self.plan['arenaTypeID']))
        if not 0<mask<1<<20:raise ValueError('Invalid native CTF visibility mask')
        early=getattr(self.avatar,'_hangar146_early_geometry',None)
        if early is not None:
            if (early.get('spaceID')!=int(self.avatar.spaceID) or
                    early.get('generation')!=self.generation or
                    early.get('geometry')!=geometry or early.get('visibility_mask')!=mask):
                raise RuntimeError('Early geometry does not belong to this session')
            if early.get('adopted'):raise RuntimeError('Early geometry was already adopted')
            if not early.get('mapping_id'):raise RuntimeError('Early geometry has no mapping ID')
            self.mapping=early['mapping_id'];early['adopted']=True
            self.mark('early_avatar_geometry_adopted',mapping_id=int(self.mapping),
                geometry_mapping_reused=True,geometry_load_phase='before_avatar_base_init')
        camera=BigWorld.CursorCamera();camera.spaceID=self.avatar.spaceID
        source=Math.Matrix();source.setRotateYPR((0.,-.6,0.));camera.source=source
        target=Math.Matrix();target.setTranslate((home[0],50.,home[1]));camera.target=target
        camera.pivotMaxDist=60.;camera.pivotPosition=(0.,5.,0.)
        BigWorld.camera(camera);self.temporary_camera=camera
        # Environment XML/default preset is registered INSIDE addSpaceGeometryMapping.
        # Make its target space current before that registration, not afterwards.
        # This function has a default ZERO setter: always pass the explicit ID.
        result=int(BigWorld.cameraSpaceID(self.avatar.spaceID))
        if result!=int(self.avatar.spaceID):raise RuntimeError('Battle camera space was not selected before mapping')
        if early is not None:
            self.mark('camera_space_selected_for_early_geometry',mapping_camera_space_id=result,
                mapping_camera_object_space_id=int(camera.spaceID),
                environment_load_order='geometry_before_avatar_base_init')
        else:
            # Compatibility for explicitly started sessions that were not
            # constructed by native_match; normal local battle uses early above.
            self.mark('camera_space_selected_before_mapping',mapping_camera_space_id=result,
                mapping_camera_object_space_id=int(camera.spaceID),environment_load_order='camera_then_geometry')
            self.mark('geometry_mapping_before',visibility_mask=mask,geometry_api='BigWorld.addSpaceGeometryMapping(spaceID,pMapper,path,visMask,environment)')
            # New x64 binding explicitly exposes visMask (default -1). Never map all
            # gameplay variants, never rewrite old x86 push instructions.
            self.mapping=BigWorld.addSpaceGeometryMapping(self.avatar.spaceID,None,geometry,mask,'')
            if not self.mapping:raise RuntimeError('Geometry mapping returned no mapping ID')
        self.phase='loading_geometry';self.mark('geometry_mapping_after',mapping_id=int(self.mapping))
        self.later(.25,self.wait_geometry)
    def wait_geometry(self):
        import BigWorld
        progress=float(BigWorld.spaceLoadStatus())
        if time.time()-self.started>180:raise RuntimeError('Geometry loading timeout (180 seconds)')
        if math.isnan(progress) or math.isinf(progress):raise RuntimeError('Nonfinite geometry loading status')
        if progress<.999 or not BigWorld.virtualTextureRenderComplete():
            self.geometry_settle_until=None;self.later(.25,self.wait_geometry);return
        # The native ArenaSpaceLoadListener also waits two seconds after load/VT
        # completion. Do not initialize the Avatar on a transient empty-space 1.0.
        if self.geometry_settle_until is None:self.geometry_settle_until=time.time()+2.
        if time.time()<self.geometry_settle_until:
            self.later(.25,self.wait_geometry);return
        self.geometry_ready=True;self.phase='planning_spawns';self.mark('geometry_ready',space_load_progress=progress)
        from . import battle_state146
        self.avatar.onSpaceLoaded()
        from .economy import descriptor
        self.records=[self.plan['player']]+self.plan['bots']
        self.descriptors=[descriptor(rec) for rec in self.records]
        self.poses=spawn146.plan(self.arena,self.descriptors,self.ground,self.rotate,self.free,random.Random(self.plan['roundID']))
        self.mark('spawn_plan_ready',spawns=self.poses,base_exclusion_radius=5.,vehicle_clearance=2.)
        self.later(0.,self.create_vehicles)
    def rotate(self,point,angles):
        import Math
        matrix=Math.Matrix();matrix.setRotateYPR(angles)
        return tuple(matrix.applyVector(Math.Vector3(*point)))
    def ray(self,start,end,terrain=False):
        import BigWorld,Math
        args=(self.avatar.spaceID,Math.Vector3(*start),Math.Vector3(*end),128)
        return BigWorld.collideSegment(*(args+(8,) if terrain else args))
    def ground(self,x,z):
        import BigWorld,Math
        top,bottom=2000.,-2000.
        hit=self.ray((x,top,z),(x,bottom,z),True)
        if hit is None:return
        y=float(hit.closestPoint.y)
        if math.isnan(y) or math.isinf(y):return
        water=float(BigWorld.collideWater(Math.Vector3(x,top,z),Math.Vector3(x,bottom,z),False))
        if water>=0 and top-water-y>.4:return
        return y
    def free(self,pose):
        # Terrain-only support does not establish that a house/rock is absent.
        # Check the actual chassis/hull envelope against the static scene.
        x,y,z=pose['position'];lo,hi=pose['bounds'];angles=(pose['yaw'],pose['pitch'],pose['roll'])
        samples=[]
        for height in (lo[1]+.35,(lo[1]+hi[1])*.5,hi[1]-.1):
            ring=[]
            for u,v in ((lo[0],lo[2]),(hi[0],lo[2]),(hi[0],hi[2]),(lo[0],hi[2])):
                dx,dy,dz=self.rotate((u,height,v),angles);ring.append((x+dx,y+dy,z+dz))
            for i in range(4):
                if self.ray(ring[i],ring[(i+1)%4]) is not None:return False
            if self.ray(ring[0],ring[2]) is not None or self.ray(ring[1],ring[3]) is not None:return False
            samples.append(ring)
        for i in range(4):
            if self.ray(samples[0][i],samples[-1][i]) is not None:return False
        return True
    def create_vehicles(self):
        global _CREATING
        import BigWorld
        from . import match_plan
        self.phase='loading_vehicles'
        _CREATING=True
        try:
            for index,(rec,descr,pose) in enumerate(zip(self.records,self.descriptors,self.poses)):
                props=properties(rec,descr,index,self.avatar)
                eid=BigWorld.createEntity('Vehicle',self.avatar.spaceID,0,pose['position'],(pose['roll'],pose['pitch'],pose['yaw']),props)
                vehicle=BigWorld.entities[eid]
                if getattr(vehicle,'_hangar146_init_failure',None):raise RuntimeError(vehicle._hangar146_init_failure)
                self.entities.append(vehicle)
        finally:_CREATING=False
        self.plan['entityIDs']=[int(v.id) for v in self.entities]
        from ._constants import OFFLINE_NICKNAME,OFFLINE_DBID
        from constants import ARENA_UPDATE
        rows=[tuple(list(row[:5])+[True]+list(row[6:])) for row in match_plan.roster(self.plan,OFFLINE_NICKNAME,OFFLINE_DBID)]
        self.plan['playerVehicleID']=int(self.entities[0].id)
        self.avatar.playerVehicleID=self.entities[0].id
        self.avatar.arena.update(ARENA_UPDATE.VEHICLE_LIST,zlib.compress(pickle.dumps(rows,2)))
        dp=self.avatar.guiSessionProvider.getArenaDP()
        # setPlayerVehicle updates controllers, NOT ArenaDataProvider's cached ID.
        # Exact 1.46 native refresh method; no direct private-slot assignment.
        if not dp._ArenaDataProvider__tryToGetRequiredData():raise RuntimeError('Native arena identity refresh failed')
        if dp.getPlayerVehicleID()!=self.avatar.playerVehicleID:raise RuntimeError('Native arena retained loading player ID')
        self.mark('arena_identity_refreshed',playerVehicleID=self.avatar.playerVehicleID)
        for v in self.entities:
            v._hangar146_defer_enter=False;v.onEnterWorld([])
        self.mark('native_vehicles_created',entity_ids=self.plan['entityIDs'],playerVehicleID=self.avatar.playerVehicleID)
        self.later(.1,self.wait_vehicles)
    def wait_vehicles(self):
        for v in self.entities:
            failure=getattr(v,'_hangar146_enter_failure',None) or getattr(v,'_hangar146_appearance_failure',None)
            if failure:raise RuntimeError(failure)
        if any(v.appearance is None or not v.appearance.isConstructed for v in self.entities):
            if time.time()-self.started>240:raise RuntimeError('Vehicle appearance loading timeout')
            self.later(.1,self.wait_vehicles);return
        self.avatar._hangar146_attached_vehicle=self.entities[0]
        self.avatar.vehicleTypeDescriptor=self.entities[0].typeDescriptor
        # The loading roster used provisional IDs. Appearance callbacks have
        # already marked our own Vehicle, so native set_playerVehicleID can skip
        # its setPlayerVehicle branch. Publish the real ID before GUI startup.
        self.avatar.guiSessionProvider.setPlayerVehicle(self.avatar.playerVehicleID,self.avatar.vehicleTypeDescriptor)
        self.mark('native_ready_before',playerVehicleID=self.avatar.playerVehicleID)
        self.ready=True;self.avatar.set_playerVehicleID(0)
        self.avatar._PlayerAvatar__onInitStepCompleted()
        if not self.avatar.initCompleted:raise RuntimeError('Native Avatar initialization did not complete')
        ctrl=getattr(self.avatar,'_hangar146_arena_load_ctrl',None)
        if ctrl is None:raise RuntimeError('Native ArenaLoadController was not captured')
        self.mark('native_init_complete')
        ctrl.arenaLoadCompleted()
        if not all(v.isStarted for v in self.entities):raise RuntimeError('Native Vehicle visuals did not start')
        self.temporary_camera=None
        from . import battle_state146
        # The native input handler has now installed the real battle camera.
        # Activate the environment here, not on the temporary loading camera.
        battle_state146.environment(self)
        from . import combat146
        combat146.attach(self)
        battle_state146.initialize_controls(self)
        try:battle_state146.configure_visibility(self)
        except Exception:self.mark('far_clip_configuration_warning',warning=traceback.format_exc())
        try:battle_state146.inspect_environment(self)
        except Exception:self.mark('environment_inspection_warning',warning=traceback.format_exc())
        self.later(2.,self.inspect_presentation)
        self.phase='prebattle';self.period('PREBATTLE',10.)
        self.mark('world_prebattle',countdown_seconds=10.,duration_seconds=900.,vehicles_started=len(self.entities))
        self.later(10.,self.live)
    def inspect_presentation(self):
        from . import battle_state146,sky_probe146
        battle_state146.report_presentation(self)
        sky_probe146.inspect_scene(self)
    def period(self,name,duration,additional=None):
        import BigWorld
        from constants import ARENA_UPDATE,ARENA_PERIOD
        now=BigWorld.serverTime();end=now+duration
        self.avatar.arena.update(ARENA_UPDATE.PERIOD,zlib.compress(pickle.dumps((getattr(ARENA_PERIOD,name),end,duration,{} if additional is None else additional),2)))
        self.mark('local_period_set',period=name,server_time=float(now),period_end=float(end),period_length=duration)
    def live(self):
        self.phase='live';self.period('BATTLE',900.)
        from . import battle_state146
        battle_state146.unlock_aim(self)
        try:battle_state146.configure_visibility(self)
        except Exception:self.mark('far_clip_configuration_warning',warning=traceback.format_exc())
        self.combat.start()
        self.mark('world_live',duration_seconds=900.)
        self.later(900.,self.finished)
    def finished(self):
        if getattr(self,'combat',None) is not None:
            # The 60 Hz authority owns the timeout and its extendable grace.
            self.combat.round.check()
            return
        self.phase='finished';self.mark('world_duration_elapsed')
        from . import native_match as N
        N.request_return()


def retire_visuals(avatar):
    """Deactivate local appearances while inputHandler/controllers still exist."""
    import BigWorld
    from .native_match import local_avatar,mark
    if not local_avatar(avatar):return
    rotator=getattr(avatar,'gunRotator',None)
    if rotator is not None:rotator.stop()
    failures=[];stopped=[]
    for vehicle in list(getattr(BigWorld,'entities',{}).values()):
        if not getattr(vehicle,'_hangar146_vehicle',False) or not getattr(vehicle,'isStarted',False):continue
        try:
            avatar.onVehicleLeaveWorld(vehicle)
            if avatar.playerVehicleID==vehicle.id:
                from PlayerEvents import g_playerEvents
                g_playerEvents.onAvatarVehicleLeaveWorld()
            vehicle.stopVisual()
            stopped.append(int(vehicle.id))
        except Exception:failures.append(dict(vehicle_id=int(vehicle.id),traceback=traceback.format_exc()))
    # Appearance.deactivate restores the original DumbFilter. Native leave-world
    # camera callbacks must not relink to its nonexistent stabilisedMatrix.
    avatar._hangar146_attached_vehicle=None
    if stopped or failures:mark('local_visuals_retired',stopped_vehicle_ids=stopped,visual_retire_failures=failures)


def install():
    import BigWorld,Vehicle,Avatar
    from .utils import override
    from .server import FakeServer
    from .battle_state146 import install_clock
    install_clock()
    @override(Avatar.PlayerAvatar,'_PlayerAvatar__onSetOwnVehicleAuxPhysicsData')
    def auxiliary_pose(base,self,prev):
        from .native_match import local_avatar
        vehicle=BigWorld.entity(self.playerVehicleID)
        if not local_avatar(self) or vehicle is None or not getattr(vehicle,'_hangar146_vehicle',False):return base(self,prev)
        if vehicle.id and vehicle.isStarted:
            # No received auxiliary physics packet exists in STATIC mode.
            # In particular, never call VehicleFilter.syncStabilisedYPR: it
            # timestamps a history through the absent BWConnection clock.
            vehicle.appearance.updateTracksScroll(0.,0.)
            self._PlayerAvatar__ownVehicleStabMProv.target=vehicle.matrix
    @override(Avatar.PlayerAvatar,'_PlayerAvatar__startVehicleVisual')
    def avatar_visual(base,self,vehicle,*args,**kwargs):
        result=base(self,vehicle,*args,**kwargs)
        from .native_match import local_avatar,mark
        if local_avatar(self) and getattr(vehicle,'_hangar146_vehicle',False) and vehicle.id==self.playerVehicleID and vehicle.isStarted:
            # Native caller assigns filter.stabilisedMatrix after auxiliary_pose.
            # Rebind it after the original method to the terrain-planned pose.
            self._PlayerAvatar__ownVehicleStabMProv.target=vehicle.matrix
            mark('static_pose_bound',vehicle_id=int(vehicle.id),network_angle_history=False)
        return result
    raw=Vehicle.Vehicle.__getattribute__
    @override(Vehicle.Vehicle,'__init__')
    def initialize(base,self):
        if not _CREATING:return base(self)
        self._hangar146_vehicle=True;self._hangar146_defer_enter=True;self._hangar146_server=FakeServer(self)
        try:
            result=base(self);self.filter=BigWorld.DumbFilter();return result
        except Exception:self._hangar146_init_failure=traceback.format_exc();raise
    @override(Vehicle.Vehicle,'_Vehicle__startPhysics')
    def start_physics(base,self):
        if not getattr(self,'_hangar146_vehicle',False):return base(self)
        # This milestone is STATIC. CompoundAppearance.activate() replaces our
        # initial DumbFilter with its VehicleFilter. Native __startPhysics then
        # attaches TankPhysics and calls syncGunAngles -> connection clock. No
        # BWConnection exists in a locally-created Account/Avatar session.
        # Keep native model activation, but never start network-owned simulation.
        self._hangar146_static_physics=True
    @override(Vehicle.Vehicle,'set_gunAnglesPacked')
    def gun_angles(base,self,*args):
        if not getattr(self,'_hangar146_vehicle',False):return base(self,*args)
        # Property itself is retained. Initial angles are neutral in properties().
        # No native time-stamped angle history in static mode; NOT a firing fix.
        from gun_rotation_shared import decodeGunAngles
        self._hangar146_static_gun_angles=decodeGunAngles(self.gunAnglesPacked,self.typeDescriptor.gun.pitchLimits['absolute'])
    @override(Vehicle.Vehicle,'startVisual')
    def visual(base,self,*args):
        if not getattr(self,'_hangar146_vehicle',False):return base(self,*args)
        from . import native_match as N
        N.mark('vehicle_visual_before',vehicle_id=int(self.id),network_physics=False)
        result=base(self,*args)
        N.mark('vehicle_visual_after',vehicle_id=int(self.id),is_started=bool(self.isStarted))
        return result
    @override(Vehicle.Vehicle,'__getattribute__')
    def gateway(base,self,name):
        if name in ('base','cell','server'):
            try:local=raw(self,'_hangar146_vehicle')
            except AttributeError:local=False
            if local:return raw(self,'_hangar146_server')
        return base(self,name)
    @override(Vehicle.Vehicle,'onEnterWorld')
    def entered(base,self,*args):
        if getattr(self,'_hangar146_defer_enter',False):return
        try:return base(self,*args)
        except Exception:
            if getattr(self,'_hangar146_vehicle',False):self._hangar146_enter_failure=traceback.format_exc()
            raise
    @override(Vehicle.Vehicle,'onLeaveWorld')
    def left(base,self,*args):
        # A failed constructor/deferred entry has no descriptor/cache to stop.
        if getattr(self,'_hangar146_vehicle',False):
            if getattr(self,'typeDescriptor',None) is None or getattr(self,'_hangar146_world_left',False):return
            self._hangar146_world_left=True
        return base(self,*args)
    @override(Vehicle.Vehicle,'_Vehicle__onAppearanceReady')
    def appearance(base,self,*args):
        try:return base(self,*args)
        except Exception:
            if getattr(self,'_hangar146_vehicle',False):self._hangar146_appearance_failure=traceback.format_exc()
            raise
