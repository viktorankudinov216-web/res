# -*- coding: utf-8 -*-
"""Restart-applied UTF-8 roster; 0 hides, never erases a saved vehicle."""
from __future__ import absolute_import
import os,io
from . import runtime_data as R

def path():return os.path.join(R.game_root(),'mods','configs','hangar146','vehicles.ini')
def visible(rec):return rec.get('visible',True)
def read(filename):
    flags={}
    if not os.path.isfile(filename):return flags
    with io.open(filename,'r',encoding='utf-8-sig') as f:
        for lineno,line in enumerate(f,1):
            line=line.split('#',1)[0].split(';',1)[0].strip()
            if not line or line.startswith('['):continue
            fields=line.split('=')
            if len(fields)!=2 or not fields[0].strip().isdigit() or fields[1].strip() not in ('0','1'):
                raise ValueError('vehicles.ini invalid line '+str(lineno))
            key=int(fields[0]);flag=int(fields[1])
            if key in flags:raise ValueError('vehicles.ini duplicate vehicle '+str(key))
            flags[key]=flag
    return flags

def labels():
    from items import vehicles
    result={}
    for r in R.catalog()['vehicles']:
        nation,tid=map(int,r['key'].split(':'))
        # List metadata only: do NOT instantiate every vehicle/model/descriptor.
        basic=(vehicles.g_list.getList(nation) or {}).get(tid)
        text=getattr(getattr(basic,'i18n',None),'userString',None)
        text=text or r['name']
        if isinstance(text,str):text=text.decode('utf-8','replace')
        result[r['typeCD']]=text
    return result

def write(flags,names=None):
    filename=path();folder=os.path.dirname(filename)
    if not os.path.isdir(folder):os.makedirs(folder)
    if names is None:names=labels()
    rows=sorted(R.catalog()['vehicles'],key=lambda r:(-r['level'],names[r['typeCD']],r['typeCD']))
    lines=[u'# Hangar146 M04. Edit only 0/1, then restart the game.',u'# 0 = hidden (saved build/crew retained); 1 = visible. ID = flag # game label | internal name',u'# XI -> I. Special/event prototypes may need their own modes/assets.',u'[vehicles]']
    prev=None
    for r in rows:
        if r['level']!=prev:prev=r['level'];lines.append(u'\n# LEVEL '+unicode(prev))
        label=names[r['typeCD']]
        if isinstance(label,str):label=label.decode('utf-8','replace')
        label=label.replace('\n',' ').replace('\r',' ')
        lines.append(u'%s = %s # %s | %s'%(r['typeCD'],flags.get(r['typeCD'],0),label,r['name']))
    tmp=filename+'.tmp';backup=filename+'.bak'
    with io.open(tmp,'w',encoding='utf-8') as f:f.write(u'\n'.join(lines)+u'\n');f.flush();os.fsync(f.fileno())
    if os.path.exists(backup):os.remove(backup)
    if os.path.isfile(filename):os.rename(filename,backup)
    try:os.rename(tmp,filename)
    except Exception:
        if os.path.exists(backup):os.rename(backup,filename)
        raise

def apply(v,flags):
    from .economy import build_vehicle
    rows=dict((r['typeCD'],r) for r in R.catalog()['vehicles'])
    if set(flags)-set(rows):raise ValueError('vehicles.ini contains unknown vehicle IDs')
    bycd=dict((r['typeCD'],r) for r in v['vehicles'].values())
    for rec in bycd.values():rec.setdefault('visible',True)
    for cd,flag in flags.items():
        if cd in bycd:bycd[cd]['visible']=bool(flag)
        elif flag:
            ids=[int(k) for k in v['vehicles']]+[(int(tid)-100000)//100 for tid in v.get('barracks',{})]+[0]
            vid=max(max(ids)+1,v.get('next_vehicle_id',1));v['next_vehicle_id']=vid+1
            rec=build_vehicle(rows[cd]);rec['visible']=True;v['vehicles'][str(vid)]=rec;bycd[cd]=rec
    return dict((cd,int(visible(bycd[cd])) if cd in bycd else 0) for cd in rows)

def sync(value):
    flags=dict((r['typeCD'],int(visible(r))) for r in value['vehicles'].values())
    write(flags)
