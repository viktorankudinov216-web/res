# -*- coding: utf-8 -*-
"""6DOF raycast tracked body. No BigWorld, subprocesses or position controllers.

An OBB is an explicit collision approximation, NOT the native convex mesh.
Static map geometry is sampled by the main-thread adapter once per 60Hz tick.
Two SI substeps integrate forces; contact planes are valid for that tick only.
"""
from __future__ import absolute_import
import math
from .math3 import *
from . import grip0922 as grip,handling

class Body(object):
 def __init__(self,origin,ypr,mass,lo,hi,com):
  self.q=quat(*ypr);self.com=tuple(com);self.p=add(origin,rotate(self.q,self.com))
  self.v=ZERO;self.w=ZERO;self.mass=max(1.,float(mass));self.inv=1./self.mass
  self.lo=tuple(lo);self.hi=tuple(hi);self.clouds={};self._support_cache={};self.shapes=[(self.lo,self.hi,ZERO,(1.,0.,0.,0.))]
  x,y,z=[max(.2,hi[i]-lo[i]) for i in range(3)]
  self.inertia=(self.mass*(y*y+z*z)/12.,self.mass*(x*x+z*z)/12.,self.mass*(x*x+y*y)/12.)
  self.force=ZERO;self.torque=ZERO
 def origin(self):return sub(self.p,rotate(self.q,self.com))
 def world(self,local):return add(self.p,rotate(self.q,sub(local,self.com)))
 def point_velocity(self,point):return add(self.v,cross(self.w,sub(point,self.p)))
 def inverse_inertia(self,v):
  local=rotate(conjugate(self.q),v)
  return rotate(self.q,tuple(local[i]/self.inertia[i] for i in range(3)))
 def inertia_world(self,v):
  local=rotate(conjugate(self.q),v)
  return rotate(self.q,tuple(local[i]*self.inertia[i] for i in range(3)))
 def apply(self,force,point):
  self.force=add(self.force,force);self.torque=add(self.torque,cross(sub(point,self.p),force))
 def impulse(self,j,point):
  self.v=add(self.v,mul(j,self.inv));self.w=add(self.w,self.inverse_inertia(cross(sub(point,self.p),j)))
 def effective(self,point,n):
  r=sub(point,self.p)
  return self.inv+dot(n,cross(self.inverse_inertia(cross(r,n)),r))
 def integrate_velocity(self,dt):
  self.v=add(self.v,mul(self.force,self.inv*dt))
  gyro=cross(self.w,self.inertia_world(self.w))
  self.w=add(self.w,mul(self.inverse_inertia(sub(self.torque,gyro)),dt))
  # Weak isotropic numerical/air damping, not a horizon-aligning torque.
  self.v=mul(self.v,math.exp(-.008*dt));self.w=mul(self.w,math.exp(-.04*dt))
 def integrate_pose(self,dt):
  self.p=add(self.p,mul(self.v,dt));self.q=advance(self.q,self.w,dt)
 def add_shape(self,lo,hi,offset=ZERO,orientation=(1.,0.,0.,0.)):
  self.shapes.append((tuple(lo),tuple(hi),tuple(offset),orientation))
 def support(self,n,shape_index=None):
  results=[]
  for index,(lo,hi,offset,q) in enumerate(self.shapes):
   if shape_index is not None and index!=shape_index:continue
   local_n=rotate(conjugate(q),rotate(conjugate(self.q),n))
   cloud=self.clouds.get(index)
   if cloud:
    key=(index,id(cloud),tuple(round(v,6) for v in local_n))
    coords=self._support_cache.get(key)
    if coords is None:
     projected=[(dot(point,local_n),point) for point in cloud]
     minimum=min(row[0] for row in projected)
     face=[point for value,point in projected if value<=minimum+.002]
     coords=tuple(sum(point[i] for point in face)/len(face) for i in range(3))
     if len(self._support_cache)>=256:self._support_cache.clear()
     self._support_cache[key]=coords
   else:coords=tuple(lo[i] if local_n[i]>1e-6 else hi[i] if local_n[i]<-1e-6 else (lo[i]+hi[i])*.5 for i in range(3))
   results.append(self.world(add(offset,rotate(q,coords))))
  return min(results,key=lambda point:dot(point,n))

class Wheel(object):
 def __init__(self,x,z,mount,rest,travel,mass,side,radius=.35,name='',static_deflection=None):
  self.local=(x,mount,z);self.rest=rest;self.travel=travel;self.mass=mass;self.side=side;self.radius=radius;self.name=name
  freq=2.*math.pi*1.55
  self.k=mass*freq*freq;self.c=2.*.9*mass*freq
  if static_deflection is not None:
   self.k=mass*9.81/max(.025,static_deflection);self.c=2.*.95*math.sqrt(self.k*mass)
  self.support_radius=radius;self.compression=mass*9.81/self.k;self.load=0.;self.contact=False
 def ray(self,body):
  up=rotate(body.q,(0.,1.,0.));a=body.world(self.local)
  return a,sub(a,mul(up,self.rest+self.support_radius+.10))

def track_targets(flags,speed,params,half_track):
 throttle=float(bool(flags&1))-float(bool(flags&2));steer=float(bool(flags&8))-float(bool(flags&4));brake=bool(flags&64)
 maximum=params['speedFwd'] if throttle>=0 else params['speedBwd']
 # Desired surface velocity is a drive slip target, not assigned hull speed.
 target=throttle*maximum
 yaw=steer*params['rotSpd']*half_track
 if brake and steer:
  # Pivot about the braked inside track: outside track drives FORWARD.
  return (abs(yaw)*2.,0.) if steer>0 else (0.,abs(yaw)*2.)
 if brake:return (0.,0.)
 return (target+yaw,target-yaw)

class Vehicle(object):
 def __init__(self,body,wheels,params):
  self.b=body;self.wheels=wheels;self.params=params;self.drive_params=grip.parameters(params);self.tracks=(0.,0.);self.contacts=0;self.last_landing=None
 def tick(self,dt,flags,hits,planes):
  b=self.b;h=dt/2.;self.last_landing=None;self.drive_params.update(self.params)
  targets=track_targets(flags,dot(b.v,rotate(b.q,(0.,0.,1.))),self.params,max(.3,self.params.get('trackCenter',1.5)))
  for unused in range(2):
   velocity_before_step=b.v
   b.force=(0.,-9.81*b.mass,0.);b.torque=ZERO;active=[]
   forward=rotate(b.q,(0.,0.,1.));right=rotate(b.q,(1.,0.,0.));up=rotate(b.q,(0.,1.,0.))
   # Backward-Euler spring/damper constraints, solved as coupled impulses.
   # Gravity enters once; no explicit 8g spring kick at bottom-out.
   b.integrate_velocity(h)
   struts=[]
   for wheel,hit in zip(self.wheels,hits):
    wheel.contact=False;wheel.load=0.;wheel.compression=0.
    if hit is None:continue
    plane,normal=hit;ny=dot(up,normal)
    if ny<.25:continue
    mount=b.world(wheel.local)
    # Re-intersect the tick's local plane with this substep's actual strut.
    distance=dot(sub(mount,plane),normal)/ny-wheel.support_radius
    point=sub(mount,mul(up,distance+wheel.support_radius))
    if length(sub(point,plane))>.45:continue
    compression=wheel.rest-distance
    if compression<0.:continue
    wheel.compression=clamp(compression,0.,wheel.travel)
    over=max(0.,compression-wheel.travel)
    stiffness=wheel.k*(1.+4.*min(1.,over/max(.04,wheel.travel)))
    elastic=wheel.k*compression+wheel.k*4.*over
    vn=dot(b.point_velocity(point),normal)
    damping=wheel.c*(2.2 if vn>0. else 1.15)
    # x is strut-axis compression; dx/dt = -normal speed / ny.
    denom=damping+h*stiffness/ny
    gamma=1./max(1e-9,h*denom)
    bias=elastic/denom
    struts.append([wheel,point,normal,gamma,bias,0.])
   for iteration in range(6):
    for row in struts:
     wheel,point,normal,gamma,bias,accum=row
     vn=dot(b.point_velocity(point),normal)
     delta=(bias-vn-gamma*accum)/(b.effective(point,normal)+gamma)
     value=clamp(accum+delta,0.,wheel.mass*9.81*8.*h)
     b.impulse(mul(normal,value-accum),point);row[5]=value
   for wheel,point,normal,gamma,bias,impulse in struts:
    force=impulse/h
    if force<=1e-6:continue
    wheel.load=force;wheel.contact=True;active.append((wheel,point,normal,force))
   old_contacts=self.contacts;self.contacts=len(active)
   if not old_contacts and active:self.last_landing=max(0.,-velocity_before_step[1])
   velocity_before_forces=velocity_before_step
   throttle=float(bool(flags&1))-float(bool(flags&2))
   steer=float(bool(flags&8))-float(bool(flags&4));brake=bool(flags&64)
   total_load=sum(row[3] for row in active);self.governor_impulse=0.
   if total_load>1e-6:
    normal=unit(tuple(sum(row[2][i]*row[3] for row in active) for i in range(3)))
    f=unit(sub(forward,mul(normal,dot(forward,normal))),(0.,0.,1.));r=unit(cross(normal,f),(1.,0.,0.))
    vf=dot(b.v,f);before=dot(velocity_before_forces,f);vr=dot(b.v,r);wy=dot(b.w,normal)
    gauge=max(.35,sum(abs(w.local[0]-b.com[0])*load for w,pt,n,load in active)/total_load)
    load_by_side=[sum(load for w,pt,n,load in active if w.side==side) for side in ('left','right')]
    two_sides=min(load_by_side)>total_load*.02
    pitch=math.asin(clamp(-f[1],-1.,1.))
    ny=max(.1,normal[1]);mu_long,mu_lat=grip.coefficients(self.drive_params,ny,throttle or abs(vf)>.05)
    # Track adhesion is not the donor's parked fall-line threshold (0.5g).
    # Use contact cohesion for moving lateral grip as well.
    mu_lat=max(mu_lat,mu_long*1.10)
    target_speed=grip.next_speed(self.drive_params,before,throttle,bool(steer),pitch,h,brake and not steer)
    # Imported donor integrates its own slope gravity. Match its TOTAL next
    # speed against velocity AFTER rigid forces, so gravity is never doubled.
    mode=handling.brake_mode(before,throttle,brake)
    braking_decel=handling.deceleration(mode)
    if braking_decel:target_speed=handling.brake_target(before,pitch,h,braking_decel)
    longitudinal=b.mass*(target_speed-vf)/h
    center_contact=tuple(sum(pt[i]*load for w,pt,n,load in active)/total_load for i in range(3))
    cg_height=max(.35,dot(sub(b.p,center_contact),normal))
    # Limit commanded lateral load transfer, not the roll angle. Real spring
    # forces remain responsible for pitch/roll and airborne motion.
    safe_lateral=.55*9.81*gauge/cg_height
    cap_long=mu_long*total_load;cap_lat=min(mu_lat*total_load*.85,b.mass*safe_lateral)
    longitudinal=clamp(longitudinal,-cap_long,cap_long)
    desired_yaw=steer*self.params['rotSpd']*(-1. if throttle<0. else 1.)
    yaw_cap=cap_lat/b.mass/max(1.,abs(vf));desired_yaw=clamp(desired_yaw,-yaw_cap,yaw_cap)
    old_target=getattr(self,'steering_target',0.)
    rise=2.5 if abs(vf)>2. else 8.
    desired_yaw=clamp(desired_yaw,old_target-rise*h,old_target+rise*h) if steer else 0.
    self.steering_target=desired_yaw
    yaw_inertia=1./max(1e-12,dot(normal,b.inverse_inertia(normal)))
    yaw_torque=yaw_inertia*(desired_yaw-wy)/(.09 if steer else h)
    # Counteract the yaw moment from lateral contact forces before allocating
    # differential drive. Otherwise grip itself fights steering at road speed.
    # Anticipate rotation of the contact frame: centripetal force is not
    # obtained by waiting for one substep of sideways sliding.
    lateral_trial=clamp(b.mass*(vf*wy-vr/h),-cap_lat,cap_lat)
    lateral_moment=sum(dot(cross(sub(pt,b.p),mul(r,lateral_trial*load/total_load)),normal) for w,pt,n,load in active)
    yaw_torque-=lateral_moment
    if not two_sides:
     # An airborne track cannot supply the opposing torque. Do NOT cancel
     # the remaining track's propulsion while trying to enforce zero yaw.
     yaw_torque=0.
    elif steer:
     effort=grip.steering_effort(self.drive_params,vf,pitch,total_load)
     if brake and abs(vf)<1.0:
      # Once nearly stopped, pivot about the locked inside belt. At road
      # speed the handbrake must BRAKE, not accelerate toward a pivot target.
      target_center=abs(desired_yaw)*gauge
      longitudinal=clamp(b.mass*(target_center-vf)/.18,-b.mass*9.5,b.mass*3.0)
     # Braking and slope holding do not consume engine power. Only positive
     # commanded traction shares the engine budget with active steering.
     driven=max(0.,longitudinal*throttle) if throttle else max(0.,longitudinal) if brake else 0.
     if abs(vf)<1.5:
      budget=min(1.,effort/max(1e-9,driven+abs(yaw_torque)/gauge))
      if driven:longitudinal*=budget
      yaw_torque*=budget
    else:yaw_torque=clamp(yaw_torque,-cap_long*gauge,cap_long*gauge)
    requested_yaw_torque=yaw_torque
    scrub_torque=0.
    if two_sides:
     # The weaker belt limits corrective yaw authority. Never consume the
     # loaded belt's entire propulsion to demand torque from a near-air belt.
     authority=2.*gauge*mu_long*min(load_by_side)*.85
     yaw_torque=clamp(yaw_torque,-authority,authority)
    if two_sides:
     # A released turn is braked by the WHOLE track footprint, not only by
     # longitudinal forces separated by the narrow track gauge. Front/rear
     # lateral contacts supply scrub torque; all impulses still share the
     # same per-patch Coulomb ellipse below. No angular velocity assignment.
     scrub_capacity=sum(mu_lat*load*abs(dot(sub(pt,b.p),f)) for w,pt,n,load in active)*.85
     # Front/rear patches also correct yaw error DURING a turn, preventing
     # the unloaded rear from being left to drift behind the driven front.
     if steer:yaw_torque*=.40
     scrub_torque=clamp(requested_yaw_torque-yaw_torque,-scrub_capacity,scrub_capacity)
    if steer and abs(vf)>=1.5:
     # Charge only APPLIED torque at ACTUAL angular speed, after authority
     # clamping. M11 charged an uncapped desired torque even before turning.
     power=max(0.,yaw_torque*wy)
     longitudinal-=math.copysign(power/max(1.5,abs(vf)),vf)
    braking=longitudinal*vf<0. and abs(vf)>.025
    if braking:
     wheelbase=max(w.local[2] for w in self.wheels)-min(w.local[2] for w in self.wheels)
     safe_decel=.65*9.81*wheelbase*.5/cg_height
     limit=min(braking_decel or 7.5,safe_decel)
     longitudinal=clamp(longitudinal,-b.mass*limit,b.mass*limit)
    previous=getattr(self,'last_longitudinal',0.)
    # Faster pressure rise than M11, still finite to avoid a contact impulse.
    jerk=75. if brake else 55. if mode=='counter' else 60.
    change=b.mass*jerk*h if braking else cap_long*2.
    longitudinal=clamp(longitudinal,previous-change,previous+change)
    if braking_decel and not (brake and steer and abs(vf)<1.):
     stop=b.mass*(target_speed-vf)/h
     if stop*longitudinal<0.:longitudinal=0.
     elif abs(longitudinal)>abs(stop):longitudinal=stop
    self.last_longitudinal=longitudinal;self.brake_mode=mode

    # Static/Coulomb side hold, sourced from 0.9.22 contact_push_decel.
    # Cancel a small drift completely within the available force budget.
    lateral=lateral_trial
    scrub_den=sum(load*dot(sub(pt,b.p),f)**2 for w,pt,n,load in active)
    # Allocate per TRACK first. With unequal load, uniform per-wheel yaw
    # cancellation would steal the only grounded belt's drive force.
    side_forces=[]
    for i in range(2):
     share=load_by_side[i]/total_load
     side_forces.append(longitudinal*share+(1. if i==0 else -1.)*yaw_torque/(2.*gauge) if two_sides else longitudinal*share)
    requested=[];totals=[0.,0.];actuals=[0.,0.]
    for wheel,point,n,load in active:
     side=0 if wheel.side=='left' else 1
     fx=lateral*load/total_load+(scrub_torque*load*dot(sub(point,b.p),f)/max(1e-9,scrub_den))
     fz=side_forces[side]*load/max(1e-9,load_by_side[side])
     # Anisotropic track-grip ellipse; specificFriction is mu*g rolling
     # resistance in the donor, NOT the adhesion coefficient.
     # Lateral-first ellipse: engine/braking demand cannot scale away the
     # already budgeted side adhesion. Remaining capacity goes to drive.
     fx=clamp(fx,-mu_lat*load,mu_lat*load)
     remaining=mu_long*load*math.sqrt(max(0.,1.-(fx/max(1e-9,mu_lat*load))**2))
     applied_z=clamp(fz,-remaining,remaining)
     tangent=add(mul(r,fx),mul(f,applied_z));tangent=sub(tangent,mul(n,dot(tangent,n)))
     requested.append((point,mul(tangent,h)));totals[side]+=fz;actuals[side]+=applied_z
    for point,impulse in requested:b.impulse(impulse,point)
    self.yaw_scrub_torque=scrub_torque
    self.slip_lateral=vr;self.yaw_target=desired_yaw;self.grip_force=(lateral,longitudinal,yaw_torque)
    self.side_loads=tuple(load_by_side);self.side_forces=tuple(side_forces);self.grip_coefficients=(mu_long,mu_lat)
    self.slip_tracks=tuple(clamp((totals[i]-actuals[i])/max(1.,mu_long*load_by_side[i]),-1.,1.)*2. for i in range(2))
   else:
    self.slip_lateral=dot(b.v,right);self.yaw_target=0.;self.grip_force=(0.,0.,0.);self.slip_tracks=(0.,0.)
    self.side_loads=(0.,0.);self.side_forces=(0.,0.);self.grip_coefficients=(0.,0.);self.last_longitudinal=0.;self.steering_target=0.
   # Contact constraints preserve angular response. No 'v = 0 on wall' gate.
   for repeat in range(3):
    for plane in planes:
     point,normal=plane[:2];shape_index=plane[2] if len(plane)>2 else None
     support=b.support(normal,shape_index);depth=-dot(sub(support,point),normal)
     vn=dot(b.point_velocity(support),normal)
     if depth< -.035:
      bias=(depth+.015)/max(h,1e-5)
     else:
      # Ground depenetration must not act as a restitution/launch impulse.
      recovery=.20 if normal[1]>.5 else .9
      bias=min(recovery,max(0.,depth-.008)*.16/max(h,1e-5))
     impulse=max(0.,(bias-vn)/max(b.effective(support,normal),1e-12))
     if impulse:
      b.impulse(mul(normal,impulse),support)
      vel=b.point_velocity(support);t=sub(vel,mul(normal,dot(vel,normal)));speed=length(t)
      if speed>1e-6:
       tangent=mul(t,1./speed);j=min(.4*impulse,speed/max(b.effective(support,tangent),1e-12));b.impulse(mul(tangent,-j),support)
   if active:
    # Explicit arcade driveline governor requested for this mod: descriptor
    # maximum in either direction, including downhill. Not applied in flight.
    final=dot(b.v,f);limited=clamp(final,-self.params['speedBwd'],self.params['speedFwd'])
    if limited!=final:
     j=b.mass*(limited-final);b.impulse(mul(f,j),b.p);self.governor_impulse+=abs(j)
   b.integrate_pose(h)
  # Track animation follows measured rigid motion. Extra belt slip appears
  # only when commanded traction saturates, not a permanent +2.5m/s offset.
  fw=rotate(b.q,(0.,0.,1.));actual=dot(b.v,fw)
  half=max(.3,sum(abs(w.local[0]-b.com[0]) for w in self.wheels)/max(1,len(self.wheels)))
  yaw_local=dot(b.w,rotate(b.q,(0.,1.,0.)))
  measured=[actual+yaw_local*half,actual-yaw_local*half]
  for side_index,side in enumerate(('left','right')):
   rows=[row for row in active if row[0].side==side]
   load=sum(row[3] for row in rows)
   if load>1e-6:
    measured[side_index]=sum(dot(b.point_velocity(pt),unit(sub(fw,mul(n,dot(fw,n))),fw))*force for wheel,pt,n,force in rows)/load
  values=[]
  for i in range(2):
   target=targets[i]
   if flags&64 and abs(target)<1e-9:desired=0.
   elif not self.contacts and flags&15:desired=target
   else:desired=measured[i]+getattr(self,'slip_tracks',(0.,0.))[i]
   old=self.tracks[i];values.append(0. if flags&64 and abs(target)<1e-9 else old+(desired-old)*(1.-math.exp(-dt/.055)))
  self.tracks=tuple(values)
