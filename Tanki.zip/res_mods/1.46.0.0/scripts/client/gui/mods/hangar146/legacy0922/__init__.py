"""Copied engine-independent 0.9.22 laws; see PORT_STATUS_RU.md."""
