# -*- coding: utf-8 -*-
from __future__ import absolute_import
import json,os,sys,base64,copy,time
from .profile import Profile
from .logging import LOG_DEBUG
_CACHE=None
_STATE=None
GAME=None

def game_root():
    for p in [os.getcwd(),os.path.dirname(os.path.abspath(sys.executable))]:
        for unused in range(5):
            if os.path.isfile(os.path.join(p,'version.xml')):return p
            p=os.path.dirname(p)
    raise RuntimeError('Game root not found')

def read_resource(name):
    import ResMgr
    ds=ResMgr.openSection('helpers/hangar146/'+name)
    if ds is None:raise IOError('Missing resource '+name)
    return ds.asBinary

def decode(value):
    if isinstance(value,list):return [decode(v) for v in value]
    if not isinstance(value,dict):return value
    if '$map' in value:
        def key(v):return tuple(key(x) for x in v) if isinstance(v,list) else v
        return dict((key(decode(k)),decode(v)) for k,v in value['$map'])
    if '$set' in value:return set(decode(v) for v in value['$set'])
    if '$bytes_base64' in value:return base64.b64decode(value['$bytes_base64'])
    if '$float' in value:return float(value['$float'])
    if '$class' in value:
        if value['$class']!='items.ItemsPrices':raise ValueError('Unsupported shop class '+value['$class'])
        from items import ItemsPrices
        fields=decode(value['fields'])
        return ItemsPrices(fields['_itemsPriceInfo'])
    if any(k.startswith('$') for k in value):raise ValueError('Incomplete serialized shop data')
    return dict((k,decode(v)) for k,v in value.items())

def jsonl(name):
    return [json.loads(l) for l in read_resource(name).splitlines() if l.strip()]

def catalog():
    global _CACHE
    if _CACHE is None:
        LOG_DEBUG('stage=catalog_loading (compact data only; no full vehicle traversal)')
        from items import ItemsPrices
        vehicles=json.loads(read_resource('vehicles.json'))
        prices=dict((int(r['data']['compactDescr']),r['data']['currencies']) for r in jsonl('prices_live.jsonl'))
        defaults=dict((int(r['data']['compactDescr']),r['data']['currencies']) for r in jsonl('prices_defaults.jsonl'))
        shop=dict((r['key'],decode(r['data'])) for r in jsonl('shop_live.jsonl'))
        defshop=dict((r['key'],decode(r['data'])) for r in jsonl('shop_defaults.jsonl'))
        shop.setdefault('items',{})['itemPrices']=ItemsPrices(prices)
        defshop.setdefault('items',{})['itemPrices']=ItemsPrices(defaults)
        shop['defaults']=defshop
        _CACHE={'vehicles':vehicles,'prices':prices,'shop':shop}
        LOG_DEBUG('stage=catalog_ready vehicles=%s prices=%s'%(len(vehicles),len(prices)))
    return _CACHE

def state():
    global _STATE
    if _STATE is None:_STATE=Profile(os.path.join(game_root(),'mods','configs','hangar146','profile_m01.json'))
    return _STATE

def prepare():
    # One-time migration requested by the user. Preserve wallet and depot;
    # replace the old demo roster, not the entire on-disk profile.
    from .economy import build_vehicle
    p=state();c=catalog()
    if p.value.get('demo_roster')=='heavy_v1':
        prepare_m04(p);return
    names=('china:Ch41_WZ_111_5A','usa:A69_T110E5','ussr:R45_IS-7')
    byname=dict((r['name'],r) for r in c['vehicles'])
    seed=dict((str(i+1),build_vehicle(byname[name])) for i,name in enumerate(names))
    def change(v):
        v['vehicles']=seed;v['demo_roster']='heavy_v1';v.setdefault('stock',{});v.setdefault('intUserSettings',{})
    if os.path.isfile(p.path) and not os.path.exists(p.path+'.before_m02'):
        import shutil
        shutil.copy2(p.path,p.path+'.before_m02')
    p.transact(change);LOG_DEBUG('stage=heavy_roster_seeded vehicles=3 (one-time migration)')
    prepare_m04(p)

def account_extra(value=None):
    v=state().value if value is None else value
    from dog_tags_common.dog_tags_storage import PlayerDogTagStorage,ExtraDataStorage
    from dog_tags_common.components_config import componentConfigAdapter
    defaults=PlayerDogTagStorage.default()
    return {'intUserSettings':dict((int(k),n) for k,n in v.get('intUserSettings',{}).items()),
            'badges':tuple(v.get('badges',[])),
            'customizationDisplayType':dict((int(k),n) for k,n in v.get('customizationDisplayType',{}).items()),
            'dogTags':{'playerDogTag':v.get('playerDogTag',defaults),'unlockedComponents':set(defaults),'progress':{},'extra':ExtraDataStorage.default()},
            'battleRoyale':{'brBattleStats':{},'BRSoloTop1Count':0,'BRSquadTop1Count':0,'BRBattlesCount':0,'BRTotalKills':0,'accBRTitle':(1,0)}}

def inventory(value=None):
    from gui.shared.gui_items import GUI_ITEM_TYPE as T
    from constants import SkinInvData
    from .economy import descriptor,item_type
    snapshot=state().value if value is None else value
    data=dict((i,{}) for i in range(1,100))
    fields=('repair','crew','settings','compDescr','eqs','boosters','customizationExpiryTime','lock','shells','shellsLayout','eqsLayout','boostersLayout','devicesLayout','layoutIndexes','vehicle','postProgression','customRoleSlots','activeSeason')
    veh=dict((k,{}) for k in fields);tman={'compDescr':{},'vehicle':{},'dismissedAt':{}}
    for key,rec in sorted(snapshot['vehicles'].items(),key=lambda x:int(x[0])):
        if not rec.get('visible',True):continue
        vid=int(key);d=descriptor(rec)
        veh['compDescr'][vid]=base64.b64decode(rec['compactDescr_b64']);veh['crew'][vid]=[]
        for slot,cd in enumerate(rec.get('crew',[])):
            tid=100000+vid*100+slot
            tman['compDescr'][tid]=base64.b64decode(cd);tman['vehicle'][tid]=vid;veh['crew'][vid].append(tid)
        veh['repair'][vid]=tuple(rec.get('repair',[0,0]));veh['settings'][vid]=rec.get('settings',0);veh['lock'][vid]=(0,0)
        veh['shells'][vid]=list(rec.get('shells',[]))
        # 1.46 requires nested layouts, unlike the flat 0.9.22 representation.
        shellkey=(d.turret.compactDescr,d.gun.compactDescr)
        veh['shellsLayout'][vid]={shellkey:[list(rec.get('shellsLayout',[]))]}
        for field in ('eqs','boosters'):
            veh[field][vid]=list(rec.get(field,[]));veh[field+'Layout'][vid]=[list(rec.get(field+'Layout',rec.get(field,[])))]
        veh['devicesLayout'][vid]=[[dev.compactDescr if dev is not None else 0 for dev in d.optionalDevices]]
        veh['layoutIndexes'][vid]={1:0,2:0};veh['activeSeason'][vid]=rec.get('activeSeason',0)
        from .loadouts import wire
        wire(rec,veh,vid,d)
    for rawcd,count in snapshot.get('stock',{}).items():
        cd=int(rawcd)
        if count:data[item_type(cd)][cd]=count
    for tid,raw in snapshot.get('barracks',{}).items():
        tman['compDescr'][int(tid)]=base64.b64decode(raw);tman['vehicle'][int(tid)]=0
    from . import customization,progression
    for rec in snapshot['vehicles'].values():
        if not rec.get('visible',True):continue
        if rec.get('vpp'):veh['postProgression'][rec['typeCD']]=progression.state(rec).toRawData()
        if rec.get('customRoleSlot'):veh['customRoleSlots'][rec['typeCD']]=rec['customRoleSlot']
    data[getattr(T,'CUSTOMIZATION',12)]=customization.wire(snapshot)
    data[T.VEHICLE]=veh;data[T.TANKMAN]=tman;data[T.CREW_SKINS]={SkinInvData.OUTFITS:{}}
    return {'inventory':data}

def shop():
    result=copy.deepcopy(catalog()['shop']);result['rev']=1;result.pop('prevRev',None)
    return result


def prepare_m04(p):
    from . import progression,crew,ownership
    import shutil
    if os.path.isfile(p.path) and not os.path.exists(p.path+'.before_m04'):
        shutil.copy2(p.path,p.path+'.before_m04')
    if os.path.isfile(p.path) and not os.path.exists(p.path+'.before_m045'):
        shutil.copy2(p.path,p.path+'.before_m045')
    flags=ownership.read(ownership.path());proposal=copy.deepcopy(p.value)
    progression.migrate(proposal);crew.seed_books(proposal)
    from . import bonds
    bonds.prepare(proposal)
    from .loadouts import sync
    for rec in proposal['vehicles'].values():sync(rec)
    ownership.apply(proposal,flags)
    if proposal!=p.value:
        def change(value):value.clear();value.update(proposal)
        p.transact(change)
    ownership.sync(p.value)
