# -*- coding: utf-8 -*-
"""Stock belt components + solver-driven scene struts.

No replacement of a registered C++ Suspension, no guessed constructor flag.
The spring solver owns carrier/ground-node translations; the stock animator
owns belt scrolling, with explicit wheel rotation correction for frozen nodes.
"""

def bind(vehicle,actor,mark):
 from . import wheel_scene
 app=vehicle.appearance
 actor._rigid_native_visual=False
 if app.suspension is None:raise RuntimeError('Native suspension unavailable')
 model=app.compoundModel
 for name in ('suspension','collisionObstaclesCollector','tessellationCollisionSensor'):
  component=getattr(app,name,None)
  if component is not None:component.reattachCompound(model)
 collector=getattr(app,'collisionObstaclesCollector',None)
 if collector is not None:app.suspension.setCollisionObstaclesCollector(collector)
 nodes=getattr(app,'trackNodesAnimator',None)
 if nodes is not None:nodes.setWheelsDataProvider(app.wheelsAnimator)
 app.wheelsAnimator.removeScrollProcessors()
 app.wheelsAnimator.setMovementInfo(actor._rigid_wheel_provider)
 app.wheelsAnimator.stopAnimatingWheels(False,False)
 app.suspension.stopAnimating(False,False)
 app.suspension.forceCorrectionRecalculation()
 runtime=getattr(vehicle,'_hangar146_combat_runtime',None)
 if runtime is not None and int(vehicle.id)==runtime.player_id:
  import Vehicular
  link=Vehicular.getDummyLodLink();actor._rigid_native_lod=link
  for name in ('wheelsAnimator','trackNodesAnimator','collisionObstaclesCollector','tessellationCollisionSensor','tracks','suspension'):
   component=getattr(app,name,None)
   if component is not None:component.setLodLink(link)
 count=wheel_scene.attach(vehicle,actor)
 actor._rigid_native_visual=True;actor._native_chain_error=None
 actor._native_ground_nodes=sum(not row['is_wheel'] for row in actor._wheel_scene)
 mark('native_track_chain_bound',vehicle_id=actor.id,scene_nodes=count or 0,
      ground_nodes=actor._native_ground_nodes,roadwheel_transform_owner='rigid_strut_scene_provider',
      belt_owner='stock_track_components_unverified_in_client',
      separate_roadwheel_translation=True,suspension_replaced_once=False,
      remove_ground_nodes_called=False,native_renderer_gate_bypassed=False)

def tick(vehicle,actor):
 if actor.health<=0 or not getattr(actor,'_rigid_native_visual',False):return
 app=vehicle.appearance
 if actor.flags or abs(actor.v)>.01 or not getattr(actor,'sleeping',False):
  app.suspension.forceCorrectionRecalculation()
 app.wheelsAnimator.setMovementInfo(actor._rigid_wheel_provider)
