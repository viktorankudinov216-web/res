# -*- coding: utf-8 -*-
"""Explicit brake modes, SI units. No body pose edits or latency queue."""
import math

def brake_mode(speed,throttle,handbrake):
 if handbrake:return 'handbrake'
 if throttle and speed*throttle<-.025:return 'counter'
 if not throttle:return 'release_reverse' if speed<-.025 else 'release'
 return 'drive'

def deceleration(mode):
 return {'handbrake':10.5,'counter':8.5,'release_reverse':8.0,'release':6.5}.get(mode,0.)

def brake_target(speed,pitch,dt,decel):
 gravity=9.81*math.sin(pitch)
 if abs(speed)<.025 and abs(gravity)<=decel:return 0.
 sign=1. if speed>0. else -1. if speed<0. else 1. if gravity>0. else -1.
 value=speed+(gravity-sign*decel)*dt
 if value*speed<0. and abs(gravity)<=decel:return 0.
 return value
