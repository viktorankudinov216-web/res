"""Local garage and experimental native static world for MT 1.46 M06."""
