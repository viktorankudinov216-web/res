# -*- coding: utf-8 -*-
"""Local native Avatar lifecycle and world checkpoint; no GUI overlay or memory patch."""
from __future__ import absolute_import
import os,sys,json,time,pickle,zlib,traceback,hashlib
from . import runtime_data as R
from .logging import LOG_NOTE,LOG_ERROR
from .utils import override,local_session_id
EXPECTED_EXE_SHA256='571b59a0449cec88aa74880b67f14600187ba328fdc532a9ba4de1800ff1d39b'
_PLAN=None
_CREATING=False
_AVATAR=None
_GENERATION=0
_REPORT={}
_INSTALLED=False
_KEY_HANDLER=None
_RETURNING=False
_RETURN_SCHEDULED=False
_REPORT_SAVED_AT=0.

def avatar_play_limits(account_limits):
    # scripts/entity_defs/alias.xml: PLAY_LIMITS = FIXED_DICT of four INT32.
    result={'curfew':-1,'weeklyPlayLimit':account_limits[1][0],
            'dailyPlayLimit':account_limits[0][0],'sessionLimit':-1}
    for key,value in result.items():
        if isinstance(value,bool) or not isinstance(value,(int,long)) or not -1<=value<=2147483647:
            raise ValueError('Invalid Avatar PLAY_LIMITS INT32: '+key)
    return result

def initial_properties(plan):
    from constants import ARENA_BONUS_TYPE,ARENA_GUI_TYPE
    from ._constants import OFFLINE_DBID,OFFLINE_NICKNAME
    from .data import getOfflineStats
    # Explicit client properties, not blanket __getattr__ defaults.
    return dict(arenaUniqueID=plan['roundID'],arenaTypeID=plan['arenaTypeID'],
        arenaBonusType=ARENA_BONUS_TYPE.REGULAR,arenaGuiType=ARENA_GUI_TYPE.RANDOM,
        arenaExtraData={},weatherPresetID=0,team=1,accountDBID=OFFLINE_DBID,
        name=OFFLINE_NICKNAME,isOffline=True,ownVehicleAuxPhysicsData=0,ownVehicleGear=0,
        denunciationsLeft=10,tkillIsSuspected=False,clientCtx='',isObserverBothTeams=False,isGunLocked=True,
        sessionID=local_session_id(plan['roundID'],OFFLINE_DBID),playerVehicleID=0,goodiesSnapshot=[],
        playLimits=avatar_play_limits(getOfflineStats()['stats']['playLimits']))


def local_avatar(obj=None):
    import BigWorld
    if obj is None:obj=BigWorld.player()
    return bool(obj is not None and getattr(obj,'_hangar146_loading_avatar',False))

def mark(stage,**details):
    global _REPORT_SAVED_AT
    now=time.time()
    if 'error' in details and 'primary_failure' not in _REPORT:
        _REPORT['primary_failure']={'stage':stage,'error':details['error']}
    _REPORT.setdefault('history',[]).append({'stage':stage,'time':time.time()})
    _REPORT['history']=_REPORT['history'][-60:]
    _REPORT.update(details);_REPORT.update(stage=stage,updated=time.time(),build='M12-test-contact-suspension')
    _REPORT.setdefault('geometry_loaded',False)
    hot=stage in ('combat_tick','rigid_wheels_readback','local_shot','local_shell_contact','local_vehicle_hit_visual','local_projectile_stopped','shot_slow_stage')
    if not hot or now-_REPORT_SAVED_AT>=2.:
        folder=os.path.join(R.game_root(),'mods','configs','hangar146')
        if not os.path.isdir(folder):os.makedirs(folder)
        with open(os.path.join(folder,'battle_stage.json'),'wb') as f:
            f.write(json.dumps(_REPORT,ensure_ascii=True,separators=(',',':')).encode('ascii'))
        _REPORT_SAVED_AT=now
    # Complete structured state stays in JSON; never flood the engine's
    # bounded log line with layout tables or an entire solver dump.
    if stage=='combat_tick':
        shown=dict((k,details[k]) for k in ('battle_seconds','physics_model','active_projectiles','physics_max_ms') if k in details)
    elif stage in ('rigid_vehicle_prepared','rigid_layout_finalized'):
        state=details.get('rigid',{});shown=dict(vehicle_id=details.get('vehicle_id'),layout=state.get('layout'),wheel_count=state.get('wheel_count'),roof_source=state.get('roof_source'))
    else:shown=details
    LOG_NOTE('battle stage='+stage,shown)

def world_enabled():
    from .config import ENABLE_WORLD
    return ENABLE_WORLD

def start_world():
    from . import world146
    world146.start()

def fingerprint():
    paths=[sys.executable,os.path.join(R.game_root(),'win64','Tanki.exe'),os.path.join(R.game_root(),'Tanki.exe')]
    for path in paths:
        if os.path.basename(path).lower()!='tanki.exe' or not os.path.isfile(path):continue
        digest=hashlib.sha256()
        with open(path,'rb') as f:
            for part in iter(lambda:f.read(1048576),''):digest.update(part)
        actual=digest.hexdigest()
        if actual==EXPECTED_EXE_SHA256:return actual
    raise RuntimeError('Tanki.exe does not match the supplied x64 build; no native transition performed')

def install():
    global _INSTALLED,_KEY_HANDLER
    if _INSTALLED:return
    from . import utils
    checkpoint=len(utils._PATCHES)
    try:_install_hooks()
    except Exception:
        utils.restore(checkpoint)
        _INSTALLED=False;_KEY_HANDLER=None
        raise

def _install_hooks():
    global _INSTALLED,_KEY_HANDLER
    import Avatar,Account,BigWorld,ClientArena,Keys
    from gui import InputHandler
    if InputHandler.g_instance is None or not hasattr(InputHandler.g_instance,'onKeyDown'):
        raise RuntimeError('gui.InputHandler key event unavailable')
    from .server import FakeServer
    original_getattribute=Avatar.PlayerAvatar.__getattribute__
    @override(Avatar.PlayerAvatar,'__init__')
    def avatar_init(base,self):
        if not _CREATING:return base(self)
        self._hangar146_loading_avatar=True;self._hangar146_server=FakeServer(self)
        field=None
        try:
            for field,value in initial_properties(_PLAN).items():setattr(self,field,value)
            if world_enabled():
                from . import world146
                field='early_avatar_geometry'
                world146.prepare_avatar_space(self,_PLAN,_GENERATION)
            result=base(self);self._hangar146_init_complete=True
            if getattr(self,'_hangar146_early_geometry',None) is not None:
                mark('avatar_base_initialized_after_geometry',early_geometry_before_avatar_init=True)
            return result
        except Exception:
            failure=sys.exc_info()
            self._hangar146_init_failure=traceback.format_exc()
            try:mark('avatar_constructor_failed',attribute=field,error=self._hangar146_init_failure)
            except Exception:LOG_ERROR('Could not save Avatar constructor failure')
            raise failure[0],failure[1],failure[2]
    @override(Avatar.PlayerAvatar,'__getattribute__')
    def gateway(base,self,name):
        if name=='vehicle':
            try:
                attached=original_getattribute(self,'_hangar146_attached_vehicle')
                if original_getattribute(self,'_hangar146_loading_avatar'):return attached
            except AttributeError:pass
        if name in ('base','cell','server'):
            try:is_local=original_getattribute(self,'_hangar146_loading_avatar')
            except AttributeError:is_local=False
            if is_local:return original_getattribute(self,'_hangar146_server')
        return base(self,name)
    @override(Avatar.PlayerAvatar,'onEnterWorld')
    def entered(base,self,*args):
        if local_avatar(self) and getattr(self,'_hangar146_init_failure',None):return
        try:return base(self,*args)
        except Exception:
            if local_avatar(self):self._hangar146_enter_failure=traceback.format_exc()
            raise
    @override(Avatar.PlayerAvatar,'onLeaveWorld')
    def left(base,self,*args):
        if local_avatar(self):
            if getattr(self,'_hangar146_init_failure',None) or getattr(self,'_hangar146_world_left',False):return
            self._hangar146_world_left=True
        return base(self,*args)
    @override(Avatar.PlayerAvatar,'_PlayerAvatar__startGUI')
    def gui_started(base,self):
        result=base(self)
        if local_avatar(self):self._hangar146_avatar_gui_started=True
        return result
    @override(Avatar.PlayerAvatar,'_PlayerAvatar__destroyGUI')
    def gui_destroy(base,self):
        if not local_avatar(self) or getattr(self,'_hangar146_avatar_gui_started',False):return base(self)
        # Native init may stop BEFORE __initGUI; never invent sound/handler stubs.
        # No arena GUI listeners were attached if __startGUI did not run.
        errors=[]
        for name,method in (('soundNotifications','destroy'),('complexSoundNotifications','destroy'),('inputHandler','stop')):
            resource=getattr(self,name,None)
            if resource is not None:
                try:getattr(resource,method)()
                except Exception:errors.append({'resource':name,'error':traceback.format_exc()})
                finally:setattr(self,name,None)
        if errors:mark('partial_avatar_gui_cleanup',cleanup_errors=errors)
    @override(Avatar.PlayerAvatar,'onBecomePlayer')
    def become(base,self):
        if not local_avatar(self):return base(self)
        try:
            result=base(self);self._hangar146_become_complete=True;return result
        except Exception:
            self._hangar146_become_failure=traceback.format_exc();raise
    @override(Account.PlayerAccount,'onBecomeNonPlayer')
    def retire_account(base,self):
        if getattr(self,'_hangar146_local',False):
            if getattr(self,'_hangar146_retired',False):return
            self._hangar146_retired=True
        return base(self)
    @override(Avatar.PlayerAvatar,'onBecomeNonPlayer')
    def retire_avatar(base,self):
        if local_avatar(self):
            if getattr(self,'_hangar146_retired',False):return
            self._hangar146_retired=True
            from .world146 import retire_visuals
            warnings=[]
            try:retire_visuals(self)
            except Exception:warnings.append({'step':'visuals','warning':traceback.format_exc()})
            for vehicle in list(BigWorld.entities.values()):
                if getattr(vehicle,'_hangar146_vehicle',False):
                    try:vehicle.onLeaveWorld()
                    except Exception:warnings.append({'step':'vehicle_leave','vehicle_id':int(vehicle.id),'warning':traceback.format_exc()})
            try:self.onLeaveWorld()
            except Exception:warnings.append({'step':'avatar_leave','warning':traceback.format_exc()})
            if warnings:mark('local_world_drain_warnings',cleanup_warnings=warnings)
        return base(self)
    @override(ClientArena.ClientArena,'__init__')
    def arena_init(base,self,*args,**kwargs):
        result=base(self,*args,**kwargs)
        if _PLAN is not None and args and args[0]==_PLAN['roundID'] and local_avatar():
            from constants import ARENA_UPDATE,ARENA_PERIOD
            from . import match_plan
            from ._constants import OFFLINE_NICKNAME,OFFLINE_DBID
            # Seed before guiSessionProvider.start(): roster is already complete
            # when native arena info controllers attach to the Avatar.
            BigWorld.player().playerVehicleID=_PLAN['playerVehicleID']
            rows=match_plan.roster(_PLAN,OFFLINE_NICKNAME,OFFLINE_DBID)
            self.update(ARENA_UPDATE.VEHICLE_LIST,zlib.compress(pickle.dumps(rows,2)))
            self.update(ARENA_UPDATE.PERIOD,zlib.compress(pickle.dumps((ARENA_PERIOD.WAITING,0.,0.,{}),2)))
            mark('arena_roster_seeded',vehicles=len(rows))
        return result
    from . import world146
    def avatar_gate(name):
        def gated(base,self,*args,**kwargs):
            if local_avatar(self):
                if not world146.allowed('space' if name=='onSpaceLoaded' else 'ready'):return
                if name=='onSpaceLoaded' and getattr(self,'_hangar146_space_notified',False):return
                result=base(self,*args,**kwargs)
                if name=='onSpaceLoaded':self._hangar146_space_notified=True
                return result
            return base(self,*args,**kwargs)
        return gated
    for name in ('_PlayerAvatar__onInitStepCompleted','setClientReady','onSpaceLoaded'):
        if not hasattr(Avatar.PlayerAvatar,name):
            alternate=name.replace('_PlayerAvatar__','_Avatar__')
            if not hasattr(Avatar.PlayerAvatar,alternate):raise RuntimeError('Missing Avatar readiness boundary: '+name)
            name=alternate
        override(Avatar.PlayerAvatar,name)(avatar_gate(name))
    from gui.battle_control.controllers.arena_load_ctrl import ArenaLoadController
    @override(ArenaLoadController,'startControl')
    def load_started(base,self,*args,**kwargs):
        if local_avatar():BigWorld.player()._hangar146_arena_load_ctrl=self
        return base(self,*args,**kwargs)
    def load_gate(name):
        def gated(base,self,*args,**kwargs):
            if local_avatar():
                BigWorld.player()._hangar146_arena_load_ctrl=self
                if not world146.allowed('space' if name=='spaceLoadCompleted' else 'ready'):return
                if name=='arenaLoadCompleted' and getattr(self,'_hangar146_completed',False):return
                result=base(self,*args,**kwargs)
                if name=='arenaLoadCompleted':self._hangar146_completed=True
                return result
            return base(self,*args,**kwargs)
        return gated
    for name in ('spaceLoadCompleted','arenaLoadCompleted'):override(ArenaLoadController,name)(load_gate(name))
    # Final UI guard, in addition to the loading/ready barriers above.
    from gui.app_loader.loader import AppLoader
    from gui.app_loader.spaces import BattleSpace
    @override(AppLoader,'changeSpace')
    def gui_space(base,self,space):
        if local_avatar() and isinstance(space,BattleSpace) and not world146.allowed():return False
        return base(self,space)
    from . import loading_ui,battle_state146
    # Before any battle page/listener can cache a bound panel method.
    battle_state146.install_presentation()
    loading_ui.install()
    world146.install()
    from . import combat146
    combat146.install()
    _INSTALLED=True

def begin(owner,plan):
    global _PLAN,_GENERATION,_AVATAR,_RETURNING,_RETURN_SCHEDULED
    import BigWorld
    from helpers import dependency
    from skeletons.gui.app_loader import IAppLoader
    from gui.app_loader import spaces
    try:
        if BigWorld.player() is not owner:return
        if _RETURNING:raise RuntimeError('Previous garage restoration is still in progress')
        sha=fingerprint();install();_GENERATION+=1;generation=_GENERATION;_PLAN=plan
        _RETURN_SCHEDULED=False
        _REPORT.clear();mark('transition_preflight',exe_sha256=sha,map=plan['map'],arenaTypeID=plan['arenaTypeID'],roundID=plan['roundID'],playerVehicleID=plan['playerVehicleID'],
            bot_types=[r['name'] for r in plan['bots']],bot_typeCDs=[r['typeCD'] for r in plan['bots']],map_candidates=plan['installed_ctf_maps'],skipped_maps=plan['skipped_maps'],map_rejections=plan.get('map_rejections',[]))
        # Store public local loadouts for diagnosing descriptor/roster contracts.
        with open(os.path.join(R.game_root(),'mods','configs','hangar146','match_plan.json'),'wb') as f:f.write(json.dumps(plan,ensure_ascii=True,indent=2).encode('ascii'))
        # Reference 1.23: lifecycle swap first; native SwitchToBattleObserver
        # owns destroyLobby/createBattle. No pre-emptive GUI teardown or curtain.
        owner.onBecomeNonPlayer();mark('account_retired')
        BigWorld.worldDrawEnabled(False);BigWorld.clearEntitiesAndSpaces();mark('lobby_entities_cleared')
        create_avatar(generation)
    except Exception:fail('preflight_failed')

def create_avatar(generation):
    global _CREATING,_AVATAR
    import BigWorld
    if generation!=_GENERATION or _PLAN is None:return
    try:
        from constants import ARENA_BONUS_TYPE,ARENA_GUI_TYPE
        sid=BigWorld.createSpace();mark('empty_avatar_space_created',spaceID=sid)
        _CREATING=True
        try:eid=BigWorld.createEntity('Avatar',sid,0,(0.,0.,0.),(0.,0.,0.),{})
        finally:_CREATING=False
        avatar=BigWorld.entities[eid];_AVATAR=avatar
        for field in ('_hangar146_init_failure','_hangar146_enter_failure'):
            failure=getattr(avatar,field,None)
            if failure:raise RuntimeError(failure)
        avatar.arenaUniqueID=_PLAN['roundID'];avatar.arenaTypeID=_PLAN['arenaTypeID']
        avatar.arenaBonusType=ARENA_BONUS_TYPE.REGULAR;avatar.arenaGuiType=ARENA_GUI_TYPE.RANDOM
        avatar.arenaExtraData={};avatar.weatherPresetID=0;avatar.team=1
        from ._constants import OFFLINE_DBID,OFFLINE_NICKNAME
        avatar.accountDBID=OFFLINE_DBID;avatar.name=OFFLINE_NICKNAME
        mark('native_avatar_created',avatarEntityID=eid)
        # onAvatarBecomePlayer drives native SwitchToBattleObserver.
        # Do not pre-create another app before that event.
        BigWorld.player(avatar)
        failure=getattr(avatar,'_hangar146_become_failure',None)
        if failure:raise RuntimeError(failure)
        if not getattr(avatar,'_hangar146_become_complete',False):raise RuntimeError('Avatar.onBecomePlayer did not finish')
        if avatar.arena is None or len(avatar.arena.vehicles)!=(1+len(_PLAN['bots'])):raise RuntimeError('Native arena roster was not installed')
        from helpers import dependency
        from skeletons.gui.app_loader import IAppLoader
        from gui.app_loader import spaces
        loader=dependency.instance(IAppLoader)
        if loader.getDefBattleApp() is None:
            raise RuntimeError('Native SwitchToBattleObserver did not create the battle app')
        mark('battle_gui_ready',source='native_observer',battle_app_present=True)
        ctrl=getattr(avatar,'_hangar146_arena_load_ctrl',None)
        if ctrl is None:raise RuntimeError('Native ArenaLoadController was not captured')
        # This posts AVATAR_ARENA_INFO. The native BattleLoadingObserver switches
        # the GUI space; do not force that transition manually a second time.
        ctrl.invalidateArenaInfo()
        mark('native_loading_requested',source='native_arena_info_event',native_arena_vehicles=len(avatar.arena.vehicles),stop_before_3d=not world_enabled(),return_source='Esc_confirmed_leaveArena')
        def check():
            if generation!=_GENERATION or not local_avatar(avatar):return
            try:
                app=loader.getDefBattleApp();provider=avatar.guiSessionProvider
                dp=provider.getArenaDP()
                mark('loading_checkpoint',battle_app_present=app is not None,gui_space=str(loader.getSpaceID()),native_arena_vehicles=len(avatar.arena.vehicles),arena_dp_vehicles=len(list(dp.getVehiclesInfoIterator())),stop_before_3d=not world_enabled())
            except Exception:fail('checkpoint_probe_failed')
        BigWorld.callback(3.,check)
    except Exception:fail('avatar_or_loading_failed')

def fail(stage):
    error=traceback.format_exc();LOG_ERROR(stage,error)
    try:mark(stage,error=error)
    except Exception:LOG_ERROR('Could not save battle_stage.json')
    # Before retirement there is still a usable Account; do not replace it.
    import BigWorld
    from . import match_queue
    match_queue.stop()
    player=BigWorld.player()
    if player is not None and getattr(player,'_hangar146_local',False) and not getattr(player,'_hangar146_retired',False):
        try:
            from gui.prb_control.events_dispatcher import g_eventDispatcher
            g_eventDispatcher.loadHangar()
        except Exception:LOG_ERROR(traceback.format_exc())
    else:request_return()

def request_return():
    global _RETURN_SCHEDULED
    import BigWorld
    if _RETURNING or _RETURN_SCHEDULED:return False
    if _PLAN is None and not local_avatar():return False
    _RETURN_SCHEDULED=True
    generation=_GENERATION
    def dispatch():
        global _RETURN_SCHEDULED
        if generation!=_GENERATION:return
        _RETURN_SCHEDULED=False
        return_to_garage()
    BigWorld.callback(0.,dispatch)
    return True

def release_loading_mode(reason):
    import BigWorld
    BigWorld.setReducedFpsMode(False)
    BigWorld.enableLoadingTimer(False)
    mark('loading_mode_released',reason=reason,reduced_fps_requested=False)

def garage_shown(account):
    # Called only AFTER native Account.showGUI; promotion alone is not success.
    global _RETURNING
    import BigWorld
    if _RETURNING and BigWorld.player() is account:
        _RETURNING=False
        release_loading_mode('garage_show_gui')
        mark('garage_show_gui_complete')


def return_to_garage():
    global _PLAN,_AVATAR,_GENERATION,_RETURNING,_RETURN_SCHEDULED
    import BigWorld
    if _RETURNING:return
    if _PLAN is None and not local_avatar():return
    _RETURNING=True;_RETURN_SCHEDULED=False
    from . import match_queue
    _GENERATION+=1;generation=_GENERATION;match_queue.stop()
    from . import world146
    world146.stop()
    try:
        release_loading_mode('return_to_garage')
        from helpers import dependency
        from skeletons.gui.app_loader import IAppLoader
        loader=dependency.instance(IAppLoader)
        current=BigWorld.player();retired_id=getattr(current,'id',None);errors=[]
        # BattleLoadingSpace.hideGUI already destroys battle and creates lobby.
        # DO NOT destroy that freshly created lobby a second time.
        if local_avatar(current):
            try:current.onBecomeNonPlayer()
            except Exception:errors.append({'step':'retireAvatar','error':traceback.format_exc()})
        # onLeaveWorld needs the still-live native appearance cache. Retire
        # world entries explicitly once, before onBecomeNonPlayer stops managers.
        BigWorld.clearEntitiesAndSpaces();_AVATAR=None;_PLAN=None
        try:loader.destroyBattle()
        except Exception:errors.append({'step':'destroyBattle','error':traceback.format_exc()})
        mark('battle_gui_destroyed_for_return',cleanup_errors=errors)
        def restore():
            if generation!=_GENERATION or not _RETURNING:return
            try:
                observed=BigWorld.player()
                # clearEntitiesAndSpaces may retain the retired player wrapper.
                # It is not a new owner; promotion below replaces it.
                same_retired=observed is current
                if observed is not None and not same_retired and retired_id is not None:
                    try:same_retired=(observed.id==retired_id)
                    except (AttributeError,ReferenceError):pass
                if observed is not None and not same_retired:
                    mark('garage_restore_owner_conflict',owner_type=type(observed).__name__)
                    raise RuntimeError('A different player took ownership during garage restoration')
                if same_retired and observed is not None:
                    mark('retired_avatar_owner_replaced')
                sid=BigWorld.createSpace();eid=BigWorld.createEntity('Account',sid,0,(0.,0.,0.),(0.,0.,0.),{})
                account=BigWorld.entities[eid]
                if not getattr(account,'_hangar146_local',False):
                    raise RuntimeError('Restored Account did not finish local initialization')
                if loader.getDefLobbyApp() is None:loader.createLobby()
                BigWorld.player(account)
                failure=getattr(account,'_hangar146_become_error',None)
                if failure:raise RuntimeError('Account.onBecomePlayer failed: '+failure)
                BigWorld.worldDrawEnabled(True);mark('garage_restore_requested')
                def watchdog():
                    if generation==_GENERATION and _RETURNING:
                        mark('garage_restore_timeout',error='Account.showGUI did not complete within 30 seconds')

                BigWorld.callback(30.,watchdog)
            except Exception:
                mark('garage_restore_failed',error=traceback.format_exc())

        BigWorld.callback(0.1,restore)
    except Exception:
        mark('return_failed',error=traceback.format_exc())


def fini():
    global _KEY_HANDLER,_GENERATION,_PLAN,_INSTALLED,_RETURNING,_RETURN_SCHEDULED
    had_local_session=_PLAN is not None or _RETURNING
    _GENERATION+=1;_PLAN=None;_RETURNING=False;_RETURN_SCHEDULED=False
    if had_local_session:release_loading_mode('fini')
    from . import world146
    world146.stop()
    if _KEY_HANDLER is not None:
        from gui import InputHandler
        InputHandler.g_instance.onKeyDown-=_KEY_HANDLER;_KEY_HANDLER=None
    _INSTALLED=False

