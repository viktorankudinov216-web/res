# -*- coding: utf-8 -*-
"""1.46 local presentation packets. No damage, firing or inventory mutations."""
from __future__ import absolute_import
import base64,math,re,traceback


class LocalServerClock(object):
    """Callable, deliberately NOT a Python function descriptor.

    MapActivities.Timer caches serverTime on a class. Python2 binds a plain
    function to that class, unlike the original native builtin. A callable object
    keeps native call semantics both on a module and when cached on any class.
    """
    def __init__(self,original):self.original=original
    def __call__(self):
        import BigWorld
        from .native_match import local_avatar
        player=BigWorld.player()
        if not local_avatar(player):return self.original()
        now=float(BigWorld.time())
        origin=getattr(player,'_hangar146_clock_origin',None)
        if origin is None:
            origin=now;player._hangar146_clock_origin=origin
        return 1000.+max(0.,now-origin)


def install_clock():
    import BigWorld
    from . import utils
    if isinstance(BigWorld.serverTime,LocalServerClock):return
    own='serverTime' in BigWorld.__dict__;raw=BigWorld.__dict__.get('serverTime')
    clock=LocalServerClock(BigWorld.serverTime)
    BigWorld.serverTime=clock
    utils._PATCHES.append((BigWorld,'serverTime',own,raw,clock))


def outfit_snapshot(value,rec,arena):
    from items.components.c11n_constants import SeasonType
    season=SeasonType.fromArenaKind(arena.vehicleCamouflageKind)
    outfits=value.get('outfits',{}).get(str(rec['typeCD']),{})
    return outfits.get(str(season),outfits.get(str(SeasonType.ALL),''))


def daytime(settings):
    value=settings.readString('timeOfDay/initialTimeOfDay','12:00') if settings is not None else '12:00'
    if not re.match(r'^\d{1,2}:\d{2}$',value):return '12:00'
    hours,minutes=map(int,value.split(':'))
    return value if 0<=hours<24 and 0<=minutes<60 else '12:00'


def active_environment(geometry):
    import ResMgr
    section=ResMgr.openSection(geometry+'/environments/environments.xml')
    if section is None:return ''
    value=section.readString('activeEnvironment','').strip()
    # IDs/names belong to this map. Never use a constant GUID or another skybox.
    return value


def environment_descriptor(geometry):
    import ResMgr
    environment_id=active_environment(geometry)
    if not environment_id:raise ValueError('Map activeEnvironment is empty')
    if not re.match(r'^[0-9A-Fa-f]{8}(?:\.[0-9A-Fa-f]{8}){3}$',environment_id):
        raise ValueError('Invalid native environment ID: '+environment_id)
    folder=geometry+'/environments/'+environment_id.replace('.','-')
    path=folder+'/environment.xml'
    section=ResMgr.openSection(path)
    if section is None:raise ValueError('Environment definition missing: '+path)
    name=section.readString('name','').strip()
    if not name:raise ValueError('Environment has no native name: '+path)
    # Native 1.46 activateMainEnvironment compares this XML name, NOT its GUID.
    return dict(id=environment_id,name=name,folder=folder,config_path=path)


def environment(session):
    import BigWorld,ResMgr
    geometry=session.arena.geometry
    settings=ResMgr.openSection(geometry+'/space.settings')
    hour=daytime(settings)
    # Exact x64 1.46 export: space ID + optional BW::string. Set AFTER mapping
    # and geometry settling, not against the outgoing hangar's camera space.
    # Hangar event overrides use this same global switcher in stock 1.46.
    # Select the actual battle camera space, then activate its default environment.
    # Do not guess an environment name or borrow a skybox from another map.
    try:
        # cameraSpaceID has an optional spaceID defaulting to ZERO. A no-arg
        # call resets the camera space; it is NOT a getter. Capture setter result.
        selected=environment_descriptor(geometry)
        from . import sky_probe146
        sky_probe146.bind_current_camera(session)
        camera_space=int(BigWorld.cameraSpaceID(session.avatar.spaceID))
        switcher=BigWorld.EnvironmentSwitcher.instance()
        switcher.setMainEnvironment(selected['name'],tryActivate=True)
        switcher.activateMainEnvironment()
        session.mark('battle_environment_activated',camera_space_id=camera_space,environment_name=selected['name'],environment_id=selected['id'],environment_source=selected['config_path'],main_environment_activation_requested=True,environment_render_verified=False)
    except Exception:
        # A presentation failure must be visible, but must not kick out a loaded match.
        session.mark('battle_environment_warning',warning=traceback.format_exc())
    from . import sky_probe146
    sky_probe146.ensure_sky(session)
    actual=BigWorld.spaceTimeOfDay(session.avatar.spaceID,hour)
    session.mark('environment_initialized',time_of_day=hour,engine_time_of_day=str(actual),space_id=int(session.avatar.spaceID),settings_keys=list(settings.keys())[:64] if settings is not None else [])


def inspect_environment(session):
    """Bounded read-only diagnostics from this map's packaged resource sections."""
    import ResMgr,Math
    from . import native_match as N
    geometry=session.arena.geometry
    result=[]
    paths=[geometry+'/space.settings',geometry+'/environments/environments.xml']
    try:
        selected=environment_descriptor(geometry)
        paths.extend([selected['config_path'],selected['folder']+'/skyDome/skybox.model',selected['folder']+'/skyDome/forward/skybox.model'])
    except Exception:N._REPORT['environment_descriptor_warning']=traceback.format_exc()
    for path in paths:
        entry=dict(path=path,rows=[],truncated=False)
        result.append(entry)
        try:
            section=ResMgr.openSection(path);entry['exists']=section is not None
            if section is None:continue
            stack=[([],section)];budget=65536
            while stack and len(entry['rows'])<384 and budget>0:
                trail,node=stack.pop();value=unicode(node.asString)[:2048]
                children=list(node.items());budget-=len(value)
                entry['rows'].append(dict(path=trail,value=value,children=len(children)))
                if len(trail)<20:
                    room=max(0,min(128,384-len(entry['rows'])-len(stack)))
                    if len(children)>room:entry['truncated']=True
                    for i,(key,child) in reversed(list(enumerate(children[:room]))):stack.append((trail+[[unicode(key),i]],child))
                elif children:entry['truncated']=True
                if len(children)>128:entry['truncated']=True
            if stack:entry['truncated']=True
        except Exception:entry['warning']=traceback.format_exc()
    try:
        root=ResMgr.openSection(geometry)
        listing=list(root.keys())[:128] if root is not None else []
    except Exception:listing=[]
    poses=[]
    for vehicle in session.entities:
        entry=dict(vehicle_id=int(vehicle.id))
        try:
            entry['entity_position']=list(vehicle.position)
            entry['entity_matrix_position']=list(Math.Matrix(vehicle.matrix).translation)
            entry['model_matrix_position']=list(Math.Matrix(vehicle.appearance.compoundModel.matrix).translation)
            entry['filter_class']=type(vehicle.filter).__name__
        except Exception:entry['warning']=traceback.format_exc()
        poses.append(entry)
    # mark() writes the report; do not print the XML tree into python.log.
    N._REPORT.update(environment_resources=result,map_resource_names=listing,model_pose_diagnostics=poses)
    session.mark('environment_resources_inspected',environment_sections=len(result),pose_records=len(poses))


def configure_visibility(session):
    """Extend local camera depth clipping to cover opposing map spawns.

    This changes far-plane clipping, NOT spotting, wall occlusion or damage.
    Low map quality can select a 600m plane while bases are ~900m apart.
    """
    import BigWorld
    projection=BigWorld.projection()
    current=float(projection.farPlane)
    bounds=session.arena.boundingBox
    width=float(bounds[1][0])-float(bounds[0][0]);height=float(bounds[1][1])-float(bounds[0][1])
    if width<=0. or height<=0.:raise ValueError('Invalid map bounds for far clip')
    diagonal=finite_positive(math.hypot(width,height),'map diagonal')
    # Room for a pulled-back arcade camera. Existing larger native planes stay.
    required=diagonal+512.
    if not hasattr(session,'original_far_plane'):session.original_far_plane=current
    projection.farPlane=max(current,required)
    session.mark('local_far_clip_configured',original_far_plane=session.original_far_plane,
        far_plane_before=current,far_plane=float(projection.farPlane),map_diagonal=diagonal)


def restore_visibility(session):
    if not hasattr(session,'original_far_plane'):return
    import BigWorld
    # Session.stop runs before the hangar camera/environment is recreated.
    BigWorld.projection().farPlane=session.original_far_plane
    del session.original_far_plane


def install_presentation():
    """Local-only aim authority and equipment-panel visibility; keep native effects."""
    import BigWorld,VehicleGunRotator
    from gui.Scaleform.daapi.view.battle.shared.consumables_panel import ConsumablesPanel
    from .native_match import local_avatar
    from .utils import override
    cls=VehicleGunRotator.VehicleGunRotator
    name='_VehicleGunRotator__syncWithServerTurretYaw'
    if not getattr(cls.__dict__.get(name),'_hangar146_local_presentation',False):
        @override(cls,name)
        def sync_yaw(base,self,turret_yaw):
            avatar=self._avatar
            vehicle=getattr(avatar,'vehicle',None)
            if (local_avatar(avatar) and vehicle is not None and
                    getattr(vehicle,'_hangar146_vehicle',False) and
                    vehicle.id==avatar.playerVehicleID):
                # No server gun packets exist. Native correction compares to the
                # initial zero angle and repeatedly snaps prediction to zero.
                # Keep native rotate(), speed, yaw/pitch limits and gun marker.
                return turret_yaw
            return base(self,turret_yaw)
        cls.__dict__[name]._hangar146_local_presentation=True
    for name in ('_ConsumablesPanel__onOptionalDeviceAdded',
                 '_ConsumablesPanel__onOptionalDeviceUpdated',
                 '_addOptionalDeviceSlot','_updateOptionalDeviceSlot'):
        if getattr(ConsumablesPanel.__dict__.get(name),'_hangar146_local_presentation',False):continue
        @override(ConsumablesPanel,name)
        def optional_slot(base,self,*args,**kwargs):
            avatar=BigWorld.player()
            if local_avatar(avatar):
                avatar._hangar146_hidden_optional_calls=getattr(avatar,'_hangar146_hidden_optional_calls',0)+1
                return
            return base(self,*args,**kwargs)
        ConsumablesPanel.__dict__[name]._hangar146_local_presentation=True


def finite_positive(value,label,zero=False):
    value=float(value)
    if math.isnan(value) or math.isinf(value) or value<0. or (not zero and value==0.):raise ValueError('Invalid '+label)
    return value


def initialize_controls(session):
    from constants import EQUIPMENT_STAGES,VEHICLE_SETTING
    from items import vehicles
    install_presentation()
    avatar=session.avatar;vehicle=session.entities[0];rec=session.records[0]
    descr=vehicle.typeDescriptor;gun=descr.gun;vid=vehicle.id
    # Stop the alternative-setup selector before native ammo packets: Avatar's
    # shell processor intentionally drops packets for the prebattle preview ID.
    avatar.beforeSetupUpdate(vid)
    counts=dict((abs(int(cd)),int(count)) for cd,count in zip(rec.get('shells',[])[::2],rec.get('shells',[])[1::2]))
    order=[vehicles.makeIntCompactDescrByID('shell',*shot.shell.id) for shot in gun.shots]
    chosen=next((cd for cd in order if counts.get(cd,0)>0),None)
    clip=max(1,int(gun.clip[0]));total=sum(max(0,counts.get(cd,0)) for cd in order)
    for cd in order:
        quantity=max(0,counts.get(cd,0))
        avatar.updateVehicleAmmo(vid,cd,quantity,min(clip,quantity) if cd==chosen else 0,0,0.,0.)
    if chosen is not None:
        avatar.updateVehicleSetting(vid,VEHICLE_SETTING.CURRENT_SHELLS,chosen)
        avatar.updateVehicleSetting(vid,VEHICLE_SETTING.NEXT_SHELLS,chosen)
    for cd in rec.get('eqs',[]):
        cd=abs(int(cd))
        avatar.updateVehicleAmmo(vid,cd,1 if cd else 0,EQUIPMENT_STAGES.READY,EQUIPMENT_STAGES.READY,0.,0.)
    for device in descr.optionalDevices:
        if device is not None:
            # Avatar RPC uses the item ID (e.g. 45), NOT compactDescr (11769).
            # Exact 1.46 opt_device_in_battle._getDescriptor indexes this cache.
            device_id=int(device.id[1])
            canonical=vehicles.g_cache.optionalDevices()[device_id]
            if canonical.compactDescr!=device.compactDescr:raise ValueError('Optional device ID/compactDescr mismatch')
            avatar.updateVehicleOptionalDeviceStatus(vid,device_id,True)
    from .battle_loadout146 import for_record
    loadout=for_record(rec,descr)
    base_time=finite_positive(loadout['reload_seconds'],'effective reload time')
    avatar.updateVehicleGunReloadTime(vid,0. if chosen else -2.,base_time)
    if clip>1:
        avatar.updateVehicleClipReloadTime(vid,0. if chosen else -2.,base_time,base_time,False,False)
    factors=descr.miscAttrs
    crew_factors=loadout['factors']
    # Values are already radians/second in 1.46 VehicleDescr. No degree conversion.
    avatar.updateTargetingInfo(vid,0.,0.,
        finite_positive(descr.turret.rotationSpeed*crew_factors.get('turret/rotationSpeed',1.),'turret rotation',True),
        finite_positive(gun.rotationSpeed*crew_factors.get('gun/rotationSpeed',1.),'gun rotation',True),
        finite_positive(factors.get('multShotDispersionFactor',1.),'dispersion'),
        finite_positive(factors.get('gun/shotDispersionFactors/afterShot',1.)*crew_factors.get('gun/shotDispersionFactors/afterShot',1.),'after-shot factor',True),
        finite_positive(factors['gun/shotDispersionFactors/turretRotation']*crew_factors.get('gun/shotDispersionFactors/turretRotation',1.),'turret dispersion',True),
        finite_positive(factors['chassis/shotDispersionFactors/movement']*crew_factors.get('chassis/shotDispersionFactors/movement',1.),'movement dispersion',True),
        finite_positive(factors['chassis/shotDispersionFactors/rotation']*crew_factors.get('chassis/shotDispersionFactors/rotation',1.),'rotation dispersion',True),
        finite_positive(loadout.get('aiming_seconds',gun.aimingTime*factors.get('gunAimingTimeFactor',1.)),'aiming time'))
    session.mark('battle_controls_initialized',shell_types=len(order),shell_count=total,
        effective_reload_seconds=base_time,base_reload_seconds=float(gun.reloadTime),loadout_source=loadout['source'],
        equipment=list(rec.get('eqs',[])),outfit_applied=bool(rec.get('outfit_b64')),
        server_time=float(__import__('BigWorld').serverTime()),native_client_aim=True,stun_enabled=False,optional_device_panel=False)


def unlock_aim(session):
    from vehicle_systems import model_assembler
    avatar=session.avatar;vehicle=session.entities[0]
    avatar.isGunLocked=False;avatar.set_isGunLocked()
    rotator=avatar.gunRotator
    if rotator is None:raise RuntimeError('Native VehicleGunRotator missing')
    # The native period-change listener starts it on BATTLE. start is idempotent;
    # also handles a GUI-ready callback arriving in the same frame as the period.
    rotator.clientMode=True;rotator.start();rotator.lock(False)
    vehicle.appearance.setupGunMatrixTargets(rotator)
    avatar._PlayerAvatar__ownVehicleTurretMProv.target=rotator.turretMatrix
    model_assembler.setupTurretRotations(vehicle.appearance)
    session.mark('native_client_aim_unlocked',is_on_arena=bool(avatar.isOnArena),network_filter_history=False)


def report_presentation(session):
    import BigWorld
    info=dict(optional_panel_blocked_calls=int(getattr(session.avatar,'_hangar146_hidden_optional_calls',0)),clock_callable_kind=type(BigWorld.serverTime).__name__)
    try:info['actual_render_far_plane']=float(BigWorld.projection().farPlane)
    except Exception:info['far_plane_read_warning']=traceback.format_exc()
    try:info['actual_space_items_visibility_mask']=int(BigWorld.getSpaceItemsVisibilityMask(session.avatar.spaceID))&0xffffffff
    except Exception:info['space_items_mask_read_warning']=traceback.format_exc()
    session.mark('presentation_diagnostics',**info)
