# -*- coding: utf-8 -*-
"""Local customization ownership, prices and native outfit validation."""
from __future__ import absolute_import
import base64,copy
from collections import Counter
from . import runtime_data as R
from .economy import Reject,number,row,descriptor,cost,charge,item_type

def definition(cd):
    from items import vehicles
    if item_type(number(cd,1))!=12:raise Reject('NOT_CUSTOMIZATION_ITEM')
    return vehicles.getItemByCompactDescr(cd)

def vehicle(v,vid):
    return row(v,vid) if vid else None

def binding(cd,rec):
    descr=definition(cd)
    if descr.isVehicleBound():
        if rec is None:raise Reject('CUSTOMIZATION_REQUIRES_VEHICLE')
        return rec['typeCD']
    return 0

def owned(v,cd,bound,delta):
    store=v.setdefault('c11n_stock',{}).setdefault(str(cd),{})
    count=store.get(str(bound),0)+delta
    if count<0:raise Reject('NOT_ENOUGH_CUSTOMIZATION_ITEMS')
    store[str(bound)]=count

def buy(v,vid,cd,count):
    rec=vehicle(v,vid);descr=definition(cd);count=number(count,1,1000)
    if rec is not None and not descr.matchVehicleType(descriptor(rec).type):raise Reject('INCOMPATIBLE_CUSTOMIZATION_VEHICLE')
    if getattr(descr,'requiredToken',''):raise Reject('TOKEN_CUSTOMIZATION_NOT_AVAILABLE')
    if descr.isStyleOnly:raise Reject('STYLE_ONLY_CUSTOMIZATION')
    if descr.isProgressive():raise Reject('PROGRESSIVE_CUSTOMIZATION_NOT_IMPLEMENTED')
    bound=binding(cd,rec)
    maximum=getattr(descr,'maxNumber',0)
    if maximum:
        total=sum(v.get('c11n_stock',{}).get(str(cd),{}).values())
        total+=sum(counts.get(cd,0) for counts in all_dressed(v).values())
        if total+count>maximum:raise Reject('CUSTOMIZATION_MAX_NUMBER')
    charge(v,cost(cd,count));owned(v,cd,bound,count)

def sell(v,vid,cd,count):
    from items.components.c11n_constants import ItemTags
    from .garage_ops import proceeds
    rec=vehicle(v,vid);descr=definition(cd);count=number(count,1,1000)
    if ItemTags.CANNOT_BE_SOLD in descr.tags or ItemTags.CANNOT_BE_SOLD in getattr(descr,'priceGroupTags',()):raise Reject('CUSTOMIZATION_CANNOT_BE_SOLD')
    owned(v,cd,binding(cd,rec),-count);v['wallet']['credits']+=proceeds(cd,count)

def counts(encoded):
    from items import vehicles,customizations
    from serializable_types.customizations import parseC11sComponentDescr
    if not encoded:return Counter()
    outfit=parseC11sComponentDescr(base64.b64decode(encoded))
    # Native function accounts for paint quantities per area, decals and styles.
    return Counter(customizations.getAllItemsFromOutfit(vehicles.g_cache.customization20(),outfit,True,True,True,False))

def dressed(outfits):
    total=Counter()
    for encoded in outfits.values():total.update(counts(encoded))
    # A style is an indivisible all-season item, not one purchased per season.
    from items import parseIntCompactDescr
    from items.components.c11n_constants import CustomizationType
    for cd in total:
        if parseIntCompactDescr(cd)[1]==CustomizationType.STYLE:total[cd]=1
    return total

def all_dressed(v):
    return dict((int(cd),dressed(outfits)) for cd,outfits in v.get('outfits',{}).items())

def apply(v,int_args,str_args):
    from items import vehicles
    from items.components.c11n_constants import SeasonType,MAX_OUTFIT_LENGTH
    from serializable_types.customizations import parseC11sComponentDescr
    if len(int_args)<2 or len(str_args)!=len(int_args)-2:raise Reject('INVALID_OUTFIT_REQUEST')
    rec=row(v,int_args[1]);d=descriptor(rec);cd=rec['typeCD'];seasons=int_args[2:]
    if len(seasons)!=len(set(seasons)) or any(s not in SeasonType.RANGE for s in seasons):raise Reject('INVALID_OUTFIT_SEASONS')
    allout=v.setdefault('outfits',{});previous=allout.get(str(cd),{});proposed=copy.deepcopy(previous)
    cache=vehicles.g_cache.customization20()
    for season,raw in zip(seasons,str_args):
        if not isinstance(raw,str) or len(raw)>MAX_OUTFIT_LENGTH:raise Reject('INVALID_OUTFIT_BYTES')
        parsed=parseC11sComponentDescr(raw) if raw else __import__('items.customizations',fromlist=['CustomizationOutfit']).CustomizationOutfit()
        allowed,reason=cache.validateOutfit(d,parsed,{}, {},None,season)
        if not allowed:raise Reject('INVALID_OUTFIT: '+str(reason))
        if parsed:proposed[str(season)]=base64.b64encode(parsed.makeCompDescr())
        else:proposed.pop(str(season),None)
    before=dressed(previous);after=dressed(proposed)
    for item in set(before)|set(after):
        change=after[item]-before[item];bound=binding(item,rec)
        if change<0:owned(v,item,bound,-change)
        elif change>0:
            available=v.get('c11n_stock',{}).get(str(item),{}).get(str(bound),0)
            if available<change:buy(v,int_args[1],item,change-available)
            owned(v,item,bound,-change)
    allout[str(cd)]=proposed

def wire(v):
    from constants import CustomizationInvData as K
    from items import parseIntCompactDescr
    result={K.ITEMS:{},K.OUTFITS:{},K.NOVELTY_DATA:{},K.DRESSED:{},K.PROGRESSION:{},K.SERIAL_NUMBERS:{},K.ORDERING:{},K.TAG_MASK:{}}
    for rawcd,bounds in v.get('c11n_stock',{}).items():
        _,itype,iid=parseIntCompactDescr(int(rawcd));values=dict((int(b),n) for b,n in bounds.items() if n)
        if values:result[K.ITEMS].setdefault(itype,{})[iid]=values
    for rawcd,outfits in v.get('outfits',{}).items():
        if outfits:result[K.OUTFITS][int(rawcd)]=dict((int(s),base64.b64decode(raw)) for s,raw in outfits.items())
    for vehcd,items in all_dressed(v).items():
        for cd,count in items.items():
            _,itype,iid=parseIntCompactDescr(cd)
            if count:result[K.DRESSED].setdefault(itype,{}).setdefault(iid,{})[vehcd]=count
    return result

def command(v,name,args,arr):
    if name=='CMD_BUY_C11N_ITEMS':
        if len(arr)<2 or (len(arr)-2)%2:raise Reject('INVALID_CUSTOMIZATION_BUY')
        for i in range(2,len(arr),2):buy(v,arr[1],arr[i],arr[i+1])
    elif name=='CMD_SELL_C11N_ITEMS':
        if len(args)!=4:raise Reject('INVALID_CUSTOMIZATION_SELL')
        sell(v,args[3],args[1],args[2])
    elif name=='CMD_VEH_APPLY_OUTFIT':
        if len(args)!=2:raise Reject('INVALID_OUTFIT_TRANSPORT')
        apply(v,list(args[0]),list(args[1]))
    elif name=='CMD_RESET_C11N_ITEMS_NOVELTY':
        # Local purchases are already acknowledged; persist explicit seen IDs.
        v['c11n_seen']=sorted(set(v.get('c11n_seen',[]))|set(number(x) for x in arr[1:]))
    return {}
SUPPORTED=('CMD_BUY_C11N_ITEMS','CMD_SELL_C11N_ITEMS','CMD_VEH_APPLY_OUTFIT','CMD_RESET_C11N_ITEMS_NOVELTY')
