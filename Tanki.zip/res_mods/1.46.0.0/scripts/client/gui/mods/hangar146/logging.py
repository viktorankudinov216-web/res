# -*- coding: utf-8 -*-
from __future__ import print_function,absolute_import
_VERBOSE=False
_LEVELS=[]
def LOG_DEBUG(*args):
    if _VERBOSE:print('[Hangar146 M12-test]',*args)
def LOG_NOTE(*args):print('[Hangar146 M12-test]',*args)
LOG_ERROR=LOG_NOTE

def configure(verbose=False):
    global _VERBOSE
    _VERBOSE=bool(verbose)
    if _VERBOSE:return
    import logging
    # Only known, very noisy logger INFO/DEBUG messages. WARNING+ stay visible.
    for name in ('frameworks.wulf','gui.shared.personality','gui.ClientUpdateManager'):
        logger=logging.getLogger(name);_LEVELS.append((logger,logger.level));logger.setLevel(logging.WARNING)

def restore():
    while _LEVELS:
        logger,level=_LEVELS.pop();logger.setLevel(level)
