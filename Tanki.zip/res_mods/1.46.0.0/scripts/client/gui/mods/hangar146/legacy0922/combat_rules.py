# uncompyle6 version 3.9.3
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.13.15 (main, Aug 24 2026, 00:00:00) [GCC 11.5.0 20240719 (Red Hat 11.5.0-5)]
# Embedded file name: scripts/client/gui/mods/offline_lan_0922/combat_rules.py
# Compiled at: 2026-09-14 14:11:28
from __future__ import print_function
import math, random
_OFFH_RANGE_NEAR = 100.0
_OFFH_RANGE_FAR = 500.0
_OFFH_RANGE_SPAN = _OFFH_RANGE_FAR - _OFFH_RANGE_NEAR
_OFFH_MIN_HIT_ANGLE_COS = 1e-05
_OFFH_MISSING = object()

def _offh_range_piercing(shot, dist_m):
    """Non-randomized P100/P500 interpolation with the shell range cutoff."""
    pp = shot.get('piercingPower', (100.0, 100.0))
    try:
        p100 = float(pp[0])
        p500 = float(pp[1])
    except Exception:
        p100 = p500 = 100.0

    try:
        distance = float(dist_m)
    except Exception:
        distance = 0.0

    try:
        maximum = float(shot.get('maxDistance', 0.0) or 0.0)
    except Exception:
        maximum = 0.0

    if distance <= _OFFH_RANGE_NEAR:
        return p100
    if maximum <= 0.0 or distance >= maximum:
        return 0.0
    t = (distance - _OFFH_RANGE_NEAR) / _OFFH_RANGE_SPAN
    return max(0.0, p100 + (p500 - p100) * t)


def _offh_material_value(material, name, default=_OFFH_MISSING):
    if material is None:
        return default
    else:
        if isinstance(material, dict):
            return material.get(name, default)
        return getattr(material, name, default)


def _offh_material_flag(material, name, default):
    if name == 'checkCaliberForRicochet':
        value = _offh_material_value(material, 'checkCaliberForRichet', _OFFH_MISSING)
        if value is _OFFH_MISSING:
            value = _offh_material_value(material, name, _OFFH_MISSING)
    else:
        value = _offh_material_value(material, name, _OFFH_MISSING)
    if value is _OFFH_MISSING:
        return bool(default)
    return bool(value)


def _offh_resolve_armor_contact(shot, dist_m, all_hits, initial_pierce_loss=0.0, penetration_factor=None, base_penetration_multiplier=1.0, random_gauss=None):
    """Resolve the terminal external or structural plate in projectile order.

        Returns a contact dictionary for the plate that stops external traversal or
        the first structural plate.  accumulated_loss is the penetration already
        spent before that returned plate.  None means no structural plate was reached
        and every external plate that was found was penetrated.

        Tracks and external devices carry vehicleDamageFactor 0.0: they are not the
        hull, so they never take hull damage.  They are nevertheless real plates: the
        shell must penetrate each one, then pays that plate's effective thickness.

        HEAT continues as a jet after penetrating an external layer.  It pays both
        the plate and 5 percent of its rolled penetration per 10 cm travelled before
        the next layer.  One shot-owned penetration factor is reused for every layer."""
    if not all_hits:
        return
    else:
        shell = shot.get('shell') or {} if hasattr(shot, 'get') else {}
        kind = shell.get('kind', 'ARMOR_PIERCING')
        spaced = float(initial_pierce_loss or 0.0)
        factor = penetration_factor
        base_pierce = None
        heat_last_plate_distance = None
        seen_once = set()
        try:
            _ordered = sorted(all_hits, key=(lambda h: h[0]))
        except Exception:
            _ordered = all_hits

        for _h in _ordered:
            try:
                _d, _ac, _mat = _h[0], _h[1], _h[2]
            except Exception:
                continue

            _comp = _h[3] if len(_h) > 3 else None
            if factor is None:
                factor = sample_penetration_factor(random_gauss)
            if base_pierce is None:
                base_pierce = _offh_range_piercing(shot, dist_m) * float(base_penetration_multiplier) * float(factor)
            if kind == 'HOLLOW_CHARGE' and heat_last_plate_distance is not None:
                try:
                    _gap = max(0.0, float(_d) - heat_last_plate_distance)
                except Exception:
                    _gap = 0.0

                _remaining = max(0.0, base_pierce - spaced)
                spaced += _remaining * min(1.0, 0.5 * _gap)
            if _mat is None:
                if base_pierce - spaced <= 0.0:
                    break
                if kind == 'HOLLOW_CHARGE':
                    heat_last_plate_distance = float(_d)
                continue
            _once_key = None
            if _offh_material_flag(_mat, 'collideOnceOnly', False):
                _mat_kind = _offh_material_value(_mat, 'kind', _OFFH_MISSING)
                _once_key = (_comp, _mat_kind) if _mat_kind is not _OFFH_MISSING else (
                 _comp, id(_mat))
                if _once_key in seen_once:
                    continue
            _vdf = _offh_material_value(_mat, 'vehicleDamageFactor', 1.0)
            _arm = float(_offh_material_value(_mat, 'armor', 0.0) or 0.0)
            if _arm < 0.0:
                continue
            _res, _eff, _p = _offh_penetration(shot, dist_m, _arm, _ac, spaced, factor, _mat, not (kind == 'HOLLOW_CHARGE' and heat_last_plate_distance is not None), base_penetration_multiplier)
            _contact = {'result': _res, 
               'layer': ('structural' if bool(_vdf) else 'external'), 
               'distance': _d, 
               'material': _mat, 
               'accumulated_loss': spaced, 
               'effective_armor': _eff, 
               'piercing': _p, 
               'angle_cos': _ac, 
               'component': _comp}
            if not _vdf:
                if kind == 'HIGH_EXPLOSIVE':
                    _contact['result'] = 1
                    return _contact
                if _res != 2:
                    return _contact
                spaced += _eff
                if base_pierce - spaced <= 0.0:
                    _contact['result'] = 1
                    return _contact
                if kind == 'HOLLOW_CHARGE':
                    heat_last_plate_distance = float(_d) + _arm * 0.001
                if _once_key is not None:
                    seen_once.add(_once_key)
                continue
            return _contact

        return


def _offh_resolve_hull_hit(shot, dist_m, all_hits, initial_pierce_loss=0.0, penetration_factor=None, base_penetration_multiplier=1.0, random_gauss=None):
    """Keep the legacy structural-hit tuple contract unchanged."""
    contact = _offh_resolve_armor_contact(shot, dist_m, all_hits, initial_pierce_loss, penetration_factor, base_penetration_multiplier, random_gauss)
    if contact is None or contact['layer'] != 'structural':
        return
    return (
     contact['result'], contact['effective_armor'],
     contact['piercing'], contact['accumulated_loss'],
     contact['angle_cos'])


_OFFH_HE_DAMAGE_FACTOR = 0.5
_OFFH_HE_DAMAGE_ABSORPTION_FACTOR = 1.3
_OFFH_HE_EDGE_DAMAGE_FACTOR = 0.15
_OFFH_HE_TUNING_OVERRIDES = {}

def _offh_is_he(shot):
    """True for a high-explosive round. Reads shell['kind'] - never the name:
        every HEAT shell contains the letters 'HE' too, which is exactly the bug the
        shared penetration model was written to kill."""
    shell = shot.get('shell') or {} if hasattr(shot, 'get') else {}
    return shell.get('kind') == 'HIGH_EXPLOSIVE'


def _offh_he_radius(shot):
    """explosionRadius of this shot's shell, in metres. items/vehicles.py falls
        back to caliber^2 / 5555 when the shell XML omits it - mirror that rather
        than inventing a number."""
    shell = shot.get('shell') or {} if hasattr(shot, 'get') else {}
    try:
        r = float(shell.get('explosionRadius', 0.0) or 0.0)
    except Exception:
        r = 0.0

    if r > 0.0:
        return r
    try:
        cal = float(shell.get('caliber', 0) or 0)
    except Exception:
        cal = 0.0

    if cal > 0.0:
        return cal * cal / 5555.0
    return 0.0


def _offh_he_nominal_armor(all_hits, td=None):
    """Nominal thickness of the first STRUCTURAL plate on the ray.
        
        The HE reduction uses the plate's NOMINAL thickness, not the angled effective
        value: a sloped plate does not shrug off blast the way it deflects a solid
        shot. Spaced plates (vehicleDamageFactor 0 - tracks, external gear) are
        skipped; HE bursts on them and what has to hold is the hull behind."""
    best = None
    for _h in all_hits or []:
        try:
            _d, _mat = _h[0], _h[2]
        except Exception:
            continue

        if _mat is None or getattr(_mat, 'vehicleDamageFactor', 1.0) == 0.0:
            continue
        _a = float(getattr(_mat, 'armor', 0.0) or 0.0)
        if _a <= 0.0:
            continue
        if best is None or _d < best[0]:
            best = (
             _d, _a)

    if best is not None:
        return best[1]
    else:
        return


def _offh_he_factor(shell, name, default, maximum=None):
    value = shell.get(name, _OFFH_MISSING)
    if value is _OFFH_MISSING:
        value = default
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)

    if value != value or abs(value) == float('inf') or value <= 0.0 or maximum is not None and value > maximum:
        return float(default)
    else:
        return value


def _offh_he_factors(shot):
    """Return damage, absorption, and edge factors for one #1513 HE shell."""
    shell = shot.get('shell') or {} if hasattr(shot, 'get') else {}
    damage_factor = _offh_he_factor(shell, 'explosionDamageFactor', _OFFH_HE_DAMAGE_FACTOR)
    absorption_factor = _offh_he_factor(shell, 'explosionDamageAbsorptionFactor', _OFFH_HE_DAMAGE_ABSORPTION_FACTOR)
    edge_factor = _offh_he_factor(shell, 'explosionEdgeDamageFactor', _OFFH_HE_EDGE_DAMAGE_FACTOR, 1.0)
    damage_factor = _OFFH_HE_TUNING_OVERRIDES.get('splash_fraction', damage_factor)
    absorption_factor = _OFFH_HE_TUNING_OVERRIDES.get('armor_factor', absorption_factor)
    return (damage_factor, absorption_factor, edge_factor)


def _offh_he_spall(spall_coefficient):
    """Target Spall Liner multiplier on the armour absorption term."""
    try:
        value = float(spall_coefficient)
    except (TypeError, ValueError, OverflowError):
        return 1.0

    if value != value or abs(value) == float('inf') or value < 1.0:
        return 1.0
    return value


def _offh_he_damage(shot, base_damage, armor_nominal, dist_frac=0.0, spall_coefficient=1.0):
    """Damage an HE burst does to a hull it did NOT get through.

        dist_frac is 0.0 for the vehicle actually struck and rises to 1.0 at the edge
        of explosionRadius for everything else caught in the blast. Returns 0 when the
        plate eats the whole thing - the normal outcome against heavy armour, and the
        reason a derp gun rewards shooting thin plate."""
    damage_factor, absorption_factor, edge_factor = _offh_he_factors(shot)
    try:
        distance_fraction = float(dist_frac)
    except (TypeError, ValueError, OverflowError):
        distance_fraction = 0.0

    distance_fraction = max(0.0, min(1.0, distance_fraction))
    blast_factor = damage_factor + (edge_factor - damage_factor) * distance_fraction
    d = float(base_damage) * blast_factor - absorption_factor * float(armor_nominal or 0.0) * _offh_he_spall(spall_coefficient)
    if d > 0.0:
        return int(d)
    return 0


def _offh_he_apply_tuning(overrides):
    """Overlay config.json "he_tuning" onto descriptor-owned HE factors."""
    _OFFH_HE_TUNING_OVERRIDES.clear()
    applied = []
    if isinstance(overrides, dict):
        for k in ('splash_fraction', 'armor_factor'):
            if k in overrides:
                try:
                    value = float(overrides[k])
                    if value != value or abs(value) == float('inf'):
                        continue
                    _OFFH_HE_TUNING_OVERRIDES[k] = value
                    applied.append('%s=%s' % (k, overrides[k]))
                except (TypeError, ValueError, OverflowError):
                    pass

    return applied


def _offh_penetration(shot, dist_m, armor, hit_angle_cos, pierce_loss=0.0, penetration_factor=None, material=None, allow_ricochet=True, base_penetration_multiplier=1.0, random_gauss=None):
    """Armour test shared by the player and by bot-vs-bot fire.

        Returns (result, eff_armor, pierce): 0 ricochet, 1 no penetration, 2 penetration.

        Fixes two faults of the old inline version:
          * it classified shells with `'HE' not in shell['name']`, a substring test on the
            NAME. Every HEAT round contains 'HE', so both the ricochet and the
            no-penetration branch were skipped for it and it always went through.
            items/vehicles.py stores a proper shell['kind'] - use that.
          * piercingPower is a Vector2 (P100, P500), not a maxDistance endpoint.
        Randomisation is WG's own g_cache.commonConfig piercingPowerRandomization = 0.25.
        """
    import math
    shell = shot.get('shell') or {} if hasattr(shot, 'get') else {}
    kind = shell.get('kind', 'ARMOR_PIERCING')
    is_normalizing_ap = kind in ('ARMOR_PIERCING', 'ARMOR_PIERCING_CR')
    pierce = _offh_range_piercing(shot, dist_m) * float(base_penetration_multiplier)
    if penetration_factor is None:
        penetration_factor = sample_penetration_factor(random_gauss)
    pierce *= float(penetration_factor)
    pierce -= float(pierce_loss or 0.0)
    if pierce < 0.0:
        pierce = 0.0
    armor = max(0.0, float(armor or 0.0))
    use_hit_angle = _offh_material_flag(material, 'useHitAngle', True)
    if use_hit_angle:
        _ac = float(hit_angle_cos)
    else:
        _ac = 1.0
    caliber = float(shell.get('caliber', 100) or 100)
    norm = math.radians(2.0) if kind == 'ARMOR_PIERCING_CR' else math.radians(5.0) if kind == 'ARMOR_PIERCING' else 0.0
    if use_hit_angle and is_normalizing_ap and _offh_material_flag(material, 'checkCaliberForHitAngleNorm', True) and caliber > armor * 2.0 and armor * 2.0 > 0.0:
        norm *= 1.4 * caliber / (armor * 2.0)
    shell_may_ricochet = is_normalizing_ap or kind == 'HOLLOW_CHARGE'
    may_ricochet = allow_ricochet and use_hit_angle and shell_may_ricochet and _offh_material_flag(material, 'mayRicochet', True)
    no_ap_ricochet = is_normalizing_ap and _offh_material_flag(material, 'checkCaliberForRicochet', True) and caliber > armor * 3.0
    if may_ricochet:
        if is_normalizing_ap and not no_ap_ricochet and _ac <= math.cos(math.radians(70.0)):
            return (0, armor / max(_OFFH_MIN_HIT_ANGLE_COS, _ac), pierce)
        if kind == 'HOLLOW_CHARGE' and _ac <= math.cos(math.radians(85.0)):
            return (0, armor / max(_OFFH_MIN_HIT_ANGLE_COS, _ac), pierce)
    _eff_ac = _ac
    if use_hit_angle and norm > 0.0 and _eff_ac < 1.0:
        ang_eff = math.acos(_eff_ac) - norm
        if ang_eff < 0.0:
            _eff_ac = 1.0
        else:
            maximum_angle = math.pi / 2.0 - _OFFH_MIN_HIT_ANGLE_COS
            if ang_eff > maximum_angle:
                ang_eff = maximum_angle
            _eff_ac = math.cos(ang_eff)
    if _eff_ac < _OFFH_MIN_HIT_ANGLE_COS:
        _eff_ac = _OFFH_MIN_HIT_ANGLE_COS
    eff = armor / _eff_ac
    penetrated = pierce > 0.0 and pierce >= eff
    if kind == 'HIGH_EXPLOSIVE':
        return (
         2 if penetrated else 1, eff, pierce)
    else:
        return (
         2 if penetrated else 1, eff, pierce)


def _field(value, name, default=None):
    if isinstance(value, dict):
        return value.get(name, default)
    return getattr(value, name, default)


def _legacy_shell(shell):
    if isinstance(shell, dict):
        return shell
    else:
        result = {}
        for name in ('kind', 'caliber', 'damage', 'explosionRadius', 'explosionDamageFactor',
                     'explosionDamageAbsorptionFactor', 'explosionEdgeDamageFactor',
                     'compactDescr', 'name'):
            value = getattr(shell, name, None)
            if value is None:
                value = getattr(getattr(shell, 'type', None), name, None)
            if value is not None:
                result[name] = value

        if 'kind' not in result:
            kind = getattr(getattr(shell, 'type', None), 'name', None)
            if kind is not None:
                result['kind'] = kind
        return result


def legacy_shot(shot):
    """Convert a #1513 GunShot object without changing the copied law."""
    if isinstance(shot, dict):
        return shot
    return {'shell': (_legacy_shell(_field(shot, 'shell', {}) or {})), 'piercingPower': (_field(shot, 'piercingPower', (100.0, 100.0))), 
       'maxDistance': (_field(shot, 'maxDistance', 0.0))}


def collision_layers(collisions):
    result = []
    for collision in collisions or ():
        distance = getattr(collision, 'dist')
        angle = getattr(collision, 'hitAngleCos')
        material = getattr(collision, 'matInfo')
        component = getattr(collision, 'compName')
        try:
            result.append((float(distance), float(angle), material, component))
        except (TypeError, ValueError):
            raise TypeError('#1513 collision contains a non-numeric field')

    return sorted(result, key=(lambda item: item[0]))


def _offh_he_xyz(value):
    """Read one finite three-coordinate point from a native vector or tuple."""
    try:
        result = tuple(float(value[index]) for index in range(3))
    except (AttributeError, IndexError, KeyError, TypeError, ValueError, OverflowError):
        return

    if any(item != item or abs(item) == float('inf') for item in result):
        return
    else:
        return result


def _offh_he_collision_values(collision):
    """Extract distance and material while retaining the native collision."""
    try:
        distance = getattr(collision, 'dist')
        material = getattr(collision, 'matInfo')
    except (AttributeError, TypeError):
        try:
            distance = collision[0]
            material = collision[2]
        except (IndexError, KeyError, TypeError):
            return

    try:
        distance = float(distance)
    except (TypeError, ValueError, OverflowError):
        return

    if distance != distance or abs(distance) == float('inf'):
        return
    return (
     distance, material, collision)


def _offh_he_material_is_structural(material):
    """Only an explicit positive vehicle-damage factor is structure."""
    factor = _offh_material_value(material, 'vehicleDamageFactor', _OFFH_MISSING)
    if factor is _OFFH_MISSING:
        return False
    try:
        factor = float(factor)
    except (TypeError, ValueError, OverflowError):
        return False

    return factor == factor and abs(factor) != float('inf') and factor > 0.0


def he_blast_contact(shot, burst, start, end, collisions, rolled_damage, spall_coefficient=1.0):
    """Resolve one real structural HE contact from already-native ray evidence.

        ``collisions`` remains native evidence: this routine only orders it, rebuilds
        the contact along ``start``/``end``, and applies the existing HE formula to
        the first structural material at or beyond the burst.  It never samples
        randomness and never substitutes a descriptor-wide armour fallback.
        """
    converted = legacy_shot(shot)
    if not _offh_is_he(converted):
        return
    burst = _offh_he_xyz(burst)
    start = _offh_he_xyz(start)
    end = _offh_he_xyz(end)
    radius = _offh_he_radius(converted)
    try:
        rolled_damage = float(rolled_damage)
    except (TypeError, ValueError, OverflowError):
        return

    if burst is None or start is None or end is None or radius <= 0.0 or rolled_damage != rolled_damage or abs(rolled_damage) == float('inf'):
        return
    delta = tuple(end[index] - start[index] for index in range(3))
    length_squared = sum(item * item for item in delta)
    if length_squared <= 0.0:
        return
    else:
        length = math.sqrt(length_squared)
        direction = tuple(item / length for item in delta)
        burst_along = sum((burst[index] - start[index]) * direction[index] for index in range(3))
        ordered = []
        for collision in collisions or ():
            values = _offh_he_collision_values(collision)
            if values is not None:
                ordered.append(values)

        ordered.sort(key=(lambda item: item[0]))
        through_contact = []
        for distance_along, material, collision in ordered:
            if distance_along < 0.0 or distance_along > length:
                continue
            if distance_along < burst_along - 0.001:
                continue
            point = tuple(start[index] + direction[index] * distance_along for index in range(3))
            distance = math.sqrt(sum((point[index] - burst[index]) ** 2 for index in range(3)))
            structural = _offh_he_material_is_structural(material)
            if distance > radius:
                if structural:
                    return
                continue
            through_contact.append(collision)
            if not structural:
                continue
            try:
                nominal_armor = float(_offh_material_value(material, 'armor', _OFFH_MISSING))
            except (TypeError, ValueError, OverflowError):
                return

            if nominal_armor != nominal_armor or abs(nominal_armor) == float('inf') or nominal_armor < 0.0:
                return
            uses_liner = _offh_material_flag(material, 'useAntifragmentationLining', True)
            spall = spall_coefficient if uses_liner else 1.0
            return {'damage': (_offh_he_damage(converted, rolled_damage, nominal_armor, distance / radius, spall)), 
               'nominal_armor': nominal_armor, 
               'distance': distance, 
               'point': point, 
               'direction': direction, 
               'collision': collision, 
               'collisions': (tuple(through_contact))}

        return


def sample_shell_value(mean, random_gauss=None):
    """Reconstruct the post-8.6 +/-25%, three-sigma shell roll.

    WG described penetration and vehicle damage as normal, not uniform:
    https://wot-news.com/track/post/ru/HuKoguM/1369231089
    https://worldoftanks.com/en/news/general-news/86-update-notes/
    https://wot-news.com/track/post/eu/MrConway/1497292760
    The 8.6 announcement explicitly changes damage/penetration from two to
    three sigma; the release notes confirm fewer extreme rolls. The older
    2011 recollection of 2.5 sigma must not override this versioned change.
    Those statements do not specify outlier handling. Conditional resampling
    is an explicit reconstruction choice, not a recovered #1513 server ABI;
    it preserves the normal density inside the stated interval without
    inventing probability mass at the endpoints. See COMPATIBILITY_REVIEW.
    """
    mean = float(mean)
    if mean != mean or abs(mean) == float('inf'):
        raise ValueError('shell roll mean must be finite')
    if mean <= 0.0:
        return 0.0
    else:
        sampler = random.gauss if random_gauss is None else random_gauss
        minimum, maximum = mean * 0.75, mean * 1.25
        sigma = mean * 0.25 / 3.0
        while True:
            value = float(sampler(mean, sigma))
            if value != value or abs(value) == float('inf'):
                raise ValueError('shell roll must be finite')
            if minimum <= value <= maximum:
                return value

        return


def penetration(shot, distance, armor, hit_angle_cos, pierce_loss=0.0, random_gauss=None, penetration_factor=None, material=None, base_penetration_multiplier=1.0):
    return _offh_penetration(legacy_shot(shot), distance, armor, hit_angle_cos, pierce_loss, penetration_factor, material, True, base_penetration_multiplier, random_gauss)


def sample_penetration_factor(random_gauss=None):
    """Draw the one penetration factor frozen and owned by a shell."""
    return sample_shell_value(1.0, random_gauss)


def range_piercing(shot, distance):
    """Return the non-randomized piercing mean at one travelled distance."""
    return _offh_range_piercing(legacy_shot(shot), distance)


def sampled_piercing(shot, distance, penetration_factor, pierce_loss=0.0, base_penetration_multiplier=1.0):
    """Reuse one shell-owned factor at distance after external obstacles."""
    return max(0.0, range_piercing(shot, distance) * float(base_penetration_multiplier) * float(penetration_factor) - float(pierce_loss or 0.0))


def first_ricochet_penetration_multiplier(shell_kind):
    """Return the 9.3-0.9.22 retained penetration for a first ricochet."""
    if shell_kind in ('ARMOR_PIERCING', 'ARMOR_PIERCING_CR'):
        return 0.75
    else:
        if shell_kind == 'HOLLOW_CHARGE':
            return 1.0
        return


def nominal_piercing_after_loss(shot, distance, pierce_loss=0.0):
    """Return the non-randomized #1513 range value after external obstacles."""
    return max(0.0, range_piercing(shot, distance) - float(pierce_loss or 0.0))


def resolve_armor_contact(shot, distance, collisions, random_gauss=None, pierce_loss=0.0, penetration_factor=None, base_penetration_multiplier=1.0):
    """Return the terminal external or structural armor contact."""
    return _offh_resolve_armor_contact(legacy_shot(shot), distance, collision_layers(collisions), pierce_loss, penetration_factor, base_penetration_multiplier, random_gauss)


def resolve_hull_hit(shot, distance, collisions, random_gauss=None, pierce_loss=0.0, penetration_factor=None, base_penetration_multiplier=1.0):
    return _offh_resolve_hull_hit(legacy_shot(shot), distance, collision_layers(collisions), pierce_loss, penetration_factor, base_penetration_multiplier, random_gauss)


def he_nominal_armor(collisions, descriptor=None):
    return _offh_he_nominal_armor(collision_layers(collisions), descriptor)


def shell_damage_roll(shot, random_gauss=None):
    """Draw vehicle damage before armour absorption and integer HP display."""
    converted = legacy_shot(shot)
    shell = converted.get('shell') or {}
    raw = shell.get('damage')
    try:
        average = float(raw[0])
    except (TypeError, ValueError, IndexError):
        try:
            average = float(raw)
        except (TypeError, ValueError):
            return 0

    return sample_shell_value(average, random_gauss)


def shell_nominal_damage(shot):
    """Return the listed vehicle damage of a shell without the +/-25% roll.

    A shell that never pierced armour never had its damage drawn, so the
    armour ledger and the damage indicator report the shell's published
    value rather than a sample nobody took.  Reuse ``shell_damage_roll``
    with the identity sampler so the nominal and the roll cannot drift on
    field lookup, missing-descriptor fallback or rounding.
    """
    return shell_damage_roll(shot, random_gauss=(lambda mean, unused_sigma: mean))


def damage(shot, result, nominal_armor, random_gauss=None, spall_coefficient=1.0, rolled_damage=None):
    """Apply direct damage, optionally reusing the caller's exact frozen roll."""
    converted = legacy_shot(shot)
    if rolled_damage is None:
        rolled_damage = shell_damage_roll(converted, random_gauss)
    rolled = int(rolled_damage)
    if int(result) == 2:
        return rolled
    else:
        if _offh_is_he(converted):
            return _offh_he_damage(converted, rolled, nominal_armor, 0.0, spall_coefficient)
        return 0


def he_radius(shot):
    return _offh_he_radius(legacy_shot(shot))


def is_he(shot):
    return _offh_is_he(legacy_shot(shot))


def he_factors(shot):
    return _offh_he_factors(legacy_shot(shot))


def he_splash_damage(shot, nominal_armor, distance_fraction, random_gauss=None, spall_coefficient=1.0):
    converted = legacy_shot(shot)
    rolled = shell_damage_roll(converted, random_gauss)
    return _offh_he_damage(converted, rolled, nominal_armor, distance_fraction, spall_coefficient)


def apply_he_tuning(overrides):
    return _offh_he_apply_tuning(overrides)



# okay decompiling /data/mod_audit/wotmod/res/scripts/client/gui/mods/offline_lan_0922/combat_rules.pyc
