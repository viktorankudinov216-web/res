# -*- coding: utf-8 -*-
"""Local-only queue boundary tracing. Never forces an entity transition."""
from __future__ import absolute_import
import os,json,time,traceback
from . import runtime_data as R
from .logging import LOG_NOTE,LOG_ERROR
from .utils import override
_STATE={}
_SERIAL=0
_INSTALLED=False

def mark(stage,**details):
    global _SERIAL
    _SERIAL+=1
    record=dict(stage=stage,time=time.time(),seq=_SERIAL,details=details)
    _STATE['stage']=stage;_STATE.setdefault('events',[]).append(record)
    _STATE['events']=_STATE['events'][-80:]
    LOG_NOTE('queue trace',stage,details)
    try:
        folder=os.path.join(R.game_root(),'mods','configs','hangar146')
        if not os.path.isdir(folder):os.makedirs(folder)
        with open(os.path.join(folder,'queue_trace.json'),'wb') as f:f.write(json.dumps(_STATE,ensure_ascii=True,indent=2).encode('ascii'))
    except Exception:LOG_ERROR('queue trace write failed',traceback.format_exc())

def install():
    global _INSTALLED
    if _INSTALLED:return
    import BigWorld,Account,AccountCommands as C
    from constants import QUEUE_TYPE
    from gui.prb_control.entities.random.pre_queue.entity import RandomEntity
    def local(owner):return owner is not None and bool(getattr(owner,'_hangar146_local',False))
    @override(RandomEntity,'_doQueue')
    def queue_request(base,self,ctx):
        owner=BigWorld.player()
        if not local(owner):return base(self,ctx)
        token=getattr(owner,'_hangar146_queue_attempt',0)+1;owner._hangar146_queue_attempt=token
        owner._hangar146_queue_ack=False
        mark('random_entity_doQueue',vehicle=ctx.getVehicleInventoryID(),attempt=token)
        def timeout():
            if BigWorld.player() is not owner or getattr(owner,'_hangar146_queue_attempt',None)!=token or getattr(owner,'_hangar146_queue_ack',False):return
            mark('join_timeout',attempt=token)
            try:
                from . import match_queue
                match_queue.stop()
                owner.onEnqueueFailure(QUEUE_TYPE.RANDOMS,C.RES_FAILURE,'LOCAL_QUEUE_JOIN_TIMEOUT; see queue_trace.json')
                # Complete this exact context, never a later user request.
                if getattr(self,'_requestCtx',None) is ctx and ctx.isProcessing():ctx.stopProcessing(False)
            except Exception:LOG_ERROR('queue timeout cleanup failed',traceback.format_exc())
        BigWorld.callback(20.,timeout)
        try:return base(self,ctx)
        except Exception:
            mark('random_entity_doQueue_failed',error=traceback.format_exc());raise
    @override(Account.PlayerAccount,'enqueueRandom')
    def enqueue(base,self,*args,**kwargs):
        if not local(self):return base(self,*args,**kwargs)
        from PlayerEvents import g_playerEvents
        changing=bool(g_playerEvents.isPlayerEntityChanging)
        mark('account_enqueueRandom',entity_changing=changing)
        if changing:
            mark('enqueue_blocked_entity_changing')
            self.onEnqueueFailure(QUEUE_TYPE.RANDOMS,C.RES_FAILURE,'LOCAL_PLAYER_ENTITY_IS_CHANGING')
            return
        try:return base(self,*args,**kwargs)
        except Exception:
            mark('account_enqueueRandom_failed',error=traceback.format_exc());raise
    @override(Account.PlayerAccount,'onEnqueued')
    def enqueued(base,self,queueType):
        if local(self):
            mark('account_onEnqueued',queueType=queueType)
            # Mark only after all native subscribers accepted the notification.
            result=base(self,queueType);self._hangar146_queue_ack=True
            mark('native_queue_notification_complete');return result
        return base(self,queueType)
    @override(Account.PlayerAccount,'onEnqueueFailure')
    def enqueue_failed(base,self,*args):
        if local(self):
            self._hangar146_queue_ack=True
            mark('account_onEnqueueFailure',queueType=args[0] if args else None,error=str(args[-1]) if args else '')
        return base(self,*args)
    _INSTALLED=True
