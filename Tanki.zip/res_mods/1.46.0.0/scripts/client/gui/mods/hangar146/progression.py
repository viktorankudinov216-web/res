# -*- coding: utf-8 -*-
from __future__ import absolute_import
from . import runtime_data as R
from .economy import Reject,number,row,descriptor,charge

def state(rec):
    from post_progression_common import VehicleState
    value=rec.get('vpp')
    return VehicleState([set(value[0]),dict((int(k),n) for k,n in value[1].items()),set(value[2]),list(value[3])]) if value else VehicleState()

def save(rec,value):
    raw=value.toRawData();rec['vpp']=[sorted(raw[0]),dict((str(k),n) for k,n in raw[1].items()),sorted(raw[2]),list(raw[3])]

def ext(rec):
    from items import vehicles
    d=vehicles.VehicleDescr(compactDescr=__import__('base64').b64decode(rec['compactDescr_b64']))
    treeID=getattr(d.type,'postProgressionTree',None)
    return {'customRoleSlotTypeId':rec.get('customRoleSlot',0),'vehPostProgression':state(rec).toActionCDs(vehicles.g_cache.postProgression().trees[treeID]) if treeID is not None and rec.get('vpp') else []}

def find(v,cd):
    found=[r for r in v['vehicles'].values() if r['typeCD']==cd]
    if len(found)!=1:raise Reject('VEHICLE_TYPE_NOT_OWNED')
    return found[0]

def context(v,cd):
    from items import vehicles
    rec=find(v,number(cd,1));d=descriptor(rec);cache=vehicles.g_cache.postProgression()
    tree=cache.trees.get(d.type.postProgressionTree)
    if tree is None:raise Reject('NO_POST_PROGRESSION_TREE')
    return rec,d,cache,tree,state(rec)

def pay(v,rec,price):
    price=dict(price);xp=number(price.pop('xp',0));vehicle_xp=number(rec.get('xp',0));spent=min(xp,vehicle_xp)
    rec['xp']=vehicle_xp-spent
    if xp>spent:price['freeXP']=price.get('freeXP',0)+xp-spent
    charge(v,price)


def unlock_free_pairs(d,cache,tree,s):
    """Pair nodes are not offered by the native FEATURE/MODIFICATION research UI.
    Materialize only zero-priced, compatible pair nodes with paid prerequisites.
    Selecting either modification remains a separately charged operation.
    """
    from post_progression_common import ACTION_TYPES
    from post_progression_prices_common import getPostProgressionPrice
    added=[]
    while True:
        changed=False
        for sid,step in sorted(tree.steps.items()):
            if step.action[0]!=ACTION_TYPES.PAIR_MODIFICATION or s.isUnlocked(sid):continue
            if any(not s.isUnlocked(i) for i in step.requiredUnlocks):continue
            if step.vehicleFilter is not None and not step.vehicleFilter.checkCompatibilityWithVehType(d.type):continue
            price=getPostProgressionPrice(step.priceTag,d.type)
            if not isinstance(price,dict) or not price:continue
            if any(number(value)>0 for value in price.values()):continue
            s.addUnlock(sid);added.append(sid);changed=True
        if not changed:return added

def unlock(v,cd,steps):
    from post_progression_common import ACTION_TYPES
    from post_progression_prices_common import getPostProgressionPrice
    rec,d,cache,tree,s=context(v,cd);todo=set(number(i,1) for i in steps)
    if len(todo)!=len(steps):raise Reject('DUPLICATE_PROGRESSION_STEP')
    while todo:
        progressed=False
        for sid in sorted(todo):
            step=tree.steps.get(sid)
            if step is None:raise Reject('UNKNOWN_PROGRESSION_STEP')
            if s.isUnlocked(sid):todo.remove(sid);progressed=True;break
            if any(not s.isUnlocked(req) for req in step.requiredUnlocks):continue
            if step.vehicleFilter is not None and not step.vehicleFilter.checkCompatibilityWithVehType(d.type):raise Reject('PROGRESSION_RESTRICTED_FOR_VEHICLE')
            price=getPostProgressionPrice(step.priceTag,d.type)
            if not isinstance(price,dict) or not price:raise Reject('MISSING_PROGRESSION_PRICE')
            pay(v,rec,price);s.addUnlock(sid)
            action,item=step.action
            if action==ACTION_TYPES.FEATURE:s.addFeature(item)
            todo.remove(sid);progressed=True;break
        if not progressed:raise Reject('PROGRESSION_PREREQUISITES_NOT_UNLOCKED')
    unlock_free_pairs(d,cache,tree,s)
    save(rec,s);return sorted(s.unlocks)

def command(v,name,args,arr):
    from post_progression_common import ACTION_TYPES,PAIR_TYPES
    from post_progression_prices_common import getPostProgressionPrice
    if name=='CMD_VPP_UNLOCK_ITEMS':
        if len(arr)<2:raise Reject('EMPTY_PROGRESSION_PURCHASE')
        return unlock(v,arr[0],arr[1:])
    if name=='CMD_SET_CUSTOM_ROLE_SLOT':
        if len(arr)!=3:raise Reject('INVALID_ROLE_SLOT_ARGS')
        rec=row(v,arr[1]);d=descriptor(rec);s=state(rec);slot=number(arr[2],1)
        from items import vehicles
        feature_ids=[i for i,f in vehicles.g_cache.postProgression().features.items() if f.name=='roleSlot']
        if not any(s.hasFeature(i) for i in feature_ids) or slot not in d.type.customRoleSlotOptions:raise Reject('ROLE_SLOT_NOT_UNLOCKED_OR_INVALID')
        if rec.get('customRoleSlot',0)==slot:return {}
        if rec.get('customRoleSlot',0):charge(v,getPostProgressionPrice('customRoleSlotChangeCost',d.type,{'customRoleSlotChangeCost':R.catalog()['shop']['customRoleSlotChangeCost']}))
        # Validate existing equipment with the newly selected category in native code.
        d.installCustomRoleSlot(slot);rec['customRoleSlot']=slot;return {}
    rec,d,cache,tree,s=context(v,arr[0])
    if name=='CMD_VPP_SELECT_PAIR':
        if len(arr)!=3:raise Reject('INVALID_PAIR_ARGS')
        sid=number(arr[1],1);choice=number(arr[2],1,2);step=tree.steps.get(sid)
        if step is None or step.action[0]!=ACTION_TYPES.PAIR_MODIFICATION or not s.isUnlocked(sid):raise Reject('PAIR_NOT_UNLOCKED')
        if s.getPair(sid)!=choice:
            pair=cache.pairs[step.action[1]]
            price=getPostProgressionPrice((pair.first if choice==PAIR_TYPES.FIRST else pair.second)[1],d.type)
            if not price:raise Reject('MISSING_PAIR_PRICE')
            charge(v,price);s.setPair(sid,choice)
    elif name=='CMD_VPP_DISCARD_PAIRS':
        for sid in arr[1:]:
            step=tree.steps.get(sid)
            if step is None or step.action[0]!=ACTION_TYPES.PAIR_MODIFICATION:raise Reject('NOT_A_PAIR')
            s.removePair(sid)
    save(rec,s);return {}
SUPPORTED=('CMD_VPP_UNLOCK_ITEMS','CMD_VPP_SELECT_PAIR','CMD_VPP_DISCARD_PAIRS','CMD_SET_CUSTOM_ROLE_SLOT')


def migrate(value):
    """M03 wrote names, while native TankSetupLayouts indexes features by ID."""
    from items import vehicles
    from post_progression_common import ACTION_TYPES
    cache=vehicles.g_cache.postProgression(); changed=0
    for rec in value['vehicles'].values():
        if not rec.get('vpp'):continue
        raw=rec['vpp'];features=set()
        for old in raw[2]:
            if old in cache.features:features.add(old)
            else:
                matches=[i for i,f in cache.features.items() if f.name==old]
                if len(matches)!=1:raise Reject('UNMIGRATABLE_PROGRESSION_FEATURE')
                features.add(matches[0])
        # Reconstruct the feature ledger from already paid/unlocked steps too.
        d=vehicles.VehicleDescr(compactDescr=__import__('base64').b64decode(rec['compactDescr_b64']))
        tree=cache.trees.get(d.type.postProgressionTree)
        if tree is None:raise Reject('MISSING_SAVED_PROGRESSION_TREE')
        for sid in raw[0]:
            step=tree.steps.get(sid)
            if step is None:raise Reject('UNKNOWN_SAVED_PROGRESSION_STEP')
            if step.action[0]==ACTION_TYPES.FEATURE:
                fid=step.action[1]
                if fid not in cache.features:raise Reject('UNKNOWN_SAVED_PROGRESSION_FEATURE')
                features.add(fid)
        current=sorted(features)
        if raw[2]!=current:raw[2]=current;changed+=1
        saved_state=state(rec)
        if unlock_free_pairs(d,cache,tree,saved_state):save(rec,saved_state);changed+=1
    return changed
