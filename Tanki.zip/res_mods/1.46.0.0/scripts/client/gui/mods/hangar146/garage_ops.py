# -*- coding: utf-8 -*-
from __future__ import absolute_import
import math,base64
from collections import Counter
from . import runtime_data as R
from .economy import Reject,number,row,descriptor,stock,charge,removal_cost,pairs

def proceeds(cd,count=1):
    p=R.catalog()['prices'].get(cd)
    if p is None:raise Reject('ITEM_HAS_NO_SELL_PRICE')
    if any(n for k,n in p.items() if k not in ('credits','gold','crystal')):raise Reject('UNSUPPORTED_SELL_CURRENCY')
    shop=R.catalog()['shop']
    if cd in shop.get('items',{}).get('forbiddenToSellItems',()):raise Reject('ITEM_CANNOT_BE_SOLD')
    base=p.get('credits',0)+p.get('gold',0)*shop['exchangeRate']+p.get('crystal',0)*shop['crystalExchangeRate']
    return int(math.ceil(float(shop['sellPriceFactor'])*base))*number(count,1,1000000)

def sell_vehicles(v,arr):
    # Modern CMD304: rev, repeated [vid, dismissCrew, five counted arrays].
    from . import customization as C
    cursor=1;seen=set()
    while cursor<len(arr):
        if cursor+2>len(arr):raise Reject('TRUNCATED_VEHICLE_SALE')
        vid=number(arr[cursor],1);flags=number(arr[cursor+1],0,1);cursor+=2
        if vid in seen:raise Reject('DUPLICATE_VEHICLE_SALE')
        seen.add(vid);groups=[]
        for _ in range(5):
            if cursor>=len(arr):raise Reject('TRUNCATED_VEHICLE_SALE')
            size=number(arr[cursor],0,10000);cursor+=1
            if cursor+size>len(arr):raise Reject('TRUNCATED_VEHICLE_SALE')
            groups.append(arr[cursor:cursor+size]);cursor+=size
        selected,depot,custom,kits,free=groups
        if kits:raise Reject('DEMOUNT_KIT_SALE_NOT_IMPLEMENTED')
        if len(selected)!=len(set(selected)) or len(depot)!=len(set(depot)):raise Reject('DUPLICATE_SALE_ITEM')
        rec=row(v,vid);d=descriptor(rec);mounted=Counter()
        for cd,count in pairs(rec.get('shells',[])):
            if cd and count:mounted[abs(cd)]+=count
        for field in ('eqs','boosters'):
            mounted.update(cd for cd in rec.get(field,[]) if cd)
        devices=dict((dev.compactDescr,dev) for dev in d.optionalDevices if dev)
        mounted.update(list(devices))
        if rec.get('loadouts'):
            from .loadouts import pooled
            from items import vehicles
            mounted=pooled(rec)
            devices=dict((cd,vehicles.getItemByCompactDescr(cd)) for cd in mounted if cd&15==9)
        if any(cd not in mounted for cd in selected):raise Reject('SALE_ITEM_NOT_MOUNTED')
        if any(cd not in devices or not getattr(devices[cd],'removable',False) for cd in free):raise Reject('FREE_DEMOUNT_NOT_ALLOWED')
        gain=proceeds(rec['typeCD'])
        defaults,installed,unused=d.getDevices()
        for old,new in zip(defaults,installed):
            if old!=new:gain+=proceeds(new)-proceeds(old)
        gain-=number(rec.get('repair',[0,0])[0])
        for cd,count in mounted.items():
            if cd in selected:gain+=proceeds(cd,count)
            else:
                if cd in devices and not getattr(devices[cd],'removable',False):charge(v,removal_cost(devices[cd]))
                stock(v,cd,count)
        for cd in depot:
            count=v.get('stock',{}).get(str(cd),0)
            if count:stock(v,cd,-count);gain+=proceeds(cd,count)
        # User-selected customization quantities are exact; unselected outfits
        # return to the customization depot before removing this vehicle.
        outfits=v.setdefault('outfits',{}).pop(str(rec['typeCD']),{})
        for cd,count in C.dressed(outfits).items():C.owned(v,cd,C.binding(cd,rec),count)
        for cd,count in pairs(custom):C.sell(v,vid,cd,count)
        if not flags:
            barracks=v.setdefault('barracks',{})
            if len(barracks)+len(rec.get('crew',[]))>v.get('berths',100):raise Reject('NO_BARRACKS_BERTHS')
            for idx,crew in enumerate(rec.get('crew',[])):
                if crew:barracks[str(100000+vid*100+idx)]=crew
        v['wallet']['credits']+=gain;del v['vehicles'][str(vid)]
    if not seen:raise Reject('EMPTY_VEHICLE_SALE')

SUPPORTED=('CMD_SELL_VEHICLE',)
