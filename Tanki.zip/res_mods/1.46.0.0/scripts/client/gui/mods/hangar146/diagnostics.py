# -*- coding: utf-8 -*-
"""Read-only readiness snapshot. Does not force entity/state or fake matchmaking."""
from __future__ import absolute_import
import os,json,time
from . import runtime_data as R

_LAST_CREW_REJECTION=None

def crew_rejection(command,args,error):
    global _LAST_CREW_REJECTION
    flat=list(args[0]) if len(args)==1 and isinstance(args[0],(list,tuple)) else list(args)
    _LAST_CREW_REJECTION={'command':command,'error':str(error),'timestamp':time.time(),
        'argument_types':[type(a).__name__ for a in flat],
        'arguments':[a if isinstance(a,(int,long)) and not isinstance(a,bool) else None for a in flat]}

def capture():
    data={'build':'M05','timestamp':time.time(),'battle_runtime_ported':False,'queue_command_700_implemented':True}
    if _LAST_CREW_REJECTION is not None:data['last_crew_rejection']=dict(_LAST_CREW_REJECTION)
    def probe(name,fn):
        try:data[name]=fn()
        except Exception as e:data[name]={'error':type(e).__name__+': '+str(e)}
    from PlayerEvents import g_playerEvents
    probe('player_entity_changing',lambda:bool(g_playerEvents.isPlayerEntityChanging))
    from CurrentVehicle import g_currentVehicle
    vehicle=g_currentVehicle.item
    if vehicle is not None:
        for name in ('invID','intCD','level','isCrewFull','isBroken','isInBattle','isLocked','isDisabled','isInPrebattle'):
            probe(name,lambda name=name:getattr(vehicle,name))
        probe('setup_groups',lambda:dict((str(g),{'index':vehicle.setupLayouts.getLayoutIndex(g),'capacity':vehicle.setupLayouts.getGroupCapacity(g)}) for g in (1,2)))
        probe('vehicle_state',vehicle.getState)
        probe('custom_state',vehicle.getCustomState)
        probe('ready_to_fight',lambda:vehicle.isReadyToFight)
        probe('allowed_random_levels',lambda:list(vehicle.lobbyContext.getServerSettings().randomBattlesConfig.getLevels()))
        probe('is_elite',lambda:vehicle.isElite)
        probe('lock',lambda:list(vehicle.lock))
        probe('random_enabled',lambda:vehicle.lobbyContext.getServerSettings().randomBattlesConfig.isEnabled)
        def progression_availability():
            result=vehicle.postProgressionAvailability()
            return {'available':bool(result),'reason':getattr(result.reason,'value',str(result.reason)),
                    'active':vehicle.isPostProgressionActive,'exists':vehicle.isPostProgressionExists}
        probe('post_progression_availability',progression_availability)
        def progression_steps():
            result=[]
            for step in vehicle.postProgression.iterOrderedSteps():
                action=step.action
                result.append({'step':step.stepID,'state':step.getState().value,'action_type':type(action).__name__,
                               'action_disabled':action.isDisabled(),'active_action':action.getActiveID(),
                               'step_price':str(step.getPrice())})
            return result
        probe('post_progression_steps',progression_steps)
        def pp_settings():
            from helpers import dependency
            from skeletons.gui.game_control import IVehiclePostProgressionController
            settings=dependency.instance(IVehiclePostProgressionController).getSettings()
            return {'enabledFeatures':sorted(settings.enabledFeatures),
                    'forbiddenVehicles':sorted(settings.forbiddenVehicles)}
        probe('post_progression_settings',pp_settings)
    else:data['vehicle_state']='CURRENT_VEHICLE_NOT_READY'
    def center_disconnected():
        from account_helpers import isLongDisconnectedFromCenter
        return bool(isLongDisconnectedFromCenter())
    probe('center_disconnected',center_disconnected)
    def wallet_available():
        from helpers import dependency
        from skeletons.gui.game_control import IWalletController
        return bool(dependency.instance(IWalletController).isAvailable)
    probe('wallet_available',wallet_available)
    data['visible_roster']=[{'invID':int(k),'typeCD':r['typeCD'],'name':r['name']} for k,r in sorted(R.state().value['vehicles'].items()) if r.get('visible',True)]
    def entity_name():
        from gui.prb_control.dispatcher import g_prbLoader
        dispatcher=g_prbLoader.getDispatcher()
        return type(dispatcher.getEntity()).__module__+'.'+type(dispatcher.getEntity()).__name__
    probe('prebattle_entity',entity_name)
    def prebattle_validation():
        from gui.prb_control.dispatcher import g_prbLoader
        from gui.Scaleform.daapi.view.lobby.header import battle_selector_items
        from helpers import dependency
        from skeletons.gui.shared import IItemsCache
        from constants import ACCOUNT_ATTR
        dispatcher=g_prbLoader.getDispatcher();entity=dispatcher.getEntity()
        result=entity.canPlayerDoAction()
        attrs=dependency.instance(IItemsCache).items.stats.attributes
        selected=[{'class':type(item).__name__,'locked':bool(item.isLocked())}
                  for item in battle_selector_items.getItems().allItems if item.isSelected()]
        restriction=result.restriction
        return {'is_valid':bool(result.isValid),'restriction':None if restriction is None else str(restriction),
                'is_in_queue':bool(entity.isInQueue()),'account_attributes':attrs,
                'random_battles_allowed':bool(attrs & ACCOUNT_ATTR.RANDOM_BATTLES),'selected_modes':selected}
    probe('prebattle_validation',prebattle_validation)
    filename=os.path.join(R.game_root(),'mods','configs','hangar146','battle_readiness.json')
    with open(filename,'wb') as f:f.write(json.dumps(data,ensure_ascii=True,indent=2,sort_keys=True).encode('ascii'))
    return data

def safe_capture():
    try:capture()
    except Exception:
        import traceback
        from .logging import LOG_ERROR
        LOG_ERROR('Readiness report failed:',traceback.format_exc())


_GENERATION=0
def schedule(owner):
    """Debounced read-only snapshot once native caches settle after a command."""
    global _GENERATION
    if not getattr(owner,'_hangar146_local',False):return
    import BigWorld
    _GENERATION+=1;generation=_GENERATION
    def run():
        if generation==_GENERATION and BigWorld.player() is owner:safe_capture()
    BigWorld.callback(0.5,run)
