# -*- coding: utf-8 -*-
"""Main-thread engine adapter, bounded radial + motion sweeps for OBB contacts."""
from __future__ import absolute_import
from .math3 import *

def contact(runtime,start,end):
 runtime.ray_count+=1;hit=runtime.geometry.ray(start,end,True)
 if hit is None:return None
 point=tuple(float(v) for v in hit.closestPoint);normal=getattr(hit,'normal',None)
 if normal is None:
  # Fallback on clients without material-query normals. Do not call a hit
  # position a normal: sample a small same-layer terrain stencil instead.
  terrain=getattr(hit,'isTerrain',False);terrain=terrain() if callable(terrain) else terrain
  if terrain:
   gradients=[]
   for dx,dz in ((.10,0.),(0.,.10)):
    runtime.ray_count+=1;other=runtime.geometry.ray((point[0]+dx,point[1]+.25,point[2]+dz),(point[0]+dx,point[1]-.25,point[2]+dz),True)
    if other is None:return None
    gradients.append((float(other.closestPoint.y)-point[1])/.1)
   normal=unit((-gradients[0],1.,-gradients[1]))
  else:normal=unit(sub(start,end))
 else:normal=unit(tuple(float(v) for v in normal))
 if dot(normal,sub(end,start))>0.:normal=mul(normal,-1.)
 return point,normal

def hull(runtime,actor,dt):
 b=actor.rigid.b;planes=[]
 def push(hit,shape_index=None):
  if hit is None:return
  p,n=hit
  if any(si==shape_index and dot(n,oldn)>.998 and abs(dot(sub(p,oldp),n))<.025 for oldp,oldn,si in planes):return
  planes.append((p,n,shape_index))
 for shape_index,(lo,hi,offset,q) in enumerate(b.shapes):
  middle=tuple((lo[i]+hi[i])*.5 for i in range(3))
  center=b.world(add(offset,rotate(q,middle)))
  locals=[(x,y,z) for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])]
  for axis in range(3):
   for value in (lo[axis],hi[axis]):
    p=list(middle);p[axis]=value;locals.append(tuple(p))
  for local in locals:
   point=b.world(add(offset,rotate(q,local)));v=b.point_velocity(point)
   endpoint=add(add(point,mul(unit(sub(point,center)),.025)),mul(v,dt))
   push(contact(runtime,center,endpoint),shape_index)
   if length(mul(v,dt))>.20:push(contact(runtime,point,add(point,mul(v,dt))),shape_index)
 low,high=runtime.s.arena.boundingBox
 for axis,edge,n in ((0,low[0]+.5,(1.,0.,0.)),(0,high[0]-.5,(-1.,0.,0.)),(2,low[1]+.5,(0.,0.,1.)),(2,high[1]-.5,(0.,0.,-1.))):
  p=list(b.p);p[axis]=edge;point=tuple(p)
  if dot(sub(b.support(n),point),n)<.1:push((point,n))
 # Static target contacts use SAT per selected part. The turret no longer
 # inflates chassis width/inertia into an enormous all-height rectangular box.
 for other in runtime.round.actors.values():
  if other.id==actor.id:continue
  ob=getattr(other,'rigid',None)
  if ob is None:continue
  ob=ob.b
  if length(sub(b.p,ob.p))>actor.radius+other.radius+8.:continue
  for si,(lo,hi,offset,q) in enumerate(b.shapes):
   center=b.world(add(offset,rotate(q,tuple((lo[i]+hi[i])*.5 for i in range(3)))))
   ba=[rotate(qmul(b.q,q),a) for a in ((1.,0.,0.),(0.,1.,0.),(0.,0.,1.))]
   for oi,(olo,ohi,ooffset,oq) in enumerate(ob.shapes):
    oc=ob.world(add(ooffset,rotate(oq,tuple((olo[i]+ohi[i])*.5 for i in range(3)))))
    oa=[rotate(qmul(ob.q,oq),a) for a in ((1.,0.,0.),(0.,1.,0.),(0.,0.,1.))]
    axes=ba+oa+[cross(a,c) for a in ba for c in oa]
    best=None;depth=1e9
    for axis in axes:
     if length(axis)<1e-5:continue
     n=unit(axis);n=mul(n,-1.) if dot(sub(center,oc),n)<0. else n
     minimum=dot(b.support(n,si),n);maximum=dot(ob.support(mul(n,-1.),oi),n)
     # Test both intervals; choosing n by centres does not alone prove overlap.
     opposite=dot(b.support(mul(n,-1.),si),n)-dot(ob.support(n,oi),n)
     overlap=maximum-minimum
     if overlap<-.025 or opposite<-.025:best=None;break
     if overlap<depth:depth=overlap;best=n
    if best is not None:push((ob.support(mul(best,-1.),oi),best),si)
 return planes
