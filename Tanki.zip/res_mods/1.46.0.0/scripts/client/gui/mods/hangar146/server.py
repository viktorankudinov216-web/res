# -*- coding: utf-8 -*-
from __future__ import absolute_import
import pickle,traceback,hashlib
import BigWorld,AccountCommands
from .logging import LOG_DEBUG,LOG_ERROR
BASE_REQUESTS={}
class FakeServer(object):
    def __init__(self,owner=None):self.owner=owner;self._unknown=set();self._completed={}
    def __getattr__(self,name):
        if name.startswith('__'):raise AttributeError(name)
        if name.startswith('doCmd'):raise AttributeError('Unsupported transport shape '+name)
        def notification(*args,**kwargs):
            if name not in self._unknown:
                self._unknown.add(name);LOG_DEBUG('native notification not emulated:',name)
        return notification
    def _dispatch(self,requestID,cmd,*args):
        # Never create entities or refresh native GUI in a Scaleform call stack.
        owner=self.owner
        # Native NO_RESPONSE is a positive shared sentinel (202 in 1.46).
        # It is neither a unique RPC id nor eligible for deduplication.
        expects_response=requestID!=AccountCommands.REQUEST_ID_NO_RESPONSE
        if cmd in (700,701,502):
            from .queue_probe import mark
            mark('transport_received',command=cmd,requestID=requestID,owner_current=owner is BigWorld.player())
        def execute():
            if owner is not BigWorld.player():
                if cmd in (700,701,502):mark('transport_dropped_owner_changed',command=cmd)
                return
            if cmd in (700,701,502):mark('transport_execute',command=cmd,registered=cmd in BASE_REQUESTS)
            fingerprint=hashlib.sha256(pickle.dumps((cmd,args),2)).digest()
            cached=self._completed.get(requestID) if expects_response and requestID>=0 else None
            if cached is not None:
                oldprint,resultID,error,ext=cached
                if oldprint!=fingerprint:resultID=AccountCommands.RES_FAILURE;error='REQUEST_ID_REUSED';ext=None
                if ext is None:owner.onCmdResponse(requestID,resultID,error)
                else:owner.onCmdResponseExt(requestID,resultID,error,pickle.dumps(ext,2))
                return
            resultID=AccountCommands.RES_FAILURE;error='NOT_IMPLEMENTED_M04_COMMAND';ext=None
            fn=BASE_REQUESTS.get(cmd)
            try:
                if fn is not None:ignored,resultID,error,ext=fn(requestID,*args)
                else:LOG_ERROR('unsupported command',cmd,'argc',len(args))
            except Exception as e:
                from .economy import Reject
                if isinstance(e,Reject):
                    LOG_ERROR('command rejected',cmd,str(e))
                    if cmd in (151,155,162,163):
                        LOG_ERROR('crew protocol args',cmd,args)
                        from .diagnostics import crew_rejection
                        crew_rejection(cmd,args,e)
                else:LOG_ERROR('command failed',cmd,'argument_types',[type(a).__name__ for a in args],traceback.format_exc())
                error=type(e).__name__+': '+str(e)
            if owner is not BigWorld.player():return
            if getattr(owner,'_hangar146_local',False):
                from .diagnostics import schedule
                schedule(owner)
            if not expects_response:return
            if requestID>=0:
                if len(self._completed)>=1024:self._completed.pop(next(iter(self._completed)))
                self._completed[requestID]=(fingerprint,resultID,error,ext)
            if ext is None:owner.onCmdResponse(requestID,resultID,error)
            else:owner.onCmdResponseExt(requestID,resultID,error,pickle.dumps(ext,2))
        BigWorld.callback(0.0,execute)
        return requestID

def _method():
    def call(self,requestID,cmd,*args):return self._dispatch(requestID,cmd,*args)
    return call
for _name in ('doCmdStr','doCmdIntStr','doCmdInt','doCmdInt2','doCmdInt3','doCmdInt4','doCmdInt2Str','doCmdInt3Str','doCmdIntArr','doCmdIntStrArr','doCmdStrArr','doCmdIntArrStrArr'):setattr(FakeServer,_name,_method())


def _battle_rpc(name):
    def call(self,*args):
        from .combat146 import enqueue
        return enqueue(self.owner,name,args)
    return call
for _rpc in ('leaveArena','vehicle_moveWith','vehicle_shoot','vehicle_reload',
             'vehicle_reloadGun','vehicle_changeSetting','vehicle_trackWorldPointWithGun',
             'vehicle_stopTrackingWithGun'):
    setattr(FakeServer,_rpc,_battle_rpc(_rpc))
