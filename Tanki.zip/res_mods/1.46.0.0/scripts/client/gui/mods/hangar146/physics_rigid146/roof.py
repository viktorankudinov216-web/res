# -*- coding: utf-8 -*-
"""One-time read-only sampling of the native turret BSP. Never per-frame."""
import math
from .math3 import *
def surface(vehicle,lo,hi):
 import Math
 from vehicle_systems.tankStructure import TankPartIndexes
 collision=vehicle.appearance.collisions
 if collision is None:return None
 points=[]
 for axis in range(3):
  for sign in (-1.,1.):
   grid=17 if axis==1 and sign>0. else 5
   rest=[i for i in range(3) if i!=axis]
   for a in range(grid):
    for c in range(grid):
     start=[0.,0.,0.];end=[0.,0.,0.]
     for i,t in zip(rest,(float(a)/(grid-1),float(c)/(grid-1))):start[i]=end[i]=lo[i]+(hi[i]-lo[i])*t
     start[axis]=hi[axis]+.02 if sign>0. else lo[axis]-.02
     end[axis]=lo[axis]-.02 if sign>0. else hi[axis]+.02
     distance=collision.collideLocal(TankPartIndexes.TURRET,Math.Vector3(*start),Math.Vector3(*end))
     span=abs(end[axis]-start[axis])
     if distance is None or not 0.<=float(distance)<=span+.001:continue
     point=list(start);point[axis]-=sign*float(distance);points.append(tuple(point))
 return points if len(points)>=16 else None
