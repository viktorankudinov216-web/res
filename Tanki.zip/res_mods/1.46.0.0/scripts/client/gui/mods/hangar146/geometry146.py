# -*- coding: utf-8 -*-
"""Pinned #2304 material query: (collided, point, normal, material, filename).

ABI recovered from the supplied Tanki.exe registration and tuple builder.
Do not feed the seven-element #1513 destructible tuple into this adapter.
Native calls are exclusively on the game's main thread.
"""
from __future__ import absolute_import
import math

class Hit(object):
    def __init__(self,point,normal,material,filename):
        self.closestPoint=point;self.normal=normal;self.matKind=material;self.filename=filename

def decode(result,start,end):
    if not isinstance(result,tuple) or len(result)!=5 or type(result[0]) is not bool:raise ValueError('Expected #2304 five-element material tuple')
    if not result[0]:return None
    point,normal,material,filename=result[1:]
    values=tuple(point)+tuple(normal)
    if len(values)!=6 or any(math.isnan(float(v)) or math.isinf(float(v)) for v in values):raise ValueError('Non-finite collision')
    norm=sum(float(v)**2 for v in normal)
    if not .5<norm<1.5:raise ValueError('Non-unit surface normal')
    direction=tuple(end[i]-start[i] for i in range(3));length=sum(v*v for v in direction)
    t=sum((point[i]-start[i])*direction[i] for i in range(3))/max(length,1e-16)
    if not -.01<=t<=1.01:raise ValueError('Collision outside segment')
    if sum((point[i]-start[i]-direction[i]*t)**2 for i in range(3))>.05**2:raise ValueError('Collision off segment')
    return Hit(point,normal,int(material),filename)

class Geometry(object):
    def __init__(self,session):self.s=session;self.enabled=None;self.supports_terrain=None;self.queries=0;self.filtered_callbacks=0;self.failures=0;self.cheap_queries=0
    def broken(self,*identity):
        # Callback is queried only for a native destructible by this collector.
        # Temporary movement policy: treat it as broken; do not hide its visual,
        # mutate the map, or change projectile/line-of-sight collision rules.
        self.filtered_callbacks+=1
        return True
    def query(self,start,end,filtered=True):
        import BigWorld,Math
        self.queries+=1
        a=Math.Vector3(*start);b=Math.Vector3(*end)
        result=BigWorld.getMatInfoNearPoint(self.s.avatar.spaceID,a,b,a,self.broken if filtered else (lambda *unused:False),128,0)
        return decode(result,start,end)
    def ray(self,start,end,cheap=False):
        if cheap:
            self.cheap_queries+=1
            hit=self.s.ray(start,end)
            if hit is None:return None
            # Even a terrain hit can be a steep wall. Resolve its normal below;
            # only an actual empty segment may skip the material collector.
        if self.enabled is False:return self.s.ray(start,end)
        try:
            baseline=None
            if self.enabled is None or self.supports_terrain is not True:
                baseline=self.s.ray(start,end)
                terrain=False
                if baseline is not None:
                    value=baseline.isTerrain;terrain=value() if callable(value) else value
                if self.enabled is None or (terrain and self.supports_terrain is None):
                    unfiltered=self.query(start,end,False)
                    if terrain and unfiltered is None:
                        # Some material collectors intentionally omit terrain.
                        self.supports_terrain=False
                    elif (baseline is None)!=(unfiltered is None):raise ValueError('Material/segment hit mismatch')
                    elif baseline is not None:
                        if sum((baseline.closestPoint[i]-unfiltered.closestPoint[i])**2 for i in range(3))>.02**2:raise ValueError('Material/segment point mismatch')
                        if terrain:self.supports_terrain=True
                    self.enabled=True
                    self.s.mark('movement_geometry_api_ready',native_query='getMatInfoNearPoint',tuple_width=5,destructibles_ignored=True,native_terrain_normals=self.supports_terrain)
                if baseline is None:return None
                if terrain and self.supports_terrain is not True:return baseline
            before=self.filtered_callbacks
            filtered=self.query(start,end,True)
            if self.supports_terrain is not True and self.filtered_callbacks>before:
                terrain_hit=self.s.ray(start,end,True)
                if terrain_hit is not None and (filtered is None or sum((terrain_hit.closestPoint[i]-start[i])**2 for i in range(3))<sum((filtered.closestPoint[i]-start[i])**2 for i in range(3))):return terrain_hit
            return filtered
        except Exception as e:
            self.enabled=False;self.failures+=1
            self.s.mark('movement_geometry_api_fallback',error=str(e),destructibles_ignored=False)
            return self.s.ray(start,end)
