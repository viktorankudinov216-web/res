# -*- coding: utf-8 -*-
"""1.46 bridge for copied 0.9.22 ordinary tracked combat laws.

No native network-clock filter input, executable patch, teleport or extra space.
The early map/sky lifecycle is deliberately untouched.
"""
from __future__ import absolute_import
import math,pickle,zlib,traceback,random
from . import combat_core146 as C,battle_loadout146 as L,combat_visual146 as V
from .legacy0922 import vehicle_physics as P,combat_rules as armor,ballistics,bot_gunnery


class SpeedInfo(object):
    def __init__(self,actor):self.actor=actor
    @property
    def value(self):
        a=self.actor
        return (a.v,a.omega,a.v,a.omega)

def current():
    from . import world146 as W,native_match as N
    s=W._SESSION
    if s is None or not s.valid() or N._RETURNING:return None
    return getattr(s,'combat',None)

def attach(session):
    if getattr(session,'combat',None) is not None:raise RuntimeError('Combat already attached')
    session.combat=Runtime(session)
    return session.combat


def minimap_matrix(vehicle):
    if not getattr(vehicle,'_hangar146_vehicle',False):return None
    pose=getattr(vehicle,'_hangar146_pose',None)
    if pose is not None:return pose['matrix']
    matrix=getattr(vehicle,'_hangar146_minimap_matrix',None)
    if matrix is None:
        matrix=__import__('Math').Matrix(vehicle.matrix)
        vehicle._hangar146_minimap_matrix=matrix
    return matrix

def enqueue(owner,name,args):
    import BigWorld
    from . import native_match as N
    if not (N.local_avatar(owner) or getattr(owner,'_hangar146_vehicle',False)):return False
    if name=='leaveArena':return N.request_return()
    generation=N._GENERATION
    def run():
        if generation!=N._GENERATION or N._RETURNING:return
        runtime=current()
        if runtime is None:return
        try:runtime.command(owner,name,args)
        except Exception:
            runtime.s.mark('combat_command_failed',command=name,error=traceback.format_exc())
            N.request_return()
    BigWorld.callback(0.,run)
    return True


def install():
    import Avatar,Vehicle,BigWorld
    V.install()
    from .utils import override
    from .native_match import local_avatar,request_return,mark
    @override(Avatar.PlayerAvatar,'leaveArena')
    def leave(base,self,*args,**kwargs):
        if not local_avatar(self):return base(self,*args,**kwargs)
        # Native leaveArena stops input/projectiles and waits for a real BaseApp.
        # Locally the confirmed menu action must enqueue our complete lifecycle.
        mark('native_leave_requested',return_source='confirmed_Esc_leaveArena')
        return request_return()
    from VehicleGunRotator import VehicleGunRotator
    @override(VehicleGunRotator,'_VehicleGunRotator__syncWithServerTurretYaw')
    def local_yaw(base,self,yaw):
        if local_avatar(self._avatar):return yaw
        return base(self,yaw)
    from AvatarInputHandler.AimingSystems.steady_vehicle_matrix import SteadyVehicleMatrixCalculator
    @override(SteadyVehicleMatrixCalculator,'relinkSources')
    def relink(base,self):
        avatar=BigWorld.player()
        if local_avatar(avatar):
            vehicle=avatar.getVehicleAttached()
            if vehicle is None or getattr(vehicle,'_hangar146_vehicle',False):
                # Also valid during teardown after CompoundAppearance restores
                # its DumbFilter: never dereference stabilisedMatrix on it.
                matrix=vehicle.matrix if vehicle is not None and not vehicle.isHidden else __import__('Math').Matrix()
                output=self._SteadyVehicleMatrixCalculator__outputMProv
                output.rotationSrc=matrix;output.translationSrc=matrix
                self._SteadyVehicleMatrixCalculator__stabilisedMProv.target=matrix
                return
        return base(self)
    # Native observer getters otherwise prefer the inert VehicleFilter matrix.
    # Keep postmortem/spectator cameras on the same authoritative pose.
    def observed_pose(base,self,*args,**kwargs):
        if local_avatar(self) and self.isObserver():
            attached=self.getVehicleAttached()
            values=getattr(attached,'_hangar146_pose',None) if attached is not None else None
            if values is not None:return values['matrix']
        return base(self,*args,**kwargs)
    for name in ('getObservedVehicleMatrix','getObservedVehicleStabilisedMatrix','getObservedVehicleTurretMatrix'):
        if hasattr(Avatar.PlayerAvatar,name):override(Avatar.PlayerAvatar,name)(observed_pose)
    from gui.battle_control import matrix_factory as MF
    from gui.battle_control.battle_constants import VEHICLE_LOCATION
    local_matrix=minimap_matrix
    @override(MF,'makeVehicleEntityMP')
    def vehicle_mp(base,vehicle):
        matrix=local_matrix(vehicle)
        if matrix is None:return base(vehicle)
        provider=__import__('Math').TranslationOnlyMP();provider.source=matrix;return provider
    @override(MF,'getEntityMatrix')
    def entity_mp(base,entityID):
        vehicle=BigWorld.entities.get(entityID);matrix=local_matrix(vehicle)
        return matrix if matrix is not None else base(entityID)
    @override(MF,'getVehicleMPAndLocation')
    def vehicle_location(base,vehicleID,positions):
        vehicle=BigWorld.entities.get(vehicleID)
        if local_matrix(vehicle) is not None:return (MF.makeVehicleEntityMP(vehicle),VEHICLE_LOCATION.AOI)
        return base(vehicleID,positions)
    @override(MF,'makeVehicleMPByLocation')
    def vehicle_location_mp(base,vehicleID,location,positions):
        vehicle=BigWorld.entities.get(vehicleID)
        if local_matrix(vehicle) is not None and location in (VEHICLE_LOCATION.AOI,VEHICLE_LOCATION.AOI_TO_FAR):return MF.makeVehicleEntityMP(vehicle)
        return base(vehicleID,location,positions)
    from gui.Scaleform.daapi.view.battle.shared.finish_sound_player import FinishSoundPlayer
    @override(FinishSoundPlayer,'_playRoundFinished')
    def deferred_finish_sound(base,self,soundID):
        # Local kills/capture start an extendable grace window, not the final
        # result. Runtime plays one concluding event only after arbitration.
        if local_avatar(BigWorld.player()):return
        return base(self,soundID)
    raw=Vehicle.Vehicle.__getattribute__
    @override(Vehicle.Vehicle,'__getattribute__')
    def pose(base,self,name):
        if name=='speedInfo':
            try:return raw(self,'_hangar146_speed_info')
            except AttributeError:pass
        if name in ('position','yaw','pitch','roll','matrix','velocity'):
            try:values=raw(self,'_hangar146_pose')
            except AttributeError:values=None
            if values is not None and name in values:return values[name]
        return base(self,name)
    @override(Vehicle.Vehicle,'getSpeed')
    def speed(base,self):
        if getattr(self,'_hangar146_pose',None) is not None:return self._hangar146_speed
        return base(self)

class Runtime(object):
    def __init__(self,session):
        import Math
        from items import vehicles
        self.s=session;self.entities=dict((int(v.id),v) for v in session.entities)
        self.rng=random.Random(session.plan['roundID']);self.warnings=set();self.last_tick=None
        self.started=False;self.stopped=False;self.result_sent=False;self.report_at=0.;self.shot_reports=0
        from . import process_bridge146
        from . import config
        self.physics_model=config.PHYSICS_MODEL;self.bots_active=config.BOTS_ACTIVE
        if self.physics_model=='rigid_v1':
            from .physics_rigid146 import IdleBridge
            self.helper=IdleBridge()
        else:self.helper=process_bridge146.start()
        self.helper.reset()
        from .geometry146 import Geometry
        self.geometry=Geometry(session);self.clear_cache={}
        from .contact_cache146 import Bank
        self.contact_bank=Bank();self.contact_modes={};self.stage_ms={};self.recent_physics_ms=0.;self.sleep_count=0
        self.matrices={};self.bot_aim={};self.shot_types={};self.old_bounds={}
        self.physics_ms=0.;self.physics_max_ms=0.;self.physics_steps=0;self.ray_count=0
        self.summary=dict(damage=0,trackAssist=0,radioAssist=0,tankings=0,stunAssist=0,lastKillerID=0,lastDeathReasonID=0)
        actors=[]
        for i,(v,rec,pose) in enumerate(zip(session.entities,session.records,session.poses)):
            d=v.typeDescriptor;load=L.for_record(rec,d)
            factors=load['factors'];params=P.derive_params(d,factors)
            if 'engine_power_w' in load:params['powerW']=load['engine_power_w']
            if 'speed_limits_mps' in load:params['speedFwd'],params['speedBwd']=load['speed_limits_mps']
            suspension=P.derive_suspension_params(d)
            order=[vehicles.makeIntCompactDescrByID('shell',*shot.shell.id) for shot in d.gun.shots]
            shots=dict(zip(order,d.gun.shots))
            counts=dict((abs(int(cd)),int(n)) for cd,n in zip(rec.get('shells',[])[::2],rec.get('shells',[])[1::2]) if abs(int(cd)) in shots)
            if i>0 and not any(counts.values()):counts={order[0]:int(d.gun.maxAmmo)}
            selected=next((cd for cd in order if counts.get(cd,0)>0),order[0])
            mag=C.Magazine(counts,selected,load['clip_size'],load['reload_seconds'],load['clip_interval'])
            actor_class=C.Actor
            if self.physics_model=='rigid_v1':
                from .physics_rigid146 import Actor as actor_class
            actor=actor_class(v.id,pose['team'],pose['position'],pose['yaw'],v.health,params,suspension,load,mag)
            actor.body['pitch']=pose['pitch'];actor.body['roll']=pose['roll'];actor.previous_pose=actor.snapshot()
            if self.physics_model=='rigid_v1':
                from .physics_rigid146 import geometry as RG
                actor.rigid_visual_source=config.RIGID_VISUAL_SOURCE
                actor.configure_rigid(pose['bounds'],d,v)
                actor.rigid_cast=lambda start,end:RG.contact(self,start,end)
                actor.rigid_hull=lambda item,dt:RG.hull(self,item,dt)
                actor.rigid_static=i>0 and not self.bots_active
                session.mark('rigid_vehicle_prepared',simulation=self.physics_model,vehicle_id=actor.id,rigid=actor.diagnostics(full=True))
            actor.rating=bot_gunnery.resolve_rating('mixed',session.plan['roundID'],actor.team,i)
            actor.radius=max(.5,(pose['bounds'][1][0]-pose['bounds'][0][0])*.5)
            actor.external_solver=self.helper.solve;actor.ground_batch=self.ground_batch;actor.contact_epoch=0;actor.sleeping=False;actor.rest_time=0.
            actors.append(actor);self.shot_types[actor.id]=shots;self.old_bounds[actor.id]=pose['bounds']
            matrix=minimap_matrix(v)
            if matrix is None:matrix=Math.Matrix(v.matrix)
            self.matrices[actor.id]=matrix
            v._hangar146_pose=dict(matrix=matrix,position=Math.Vector3(*actor.position),yaw=actor.yaw,pitch=actor.body['pitch'],roll=actor.body['roll'],velocity=Math.Vector3(0,0,0))
            v._hangar146_speed=0.;v._hangar146_speed_info=SpeedInfo(actor)
            v.appearance.compoundModel.matrix=matrix
            camera_target=getattr(v,'_Vehicle__cameraTargetMatrix',None)
            if camera_target is not None:camera_target.target=matrix
            if i:
                class Aim(object):pass
                aim=Aim();aim.turretMatrix=Math.Matrix();aim.gunMatrix=Math.Matrix()
                aim.turretMatrix.setIdentity();aim.gunMatrix.setIdentity()
                self.bot_aim[actor.id]=aim;v.appearance.setupGunMatrixTargets(aim)
        self.round=C.Round(actors,900.);self.player_id=int(session.avatar.playerVehicleID)
        self.round.configure_bases([(index+1,base_id,tuple(pos)) for index,team_bases in enumerate(session.arena.teamBasePositions) for base_id,pos in sorted(team_bases.items())])
        for actor in actors:
            vehicle=self.entities[actor.id];vehicle._hangar146_combat_runtime=self
            V.pin_filter(vehicle);self.rebind_model(vehicle)
        self.publish_positions()
        matrix=self.matrices[self.player_id]
        session.avatar._PlayerAvatar__ownVehicleMProv.target=matrix
        session.avatar._PlayerAvatar__ownVehicleStabMProv.target=matrix
        session.mark('combat_authority_prepared',simulation=self.physics_model,
            simulation_hz=60,render_mode='per_frame_interpolated',support_normals='local_height_derivatives',
            physics_source=('isolated_rigid_6dof_spring_friction' if self.physics_model=='rigid_v1' else 'copied_vehicle_physics0922_contact_cycle'),combat_scope='ordinary_tracked_singlegun',
            battle_loadouts=[dict(vehicle_id=a.id,reload_seconds=a.loadout['reload_seconds'],base_reload_seconds=a.loadout['base_reload_seconds'],source=a.loadout['source']) for a in actors],
            unsupported_features=['special_gun_modes','full_legacy_tactical_AI','dynamic_crew_perks','destructible_authority','internal_module_damage','native_result_window','battle_economy','spotting_camouflage','consumable_actions','ramming_water_fire'])
    def rebind_model(self,vehicle):
        actor=self.round.actors.get(int(vehicle.id))
        if actor is None:return
        app=vehicle.appearance;matrix=self.matrices[actor.id]
        app.compoundModel.matrix=matrix
        collisions=getattr(app,'collisions',None)
        if collisions is not None and hasattr(collisions,'matrix'):collisions.matrix=matrix
        if actor.id in self.bot_aim and actor.health>0:app.setupGunMatrixTargets(self.bot_aim[actor.id])
        try:
            V.bind_motion(vehicle,actor,matrix)
            if self.physics_model=='rigid_v1':
                from .physics_rigid146 import visual
                visual.bind(vehicle,actor,self.s.mark)
                if self.started and actor.health>0:
                    from .physics_rigid146 import wheel_scene,native_tracks
                    if getattr(actor,'rigid_visual_source','native')=='native':native_tracks.bind(vehicle,actor,self.s.mark)
                    else:wheel_scene.attach(vehicle,actor)
        except Exception:self.warn('native_motion_binding')
    def track_report(self,actor):
        try:
            controller=self.entities[actor.id].appearance.trackScrollController
            if controller is None:return None
            return (float(controller.leftScroll()),float(controller.rightScroll()))
        except Exception:
            self.warn('track_diagnostics');return None
    def warn(self,key):
        if key in self.warnings:return
        self.warnings.add(key);self.s.mark('combat_presentation_warning',warning_key=key,warning=traceback.format_exc())
    def start(self):
        import BigWorld
        if self.started:return
        self.started=True;self.last_tick=BigWorld.time()
        if self.physics_model=='rigid_v1':
            # Model nodes can be stale during initial CGF assembly. Resolve
            # carriers again after the prebattle countdown, before integration.
            for actor in self.round.actors.values():
                if actor.rigid_layout=='model_roadwheels_compound_local':continue
                vehicle=self.entities[actor.id]
                cast,hull,static=actor.rigid_cast,actor.rigid_hull,actor.rigid_static
                try:
                    actor.configure_rigid(self.old_bounds[actor.id],vehicle.typeDescriptor,vehicle)
                    self.s.mark('rigid_layout_finalized',vehicle_id=actor.id,rigid=actor.diagnostics(full=True))
                except Exception:self.warn('rigid_layout_finalization')
                finally:actor.rigid_cast,actor.rigid_hull,actor.rigid_static=cast,hull,static
        if self.physics_model=='rigid_v1':
            from .physics_rigid146 import wheel_scene
            for actor in self.round.actors.values():
                try:
                    actor.refine_roof(self.entities[actor.id])
                    if getattr(actor,'rigid_visual_source','native')=='native':
                        from .physics_rigid146 import native_tracks
                        native_tracks.bind(self.entities[actor.id],actor,self.s.mark)
                    else:
                        count=wheel_scene.attach(self.entities[actor.id],actor)
                        self.s.mark('rigid_scene_bound',vehicle_id=actor.id,scene_nodes=count or 0)
                except Exception:
                    actor._wheel_scene_error=traceback.format_exc();actor._native_chain_error=actor._wheel_scene_error;self.warn('rigid_suspension_scene')
        self.publish_positions()
        self.round.now=0.
        self.s.mark('combat_started',combat_enabled=True,simulation=self.physics_model)
        self.s.later(0.,self.tick)
    def stop(self):
        self.stopped=True
        self.helper.reset()
        import Math
        for shot in list(self.round.shots):
            try:self.stop_visual(shot,Math.Vector3(*shot['position']))
            except Exception:self.warn('stop_visual_cleanup')
        self.round.shots[:]=[]
        for v in self.entities.values():
            # bootstrap.fini restores Python hooks before engine teardown.
            # Arm surviving entities now, while their native owners still exist.
            if getattr(getattr(v,'appearance',None),'_vehicle',None) is v:
                try:V.prepare_native_refresh(v)
                except Exception:self.warn('native_stop_guard')
            # Keep overlay matrix through native visual retirement; the entity
            # owns it until clearEntitiesAndSpaces. No camera points at freed MP.
            v._hangar146_speed=0.
            actor=self.round.actors.get(int(v.id))
            if actor is not None:
                actor.v=0.;actor.omega=0.;actor.flags=0
                if hasattr(actor,'_rigid_wheel_provider'):
                    from .physics_rigid146.visual import write_provider
                    write_provider(actor,(0.,0.,0.,0.))
            if getattr(v,'_hangar146_pose',None) is not None:v._hangar146_pose['velocity']=__import__('Math').Vector3(0.,0.,0.)
            try:
                mode=(0,0) if actor is None or actor.health<=0 else (1,0)
                v.engineMode=mode;v.appearance.changeEngineMode(mode,True)
                v.appearance.filter.setTracksSpeed(0.,True,0.,True);v.appearance.updateTracksScroll(0.,0.)
            except Exception:self.warn('native_stop_motion')
    def tick(self):
        import BigWorld
        if self.stopped:return
        now=BigWorld.time();elapsed=max(0.,now-self.last_tick);self.last_tick=now
        self.helper.poll()
        self.round.advance(elapsed,self.step)
        self.helper.flush(list(self.round.actors.values()))
        if self.round.now>=getattr(self,'positions_at',0.):
            self.positions_at=self.round.now+.1
            self.publish_positions()
        pending=self.round.pending
        signature=None if pending is None else (pending['winner'],pending['reason'],pending['deadline'])
        if signature!=getattr(self,'pending_report',None):
            self.pending_report=signature
            if pending is not None:self.s.mark('combat_finish_pending',pending_winner=pending['winner'],pending_reason=pending['reason'],pending_deadline=pending['deadline'],battle_seconds=self.round.now)
        # One interpolation per rendered frame, not one pose per timer callback.
        # Model, observer matrix and player camera use the SAME matrix provider.
        alpha=C.clamp(self.round.accumulator/C.STEP,0.,1.)
        for actor in self.round.actors.values():
            if actor.health>0 and not getattr(actor,'sleeping',False):self.present_pose(actor,alpha,False)
        if self.physics_model=='rigid_v1':
            from .physics_rigid146 import visual as rigid_visual
            for actor in self.round.actors.values():
                try:rigid_visual.drive(self.entities[actor.id],actor,now,self.round.result is None)
                except Exception:self.warn('rigid_wheel_frame_feed')
        if self.round.result is not None:self.finish(self.round.result,self.round.reason);return
        if self.round.now>=self.report_at:
            self.report_at=self.round.now+20.
            self.s.mark('combat_tick',combat_enabled=True,simulation=self.physics_model,
                physics_model=self.physics_model,bots_active=self.bots_active,rigid_states=[dict(vehicle_id=a.id,state=a.diagnostics()) for a in self.round.actors.values() if hasattr(a,'rigid') and not a.rigid_static],battle_seconds=self.round.now,active_projectiles=len(self.round.shots),physics_dropped_seconds=self.round.dropped_time,
                simulation_hz=60,worker_ready=self.helper.ready,worker_failure=self.helper.failed,worker_stats=self.helper.stats,movement_geometry_enabled=self.geometry.enabled,movement_geometry_queries=self.geometry.queries,movement_cheap_rays=self.geometry.cheap_queries,contact_cache_native=self.contact_bank.native is not None,contact_cache_error=self.contact_bank.error,contact_cache_hits=self.contact_bank.hits,contact_cache_misses=self.contact_bank.misses,contact_refresh_modes=self.contact_modes,sleeping_actors=self.sleep_count,physics_recent_ms=self.recent_physics_ms,physics_stage_ms=self.stage_ms,command_delay_ms=0,destructible_filter_calls=self.geometry.filtered_callbacks,worker_remote_actors=sum(a.health>0 and not getattr(a,'sleeping',False) and bool(getattr(a,'solver_remote',False)) for a in self.round.actors.values()),physics_steps=self.physics_steps,physics_mean_ms=self.physics_ms/max(1,self.physics_steps),physics_max_ms=self.physics_max_ms,support_rays=self.ray_count,
                combat_actors=[dict(vehicle_id=a.id,team=a.team,health=a.health,speed=a.v,position=a.position,contact_count=a.body.get('contact_count'),airborne=a.body.get('airborne'),pitch=a.body['pitch'],roll=a.body['roll'],engine_mode=getattr(a,'engine_mode',None),tracks_expected=P.track_scroll(a.params,a.v,a.omega),tracks_actual=self.track_report(a),blocked_seconds=a.blocked,last_block=getattr(a,'last_block',None),target_id=a.target_id,aim_hold=a.hold,engine_rpm=getattr(a,'audio_rpm',None),drive_acceleration=getattr(a,'drive_acceleration',0.),lateral_acceleration=getattr(a,'lateral_acceleration',0.),support_plane_error=(a.ground_plane or {}).get('max_residual')) for a in self.round.actors.values()])
        self.s.later(0.,self.tick)
    def publish_positions(self):
        # ClientArena rebuilds indices as enumerate(sorted(vehicles)); use its
        # public updatePositions contract, never mutate its private dictionary.
        try:
            indices=[];positions=[]
            for index,vid in enumerate(sorted(self.s.avatar.arena.vehicles)):
                actor=self.round.actors.get(vid)
                if actor is not None and actor.health>0:
                    indices.append(index);positions.extend((actor.position[0],actor.position[2]))
            self.s.avatar.arena.updatePositions(indices,positions)
        except Exception:self.warn('minimap_positions')
    def command(self,owner,name,args):
        actor=self.round.actors.get(self.player_id if owner is self.s.avatar else int(owner.id))
        if actor is None:return
        if name=='vehicle_moveWith':
            actor.flags=int(args[0]) if self.started and actor.health>0 and self.round.result is None else 0
        elif name=='vehicle_shoot':self.fire(actor)
        elif name in ('vehicle_reload','vehicle_reloadGun'):
            if self.started and actor.magazine.reload(self.round.now):self.publish_ammo(actor,reset_prediction=True)
        elif name=='vehicle_changeSetting':
            from constants import VEHICLE_SETTING
            code,value=args[:2]
            if code in (VEHICLE_SETTING.CURRENT_SHELLS,VEHICLE_SETTING.NEXT_SHELLS):
                if actor.magazine.select(int(value),self.round.now,immediate=code==VEHICLE_SETTING.CURRENT_SHELLS,prebattle=not self.started):self.publish_ammo(actor,reset_prediction=code==VEHICLE_SETTING.CURRENT_SHELLS)
        elif name=='vehicle_trackWorldPointWithGun':actor.aim_target=tuple(args[0])
        elif name=='vehicle_stopTrackingWithGun':actor.aim_target=None
    def publish_ammo(self,actor,reset_prediction=False):
        if actor.id!=self.player_id:return
        from constants import VEHICLE_SETTING
        avatar=self.s.avatar;mag=actor.magazine
        for cd in self.shot_types[actor.id]:
            avatar.updateVehicleAmmo(actor.id,cd,mag.counts.get(cd,0),mag.loaded if cd==mag.selected else 0,0,0.,0.)
        avatar.updateVehicleSetting(actor.id,VEHICLE_SETTING.CURRENT_SHELLS,mag.selected)
        avatar.updateVehicleSetting(actor.id,VEHICLE_SETTING.NEXT_SHELLS,mag.next_shell)
        time_left=max(0.,mag.ready_at-self.round.now)
        if not sum(mag.counts.values()):time_left=-2.
        base_time=mag.reload_time if mag.pending is not None or mag.capacity==1 else mag.interval
        if reset_prediction and time_left>0.:avatar.updateVehicleGunReloadTime(actor.id,0.,base_time)
        avatar.updateVehicleGunReloadTime(actor.id,time_left,base_time)
    def ground_batch(self,actor,requests,pseudo=False):
        plane=actor.ground_plane;gx=plane['gradient_x'] if plane else 0.;gz=plane['gradient_z'] if plane else 0.
        ny=1./math.sqrt(1.+gx*gx+gz*gz)
        player=self.round.actors[self.player_id]
        distance=math.hypot(actor.position[0]-player.position[0],actor.position[2]-player.position[2])
        ttl=1./30. if actor.id==self.player_id or distance<100. else 1./15.
        reason='reusable'
        if not plane:reason='unproven'
        elif actor.body.get('airborne',False):reason='airborne'
        elif plane.get('max_residual',1.)>.15:reason='rough'
        elif ny<.70:reason='steep'
        elif abs(actor.omega)>1.2:reason='spin'
        elif self.round.now<getattr(actor,'contact_urgent_until',0.):reason='collision'
        if reason!='reusable':ttl=0.
        self.contact_modes[reason]=self.contact_modes.get(reason,0)+len(requests)
        radius=min(.75,max(.30,abs(actor.v)*ttl+.10))
        owner=(actor.id+(getattr(actor,'contact_epoch',0)<<6))&0xffffffff
        values=self.contact_bank.batch(owner,10 if pseudo else 0,requests,self.round.now,ttl,radius,gx,gz,ny,lambda *row:self.ground(actor,*row))
        return values
    def wake(self,actor):
        if getattr(actor,'sleeping',False):
            actor.sleeping=False;actor.contact_epoch=getattr(actor,'contact_epoch',0)+1
            actor.solver_generation=getattr(actor,'solver_generation',0)+1
        actor.rest_time=0.
    def can_sleep(self,actor,dt):
        if actor.health<=0:return False
        if hasattr(actor,'rigid'):
            from .physics_rigid146.math3 import length,ZERO
            b=actor.rigid.b
            if actor.rigid_static:
                actor.previous_pose=actor.snapshot();actor.rigid_previous_q=b.q
                actor.flags=0;actor.v=0.;actor.omega=0.;actor.track_speeds=(0.,0.)
                return True
            stable=(not actor.flags&79 and length(b.v)<.025 and length(b.w)<.02 and actor.rigid.contacts==len(actor.rigid.wheels))
            if not stable:self.wake(actor);return False
            actor.rest_time+=dt
            if actor.rest_time<.75:return False
            actor.sleeping=True;b.v=ZERO;b.w=ZERO;actor.v=0.;actor.omega=0.
            actor.previous_pose=actor.snapshot();actor.rigid_previous_q=b.q
            actor.track_speeds=(0.,0.);actor.landing_speed=None
            return True
        stable=(not actor.flags&79 and abs(actor.v)<.02 and abs(actor.omega)<.005 and not actor.body.get('airborne',False) and actor.body.get('contact_count',0)>0 and abs(actor.slide_speed)<.02 and all(abs(actor.body.get(k,0.))<.025 for k in ('vertical_velocity','pitch_velocity','roll_velocity')))
        if stable:
            for other in self.round.actors.values():
                if other.id!=actor.id and other.health>0 and abs(other.v)>.05 and math.hypot(other.position[0]-actor.position[0],other.position[2]-actor.position[2])<actor.radius+other.radius+3.:stable=False;break
        if not stable:self.wake(actor);return False
        actor.rest_time+=dt
        if actor.rest_time>=.75:
            actor.sleeping=True;actor.v=0.;actor.omega=0.;actor.previous_pose=actor.snapshot();actor.landing_speed=None
            return True
        return False
    def ground(self,actor,x,z,minimum=None,maximum=None,flat_maximum=None):
        # 1.46 collideSegment supplies point/material, not 0.9.22's normal.
        # Estimate the local normal from two same-window geometry probes. Never
        # pretend closestPoint is the old (point, normal, ...) tuple.
        if minimum is None:minimum=actor.position[1]-4.
        if maximum is None:maximum=actor.position[1]+max(.5,actor.suspension['clearance']+.3)
        top=float(maximum);bottom=float(minimum)
        for unused in range(3):
            self.ray_count+=1
            hit=self.geometry.ray((x,top,z),(x,bottom,z))
            if hit is None:return None
            height=float(hit.closestPoint.y)
            if math.isnan(height) or math.isinf(height):raise RuntimeError('Non-finite suspension BSP height')
            # Small, same-layer stencil. No broad terrain-only cast through a bridge.
            native_normal=getattr(hit,'normal',None)
            normal_y=float(native_normal[1]) if native_normal is not None else 1.
            derivatives=[];epsilon=.12
            for dx,dz in (() if native_normal is not None else ((epsilon,0.),(0.,epsilon))):
                self.ray_count+=1
                nearby=self.geometry.ray((x+dx,top,z+dz),(x+dx,bottom-.25,z+dz))
                if nearby is None:derivatives=None;break
                other=float(nearby.closestPoint.y)
                if math.isnan(other) or math.isinf(other):raise RuntimeError('Non-finite suspension normal sample')
                derivatives.append((other-height)/epsilon)
            if derivatives:normal_y=1./math.sqrt(1.+sum(v*v for v in derivatives))
            if bottom-.01<=height<=maximum+.01 and P.suspension_support_allowed(height,normal_y,flat_maximum):return height
            below=height-.02
            if not bottom+.01<below<top:return None
            top=below
        return None
    def bounds(self,position):
        lo,hi=self.s.arena.boundingBox
        return lo[0]+1.<position[0]<hi[0]-1. and lo[1]+1.<position[2]<hi[1]-1.
    def solid_hit(self,start,end):
        hit=self.geometry.ray(start,end,True)
        if hit is None:return None
        normal=getattr(hit,'normal',None)
        if normal is not None:
            # Support surfaces are handled by springs, not horizontal hull walls.
            return hit if abs(float(normal[1]))<.65 else None
        terrain=hit.isTerrain
        return None if (terrain() if callable(terrain) else terrain) else hit
    def solid(self,start,end):return self.solid_hit(start,end) is not None
    def clear(self,actor,position,yaw):
        old=actor.position
        if abs(position[0]-old[0])+abs(position[2]-old[2])<1e-8 and abs(C.angle(yaw-actor.yaw))<1e-8:return True
        lo,hi=self.old_bounds[actor.id]
        clearance=actor.suspension['clearance'];levels=(max(clearance+.15,(lo[1]+hi[1])*.5),hi[1]-.1)
        corners=((lo[0],lo[2]),(hi[0],lo[2]),(hi[0],hi[2]),(lo[0],hi[2]))
        rotation=P._suspension_rotation(actor.body['pitch'],actor.body['roll'])
        offsets={};headings={}
        def point(pos,heading,x,y,z):
            key=(x,y,z)
            offset=offsets.get(key)
            if offset is None:
                offset=P._suspension_point_offset(dict(x=x,y=y,z=z),rotation);offsets[key]=offset
            trig=headings.get(heading)
            if trig is None:trig=(math.sin(heading),math.cos(heading));headings[heading]=trig
            sine,cosine=trig
            return (pos[0]+offset[0]*cosine+offset[2]*sine,pos[1]+offset[1],pos[2]-offset[0]*sine+offset[2]*cosine)
        def footprint(pos,heading):
            key=(actor.id,tuple(pos),heading,actor.body['pitch'],actor.body['roll'])
            if key in self.clear_cache:return self.clear_cache[key]
            rings=[];hits=[]
            for height in levels:
                ring=[point(pos,heading,x,height,z) for x,z in corners];rings.append(ring)
                for i in range(4):
                    hit=self.solid_hit(ring[i],ring[(i+1)%4])
                    if hit is not None:hits.append(hit)
            value=(rings,hits);self.clear_cache[key]=value
            if len(self.clear_cache)>128:self.clear_cache.clear();self.clear_cache[key]=value
            return value
        rings,hits=footprint(position,yaw);sweeps=[]
        for height,ring in zip(levels,rings):
            for (x,z),end in zip(corners,ring):
                start=point(old,actor.yaw,x,height,z)
                if sum((start[i]-end[i])**2 for i in range(3))>1e-9:
                    hit=self.solid_hit(start,end)
                    if hit is not None:sweeps.append(hit)
        if hits or sweeps:
            unused,old_hits=footprint(old,actor.yaw)
            escaping=bool(old_hits) and len(hits)<=len(old_hits)
            dx=position[0]-old[0];dz=position[2]-old[2]
            # Native normals provide a separating half-space. Existing overlap
            # must not prohibit backing out or sliding parallel to the wall.
            # Never permit deeper movement, or passage through a fresh wall.
            for hit in old_hits+hits+sweeps:
                normal=getattr(hit,'normal',None)
                hp=hit.closestPoint
                if normal is None:
                    # Conservative outward recovery when the optional material
                    # ABI is unavailable: never deepen the existing overlap.
                    nx,nz=old[0]-hp[0],old[2]-hp[2]
                    length=math.hypot(nx,nz)
                    if length<1e-6:escaping=False;break
                    nx/=length;nz/=length
                else:nx,nz=float(normal[0]),float(normal[2])
                if (old[0]-hp[0])*nx+(old[2]-hp[2])*nz<0:nx=-nx;nz=-nz
                if dx*nx+dz*nz< -1e-6:escaping=False;break
                old_rings=footprint(old,actor.yaw)[0]
                old_depth=min((q[0]-hp[0])*nx+(q[2]-hp[2])*nz for ring in old_rings for q in ring)
                new_depth=min((q[0]-hp[0])*nx+(q[2]-hp[2])*nz for ring in rings for q in ring)
                if new_depth<old_depth-1e-6:escaping=False;break
            if not escaping:actor.contact_urgent_until=self.round.now+.15;actor.last_block='static_sweep' if sweeps else 'static_perimeter';return False
        for other in self.round.actors.values():
            if other.id==actor.id or abs(position[1]-other.position[1])>3.:continue
            radius=actor.radius+other.radius
            distance=(position[0]-other.position[0])**2+(position[2]-other.position[2])**2
            previous=(old[0]-other.position[0])**2+(old[2]-other.position[2])**2
            if distance<radius**2 and distance<previous-1e-8:actor.last_block='vehicle';return False
        actor.last_block=None
        return True
    def step(self,dt):
        import time
        started=time.clock()
        self.sleep_count=0
        for actor in sorted(self.round.actors.values(),key=lambda a:a.id):
            if actor.health<=0:
                if not getattr(actor,'dead_presented',False):
                    self.present_pose(actor);actor.dead_presented=True
                continue
            if self.bots_active and actor.id!=self.player_id and self.round.now>=actor.think_at:
                previous=getattr(actor,'ai_time',self.round.now-dt);actor.ai_time=self.round.now;actor.think_at=self.round.now+1./15.
                t=time.clock();self.ai(actor,max(dt,self.round.now-previous));self.stage_ms['ai']=self.stage_ms.get('ai',0.)+(time.clock()-t)*1000.
            if not self.bots_active and actor.id!=self.player_id:
                actor.flags=0;actor.previous_pose=actor.snapshot();actor.landing_speed=None
                if hasattr(actor,'rigid'):actor.rigid_previous_q=actor.rigid.b.q
                sleeping=True
            else:sleeping=self.can_sleep(actor,dt)
            if sleeping:self.sleep_count+=1
            else:
                t=time.clock();actor.step(dt,self.ground,self.clear,self.bounds);self.stage_ms['motion']=self.stage_ms.get('motion',0.)+(time.clock()-t)*1000.
            native_due=self.round.now>=getattr(actor,'native_at',0.)
            if native_due:
                t=time.clock();actor.native_at=self.round.now+1./30.
                try:V.update_motion(self.entities[actor.id],actor,1./30.)
                except Exception:self.warn('native_motion_feed')
                self.stage_ms['drivetrain']=self.stage_ms.get('drivetrain',0.)+(time.clock()-t)*1000.
            if not sleeping:self.present_pose(actor,1.,native_due)
            if actor.landing_speed is not None:
                from constants import ATTACK_REASON
                self.damage(actor,0,P.fall_damage(actor.max_health,actor.landing_speed),ATTACK_REASON.WORLD_COLLISION)
            if actor.magazine.update(self.round.now):self.publish_ammo(actor)
        # All hull collision providers have authoritative poses before ray tests.
        for shot in list(self.round.shots):self.projectile(shot,dt)
        self.round.capture_step(dt)
        self.publish_capture()
        cost=(time.clock()-started)*1000.
        self.recent_physics_ms+=(cost-self.recent_physics_ms)*.05
        self.physics_ms+=cost;self.physics_max_ms=max(self.physics_max_ms,cost);self.physics_steps+=1
    def publish_capture(self):
        from constants import ARENA_UPDATE
        for base in self.round.bases:
            state=(int(base['points']),base['invaders'],base['stopped'],base['captured'])
            if state==base['notified']:continue
            previous=base['notified'];base['notified']=state
            remaining=(100.-base['points'])/max(1,min(3,base['invaders']))
            self.s.avatar.arena.update(ARENA_UPDATE.BASE_POINTS,pickle.dumps((base['team'],base['id'],state[0],remaining,base['invaders'],base['stopped']),2))
            if base['captured'] and (previous is None or not previous[3]):
                self.s.avatar.arena.update(ARENA_UPDATE.BASE_CAPTURED,pickle.dumps((base['team'],base['id']),2))
                self.s.mark('local_base_captured',base_team=base['team'],base_id=base['id'],grace_seconds=5.)
    def present_pose(self,actor,alpha=1.,tracks=True):
        import Math
        v=self.entities[actor.id];matrix=self.matrices[actor.id]
        old=actor.previous_pose;current=actor.snapshot()
        position=tuple(old[0][i]+(current[0][i]-old[0][i])*alpha for i in range(3))
        angles=tuple(old[i]+C.angle(current[i]-old[i])*alpha for i in (1,2,3))
        if hasattr(actor,'rigid'):position,angles=actor.render_pose(alpha)
        matrix.setRotateYPR(angles);matrix.translation=position
        pose=v._hangar146_pose;pose.update(position=Math.Vector3(*position),yaw=angles[0],pitch=angles[1],roll=angles[2],velocity=Math.Vector3(math.sin(actor.yaw)*actor.v,actor.body.get('vertical_velocity',0.),math.cos(actor.yaw)*actor.v))
        if hasattr(actor,'rigid'):pose['velocity']=Math.Vector3(*actor.rigid.b.v)
        v._hangar146_speed=actor.v
        if not tracks:return
        try:
            flags=actor.flags&15
            if actor.v>.05:flags|=1
            elif actor.v<-.05:flags|=2
            if actor.omega>.01:flags|=8
            elif actor.omega<-.01:flags|=4
            mode=(0,0) if actor.health<=0 else (2,flags) if flags else (1,0)
            if getattr(actor,'engine_mode',None)!=mode:
                v.engineMode=mode;v.appearance.changeEngineMode(mode,True);actor.engine_mode=mode
            left,right=actor.track_speeds if hasattr(actor,'rigid') else P.track_scroll(actor.params,actor.v,actor.omega)
            left_contact=not actor.body.get('left_flying',False);right_contact=not actor.body.get('right_flying',False)
            # Verified PyVehicleFilter export in 1.46. External scroll alone
            # does NOT provide movementInfo for wheels/spline belts/suspension.
            filters=[]
            for flt in (getattr(v,'filter',None),getattr(v.appearance,'filter',None)):
                if flt is None or any(flt is item for item in filters):continue
                setter=getattr(flt,'setTracksSpeed',None)
                if callable(setter):setter(left,left_contact and (abs(left)>.01 if hasattr(actor,'rigid') else True),right,right_contact and (abs(right)>.01 if hasattr(actor,'rigid') else True));filters.append(flt)
            if not filters:raise RuntimeError('Native setTracksSpeed unavailable')
            v.appearance.updateTracksScroll(left,right)
            if hasattr(actor,'rigid'):
                from .physics_rigid146 import visual
                visual.observe(v,actor,self.s.mark)
        except Exception:self.warn('track_scroll')
    def ai(self,actor,dt):
        import Math
        enemies=[a for a in self.round.actors.values() if a.team!=actor.team and a.health>0]
        if not enemies:actor.flags=0;return
        target=min(enemies,key=lambda a:sum((a.position[i]-actor.position[i])**2 for i in (0,2)))
        dx=target.position[0]-actor.position[0];dz=target.position[2]-actor.position[2];distance=math.hypot(dx,dz)
        desired=math.atan2(dx,dz);error=C.angle(desired-actor.yaw)
        flags=8 if error>.12 else 4 if error<-.12 else 0
        origin=tuple(self.muzzle(actor)[0])
        target_vehicle=self.entities[target.id]
        bbox=target_vehicle.typeDescriptor.hull.hitTester.bbox
        local=Math.Vector3(*tuple((bbox[0][i]+bbox[1][i])*.5 for i in range(3)))
        aim=tuple(Math.Matrix(target_vehicle.appearance.compoundModel.node('hull')).applyPoint(local))
        visible=self.s.ray(origin,aim) is None
        if distance>120. or not visible:
            if abs(error)<.7:flags|=1
        if actor.blocked>.3 and self.round.now>=actor.avoid_until:
            actor.avoid_until=self.round.now+2.;actor.avoid_sign=1 if self.rng.random()>.5 else -1
        if self.round.now<actor.avoid_until:flags=2|(8 if actor.avoid_sign>0 else 4)
        actor.flags=flags
        shot=self.shot_types[actor.id][actor.magazine.selected]
        roots=ballistics.ballistic_solutions(origin,aim,shot.speed,shot.gravity)
        if not roots:return
        world_pitch=roots[0][0];aim_yaw=math.atan2(aim[0]-origin[0],aim[2]-origin[2])
        world_dir=Math.Vector3(math.sin(aim_yaw)*math.cos(world_pitch),-math.sin(world_pitch),math.cos(aim_yaw)*math.cos(world_pitch))
        inverse=Math.Matrix();inverse.setRotateYPR((actor.yaw,actor.body['pitch'],actor.body['roll']));inverse.invert()
        local_dir=inverse.applyVector(world_dir)
        relative=math.atan2(local_dir.x,local_dir.z)
        pitch=math.atan2(-local_dir.y,math.hypot(local_dir.x,local_dir.z))
        wanted_pitch=pitch;wanted_yaw=relative
        descr=self.entities[actor.id].typeDescriptor;limits=descr.gun.turretYawLimits
        if limits is not None:relative=C.clamp(relative,float(limits[0]),float(limits[1]))
        delta=C.clamp(C.angle(relative-actor.gun_yaw),-descr.turret.rotationSpeed*dt,descr.turret.rotationSpeed*dt)
        actor.gun_yaw=C.angle(actor.gun_yaw+delta)
        plimits=descr.gun.pitchLimits['absolute'];pitch=C.clamp(pitch,float(plimits[0]),float(plimits[1]))
        actor.gun_pitch+=C.clamp(pitch-actor.gun_pitch,-descr.gun.rotationSpeed*dt,descr.gun.rotationSpeed*dt)
        aim_m=self.bot_aim[actor.id];aim_m.turretMatrix.setRotateYPR((actor.gun_yaw,0.,0.));aim_m.gunMatrix.setRotateYPR((0.,actor.gun_pitch,0.))
        if actor.target_id!=target.id:actor.target_id=target.id;actor.hold=0.
        aimed=abs(C.angle(wanted_yaw-actor.gun_yaw))<.025 and abs(wanted_pitch-actor.gun_pitch)<.02
        actor.hold=actor.hold+dt if visible and aimed else 0.
        if distance<min(600.,shot.maxDistance) and actor.hold>bot_gunnery.rating_parameters(actor.rating)['reaction_seconds']:
            self.fire(actor)
    def muzzle(self,actor):
        import Math
        if actor.id==self.player_id:
            origin,direction=self.s.avatar.gunRotator.getCurShotPosition()
            direction=Math.Vector3(direction);direction.normalise()
            return Math.Vector3(origin),direction
        node=self.entities[actor.id].appearance.compoundModel.node('HP_gunFire')
        if node is None:raise RuntimeError('Bot gun muzzle node unavailable')
        matrix=Math.Matrix(node);direction=matrix.applyToAxis(2);direction.normalise()
        return matrix.translation,direction
    def fire(self,actor):
        import Math
        if not self.started or self.round.result is not None or actor.health<=0:return False
        if not actor.magazine.can_fire(self.round.now):
            if actor.id==self.player_id:
                self.s.avatar.cancelWaitingForShot();self.publish_ammo(actor)
            return False
        shot_type=self.shot_types[actor.id][actor.magazine.selected]
        origin,direction=self.muzzle(actor)
        spread=float(actor.loadout.get('dispersion_angle',self.entities[actor.id].typeDescriptor.gun.shotDispersionAngle))
        if actor.id==self.player_id:
            # The native rotator incorporates current movement/aiming penalties.
            # Frozen garage dispersion is only the minimum, not perfect aim while moving.
            angles=getattr(self.s.avatar.gunRotator,'getCurShotDispersionAngles',None)
            if angles is not None:spread=max(spread,float(angles()[0]))
        # Angular spread in radians; deterministic Gaussian, capped at 2sigma.
        if spread>0:
            dx=C.clamp(self.rng.gauss(0.,spread*.5),-spread,spread)
            dy=C.clamp(self.rng.gauss(0.,spread*.5),-spread,spread)
            yaw=math.atan2(direction.x,direction.z)+dx
            elevation=math.atan2(direction.y,math.hypot(direction.x,direction.z))+dy
            direction=Math.Vector3(math.sin(yaw)*math.cos(elevation),math.sin(elevation),math.cos(yaw)*math.cos(elevation))
        velocity=direction.scale(float(shot_type.speed));acceleration=Math.Vector3(0.,-float(shot_type.gravity),0.)
        actor.magazine.fire(self.round.now)
        sid=self.round.next_shot;self.round.next_shot+=1
        record=dict(id=sid,actor=actor.id,type=shot_type,origin=tuple(origin),position=tuple(origin),velocity=tuple(velocity),acceleration=tuple(acceleration),age=0.,distance=0.)
        self.round.shots.append(record)
        try:self.entities[actor.id].showShooting(1,(0,),False)
        except Exception:self.warn('shooting_effect')
        self.s.avatar.cancelWaitingForShot() if actor.id==self.player_id else None
        try:self.s.avatar.showTracer(actor.id,sid,False,int(shot_type.shell.effectsIndex),origin,velocity,acceleration,float(shot_type.maxDistance),0)
        except Exception:self.warn('native_tracer')
        self.publish_ammo(actor,reset_prediction=True)
        if self.shot_reports<40:
            self.shot_reports+=1
            self.s.mark('local_shot',shot_id=sid,shooter_id=actor.id,effects_index=int(shot_type.shell.effectsIndex),combat_enabled=True)
        return True
    def projectile(self,shot,dt):
        import Math
        # Continuous swept segments; never test only the next projectile point.
        steps=max(1,int(math.ceil(dt/(1./60.))));h=dt/steps
        for unused in range(steps):
            start=shot['position'];v=shot['velocity'];g=shot['acceleration']
            end=tuple(start[i]+v[i]*h+.5*g[i]*h*h for i in range(3))
            new_v=tuple(v[i]+g[i]*h for i in range(3))
            segment=math.sqrt(sum((end[i]-start[i])**2 for i in range(3)))
            remaining=max(0.,float(shot['type'].maxDistance)-shot['distance'])
            if segment>remaining and segment>0:end=tuple(start[i]+(end[i]-start[i])*remaining/segment for i in range(3));segment=remaining
            a=Math.Vector3(*start);b=Math.Vector3(*end)
            hit=self.s.ray(start,end);limit=(hit.closestPoint-a).length if hit is not None else segment+1.
            world_limit=limit
            victim=None;contacts=None
            for actor in self.round.actors.values():
                if actor.id==shot['actor']:continue
                # Avoid native per-component BSP work for obviously distant actors.
                from .physics_rigid146.shots import near_segment
                if not near_segment(actor.position,start,end,18.):continue
                import time
                stamp=time.clock()
                collisions=self.entities[actor.id].collideSegmentExt(a,b)
                cost=(time.clock()-stamp)*1000.
                if cost>8.:self.s.mark('shot_slow_stage',shot_id=shot['id'] if 'id' in shot else None,stage_name='collideSegmentExt',elapsed_ms=cost,victim_id=actor.id)
                if collisions:collisions=[c for c in collisions if 0.<=float(c.dist)<=world_limit]
                if collisions:
                    nearest=min(float(c.dist) for c in collisions)
                    if 0.<=nearest<limit:
                        limit=nearest;victim=actor;contacts=collisions
            if hit is not None or victim is not None:
                fraction=C.clamp(limit/max(segment,1e-9),0.,1.)
                point=tuple(start[i]+(end[i]-start[i])*fraction for i in range(3))
                if victim is not None:
                    self.vehicle_hit(shot,victim,contacts,shot['distance']+limit,start,end)
                    terminal=shot.get('contact_distance',limit)
                    fraction=C.clamp(terminal/max(segment,1e-9),0.,1.)
                    point=tuple(start[i]+(end[i]-start[i])*fraction for i in range(3))
                self.impact(shot,point,new_v,hit if victim is None else None,victim)
                return
            shot.update(position=end,velocity=new_v,age=shot['age']+h,distance=shot['distance']+segment)
            if shot['distance']+1e-6>=float(shot['type'].maxDistance) or shot['age']>=20.:
                self.stop_visual(shot,b);self.round.shots.remove(shot);return
    def vehicle_hit(self,shot,victim,contacts,distance,start=None,end=None):
        contact=armor.resolve_armor_contact(shot['type'],distance,contacts,random_gauss=self.rng.gauss)
        if contact is None:return
        result=contact['result'];nominal=armor.he_nominal_armor(contacts,self.entities[victim.id].typeDescriptor)
        amount=armor.damage(shot['type'],result,nominal,random_gauss=self.rng.gauss) if contact['layer']=='structural' else 0
        shot['contact_distance']=float(contact['distance'])
        if start is not None and end is not None:
            try:
                import time
                stamp=time.clock()
                shown=V.hit_feedback(self.entities[victim.id],shot,contact,start,end,amount)
                cost=(time.clock()-stamp)*1000.
                if cost>8.:self.s.mark('shot_slow_stage',stage_name='hit_feedback',elapsed_ms=cost,victim_id=victim.id)
                shot['hit_feedback']=shown
                self.s.mark('local_vehicle_hit_visual',victim_id=victim.id,hit_component=contact['component'],hit_visual_shown=shown)
            except Exception:self.warn('vehicle_hit_visual')
        before=victim.health
        try:self.hit_direction(victim,shot,contact,min(victim.health,max(0,int(amount))))
        except Exception:self.warn('hit_direction')
        self.damage(victim,shot['actor'],amount)
        try:
            if before>0:self.shell_feedback(victim,shot,contact,max(0,before-victim.health))
        except Exception:self.warn('shell_hud_feedback')
        self.s.mark('local_shell_contact',victim_id=victim.id,attacker_id=shot['actor'],armor_result=result,damage=int(amount),armor_layer=contact['layer'],combat_enabled=True)
    def hit_direction(self,victim,shot,contact,taken):
        from constants import ATTACK_REASON,ATTACK_REASON_INDICES
        if victim.id!=self.player_id or victim.health<=0:return
        shooter=self.round.actors.get(shot['actor'])
        if shooter is None:return
        velocity=shot.get('velocity')
        yaw=math.atan2(velocity[0],velocity[2]) if velocity is not None else math.atan2(victim.position[0]-shooter.position[0],victim.position[2]-shooter.position[2])
        # Native indicator expects the incoming trajectory world yaw, not the
        # victim-to-shooter bearing (which reverses the arrow by pi).
        blocked=(taken==0)
        nominal=int(round(armor.shell_nominal_damage(shot['type'])))
        shell_kind=getattr(shot['type'].shell,'kind','')
        self.s.avatar.showOwnVehicleHitDirection(yaw,shooter.id,taken if taken else nominal,0,blocked,shell_kind=='HIGH_EXPLOSIVE',victim.id,ATTACK_REASON_INDICES[ATTACK_REASON.SHOT])
    def shell_feedback(self,victim,shot,contact,taken):
        from BattleFeedbackCommon import BATTLE_EVENT_TYPE as E
        from constants import ATTACK_REASON,ATTACK_REASON_INDICES
        reason=ATTACK_REASON_INDICES[ATTACK_REASON.SHOT]
        events=[];shooter=self.round.actors.get(shot['actor'])
        if shooter is None:return
        if taken and shooter.id==self.player_id and victim.team!=shooter.team:
            self.summary['damage']+=taken
            events.append(dict(eventType=E.DAMAGE,targetID=victim.id,count=1,details=E.packDamage(taken,reason)))
            if victim.health<=0:events.append(dict(eventType=E.KILL,targetID=victim.id,count=1,details=0))
        if victim.id==self.player_id:
            if taken:
                events.append(dict(eventType=E.RECEIVED_DAMAGE,targetID=shooter.id,count=1,details=E.packDamage(taken,reason)))
                if victim.health<=0:self.summary.update(lastKillerID=shooter.id,lastDeathReasonID=reason)
            elif contact['layer']=='structural' and shooter.team!=victim.team and getattr(shot['type'].shell,'kind','')!='HIGH_EXPLOSIVE':
                nominal=int(round(armor.shell_nominal_damage(shot['type'])))
                self.summary['tankings']+=nominal
                events.append(dict(eventType=E.TANKING,targetID=shooter.id,count=1,details=E.packDamage(nominal,reason)))
        if events:self.s.avatar.onBattleEvents(events)
        self.s.avatar.battleEventsSummary(dict(self.summary))
    def damage(self,victim,attacker,amount,attack_reason=None):
        from constants import ARENA_UPDATE,ATTACK_REASON_INDICES,ATTACK_REASON
        if amount>0:self.wake(victim)
        taken=self.round.damage(victim.id,attacker,amount)
        if taken<=0:return
        v=self.entities[victim.id];old=int(v.health)
        if victim.health<=0:
            V.prepare_native_refresh(v)
            self.s.mark('native_death_guard_ready',vehicle_id=victim.id,filter_pinned=v.appearance._CompoundAppearance__originalFilter is v.filter)
        v.health=victim.health
        reason=ATTACK_REASON_INDICES[attack_reason or ATTACK_REASON.SHOT]
        v.onHealthChanged(victim.health,old,int(attacker),reason)
        if victim.id==self.player_id:self.s.avatar.updateVehicleHealth(victim.id,victim.health,reason,True,False)
        if victim.health<=0:
            victim.flags=0
            # VEHICLE_KILLED is raw pickle in stock 1.46 (NOT zlib).
            self.s.avatar.arena.update(ARENA_UPDATE.VEHICLE_KILLED,pickle.dumps((victim.id,int(attacker),0,reason,1),2))
            self.s.mark('local_vehicle_destroyed',victim_id=victim.id,killer_id=int(attacker),combat_enabled=True)
    def stop_visual(self,shot,point):
        self.s.avatar.stopTracer(shot['id'],point)
        getter=getattr(self.s.avatar,'projectileMover',None)
        mover=getter() if callable(getter) else None
        if mover is None:return
        # Exact 1.46 ProjectileMover cleanup: detach FX, delMotor, delModel.
        # Both IDs matter: hide() moves the entry from id to -id.
        for sid in (shot['id'],-shot['id']):
            if mover.getProjectile(sid) is not None:mover._ProjectileMover__delProjectile(sid)
    def impact(self,shot,point,velocity,world_hit,victim):
        import Math,material_kinds
        direction=Math.Vector3(*velocity);direction.normalise()
        effect=material_kinds.EFFECT_MATERIAL_INDEXES_BY_IDS.get(getattr(world_hit,'matKind',0),0)
        try:
            # Native hide has a travel/fade interval. Remove its motor/model
            # now, then spawn world-space impact FX without a second trajectory.
            self.stop_visual(shot,Math.Vector3(*point))
            if victim is None:self.s.avatar.explodeProjectile(shot['id'],int(shot['type'].shell.effectsIndex),effect,Math.Vector3(*point),direction,[])
        except Exception:self.warn('impact_effect')
        if shot in self.round.shots:self.round.shots.remove(shot)
        self.s.mark('local_projectile_stopped',shot_id=shot['id'],impact_kind='vehicle' if victim is not None else 'static_world',impact_position=point,combat_enabled=True)
    def finish(self,winner=0,reason='timeout'):
        import BigWorld
        if self.result_sent:return
        self.result_sent=True;self.round.finish(winner,reason);self.stop()
        self.s.phase='finished'
        from . import native_match as N
        self.s.later(5.,N.request_return)
        from constants import FINISH_REASON
        native_reason=FINISH_REASON.TIMEOUT if reason=='timeout' else FINISH_REASON.BASE if reason=='capture' else FINISH_REASON.EXTERMINATION
        try:self.s.period('AFTERBATTLE',5.,(int(winner),native_reason))
        except Exception:self.warn('afterbattle_period')
        try:self.s.avatar.onRoundFinished(int(winner),native_reason,{})
        except Exception:self.warn('native_round_finished')
        result='draw' if winner==0 else 'victory' if winner==self.round.actors[self.player_id].team else 'defeat'
        self.finish_sound(reason)
        self.s.mark('combat_finished',battle_result=result,winner_team=int(winner),finish_reason=reason,combat_enabled=False)
        # No fabricated native result payload / rewards. Persist a local receipt.
        from . import runtime_data as R,native_match as N
        import os,json
        folder=os.path.join(R.game_root(),'mods','configs','hangar146')
        receipt=dict(round_id=self.s.plan['roundID'],result=result,winner_team=winner,reason=reason,seconds=self.round.now,
            actors=[dict(vehicle_id=a.id,team=a.team,health=a.health) for a in self.round.actors.values()])
        with open(os.path.join(folder,'last_battle_result.json'),'wb') as f:f.write(json.dumps(receipt,indent=2).encode('utf-8'))
        try:
            from gui import SystemMessages
            SystemMessages.pushMessage({'victory':u'Победа','defeat':u'Поражение','draw':u'Ничья'}[result],type=SystemMessages.SM_TYPE.Information)
        except Exception:self.warn('result_message')


    def finish_sound(self,reason):
        if getattr(self,'finish_sound_sent',False):return
        self.finish_sound_sent=True
        try:
            # Exact 1.46 shared FinishSoundPlayer events; common concluding sound.
            # Win/loss banner remains driven by native AFTERBATTLE winner data.
            import SoundGroups
            event='time_over' if reason=='timeout' else 'end_battle_capture_base' if reason=='capture' else 'end_battle_last_kill'
            SoundGroups.g_instance.playSound2D(event)
        except Exception:self.warn('finish_sound')
