# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os,json,re,sys,traceback
from .logging import LOG_DEBUG,LOG_ERROR
from . import runtime_data
from .utils import override,restore
_ACTIVE=False
_STOPPED=False
_ADDED_HOST=None
_HOSTS=None
_CALLBACKS=[]
_LOGIN_GENERATION=0


def status(stage,**details):
    if 'failed' in stage:LOG_ERROR('stage='+stage,details)
    else:LOG_DEBUG('stage='+stage,details)
    path=os.path.join(runtime_data.game_root(),'mods','configs','hangar146','startup_m01.json')
    folder=os.path.dirname(path)
    if not os.path.isdir(folder):os.makedirs(folder)
    with open(path,'wb') as f:f.write(json.dumps(dict(stage=stage,build='M05',**details),ensure_ascii=True).encode('ascii'))



def cleanup_obsolete_transition(root=None):
    # Remove only the three named artifacts shipped by M06.1, never profiles.
    root=runtime_data.game_root() if root is None else root
    removed=[]
    for rel in ('res_mods/1.46.0.0/scripts/client/gui/mods/hangar146/transition146.py',
                'res_mods/1.46.0.0/scripts/client/gui/mods/hangar146/transition146.pyc',
                'res_mods/1.46.0.0/gui/maps/hangar146_black.dds'):
        path=os.path.join(root,*rel.split('/'))
        if os.path.isfile(path):
            try:os.remove(path);removed.append(rel)
            except OSError:LOG_ERROR('Could not remove obsolete transition artifact:',rel)
    return removed


def install():
    global _HOSTS,_ADDED_HOST
    from ._constants import OFFLINE_SERVER_ADDRES,OFFLINE_SERVER_SETTINGS,OFFLINE_NICKNAME,OFFLINE_GUI_CTX,OFFLINE_LOGIN,OFFLINE_PWD,build_server_settings
    import BigWorld,Account
    from connection_mgr import ConnectionManager,LOGIN_STATUS
    from predefined_hosts import g_preDefinedHosts
    from gui.Scaleform.daapi.view.login.LoginView import LoginView
    from .server import FakeServer
    from . import requests
    requests.register_economy()
    from . import match_queue
    match_queue.register()
    from . import config
    from . import logging as local_logging
    local_logging.configure(config.VERBOSE_LOGGING)
    runtime_data.prepare()
    from . import process_bridge146
    if config.PHYSICS_MODEL=='legacy0922':helper=process_bridge146.start()
    else:
        from .physics_rigid146 import IdleBridge
        helper=IdleBridge()
    def helper_poll():
        if _STOPPED:return
        helper.poll()
        if not helper.failed:helper._callback=BigWorld.callback(.05,helper_poll)
    if config.PHYSICS_MODEL=='legacy0922':helper._callback=BigWorld.callback(.05,helper_poll)
    cleanup_obsolete_transition()
    _HOSTS=g_preDefinedHosts
    if not any(h.url==OFFLINE_SERVER_ADDRES for h in _HOSTS._hosts):
        _ADDED_HOST=_HOSTS._makeHostItem('Local146 M05','Local146',OFFLINE_SERVER_ADDRES)
        _HOSTS._hosts.append(_ADDED_HOST)
    original_getattribute=Account.PlayerAccount.__getattribute__
    def local(account):
        try:return original_getattribute(account,'_hangar146_local')
        except AttributeError:return False

    @override(ConnectionManager,'initiateConnection')
    def initiate(base,self,params,password,serverName):
        global _ACTIVE,_LOGIN_GENERATION
        _LOGIN_GENERATION+=1
        # Explicit offline auto-login mode must also catch the launcher's
        # earlier token2 auto-login; never forward its real credentials.
        if config.AUTO_LOGIN:serverName=OFFLINE_SERVER_ADDRES
        _ACTIVE=(serverName==OFFLINE_SERVER_ADDRES)
        if _ACTIVE:
            status('local_login_requested')
            params={'login':OFFLINE_LOGIN,'auth_method':'login','session':'','token2':''}
            password=OFFLINE_PWD
        return base(self,params,password,serverName)

    @override(Account.PlayerAccount,'__init__')
    def account_init(base,self):
        if not _ACTIVE:return base(self)
        status('account_init_enter')
        self._hangar146_local=True;self.isOffline=True;self.name=OFFLINE_NICKNAME
        self._hangar146_server=FakeServer(self)
        self.initialServerSettings,added=build_server_settings()
        LOG_DEBUG('runtime replay configs added:',added)
        key,value=Account._CLIENT_SERVER_VERSION
        setattr(self,key,value)
        result=base(self)
        status('account_initialized')
        return result

    @override(Account.PlayerAccount,'__getattribute__')
    def getattribute(base,self,name):
        if name in ('cell','base','server') and local(self):return original_getattribute(self,'_hangar146_server')
        return base(self,name)

    @override(Account.PlayerAccount,'onBecomePlayer')
    def become(base,self):
        try:result=base(self)
        except Exception:
            if local(self):
                self._hangar146_become_error=traceback.format_exc()
                status('account_become_failed',traceback=self._hangar146_become_error)
            raise
        if local(self):
            # SoundGroups expects this camera event even for an Account.
            if not hasattr(self.inputHandler,'onCameraChanged'):
                import Event
                self.inputHandler.onCameraChanged=Event.Event()
            def show():
                if _STOPPED or BigWorld.player() is not self:return
                try:
                    from gui.Scaleform.Waiting import Waiting
                    Waiting.hide('login');Waiting.close()
                    import pickle
                    context=pickle.loads(OFFLINE_GUI_CTX)
                    active_ids=sorted(int(k) for k,r in runtime_data.state().value['vehicles'].items() if r.get('visible',True))
                    context['currentVehInvID']=active_ids[0] if active_ids else -1
                    status('show_gui_before');self.showGUI(pickle.dumps(context,2));status('show_gui_after')
                    from . import native_match
                    native_match.garage_shown(self)
                    from . import queue_probe
                    queue_probe.install()
                    from .diagnostics import safe_capture
                    _CALLBACKS.append(BigWorld.callback(15.0,lambda:safe_capture() if not _STOPPED and BigWorld.player() is self else None))
                except Exception:status('show_gui_failed',traceback=traceback.format_exc())
            _CALLBACKS.append(BigWorld.callback(0.0,show))
        return result

    @override(BigWorld,'connect')
    def connect(base,server,loginParams,progressFn):
        if server!=OFFLINE_SERVER_ADDRES:return base(server,loginParams,progressFn)
        def enter():
            global _ACTIVE
            if _STOPPED:return
            _ACTIVE=True
            try:
                progressFn(1,LOGIN_STATUS.LOGGED_ON,'{"token2":"local_only","session_id":"local146"}')
                status('create_account_before')
                sid=BigWorld.createSpace()
                eid=BigWorld.createEntity('Account',sid,0,(0.,0.,0.),(0.,0.,0.),{})
                account=BigWorld.entities[eid]
                if not local(account):raise RuntimeError('Account constructor did not complete local initialization')
                status('promote_account_before')
                BigWorld.player(account)
                # Native BigWorld may log and swallow onBecomePlayer errors.
                failure=getattr(account,'_hangar146_become_error',None)
                if failure:raise RuntimeError('Account.onBecomePlayer failed: '+failure)
                status('promote_account_after')
            except Exception:status('create_account_failed',traceback=traceback.format_exc())
        _CALLBACKS.append(BigWorld.callback(0.0,enter))

    @override(BigWorld,'cancelCallback')
    def cancel_callback(base,callback_id):
        try:return base(callback_id)
        except ValueError as error:
            if _ACTIVE and 'Incorrect callback ID' in str(error):
                LOG_DEBUG('cancelCallback: already inactive callback ignored')
                return
            raise

    @override(LoginView,'_populate')
    def populate(base,self,*args,**kwargs):
        result=base(self,*args,**kwargs)
        if config.AUTO_LOGIN and not _ACTIVE:
            generation=_LOGIN_GENERATION
            def start():
                if _STOPPED or generation!=_LOGIN_GENERATION:return
                from helpers import dependency
                from skeletons.connection_mgr import IConnectionManager
                try:dependency.instance(IConnectionManager).initiateConnection({'login':OFFLINE_LOGIN,'auth_method':'login','session':'','token2':''},OFFLINE_PWD,OFFLINE_SERVER_ADDRES)
                except Exception:status('login_failed',traceback=traceback.format_exc())
            _CALLBACKS.append(BigWorld.callback(1.0,start))
        return result

    # Same targeted safety fixes used by supplied 1.44 offhangar, scoped to this
    # local session. Defaults come from the installed 1.46 classes themselves.
    from paragons_common import BaseParagonsStorage
    @override(BaseParagonsStorage,'__init__')
    def paragons_init(base,self,data):
        if _ACTIVE:
            data=dict(data or {})
            for k,v in BaseParagonsStorage.makeDefaultStorage().items():data.setdefault(k,v)
        return base(self,data)
    from dog_tags_common.dog_tags_storage import Storage
    @override(Storage,'__init__')
    def dogtag_init(base,self,data):
        if _ACTIVE:
            data=dict(data or {})
            if self.key not in data:data[self.key]=self.default()
        return base(self,data)
    try:
        from gui.impl.lobby.achievements.notifications_utils import NotificationsRuleProcessor
        @override(NotificationsRuleProcessor,'process')
        def notifications(base,self):
            if _ACTIVE:return
            return base(self)
    except ImportError:LOG_DEBUG('Optional achievement notification adapter unavailable')
    status('hooks_installed',auto_login=config.AUTO_LOGIN,vehicles=3)


def init():
    try:
        root=runtime_data.game_root()
        with open(os.path.join(root,'version.xml'),'rb') as f:raw=f.read()
        if not re.search(r'1\.46\.0\.0\s*#\s*2304',raw) or not re.search(r'<realm>\s*RU\s*</realm>',raw):raise RuntimeError('Expected Mir Tankov 1.46.0.0 #2304 RU')
        if sys.maxsize<=2**32:raise RuntimeError('Expected x64 Python 2.7')
        for name in ('gui.mods.mod_universal_dump146','gui.mods.mod_offhangar'):
            if name in sys.modules:raise RuntimeError('Remove conflicting mod: '+name)
        status('installing');install()
    except Exception:
        error=traceback.format_exc();fini()
        try:status('install_failed',traceback=error)
        except Exception:LOG_DEBUG(error)


def fini():
    global _STOPPED
    _STOPPED=True
    from . import match_queue,native_match
    match_queue.stop();native_match.fini()
    from . import process_bridge146
    process_bridge146.stop()
    try:
        import BigWorld
        for cid in _CALLBACKS:
            try:BigWorld.cancelCallback(cid)
            except Exception:pass
    finally:
        _CALLBACKS[:]=[];restore()
        if _HOSTS is not None and _ADDED_HOST is not None:
            try:_HOSTS._hosts.remove(_ADDED_HOST)
            except ValueError:pass
        from . import logging as local_logging
        local_logging.restore()
        LOG_DEBUG('fini: hooks restored; no forced process termination')
