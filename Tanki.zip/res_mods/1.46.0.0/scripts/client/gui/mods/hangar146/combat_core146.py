# -*- coding: utf-8 -*-
"""Engine-independent combat state. Fixed simulation time; one authority.

0.9.22 physics/armour laws live in legacy0922, native calls in combat146.
This is the ordinary tracked/single-gun integration, not a blanket claim that
all old runtime subsystems have been ported.
"""
from __future__ import absolute_import
import math,random
from .legacy0922 import vehicle_physics as physics
STEP=1./60.
MAX_CATCHUP=12

def clamp(v,a,b):return max(a,min(b,v))
def angle(v):return (v+math.pi)%(2.*math.pi)-math.pi

def team_result(actors):
    alive=set(a.team for a in actors if a.health>0)
    if len(alive)>1:return None
    return next(iter(alive)) if alive else 0

class Magazine(object):
    def __init__(self,counts,selected,capacity,reload_time,interval):
        self.counts=dict((int(k),max(0,int(v))) for k,v in counts.items())
        self.selected=int(selected);self.next_shell=self.selected;self.capacity=max(1,int(capacity))
        self.reload_time=float(reload_time);self.interval=max(0.,float(interval))
        if not self.reload_time>0:raise ValueError('Reload time must be positive')
        self.loaded=min(self.capacity,self.counts.get(self.selected,0));self.ready_at=0.;self.pending=None
    def available(self):
        if self.counts.get(self.next_shell,0)>0:return self.next_shell
        if self.counts.get(self.selected,0)>0:return self.selected
        choices=[cd for cd in self.counts if self.counts[cd]>0]
        return max(choices,key=lambda cd:(self.counts[cd],-cd)) if choices else None
    def begin_reload(self,cd,now):
        self.selected=cd;self.next_shell=cd;self.pending=cd;self.loaded=0;self.ready_at=now+self.reload_time
    def update(self,now):
        if self.pending is not None and now+1e-9>=self.ready_at:
            self.pending=None;self.loaded=min(self.capacity,self.counts.get(self.selected,0));return True
        return False
    def can_fire(self,now):
        self.update(now)
        return self.pending is None and now+1e-9>=self.ready_at and self.loaded>0 and self.counts.get(self.selected,0)>0
    def fire(self,now):
        if not self.can_fire(now):return False
        self.counts[self.selected]-=1;self.loaded-=1
        if self.loaded>0:self.ready_at=now+self.interval
        else:
            cd=self.available()
            if cd is not None:self.begin_reload(cd,now)
            else:self.pending=None;self.next_shell=self.selected;self.ready_at=now;self.loaded=0
        return True
    def select(self,cd,now,immediate=True,prebattle=False):
        cd=int(cd)
        if self.counts.get(cd,0)<=0:return False
        self.next_shell=cd
        if prebattle:
            self.selected=cd;self.pending=None;self.ready_at=0.;self.loaded=min(self.capacity,self.counts[cd]);return True
        if not immediate:return True
        if cd==self.selected:return True
        self.begin_reload(cd,now);return True
    def reload(self,now):
        if self.pending is not None:return False
        cd=self.available()
        if cd is None:return False
        if cd==self.selected and self.loaded>=min(self.capacity,self.counts.get(cd,0)):return False
        self.begin_reload(cd,now);return True

class Actor(object):
    def __init__(self,vid,team,position,yaw,health,params,suspension,loadout,magazine):
        self.id=int(vid);self.team=int(team);self.position=tuple(map(float,position));self.yaw=float(yaw)
        self.health=int(health);self.max_health=self.health;self.params=params;self.suspension=suspension
        self.loadout=loadout;self.magazine=magazine;self.v=0.;self.omega=0.;self.flags=0
        self.body=dict(height=self.position[1],pitch=0.,roll=0.,vertical_velocity=0.,pitch_velocity=0.,roll_velocity=0.)
        self.gun_yaw=0.;self.gun_pitch=0.;self.aim_target=None;self.blocked=0.;self.avoid_until=0.;self.avoid_sign=1.
        self.target_id=None;self.hold=0.;self.think_at=0.;self.last_damage_by=None
        self.ground_plane=None;self.support_gradient=None
        self.spring_memory=None;self.pseudo_memory=None
        self.slide_speed=0.;self.air_lateral=(0.,0.);self.landing_speed=None
        self.previous_pose=self.snapshot()
    def snapshot(self):
        return (tuple(self.position),self.yaw,self.body['pitch'],self.body['roll'])
    def samples(self,ground,position,yaw,probe_height,dt,pseudo=False):
        """0.9.22 legal spring travel and distance-limited contact retention."""
        p=self.suspension;pitch=self.body['pitch'];roll=self.body['roll']
        points=(physics.suspension_pseudo_world_points if pseudo else physics.suspension_world_points)(p,position,yaw,pitch,roll)
        parts=p['pseudo_contacts'] if pseudo else p['springs']
        key='pseudo_memory' if pseudo else 'spring_memory'
        memory=getattr(self,key)
        if memory is None or len(memory)!=len(points):memory=[None]*len(points)
        drop=physics.suspension_vertical_sweep_drop(self.body.get('vertical_velocity',0.),dt)
        result=[];requests=[]
        for i,(x,z) in enumerate(points):
            part=parts[i];height=probe_height+physics.suspension_point_offset(part,pitch,roll)[1]
            minimum=height-(p['rest_length'] if pseudo else part['rest_length'])-physics.CONTACT_PENETRATION-drop
            if pseudo:
                track=part.get('kind')=='track'
                maximum=height+(p['clearance'] if track else 0.)+physics.CONTACT_PENETRATION
                flat=height+physics.CONTACT_PENETRATION if track else None
            else:
                flat=height+part['max_compression']-part['static_compression']+.05
                maximum=max(flat,height+p['clearance']+physics.CONTACT_PENETRATION)
            requests.append((x,z,minimum,maximum,flat))
        batch=getattr(self,'ground_batch',None)
        values=batch(self,requests,pseudo) if batch is not None else [ground(self,*row) for row in requests]
        for i,((x,z),value) in enumerate(zip(points,values)):
            value,memory[i]=physics.retained_ground_contact((x,z),value,memory[i],p['contact_memory_distance'],self.support_gradient)
            result.append(value)
        setattr(self,key,memory)
        return tuple(result)
    def continuous_rise(self,ground,old,position,solved,current):
        previous=self.ground_plane
        if not physics.suspension_ground_planes_continuous(previous,current,old,position,.35,.35):return False
        start=physics.suspension_plane_height(previous,old[0],old[2])
        end=physics.suspension_plane_height(current,position[0],position[2])
        if solved['height']-position[1]>.62+max(0.,end-start):return False
        dx=position[0]-old[0];dz=position[2]-old[2]
        for t in physics.suspension_path_probe_fractions(math.hypot(dx,dz)):
            expected=start+(end-start)*t
            value=ground(self,old[0]+dx*t,old[2]+dz*t,expected-.35,expected+.35,expected+.35)
            if value is None or abs(value-expected)>.35:return False
        return True
    def step(self,dt,ground,clear,bounds=None):
        if self.health<=0:self.v=0.;self.omega=0.;self.previous_pose=self.snapshot();self.landing_speed=None;return
        throttle=float(bool(self.flags&1))-float(bool(self.flags&2))
        steer=float(bool(self.flags&8))-float(bool(self.flags&4))
        old=self.position;old_yaw=self.yaw;old_body=dict(self.body);old_speed=self.v
        self.previous_pose=self.snapshot();self.landing_speed=None
        grounded=not self.body.get('airborne',False)
        drive_pitch=physics.suspension_drive_pitch(self.ground_plane,self.yaw)
        # Body rocking must not create a fictitious uphill/downhill force.
        self.v=physics.longitudinal_step(self.params,self.v,throttle,steer!=0,drive_pitch or 0.,dt,not grounded,handbrake=bool(self.flags&64))
        self.omega=physics.traverse_step(self.params,self.omega,steer,self.v,dt,drive_intent=throttle) if grounded else self.omega
        new_yaw=angle(self.yaw+self.omega*dt)
        candidate=(old[0]+math.sin(new_yaw)*self.v*dt,old[1],old[2]+math.cos(new_yaw)*self.v*dt)
        if (bounds is None or bounds(candidate)) and clear(self,candidate,new_yaw):
            self.position=candidate;self.yaw=new_yaw;self.blocked=0.
        else:
            straight=(old[0]+math.sin(old_yaw)*self.v*dt,old[1],old[2]+math.cos(old_yaw)*self.v*dt)
            if abs(self.v)>1e-6 and (bounds is None or bounds(straight)) and clear(self,straight,old_yaw):
                self.position=straight;self.omega=0.;self.blocked=0.
            elif abs(self.omega)>1e-6 and clear(self,old,new_yaw):
                self.yaw=new_yaw;self.v=0.;self.blocked=0.
            else:self.v=0.;self.omega=0.;self.blocked+=dt
        # Lateral slope slip and airborne carry, from the old spring path.
        plane=self.ground_plane
        if grounded and plane is not None:
            gx=plane['gradient_x'];gz=plane['gradient_z'];slope=math.hypot(gx,gz)
            self.slide_speed=physics.suspension_slope_slide_speed(self.slide_speed,slope,dt)
            cross=(math.cos(self.yaw),-math.sin(self.yaw))
            dot=(-gx*cross[0]-gz*cross[1])/slope if slope>1e-9 else 0.
            self.air_lateral=tuple(v*dot*self.slide_speed for v in cross)
        elif not grounded:self.slide_speed=0.
        lx,lz=self.air_lateral
        lateral=(self.position[0]+lx*dt,self.position[1],self.position[2]+lz*dt)
        if abs(lx)+abs(lz)>1e-5:
            if (bounds is None or bounds(lateral)) and clear(self,lateral,self.yaw):self.position=lateral
            else:self.air_lateral=(0.,0.);self.slide_speed=0.
        if not grounded:self.air_lateral=tuple(v*pow(.995,dt/(1./60.)) for v in self.air_lateral)
        probe=self.position[1]
        before=physics.suspension_plane_height(plane,old[0],old[2])
        after=physics.suspension_plane_height(plane,self.position[0],self.position[2])
        if before is not None and after is not None:probe+=after-before
        heights=self.samples(ground,self.position,self.yaw,probe,dt)
        pseudos=self.samples(ground,self.position,self.yaw,probe,dt,True)
        current=physics.suspension_world_ground_plane(self.suspension,heights,self.position,self.yaw,.35,self.body['pitch'],self.body['roll'])
        vx=(self.position[0]-old[0])/dt;vz=(self.position[2]-old[2])/dt
        support=physics.suspension_support_vertical_velocity(current,vx,vz)
        if current is not None:self.support_gradient=(current['gradient_x'],current['gradient_z'])
        elif grounded and self.support_gradient is not None:support=self.support_gradient[0]*vx+self.support_gradient[1]*vz
        # Smooth bounded contact-force acceleration; a hull stop is not an
        # infinite rigid-body impulse. The CoM height is an explicit estimate.
        ax=clamp((self.v-old_speed)/max(dt,1e-6),-8.,8.) if grounded else 0.
        az=clamp(self.v*self.omega,-6.,6.) if grounded else 0.
        rate=1.-math.exp(-dt/.08)
        self.drive_acceleration=getattr(self,'drive_acceleration',0.)+(ax-getattr(self,'drive_acceleration',0.))*rate
        self.lateral_acceleration=getattr(self,'lateral_acceleration',0.)+(az-getattr(self,'lateral_acceleration',0.))*rate
        state=dict(self.body);state['height']=self.position[1]
        state['drive_acceleration']=self.drive_acceleration;state['lateral_acceleration']=self.lateral_acceleration
        solver=getattr(self,'external_solver',None)
        solved=solver(self,state,heights,dt,pseudos,support or 0.) if solver is not None else physics.damper_suspension_step(self.suspension,state,heights,dt,pseudos,support or 0.)
        values=[solved[k] for k in ('height','vertical_velocity','pitch','pitch_velocity','roll','roll_velocity')]
        if any(math.isnan(v) or math.isinf(v) for v in values):raise RuntimeError('Non-finite spring pose')
        invalid=(abs(solved['height']-self.position[1])>5. or abs(solved['pitch']-self.body['pitch'])>1.2 or abs(solved['roll']-self.body['roll'])>1.2)
        raised=(solved.get('contact_count',0)>0 and solved['height']-self.position[1]>.6 and not self.continuous_rise(ground,old,self.position,solved,current))
        if invalid or raised:
            self.solver_generation=getattr(self,'solver_generation',0)+1
            self.position=old;self.yaw=old_yaw;self.body=old_body
            for key in ('vertical_velocity','pitch_velocity','roll_velocity'):self.body[key]=0.
            self.spring_memory=None;self.pseudo_memory=None;self.support_gradient=None
            self.v=0.;self.omega=0.;self.blocked+=dt
            return
        self.body=solved;self.position=(self.position[0],solved['height'],self.position[2]);self.ground_plane=current
        if solved['airborne']:
            self.support_gradient=None;self.spring_memory=None;self.pseudo_memory=None
        elif not grounded:
            impact=solved.get('impact_speed')
            if impact is None:impact=old_body.get('vertical_velocity',0.)
            self.landing_speed=physics.landing_impact_speed((vx,impact,vz),current.get('normal') if current else None)
            self.slide_speed=max(self.slide_speed,math.hypot(*self.air_lateral));self.air_lateral=(0.,0.)


class Round(object):
    def __init__(self,actors,duration=900.):
        self.actors=dict((a.id,a) for a in actors);self.now=0.;self.duration=float(duration)
        self.result=None;self.reason=None;self.pending=None;self.capture_winner=None;self.last_kill=None;self.bases=[];self.shots=[];self.next_shot=1;self.accumulator=0.;self.dropped_time=0.
    def finish(self,winner,reason):
        if self.result is not None:return False
        self.result=int(winner);self.reason=reason
        for a in self.actors.values():a.flags=0;a.v=0.;a.omega=0.
        return True
    def damage(self,victim,attacker,amount):
        a=self.actors[victim]
        if self.result is not None or a.health<=0:return 0
        taken=min(a.health,max(0,int(amount)));a.health-=taken;a.last_damage_by=attacker
        if taken:
            for base in self.bases:
                if not base['captured']:base['credits'].pop(a.id,None)
        if taken and a.health<=0:
            self.last_kill=self.now
            if self.pending is not None:self.pending['deadline']=self.now+5.
        return taken
    def configure_bases(self,positions,radius=50.):
        self.bases=[dict(team=int(team),id=int(base_id),position=tuple(pos),radius=float(radius),credits={},points=0.,invaders=0,stopped=False,captured=False,notified=None) for team,base_id,pos in positions]
    def capture_step(self,dt):
        for base in self.bases:
            if base['captured']:continue
            x,z=base['position'];inside=[a for a in self.actors.values() if a.health>0 and (a.position[0]-x)**2+(a.position[2]-z)**2<=base['radius']**2]
            attackers=[a for a in inside if a.team!=base['team']]
            active=set(a.id for a in attackers)
            base['credits']=dict((k,v) for k,v in base['credits'].items() if k in active)
            base['invaders']=len(attackers);base['stopped']=any(a.team==base['team'] for a in inside)
            if attackers and not base['stopped']:
                rate=float(min(3,len(attackers)))/len(attackers)
                for a in attackers:base['credits'][a.id]=base['credits'].get(a.id,0.)+dt*rate
            base['points']=min(100.,sum(base['credits'].values()))
            if base['points']+1e-8>=100.:
                base['captured']=True
                team=attackers[0].team
                self.capture_winner=team if self.capture_winner in (None,team) else 0
    def check(self):
        if self.result is not None:return self.result
        winner=team_result(self.actors.values())
        reason='annihilation'
        if winner is None and self.capture_winner is not None:winner=self.capture_winner;reason='capture'
        if winner is None and self.now+1e-8>=self.duration:winner=0;reason='timeout'
        if winner is None:
            self.pending=None
            return self.result
        if self.pending is None:
            self.pending=dict(winner=int(winner),reason=reason,deadline=self.now+5.)
        else:
            # A simultaneous kill can change victory into a draw during grace.
            self.pending.update(winner=int(winner),reason=reason)
        if self.now+1e-8>=self.pending['deadline']:
            self.finish(self.pending['winner'],self.pending['reason'])
        return self.result
    def advance(self,elapsed,step):
        if self.result is not None:return 0
        elapsed=max(0.,float(elapsed))
        accepted=min(elapsed,STEP*MAX_CATCHUP);self.dropped_time+=elapsed-accepted
        self.now+=elapsed-accepted
        self.accumulator+=accepted;n=0
        while self.accumulator+1e-9>=STEP and n<MAX_CATCHUP and self.result is None:
            self.accumulator-=STEP;self.now+=STEP;step(STEP);self.check();n+=1
        return n
