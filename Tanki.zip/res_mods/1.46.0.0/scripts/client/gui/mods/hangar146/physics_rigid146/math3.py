# -*- coding: utf-8 -*-
"""Small engine-independent SI vector/quaternion kernel; YPR = Ry Rx Rz."""
import math
ZERO=(0.,0.,0.)
def add(a,b):return (a[0]+b[0],a[1]+b[1],a[2]+b[2])
def sub(a,b):return (a[0]-b[0],a[1]-b[1],a[2]-b[2])
def mul(a,s):return (a[0]*s,a[1]*s,a[2]*s)
def dot(a,b):return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def length(a):return math.sqrt(dot(a,a))
def unit(a,fallback=(0.,1.,0.)):
 n=length(a);return mul(a,1./n) if n>1e-10 else fallback
def clamp(x,a,b):return max(a,min(b,x))
def qmul(a,b):
 w,x,y,z=a;v,i,j,k=b
 return (w*v-x*i-y*j-z*k,w*i+x*v+y*k-z*j,w*j-x*k+y*v+z*i,w*k+x*j-y*i+z*v)
def conjugate(q):return(q[0],-q[1],-q[2],-q[3])
def normalize(q):
 n=math.sqrt(sum(x*x for x in q));return tuple(x/n for x in q) if n>1e-12 else (1.,0.,0.,0.)
def rotate(q,v):
 t=mul(cross(q[1:],v),2.);return add(v,add(mul(t,q[0]),cross(q[1:],t)))
def quat(y,p,r):
 return qmul(qmul((math.cos(y/2.),0.,math.sin(y/2.),0.),(math.cos(p/2.),math.sin(p/2.),0.,0.)),(math.cos(r/2.),0.,0.,math.sin(r/2.)))
def euler(q):
 x=rotate(q,(1.,0.,0.));y=rotate(q,(0.,1.,0.));z=rotate(q,(0.,0.,1.))
 if abs(z[1])>1.-1e-10:return (math.atan2(-x[2],x[0]),math.copysign(math.pi*.5,-z[1]),0.)
 return (math.atan2(z[0],z[2]),math.asin(clamp(-z[1],-1.,1.)),math.atan2(x[1],y[1]))
def advance(q,w,dt):
 # World-space angular velocity left-multiplies orientation. No Euler clamps.
 n=length(w)
 if n<1e-12:return q
 a=n*dt*.5;s=math.sin(a)/n
 return normalize(qmul((math.cos(a),w[0]*s,w[1]*s,w[2]*s),q))
def slerp(a,b,t):
 d=sum(x*y for x,y in zip(a,b))
 if d<0.:b=tuple(-v for v in b);d=-d
 if d>.9995:return normalize(tuple(x+(y-x)*t for x,y in zip(a,b)))
 angle=math.acos(clamp(d,-1.,1.));s=math.sin(angle)
 return tuple((x*math.sin((1.-t)*angle)+y*math.sin(t*angle))/s for x,y in zip(a,b))
