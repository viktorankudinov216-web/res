# -*- coding: utf-8 -*-
"""Native 1.46 loadout snapshot, frozen BEFORE Account retirement.

No changes to shared gun/chassis cache objects. UI and authority consume the
same computed seconds; no hard-coded correction for the user's 8.44 example.
"""
from __future__ import absolute_import
import base64,copy,hashlib,json,math

def positive(value,label,zero=False):
    value=float(value)
    if math.isnan(value) or math.isinf(value) or value<0 or (not zero and value==0):
        raise ValueError('Invalid battle loadout '+label)
    return value

def finite_tree(value):
    if isinstance(value,dict):return dict((k,finite_tree(v)) for k,v in value.items())
    if isinstance(value,(tuple,list)):return [finite_tree(v) for v in value]
    if isinstance(value,float) and (math.isnan(value) or math.isinf(value)):return None
    return value

def supported(descr):
    from .legacy0922.vehicle_physics import suspension_trial_excluded
    from items.components import component_constants
    return not (descr.isDualgunVehicle or getattr(descr,'isAutoShootGunVehicle',False) or
        getattr(descr,'isAutoReloadGun',False) or suspension_trial_excluded(descr) or
        getattr(descr.type,'isWheeledVehicle',False) or
        getattr(descr.gun,'burst',component_constants.DEFAULT_GUN_BURST)!=component_constants.DEFAULT_GUN_BURST)

def compact_hash(raw):return hashlib.sha256(raw).hexdigest()

def projection(descr,factors,source):
    from items import utils
    from battle_modifiers_common import BattleParams
    reload_time=descr.battleModifiers(BattleParams.RELOAD_TIME,utils.getReloadTime(descr,factors))
    clip=int(descr.gun.clip[0]);interval=float(utils.getClipTimeBetweenShots(descr,factors)) if clip>1 else 0.
    result=dict(source=source,compact_sha256=compact_hash(descr.makeCompactDescr()),
        factors=json.loads(json.dumps(finite_tree(dict(factors)),allow_nan=False)),
        reload_seconds=positive(reload_time,'reload seconds'),
        clip_size=max(1,clip),clip_interval=positive(interval,'clip interval',True),
        base_reload_seconds=positive(descr.gun.reloadTime,'base reload'),
        max_health=int(descr.maxHealth))
    if descr.isDualgunVehicle or getattr(descr,'isAutoShootGunVehicle',False) or getattr(descr,'isAutoReloadGun',False):
        raise ValueError('M07.03 does not yet support dualgun/autoreload/autoshoot authority')
    return result

def capture_player(vehicle,rec,inv_id):
    if vehicle is None:raise ValueError('No current garage vehicle')
    if not supported(vehicle.descriptor):raise ValueError('M07.03 supports ordinary tracked single-gun vehicles only')
    from gui.shared.items_parameters import functions
    from gui.shared.items_parameters.params import VehicleParams
    if vehicle is None or int(vehicle.invID)!=int(inv_id):
        raise ValueError('Current garage vehicle differs from queued vehicle')
    descr=vehicle.descriptor
    if descr.makeCompactDescr()!=base64.b64decode(rec['compactDescr_b64']):
        raise ValueError('Garage and queued compact descriptors differ')
    result=projection(descr,functions.getVehicleFactors(vehicle),'native146_garage_factors')
    params=VehicleParams(vehicle)
    seconds=params.reloadTimeSecs
    # Regular guns: exact displayed native parameter, including battle modifiers.
    if seconds is not None and int(descr.gun.clip[0])==1:
        expected=positive(seconds[0],'garage reload')
        if abs(result['reload_seconds']-expected)>.005:
            raise ValueError('Native reload projections disagree: %r != %r'%(result['reload_seconds'],expected))
        result['garage_reload_seconds']=expected
    result['aiming_seconds']=positive(params.aimingTime[0],'aiming time')
    result['dispersion_angle']=positive(params.shotDispersionAngle[0]/100.,'dispersion')
    result['speed_limits_mps']=[positive(x/3.6,'speed limit') for x in params.speedLimits]
    result['engine_power_w']=positive(params.enginePower*__import__('items.components.component_constants',fromlist=['HP_TO_WATTS']).HP_TO_WATTS,'engine power')
    result['inv_id']=int(inv_id)
    return result

def for_record(rec,descr):
    cached=rec.get('battle_loadout')
    if cached is not None:
        if cached['compact_sha256']!=compact_hash(descr.makeCompactDescr()):
            raise ValueError('Battle descriptor differs from frozen garage loadout')
        return copy.deepcopy(cached)
    from items import utils,vehicles
    factors=utils.makeDefaultVehicleAttributeFactors()
    crew=tuple(base64.b64decode(x) for x in rec.get('crew',[]) if x)
    if not crew:crew=utils.generateDefaultCrew(descr.type,100)
    eqs=[vehicles.getItemByCompactDescr(abs(int(cd))) for cd in rec.get('eqs',[])+rec.get('boosters',[]) if cd]
    utils.updateAttrFactorsWithSplit(descr,crew,eqs,factors)
    result=projection(descr,factors,'native146_generated_crew')
    result['aiming_seconds']=positive(utils.getGunAimingTime(descr,factors),'bot aiming')
    result['dispersion_angle']=positive(next(iter(utils.getClientShotDispersion(descr,factors['shotDispersion'][0]))),'bot dispersion')
    return result
