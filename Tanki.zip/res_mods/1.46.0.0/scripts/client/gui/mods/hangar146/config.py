from __future__ import absolute_import
import json,os
from .runtime_data import game_root
AUTO_LOGIN=True
VERBOSE_LOGGING=False
ENABLE_WORLD=True
PHYSICS_MODEL="rigid_v1"
BOTS_ACTIVE=False
RIGID_VISUAL_SOURCE="native"
_options={}
path=os.path.join(game_root(),'mods','configs','hangar146','config.json')
if os.path.isfile(path):
    with open(path,'rb') as f:_options=json.load(f)
    AUTO_LOGIN=bool(_options.get('auto_login',True))
    VERBOSE_LOGGING=bool(_options.get('verbose_logging',False))
    ENABLE_WORLD=bool(_options.get('enable_world',True))

# Defaults are safe for existing profiles. Add only missing selector keys.
PHYSICS_MODEL=str(_options.get('physics_model','rigid_v1'))
if PHYSICS_MODEL not in ('rigid_v1','legacy0922'):
    raise ValueError('physics_model must be rigid_v1 or legacy0922')
BOTS_ACTIVE=bool(_options.get('bots_active',False))
RIGID_VISUAL_SOURCE=str(_options.get('rigid_visual_source','native'))
if RIGID_VISUAL_SOURCE not in ('native','scene_m11'):raise ValueError('rigid_visual_source must be native or scene_m11')
if any(k not in _options for k in ('physics_model','bots_active','rigid_visual_source')):
    _options.setdefault('physics_model',PHYSICS_MODEL)
    _options.setdefault('bots_active',BOTS_ACTIVE)
    _options.setdefault('rigid_visual_source',RIGID_VISUAL_SOURCE)
    try:
        folder=os.path.dirname(path)
        if not os.path.isdir(folder):os.makedirs(folder)
        temporary=path+'.m08.tmp'
        with open(temporary,'wb') as f:f.write(json.dumps(_options,indent=2,sort_keys=True).encode('utf-8'))
        # Windows rename cannot replace an existing target; copy content only
        # after the full serialization succeeded. Never touch account state.
        with open(path,'wb') as f:f.write(open(temporary,'rb').read())
        os.remove(temporary)
    except (IOError,OSError):pass
