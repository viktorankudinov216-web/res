# -*- coding: utf-8 -*-
"""Local crew operations using the client's own TankmanDescr XP/skill codec."""
from __future__ import absolute_import
import base64
from . import runtime_data as R
from .economy import Reject,number,row,descriptor,charge,stock

def locate(v,tid):
    from items import tankmen
    try:tid=number(tid,1,0x7fffffff)
    except Reject:raise Reject('INVALID_TANKMAN_ID: '+repr(tid))
    if tid>=100100:
        vid=(tid-100000)//100;slot=(tid-100000)%100
        rec=v['vehicles'].get(str(vid))
        if rec and slot<len(rec.get('crew',[])) and rec['crew'][slot]:
            return tankmen.TankmanDescr(base64.b64decode(rec['crew'][slot])),rec,slot,None
    raw=v.get('barracks',{}).get(str(tid))
    if raw:return tankmen.TankmanDescr(base64.b64decode(raw)),None,None,str(tid)
    raise Reject('TANKMAN_NOT_OWNED')

def save(v,found):
    t,rec,slot,bid=found;raw=base64.b64encode(t.makeCompactDescr())
    if rec is not None:rec['crew'][slot]=raw
    else:v['barracks'][bid]=raw

def skill(v,tid,index,free=False):
    from items import tankmen
    found=locate(v,tid);t,rec,slot,unused=found
    try:index=number(index,0,len(tankmen.SKILL_NAMES)-1)
    except Reject:raise Reject('INVALID_SKILL_INDEX: '+repr(index))
    name=tankmen.SKILL_NAMES[index]
    roles=descriptor(rec).type.crewRoles[slot] if rec is not None else (t.role,)
    allowed=set()
    for role in roles:allowed.update(tankmen.SKILLS_BY_ROLES.get(role,()))
    if name not in allowed:raise Reject('SKILL_INCOMPATIBLE_WITH_CREW_ROLE')
    t.checkRestrictionsByVehicleTags()
    if free:
        valid,error,duplicate=t.validateLearningFreeSkill(name)
        if not valid:raise Reject('INVALID_FREE_SKILL: '+error)
        if duplicate:t.dropSkill(name,1.0)
        t.replaceFreeSkill('any',name)
    else:t.addSkill(name)
    save(v,found);return {}

def seed_books(v):
    from items import tankmen
    if v.get('crew_books_grant')=='m04_100000_each':return
    books=tankmen.g_cache.crewBooks().books
    if not books:raise Reject('CREW_BOOK_CATALOG_NOT_READY')
    for book in books.values():stock(v,book.compactDescr,100000)
    v['crew_books_grant']='m04_100000_each'

def protocol_group(gid,gsize):
    # QuickTrainingView uses serverTime(); offline native serverTime may be -1.
    try:number(gid,-1,0x7fffffffffffffff)
    except Reject:raise Reject('INVALID_CREW_GROUP_ID')
    try:number(gsize,1,10000)
    except Reject:raise Reject('INVALID_CREW_GROUP_SIZE')

def optional_id(value,field):
    # Native NO_TANKMAN / NO_VEHICLE_ID are -1. Preserve legacy 0 support.
    if isinstance(value,(int,long)) and not isinstance(value,bool) and value in (-1,0):return 0
    try:return number(value,1,0x7fffffff)
    except Reject:raise Reject('INVALID_'+field)

def learn_book(v,arr):
    from items import tankmen,parseIntCompactDescr
    if len(arr)!=6:raise Reject('INVALID_BOOK_ARGS')
    cd,count,vid,tid,gid,gsize=arr;count=number(count,1,100000)
    protocol_group(gid,gsize);vid=optional_id(vid,'BOOK_VEHICLE_ID');tid=optional_id(tid,'BOOK_TANKMAN_ID')
    cache=tankmen.g_cache.crewBooks();kind,subtype,bid=parseIntCompactDescr(cd)
    book=cache.books.get(bid)
    if kind!=14 or book is None or book.compactDescr!=cd:raise Reject('UNKNOWN_CREW_BOOK')
    if not cache.validateBookPersonality(bid,tid):raise Reject('BOOK_PERSONALITY_MISMATCH')
    if tid:
        targets=[locate(v,tid)]
        if vid and (targets[0][1] is None or targets[0][1] is not row(v,vid)):raise Reject('BOOK_VEHICLE_MISMATCH')
    else:
        rec=row(v,vid);d=descriptor(rec)
        if len(rec.get('crew',[]))!=len(d.type.crewRoles) or not all(rec['crew']):raise Reject('BOOK_REQUIRES_FULL_CREW')
        targets=[locate(v,100000+int(vid)*100+i) for i in range(len(rec['crew']))]
    xp=number(cache.getCrewBookExp(bid),1,4000000000)*count
    for found in targets:
        t,rec,slot,unused=found
        if not cache.validateCrewBookNation(bid,t.nationID):raise Reject('BOOK_WRONG_NATION')
        if not tid:
            d=descriptor(rec)
            if t.roleLevel!=100 or t.vehicleTypeID!=d.type.id[1]:raise Reject('BOOK_REQUIRES_TRAINED_SPECIALIZED_CREW')
        t.checkRestrictionsByVehicleTags()
        if t.freeXP+xp>4000000000:raise Reject('TANKMAN_XP_LIMIT')
    stock(v,cd,-count)
    for found in targets:found[0].addXP(xp);save(v,found)
    return [(cd,count)]

def command(v,name,args,arr):
    if name=='CMD_TRAINING_TMAN':
        if len(arr)!=5:raise Reject('INVALID_CREW_TRAINING_ARGS')
        rev,tid,amount,gid,gsize=arr;protocol_group(gid,gsize);amount=number(amount,1)
        found=locate(v,tid);t=found[0];t.checkRestrictionsByVehicleTags()
        rate=number(R.catalog()['shop']['freeXPToTManXPRate'],1,1000)
        if t.freeXP+amount*rate>4000000000:raise Reject('TANKMAN_XP_LIMIT')
        charge(v,{'freeXP':amount});t.addXP(amount*rate);save(v,found)
        return [('freeXP',amount)]
    if name=='CMD_TMAN_ADD_SKILL':
        if len(arr)!=3 or arr[2]!=0:raise Reject('INVALID_SKILL_ARGS')
        return skill(v,arr[0],arr[1])
    if name=='CMD_LEARN_TMAN_FREE_SKILL':
        if len(arr)!=2:raise Reject('INVALID_FREE_SKILL_ARGS')
        return skill(v,arr[0],arr[1],True)
    if name=='CMD_LEARN_CREW_BOOK':return learn_book(v,arr)
    if name=='CMD_TMAN_DROP_SKILLS':
        if len(arr)!=4:raise Reject('INVALID_DROP_SKILLS_ARGS')
        rev,tid,idx,form=arr
        if form:raise Reject('RECERTIFICATION_FORM_NOT_IMPLEMENTED')
        found=locate(v,tid);t=found[0];t.checkRestrictionsByVehicleTags()
        price=R.catalog()['shop']['dropSkillsCost'].get(number(idx,0,2))
        if not price:raise Reject('UNKNOWN_DROP_SKILLS_PRICE')
        if not t.isFreeDropSkills():charge(v,dict((k,price.get(k,0)) for k in ('credits','gold')))
        t.dropSkills(price['xpReuseFraction']);save(v,found);return {}
    raise Reject('UNKNOWN_CREW_COMMAND')

SUPPORTED=('CMD_TRAINING_TMAN','CMD_TMAN_ADD_SKILL','CMD_LEARN_TMAN_FREE_SKILL','CMD_LEARN_CREW_BOOK','CMD_TMAN_DROP_SKILLS')
