# -*- coding: utf-8 -*-
"""Select actual roadwheel bones in compound-model coordinates, NOT filter space.
The offline native filter and the rendered compound can have different roots.
"""
from .math3 import *

def collect(descriptor,vehicle,suspension):
 import Math
 model=vehicle.appearance.compoundModel
 inverse=Math.Matrix(model.matrix);inverse.invert()
 config=descriptor.chassis.wheels;names={};order=[]
 for group in config.groups:
  for i in range(group.startIndex,group.startIndex+group.count):
   name='%s%d'%(group.template,i);names[name]=(bool(group.isLeft),float(group.radius),False);order.append(name)
 for wheel in config.wheels:
  name=wheel.nodeName;names[name]=(bool(wheel.isLeft),float(wheel.radius),bool(wheel.isLeading));order.append(name)
 # Ground-node affected wheels identify suspension carriers, not upper return
 # rollers or decorative leading sprockets. Use that mapping where present.
 carriers=[];ground=getattr(descriptor.chassis,'groundNodes',None)
 for group in getattr(ground,'groups',()):
  template=group.affectedWheelsTemplate
  if template:
   carriers.extend('%s%d'%(template,i) for i in range(group.startIndex,group.startIndex+group.nodesCount))
 for node in getattr(ground,'nodes',()):
  if node.affectedWheelName:carriers.append(node.affectedWheelName)
 selected=[name for name in carriers if name in names]
 if not selected:selected=[name for name in order if not names[name][2]]
 rows=[];rejected=[];seen=set()
 for name in selected:
  if name in seen:continue
  seen.add(name);left,radius,leading=names[name]
  if leading:
   rejected.append(dict(name=name,reason='leading sprocket is not suspension carrier'));continue
  try:
   provider=model.node(name)
   if provider is None:raise ValueError('node not found')
   local=tuple(float(v) for v in inverse.applyPoint(Math.Matrix(provider).translation))
   if any(math.isnan(v) or math.isinf(v) for v in local):raise ValueError('nonfinite node')
   if not .04<radius<2.5:raise ValueError('invalid radius')
   if abs(local[0])>suspension['width']*.9 or abs(local[2])>suspension['length']*.8:raise ValueError('outside chassis envelope')
   # Upper return rollers must not become springs. Actual low roadwheel nodes
   # have a lower rim close to chassis ground level (typically y ~= radius).
   if local[1]-radius>suspension['clearance']+.35:raise ValueError('upper roller')
   rows.append((local[0],local[2],radius,local[1],'left' if left else 'right',name))
  except Exception as error:rejected.append(dict(name=name,reason=str(error)))
 # Ground-node mappings can also name upper return rollers (e.g. WD_*).
 # Do not give those long fictitious struts that reach all the way to terrain.
 if rows:
  radii=sorted(row[2] for row in rows);tolerance=max(.18,min(.30,radii[len(radii)//2]*.7))
  floors={}
  for side in ('left','right'):
   rims=sorted(row[3]-row[2] for row in rows if row[4]==side)
   if rims:floors[side]=rims[min(len(rims)-1,len(rims)//5)]
  kept=[]
  for row in rows:
   if row[3]-row[2]>floors[row[4]]+tolerance:rejected.append(dict(name=row[-1],reason='return roller above carrying plane'))
   else:kept.append(row)
  rows=kept
 ground_reference={}
 ground_names=[]
 for group in getattr(ground,'groups',()):
  template=getattr(group,'nodesTemplate',None)
  if template:ground_names.extend('%s%d'%(template,i) for i in range(group.startIndex,group.startIndex+group.nodesCount))
 ground_names.extend(node.nodeName for node in getattr(ground,'nodes',()) if getattr(node,'nodeName',None))
 for name in ground_names:
  try:
   node=model.node(name)
   if node is not None:ground_reference[name]=tuple(float(v) for v in inverse.applyPoint(Math.Matrix(node).translation))
  except (ValueError,TypeError,AttributeError):pass
 valid=4<=len(rows)<=40 and any(r[4]=='left' for r in rows) and any(r[4]=='right' for r in rows)
 details=dict(ground_reference=ground_reference,candidate_count=len(names),selected_count=len(seen),accepted_count=len(rows),rejected=rejected[:12],model_root=tuple(Math.Matrix(model.matrix).translation),carriers=[dict(name=r[5],x=r[0],z=r[1],radius=r[2],center_y=r[3],side=r[4]) for r in rows])
 return rows if valid else [],details
