# -*- coding: utf-8 -*-
"""Pinned #2304 TankWheelsAnimator input, recovered from Tanki.exe.

setMovementInfo accepts a Vector4Provider. Native tick 0x14253ee80 reads
components Y/Z, multiplies by inverse radius, and adds to wheel angle WITHOUT
multiplying by dt. Therefore Y/Z are left/right surface DISTANCE per frame.
The native filter provider reads +0x500/+0x504/+0x508/+0x50c; setTracksSpeed
only writes +0x520/+0x524 and needs filter output to derive those distances.
No memory writes/hooks and no nonexistent getWheelsSpeed on TankWheelsAnimator.
"""
import time,math

def frame_value(left,right,dt):
 dt=max(0.,min(.15,float(dt)))
 return ((left+right)*.5*dt,left*dt,right*dt,0.)

def write_provider(actor,values):
 import Math
 provider=actor._rigid_wheel_provider
 vector=Math.Vector4(*values)
 provider.keyframes=[(0.,vector),(1.,vector)]
 provider.duration=1.;provider.time=0.
 actor._rigid_wheel_value=values

def bind(vehicle,actor,mark):
 if actor.health<=0:return
 import Math
 app=vehicle.appearance;anim=getattr(app,'wheelsAnimator',None)
 if anim is None:raise RuntimeError('No TankWheelsAnimator on live tracked model')
 if vehicle.typeDescriptor.type.isWheeledVehicle:
  mark('rigid_wheels_binding',vehicle_id=actor.id,ready=False,reason='general_wheels_not_supported');return
 provider=Math.Vector4Animation()
 actor._rigid_wheel_provider=provider;actor._rigid_wheel_last_frame=None
 write_provider(actor,(0.,0.,0.,0.))
 anim.setMovementInfo(provider)
 # Signature bool,bool and separate left/right stop bits verified at
 # Py 0x1407aa100 -> 0x14253eaa0. This is not a speculative method call.
 anim.stopAnimatingWheels(False,False)
 tracks=getattr(app,'tracks',None)
 if tracks is not None and anim.scrollLinksRequired:
  tracks.collectConnectedWheels(anim);tracks.sendWheelScrollLinks(anim)
 nodes=getattr(app,'trackNodesAnimator',None)
 if nodes is not None:nodes.setWheelsDataProvider(anim)
 swing=getattr(app,'swingingAnimator',None)
 if swing is not None:
  swing.accelSwingingPeriod=0.
  # Disabling only the acceleration period did NOT detach native pitch/roll.
  try:
   basis=Math.Matrix(swing.basisMatrix);actor._rigid_hull_basis=basis
   from vehicle_systems.tankStructure import TankPartNames
   node=app.compoundModel.node(TankPartNames.HULL,basis)
   if node is None:raise RuntimeError('Hull node unavailable for swinging detachment')
   actor._rigid_hull_detached=True
  except Exception:actor._rigid_hull_detached=False
 suspension=getattr(app,'suspension',None)
 if suspension is not None:
  suspension.reattachCompound(app.compoundModel)
  collector=getattr(app,'collisionObstaclesCollector',None)
  if collector is not None:suspension.setCollisionObstaclesCollector(collector)
  suspension.stopAnimating(False,False)
  suspension.forceCorrectionRecalculation()
 sensor=getattr(app,'tessellationCollisionSensor',None)
 if sensor is not None:sensor.reattachCompound(app.compoundModel)
 actor._rigid_wheel_report_at=0.;actor._rigid_wheel_total=[0.,0.]
 mark('rigid_wheels_binding',vehicle_id=actor.id,ready=True,animator='TankWheelsAnimator',input_contract='Vector4Provider_YZ_distance_per_render_frame',external_provider=True,native_stop_mask_cleared=True,spline_track_nodes=nodes is not None)

def drive(vehicle,actor,now,enabled=True):
 if not hasattr(actor,'_rigid_wheel_provider'):return
 previous=getattr(actor,'_rigid_wheel_last_frame',None)
 if previous is not None and now<=previous:return
 actor._rigid_wheel_last_frame=now
 if actor.health>0:
  app=vehicle.appearance
  # Stock activation can rebind animatedMProv after our first setup. Keep
  # hull decoration detached; only the rigid body's root carries pitch/roll.
  basis=getattr(actor,'_rigid_hull_basis',None)
  if basis is not None:
   from vehicle_systems.tankStructure import TankPartNames
   app.compoundModel.node(TankPartNames.HULL,basis)
  app.wheelsAnimator.stopAnimatingWheels(False,False)
  suspension=getattr(app,'suspension',None)
  if suspension is not None:
   suspension.stopAnimating(False,False)
 dt=0. if previous is None else max(0.,now-previous)
 left,right=actor.track_speeds if enabled and actor.health>0 else (0.,0.)
 values=frame_value(left,right,dt);write_provider(actor,values)
 if actor.health>0:
  from . import wheel_scene,native_tracks
  native_tracks.tick(vehicle,actor)
  wheel_scene.update(actor,values)
 total=actor._rigid_wheel_total;total[0]+=values[1];total[1]+=values[2]

def observe(vehicle,actor,mark):
 now=time.time()
 if now<getattr(actor,'_rigid_wheel_report_at',0.):return
 actor._rigid_wheel_report_at=now+20.
 provider=getattr(actor,'_rigid_wheel_provider',None)
 # Read back our bound native Vector4Provider, not a method belonging to
 # GeneralWheelsAnimator. Bone bases provide actual model-side diagnostics.
 values=None;reason=None;bones=[]
 try:
  import Math
  if provider is not None:values=tuple(float(v) for v in provider.value)
  model=vehicle.appearance.compoundModel;inverse=Math.Matrix(model.matrix);inverse.invert()
  observed=list(actor.rigid.wheels)
  observed_names=set(w.name for w in observed)
  observed.extend(row['wheel'] for row in getattr(actor,'_wheel_scene',()) if row['is_wheel'] and row['name'] not in observed_names)
  for wheel in observed:
   if not wheel.name:continue
   node=model.node(wheel.name)
   if node is None:continue
   axis=inverse.applyVector(Math.Matrix(node).applyToAxis(1))
   center=inverse.applyPoint(Math.Matrix(node).translation)
   carrier=hasattr(wheel,'compression')
   bones.append(dict(carrier=carrier,name=wheel.name,basis_y=tuple(axis),angle=math.atan2(axis.z,axis.y),actual_local_center=tuple(center),observed_y_offset=float(center[1])-getattr(wheel,'reference_y',float(center[1])),computed_stroke_offset=(wheel.compression-wheel.mass*9.81/wheel.k) if carrier else 0.,reference_center_y=getattr(wheel,'reference_y',None),physical_compression=getattr(wheel,'compression',None),physical_load=getattr(wheel,'load',None),spring_travel=getattr(wheel,'travel',None)))

 except Exception as error:reason=str(error)
 mark('rigid_wheels_readback',visual_source=getattr(actor,'rigid_visual_source','scene_m11'),native_chain_ready=getattr(actor,'_rigid_native_visual',False),native_chain_error=getattr(actor,'_native_chain_error',None),native_ground_nodes=getattr(actor,'_native_ground_nodes',0),scene_nodes=len(getattr(actor,'_wheel_scene',())),scene_expected=getattr(actor,'_wheel_scene_expected',None),scene_missing=getattr(actor,'_wheel_scene_missing',None),roadwheel_owner='rigid_strut_scene_provider',scene_error=getattr(actor,'_wheel_scene_error',None),hull_swing_detached=getattr(actor,'_rigid_hull_detached',False),vehicle_id=actor.id,expected_tracks=actor.track_speeds,external_movement_value=values,accumulated_path=getattr(actor,'_rigid_wheel_total',None),wheel_bones=bones,unavailable_reason=reason)
