# -*- coding: utf-8 -*-
"""Two native setup groups, with per-vehicle shared item reservations.
Inactive layouts are not depot inventory. A copy reused in both layouts is owned
once (maximum per-item demand), not bought again on each switch.
"""
from __future__ import absolute_import
import base64,copy
from collections import Counter
from .economy import Reject,number,descriptor,stock,native_allowed
FEATURES={1:'shells_consumables_switch',2:'opt_dev_boosters_switch'}
FIELDS={1:('shells','eqs'),2:('devices','boosters')}

def capacity(rec,group):
    from items import vehicles
    from .progression import state
    group=number(group,1,2);cache=vehicles.g_cache.postProgression()
    return 2 if any(cache.features.get(fid) is not None and cache.features[fid].name==FEATURES[group] for fid in state(rec).features) else 1

def shellkey(d):return '%d:%d'%(d.turret.compactDescr,d.gun.compactDescr)
def devices(d):return [dev.compactDescr if dev else 0 for dev in d.optionalDevices]

def sync(rec):
    """Capture active edits, preserving every inactive setup and old gun layout."""
    if 'loadouts' not in rec and max(capacity(rec,1),capacity(rec,2))==1:return
    d=descriptor(rec)
    saved=rec.setdefault('loadouts',{'indexes':{'1':0,'2':0},'shells':{},'eqs':[],'boosters':[],'devices':[]})
    for group,fields in FIELDS.items():
        idx=number(saved['indexes'].get(str(group),0),0,capacity(rec,group)-1)
        saved['indexes'][str(group)]=idx
        for field in fields:
            arrays=saved['shells'].setdefault(shellkey(d),[]) if field=='shells' else saved[field]
            while len(arrays)<capacity(rec,group):arrays.append([])
            arrays[idx]=copy.deepcopy(devices(d) if field=='devices' else rec.get(field+'Layout',rec.get(field,[])))

def active_counts(rec):
    from .economy import pairs
    result=Counter()
    for cd,n in pairs(rec.get('shells',[])):
        if cd:result[abs(cd)]+=n
    for field in ('eqs','boosters'):result.update(abs(cd) for cd in rec.get(field,[]) if cd)
    result.update(cd for cd in devices(descriptor(rec)) if cd)
    return result

def pooled(rec):
    from .economy import pairs
    saved=rec.get('loadouts')
    if not saved:return active_counts(rec)
    result=Counter()
    for field in ('shells','eqs','boosters','devices'):
        maximum=Counter()
        arrays=[a for group in saved['shells'].values() for a in group] if field=='shells' else saved[field]
        for values in arrays:
            count=Counter(dict((abs(cd),n) for cd,n in pairs(values) if cd)) if field=='shells' else Counter(abs(cd) for cd in values if cd)
            maximum |= count
        result.update(maximum)
    return result

def held_elsewhere(rec,cd):
    saved=rec.get('loadouts')
    if not saved:return False
    idx=saved['indexes']['2']
    return any(cd in arr for i,arr in enumerate(saved['devices']) if i!=idx)

def begin(v,rec):
    sync(rec)
    if 'loadouts' not in rec:return False
    active=active_counts(rec)
    for cd,n in (pooled(rec)-active).items():stock(v,cd,n)
    return True

def finish(v,rec):
    sync(rec)
    # Chassis/module changes must not leave a hidden incompatible device setup.
    for values in rec['loadouts']['devices']:
        apply_devices(copy.deepcopy(rec),values)
    active=active_counts(rec)
    for cd,n in (pooled(rec)-active).items():stock(v,cd,-n)

def apply_devices(rec,values):
    d=descriptor(rec);values=list(values)+[0]*(len(d.optionalDevices)-len(values))
    if len(values)!=len(d.optionalDevices):raise Reject('INVALID_DEVICE_SEQUENCE_CAPACITY')
    if len([cd for cd in values if cd])!=len(set(cd for cd in values if cd)):raise Reject('DUPLICATE_DEVICE')
    for i,dev in enumerate(list(d.optionalDevices)):
        if dev:d.removeOptionalDevice(i)
    for i,cd in enumerate(values):
        if cd:native_allowed(d.mayInstallOptionalDevice(cd,i));d.installOptionalDevice(cd,i)
    rec['compactDescr_b64']=base64.b64encode(d.makeCompactDescr())

def switch(v,rec,group,index):
    from .economy import fit_shells,fit_equipment,ensure
    from items import EQUIPMENT_TYPES
    group=number(group,1,2);index=number(index,0,1)
    if capacity(rec,group)<2:raise Reject('SETUP_FEATURE_NOT_UNLOCKED')
    sync(rec);saved=rec['loadouts'];oldidx=saved['indexes'][str(group)]
    if oldidx==index:return
    if group==1:
        targets=copy.deepcopy(saved['shells'][shellkey(descriptor(rec))][index]);eqs=copy.deepcopy(saved['eqs'][index])
        fit_shells(v,_vid(v,rec),targets,False);fit_equipment(v,_vid(v,rec),eqs,EQUIPMENT_TYPES.regular,False)
    else:
        target=copy.deepcopy(saved['devices'][index]);before=devices(descriptor(rec))
        apply_devices(rec,target)
        for cd in before:
            if cd:stock(v,cd,1)
        for cd in target:
            if cd:ensure(v,cd,1,False)
        fit_equipment(v,_vid(v,rec),copy.deepcopy(saved['boosters'][index]),EQUIPMENT_TYPES.battleBoosters,False)
    saved['indexes'][str(group)]=index

def _vid(v,rec):return next(int(k) for k,r in v['vehicles'].items() if r is rec)

def wire(rec,veh,vid,d):
    saved=rec.get('loadouts')
    if not saved:return
    # Pure serialization: callers may ask for inventory outside a transaction.
    rec=copy.deepcopy(rec);sync(rec);saved=rec['loadouts']
    veh['layoutIndexes'][vid]=dict((int(k),i) for k,i in saved['indexes'].items())
    veh['shellsLayout'][vid]=dict((tuple(int(i) for i in key.split(':')),copy.deepcopy(arrays)) for key,arrays in saved['shells'].items())
    for field in ('eqs','boosters'):veh[field+'Layout'][vid]=copy.deepcopy(saved[field])
    veh['devicesLayout'][vid]=copy.deepcopy(saved['devices'])
    # Native parsers intersect per-layout orders with vehicle-owned item pools.
    owned=pooled(rec)
    from .economy import pairs
    shellids=set(abs(cd) for arrays in saved['shells'].values() for arr in arrays for cd,n in pairs(arr) if cd)
    veh['shells'][vid]=[part for cd in sorted(shellids) for part in (cd,owned[cd])]
    for field in ('eqs','boosters'):
        veh[field][vid]=sorted(set(abs(cd) for arr in saved[field] for cd in arr if cd))

FIT={'CMD_EQUIP':0,'CMD_EQUIP_OPTDEV':1,'CMD_EQUIP_OPT_DEVS_SEQUENCE':1,'CMD_BUY_AND_EQUIP_ITEM':2,'CMD_EQUIP_SHELLS':0,'CMD_EQUIP_EQS':0,'CMD_SET_AND_FILL_LAYOUTS':1,'CMD_SWITCH_LAYOUT':0,'CMD_TOGGLE_SWITCH_LAYOUT':0}
SUPPORTED=('CMD_SWITCH_LAYOUT','CMD_TOGGLE_SWITCH_LAYOUT')

def dispatch(v,cmd,args,inner):
    import AccountCommands as C
    from .economy import row
    name=next((n for n in FIT if getattr(C,n,None)==cmd),None)
    if name is None:
        result=inner(v,cmd,args)
        for rec in v['vehicles'].values():sync(rec)
        return result
    arr=list(args[0]) if len(args)==1 and isinstance(args[0],(list,tuple)) else list(args)
    rec=row(v,arr[FIT[name]]);tracked=begin(v,rec)
    if name=='CMD_SWITCH_LAYOUT':
        if len(arr)!=3:raise Reject('INVALID_SWITCH_LAYOUT_ARGS')
        switch(v,rec,arr[1],arr[2]);result={}
    elif name=='CMD_TOGGLE_SWITCH_LAYOUT':
        from .progression import state,save
        if len(arr)!=2:raise Reject('INVALID_TOGGLE_LAYOUT_ARGS')
        group=number(arr[1],1,2)
        if capacity(rec,group)<2:raise Reject('SETUP_FEATURE_NOT_UNLOCKED')
        s=state(rec);s.toggleSwitchLayout(group);save(rec,s);result={}
    elif name=='CMD_EQUIP_OPTDEV' and tracked:
        from .economy import install_device
        if len(arr)!=8:raise Reject('INVALID_OPTDEV_ARGS')
        target=number(arr[4],0,capacity(rec,2)-1);allsetups=number(arr[5],0,1);original=rec['loadouts']['indexes']['2']
        # Preserve native target-layout addressing even when not currently selected.
        switch(v,rec,2,target) if target!=original else None
        install_device(v,arr[1],arr[2],arr[3],arr[6],arr[7]);sync(rec)
        if allsetups:
            for other in range(capacity(rec,2)):
                if other==target:continue
                switch(v,rec,2,other)
                install_device(v,arr[1],arr[2],arr[3],arr[6],arr[7]);sync(rec)
            if rec['loadouts']['indexes']['2']!=target:switch(v,rec,2,target)
        switch(v,rec,2,original) if target!=original else None
        result={}
    else:result=inner(v,cmd,args)
    if tracked:finish(v,rec)
    else:sync(rec)
    return result
