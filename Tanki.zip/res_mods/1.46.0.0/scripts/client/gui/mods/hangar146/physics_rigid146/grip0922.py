# -*- coding: utf-8 -*-
"""Track laws from supplied 0.9.22 mod, not 1.23. No BigWorld dependencies.
Original donor vehicle_physics.py SHA e2d814cf73e42df3141a9e9d24d7f0e4b8d1dd208fb30ed44312583a3302d23e.
Keep legacy source untouched. Adapt scalar velocities to contact forces.
"""
import math
from ..legacy0922 import vehicle_physics as donor

def parameters(params):
 result=dict(donor._DEFAULTS);result.update(params);return result

def next_speed(params,speed,throttle,steering,pitch,dt,handbrake=False):
 value=donor.longitudinal_step(params,speed,throttle,steering,pitch,dt,False,0,handbrake)
 # Intentional stricter rule than donor's 1.05 downhill overspeed allowance.
 return max(-params['speedBwd'],min(params['speedFwd'],value))

def coefficients(params,normal_y,rolling):
 ny=max(.1,min(1.,normal_y));pitch=math.acos(ny)
 longitudinal=donor._grip_decel(params,pitch)/(9.81*ny)
 unused,lateral=donor.contact_push_decel(params,rolling,0,ny)
 return longitudinal,lateral/(9.81*ny)

def steering_effort(params,speed,pitch,load):
 engine=abs(donor.engine_force(params,speed,1.,pitch))
 grip=coefficients(params,math.cos(pitch),True)[0]*load
 return min(engine,grip)
