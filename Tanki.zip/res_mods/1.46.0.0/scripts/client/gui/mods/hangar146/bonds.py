# -*- coding: utf-8 -*-
from __future__ import absolute_import
import calendar,time
LIMIT=100

def week(now=None):
    stamp=time.time() if now is None else now;t=time.gmtime(stamp)
    monday=calendar.timegm((t.tm_year,t.tm_mon,t.tm_mday,0,0,0))-t.tm_wday*86400
    return time.strftime('%Y-%m-%d',time.gmtime(monday))

def prepare(value,now=None):
    current=week(now)
    if value.get('weekly_bonds',{}).get('week')!=current:value['weekly_bonds']={'week':current,'earned':{},'settled_matches':[]}

def stats(value,now=None):
    if value.get('weekly_bonds',{}).get('week')!=week(now):return {}
    return dict((int(k),n) for k,n in value['weekly_bonds']['earned'].items())

def award(value,type_cd,amount,match_id,now=None):
    """Future settlement primitive; NOT called by the loading-only checkpoint."""
    from . import runtime_data as R
    from .economy import Reject,number
    type_cd=number(type_cd,1);amount=number(amount);prepare(value,now)
    row=next((r for r in R.catalog()['vehicles'] if r['typeCD']==type_cd),None)
    if row is None or row['level']!=10 or 'earn_crystals' not in row.get('tags',[]):raise Reject('VEHICLE_NOT_ELIGIBLE_FOR_WEEKLY_BONDS')
    record=value['weekly_bonds'];key=str(match_id)
    if key in record['settled_matches']:return 0
    previous=record['earned'].get(str(type_cd),0);paid=min(amount,max(0,LIMIT-previous))
    record['earned'][str(type_cd)]=previous+paid;record['settled_matches'].append(key);value['wallet']['crystal']+=paid
    return paid

def native_keys(value):
    if isinstance(value,list):return [native_keys(v) for v in value]
    if not isinstance(value,dict):return value
    def key(k):
        if k=='True':return True
        if k=='False':return False
        return int(k) if isinstance(k,basestring) and k.isdigit() else k
    return dict((key(k),native_keys(v)) for k,v in value.items())
