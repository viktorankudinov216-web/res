# -*- coding: utf-8 -*-
"""Conservative shot broad phase; native BSP still resolves actual armour."""
from .math3 import *
def near_segment(center,start,end,radius):
 d=sub(end,start);l=dot(d,d);t=clamp(dot(sub(center,start),d)/l,0.,1.) if l>1e-12 else 0.
 delta=sub(center,add(start,mul(d,t)))
 return dot(delta,delta)<=radius*radius
