# -*- coding: utf-8 -*-
"""Bounded selected-map diagnostics; no fabricated SpaceData/server packets."""
from __future__ import absolute_import
import traceback


def bind_camera(session,camera):
    """Assign only the native space override; do not replace camera or providers."""
    sid=int(session.avatar.spaceID)
    before=int(camera.spaceID)
    if before==sid:return
    saved=getattr(session,'bound_sky_cameras',None)
    if saved is None:saved=[];session.bound_sky_cameras=saved
    if not any(item[0] is camera for item in saved):saved.append((camera,before,sid))
    camera.spaceID=sid
    after=int(camera.spaceID)
    if after!=sid:raise ValueError('Native camera rejected local space override')
    session.mark('local_camera_space_bound',camera_class=type(camera).__name__,
        camera_space_before=before,camera_space_after=after,bound_camera_count=len(saved))


def install_camera_binding():
    import BigWorld
    from . import utils
    if getattr(BigWorld.camera,'_hangar146_space_binding',False):return
    @utils.override(BigWorld,'camera')
    def camera(base,*args,**kwargs):
        # The zero-argument camera getter is untouched. This is NOT cameraSpaceID.
        if len(args)==1 and not kwargs and args[0] is not None:
            from . import world146 as W
            session=W._SESSION
            if session is not None and session.valid():
                try:bind_camera(session,args[0])
                except Exception:session.mark('local_camera_space_warning',warning=traceback.format_exc())
        return base(*args,**kwargs)
    BigWorld.camera._hangar146_space_binding=True


def bind_current_camera(session):
    import BigWorld
    install_camera_binding()
    camera=BigWorld.camera()
    before=int(camera.spaceID)
    bind_camera(session,camera)
    session.camera_binding_initial=dict(camera_class=type(camera).__name__,before=before,after=int(camera.spaceID),expected=int(session.avatar.spaceID))


def restore_camera_binding(session):
    saved=getattr(session,'bound_sky_cameras',[])
    for camera,before,sid in reversed(saved):
        try:
            # Do not undo a later owner's explicit camera reassignment.
            if int(camera.spaceID)==sid:camera.spaceID=before
        except Exception:session.mark('local_camera_restore_warning',warning=traceback.format_exc())
    session.bound_sky_cameras=[]


def watcher_bool(value):
    if value is True or value is False:return value
    if isinstance(value,(int,long)) and value in (0,1):return bool(value)
    if isinstance(value,basestring):
        text=value.strip().lower()
        if text in ('true','1'):return True
        if text in ('false','0'):return False
    raise ValueError('Unrecognized Visibility/Sky value: '+repr(value)[:128])


def ensure_sky(session):
    """Change only a confirmed disabled sky flag; preserve it for Session.stop."""
    import BigWorld
    info={}
    try:
        before=BigWorld.getWatcher('Visibility/Sky');enabled=watcher_bool(before)
        info.update(before=enabled,changed=False)
        if not enabled:
            if not hasattr(session,'original_sky_visibility'):session.original_sky_visibility=before
            BigWorld.setWatcher('Visibility/Sky',True);info['changed']=True
        info['after']=watcher_bool(BigWorld.getWatcher('Visibility/Sky'))
    except Exception:info['warning']=traceback.format_exc()
    session.sky_visibility_probe=info
    session.mark('sky_visibility_checked',sky_visibility=info)


def restore_sky(session):
    if not hasattr(session,'original_sky_visibility'):return
    import BigWorld
    try:
        BigWorld.setWatcher('Visibility/Sky',session.original_sky_visibility)
        del session.original_sky_visibility
        session.mark('sky_visibility_restored')
    except Exception:session.mark('sky_visibility_restore_warning',warning=traceback.format_exc())


def dependency_report(selected):
    import ResMgr
    report=[]
    for suffix in ('/skyDome/skybox','/skyDome/forward/skybox'):
        stem=selected['folder']+suffix;item=dict(model=stem+'.model',textures=[],effects=[])
        report.append(item)
        try:
            model=ResMgr.openSection(item['model'])
            item['model_exists']=model is not None
            if model is None:continue
            visual=model.readString('nodelessVisual','').strip()
            if not visual:raise ValueError('No nodelessVisual in selected sky model')
            # Processed visuals are the packaged 1.46 resources. Do not modify them.
            item['visual']=visual+'.visual_processed'
            item['primitives']=visual+'.primitives_processed'
            item['primitives_exists']=bool(ResMgr.isFile(item['primitives']))
            section=ResMgr.openSection(item['visual']);item['visual_exists']=section is not None
            if section is None:continue
            stack=[(0,section)];nodes=0;truncated=False
            while stack and nodes<384:
                depth,node=stack.pop();nodes+=1
                children=list(node.items())
                if len(children)>128:truncated=True
                for key,child in children[:128]:
                    if key in ('Texture','fx'):
                        value=unicode(child.asString).strip()[:1024]
                        bucket=item['textures'] if key=='Texture' else item['effects']
                        if value and not any(e['path']==value for e in bucket):
                            if len(bucket)<32:bucket.append(dict(path=value,is_file=bool(ResMgr.isFile(value))))
                            else:truncated=True
                    if depth<16:stack.append((depth+1,child))
                    elif list(child.items()):truncated=True
            item['truncated']=bool(stack or truncated);item['nodes']=nodes
        except Exception:item['warning']=traceback.format_exc()
    return report


def inspect_scene(session):
    import BigWorld
    from . import native_match as N,battle_state146 as B
    info=dict(sky_visibility_initial=getattr(session,'sky_visibility_probe',None),
        camera_binding_initial=getattr(session,'camera_binding_initial',None),
        bound_camera_count=len(getattr(session,'bound_sky_cameras',[])))
    N._REPORT['sky_diagnostics']=info
    for name,reader in (
        ('sky_visible',lambda:watcher_bool(BigWorld.getWatcher('Visibility/Sky'))),
        ('forward_pipeline',lambda:bool(BigWorld.isForwardPipeline())),
        ('camera_space_id',lambda:int(BigWorld.camera().spaceID))):
        try:info[name]=reader()
        except Exception:info[name+'_warning']=traceback.format_exc()
    # OldSpaceData is cell-only in stock bwdeprecations. Introspection is read-only.
    info['client_space_api']={name:hasattr(BigWorld,name) for name in
        ('spaces','setSpaceData','getSpaceDataFirstForKey','setSpaceTimeOfDay')}
    if info['client_space_api']['spaces']:
        try:
            space=BigWorld.spaces[session.avatar.spaceID];properties={}
            for name in ('timeOfDay','weather','itemsVisibilityMask'):
                try:
                    value=getattr(space,name)
                    if name=='timeOfDay':
                        clock={}
                        for key in ('initialTimeOfDay','gameSecondsPerSecond'):
                            try:clock[key]=float(value[key] if isinstance(value,dict) else getattr(value,key))
                            except Exception:clock[key]={'warning':traceback.format_exc()}
                        properties[name]=clock
                    else:properties[name]=repr(value)[:512]
                except Exception:properties[name]={'warning':traceback.format_exc()}
            info['space_properties']=properties
        except Exception:info['space_properties_warning']=traceback.format_exc()
    try:
        selected=B.environment_descriptor(session.arena.geometry)
        info['dependencies']=dependency_report(selected)
        # Select only the active pipeline's native model. Never attach this probe
        # model to the scene, and never replace the native sky with another map.
        if 'forward_pipeline' in info:
            path=selected['folder']+('/skyDome/forward/skybox.model' if info['forward_pipeline'] else '/skyDome/skybox.model')
            info['model_load_probe']=dict(path=path,status='pending')
            def loaded(ref):
                if not session.valid():return
                try:
                    failed=list(ref.failedIDs);info['model_load_probe']['failed_ids']=[unicode(v)[:1024] for v in failed[:16]]
                    model=ref[path] if path not in failed else None
                    session.sky_probe_refs=ref
                    info['model_load_probe'].update(status='loaded' if model is not None else 'failed',model_class=type(model).__name__)
                except Exception:info['model_load_probe'].update(status='warning',warning=traceback.format_exc())
                session.mark('sky_model_probe_completed',sky_model_load_status=info['model_load_probe']['status'])
            BigWorld.loadResourceListBG([path],loaded)
    except Exception:info['resource_probe_warning']=traceback.format_exc()
    session.mark('sky_scene_inspected',sky_render_verified=False)
