# -*- coding: utf-8 -*-
"""Nonblocking engine -> private loopback worker bridge (Python 2.7).
No waits on the render thread, bounded queues, local fallback, Job memory cap.
"""
from __future__ import absolute_import
import os,sys,json,time,errno,binascii
MAX_FRAME=512*1024
_BRIDGE=None

def encode(value):return (json.dumps(value,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


class Bridge(object):
    def __init__(self,root,executable=None):
        self.root=root;self.process=None;self.listener=None;self.sock=None;self.job=None
        self.buffer=b'';self.out=b'';self.latest=None;self.ready=False;self.failed=None;self.received=0.;self.states={};self.stats={}
        self.seq=0;self.epoch=binascii.hexlify(os.urandom(16)).decode('ascii');self.sent_at={};self.started=time.time();self.last_heartbeat=0.;self.rx_bytes=0;self.tx_bytes=0;self.contact_rows={};self.initialized=set()
        self.token=binascii.hexlify(os.urandom(32)).decode('ascii')
        try:
            global socket,subprocess
            import socket,subprocess
            helper=os.path.join(root,'mods','hangar146_helper')
            executable=executable or os.path.join(helper,'python311','pythonw.exe')
            self.listener=socket.socket(socket.AF_INET,socket.SOCK_STREAM);self.listener.bind(('127.0.0.1',0));self.listener.listen(1);self.listener.setblocking(False)
            self.devnull=open(os.devnull,'wb')
            flags=0x08000000|0x00004000 if os.name=='nt' else 0
            self.process=subprocess.Popen([executable,os.path.join(helper,'worker_main.py'),str(self.listener.getsockname()[1]),self.token],cwd=helper,stdin=self.devnull,stdout=self.devnull,stderr=self.devnull,creationflags=flags,close_fds=(os.name!='nt'))
        except Exception as e:self.fail('launch: '+str(e))
    def fail(self,reason):
        if self.failed:return
        self.failed=reason;self.close()
    def close(self):
        self.ready=False;self.states={}
        for sock in (self.sock,self.listener):
            if sock is not None:
                try:sock.close()
                except Exception:pass
        self.sock=None;self.listener=None
        if self.job:
            self.job[0].CloseHandle(self.job[1]);self.job=None
        if self.process is not None and self.process.poll() is None:
            try:self.process.terminate()
            except Exception:pass
        if hasattr(self,'devnull'):self.devnull.close()
    def reset(self):
        self.epoch=binascii.hexlify(os.urandom(16)).decode('ascii');self.states={};self.contact_rows={};self.initialized=set();self.received=0.
        self.latest=None
        if self.ready:self.out+=encode(dict(kind='reset',epoch=self.epoch))
    def poll(self):
        if self.failed:return
        try:self._poll()
        except Exception as e:self.fail('protocol: '+str(e))
    def _poll(self):
        now=time.time()
        if self.process.poll() is not None:raise RuntimeError('worker exited '+str(self.process.returncode))
        if self.sock is None:
            try:self.sock,address=self.listener.accept();self.sock.setblocking(False);self.sock.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
            except socket.error as e:
                if e.errno in (errno.EWOULDBLOCK,errno.EAGAIN,10035):
                    if now-self.started>10.:raise RuntimeError('startup timeout')
                    return
                raise
        for unused in range(4):
            try:data=self.sock.recv(65536)
            except socket.error as e:
                if e.errno in (errno.EWOULDBLOCK,errno.EAGAIN,10035):break
                raise
            if not data:raise RuntimeError('worker disconnected')
            self.rx_bytes+=len(data);self.buffer+=data
            if len(self.buffer)>MAX_FRAME:raise RuntimeError('receive overflow')
        if self.ready and b'\n' in self.buffer:
            end=self.buffer.rfind(b'\n');previous=self.buffer.rfind(b'\n',0,end)
            self.buffer=self.buffer[previous+1:]
        while b'\n' in self.buffer:
            line,self.buffer=self.buffer.split(b'\n',1);msg=json.loads(line)
            if not self.ready:
                if msg.get('kind')!='hello' or msg.get('protocol')!=2 or msg.get('token')!=self.token:raise RuntimeError('worker authentication failed')
                if os.name=='nt' and not (msg.get('memory_limit_enforced') and msg.get('memory_limit_mb')==2048):raise RuntimeError('worker memory cap not enforced')
                self.ready=True;self.listener.close();self.listener=None
                self.out=encode(dict(kind='ready'))+encode(dict(kind='reset',epoch=self.epoch))
            elif msg.get('kind')=='state' and msg.get('epoch')==self.epoch:
                sent=self.sent_at.get(int(msg['seq']))
                if sent is None or now-sent>.2:continue
                self.received=now;self.states=dict((int(a['id']),a) for a in msg['actors'])
                self.stats=dict((k,msg[k]) for k in ('steps','mean_ms','peak_ms','dropped'))
                sent=self.sent_at.get(int(msg['seq']))
                if sent is not None:self.stats['round_trip_ms']=(now-sent)*1000.
        if self.ready and now-self.last_heartbeat>1. and not self.contact_rows:
            self.latest=encode(dict(kind='contacts',epoch=self.epoch,seq=self.seq,actors=[]));self.last_heartbeat=now
        if not self.out and self.latest is not None:self.out=self.latest;self.latest=None
        if self.out:
            try:
                n=self.sock.send(self.out);self.tx_bytes+=n;self.out=self.out[n:]
            except socket.error as e:
                if e.errno not in (errno.EWOULDBLOCK,errno.EAGAIN,10035):raise
    def solve(self,actor,state,heights,dt,pseudos,support):
        # Contacts/geometry remain in the BigWorld thread. Worker owns continuous
        # vertical/pitch/roll integration; no synchronous response is awaited.
        generation=getattr(actor,'solver_generation',0)
        row=dict(id=actor.id,body=state,heights=heights,pseudos=pseudos,support=support,drive_acceleration=float(state.get('drive_acceleration',0.)),lateral_acceleration=float(state.get('lateral_acceleration',0.)),alive=actor.health>0,generation=generation)
        if actor.id not in self.initialized:row['params']=actor.suspension;self.initialized.add(actor.id)
        self.contact_rows[actor.id]=row
        result=self.states.get(actor.id)
        usable=self.ready and not self.failed and time.time()-self.received<.15 and result is not None and result['generation']==generation
        # The child exclusively integrates springs while healthy. Multiple
        # catch-up substeps in one render frame MUST NOT integrate an already
        # advanced remote state again (30 FPS used to double-step the body).
        if usable:
            actor.solver_remote=True
            if getattr(actor,'solver_steps',-1)!=self.stats.get('steps'):
                actor.solver_steps=self.stats['steps']
                return dict(result['body'])
            return dict(state)
        from .legacy0922 import vehicle_physics
        solved=vehicle_physics.damper_suspension_step(actor.suspension,state,heights,dt,pseudos,support)
        if not usable and getattr(actor,'solver_remote',False):
            actor.solver_generation=generation+1;row['generation']=actor.solver_generation;row['body']=solved
            actor.solver_remote=False
        return solved
    def flush(self,actors):
        if not self.ready or self.failed:return
        rows=[]
        for actor in actors:
            row=self.contact_rows.get(actor.id)
            if row is not None:row['alive']=actor.health>0 and not getattr(actor,'sleeping',False);rows.append(row)
        self.seq+=1;self.sent_at[self.seq]=time.time()
        # Full params are small (<20KB per vehicle) but only sent until the
        # worker has acknowledged an actor. Avoid losing first init to latest-only.
        for row in rows:
            if row['id'] not in self.states:row['params']=next(a.suspension for a in actors if a.id==row['id'])
            else:row.pop('params',None)
        self.latest=encode(dict(kind='contacts',epoch=self.epoch,seq=self.seq,actors=rows))
        if len(self.latest)>MAX_FRAME:self.fail('send overflow');return
        if len(self.sent_at)>32:
            for key in sorted(self.sent_at)[:-32]:self.sent_at.pop(key,None)
        self.poll()

def start():
    global _BRIDGE
    if _BRIDGE is None:
        from .runtime_data import game_root
        _BRIDGE=Bridge(game_root())
    return _BRIDGE

def stop():
    global _BRIDGE
    if _BRIDGE is not None:_BRIDGE.close();_BRIDGE=None
