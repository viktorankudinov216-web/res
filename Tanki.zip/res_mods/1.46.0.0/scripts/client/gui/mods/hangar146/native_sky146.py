# -*- coding: utf-8 -*-
"""Read-only native sky snapshot for the fingerprinted x64 1.46 executable.

No from_address, pointer calls, memory writes, injected code or watcher guesses.
ReadProcessMemory failure becomes a diagnostic warning, never a dereference.
"""
from __future__ import absolute_import
import struct,traceback


class Reader(object):
    def __init__(self,read,base):
        self._read=read;self.base=int(base);self.calls=0;self.bytes=0
    def read(self,address,size):
        address=int(address);size=int(size)
        if size<1 or size>4096 or address<65536 or address+size>0x0000800000000000:
            raise ValueError('Read outside bounded user-memory range')
        self.calls+=1;self.bytes+=size
        if self.calls>256 or self.bytes>65536:raise ValueError('Native snapshot budget exhausted')
        data=self._read(address,size)
        if len(data)!=size:raise ValueError('Incomplete native diagnostic read')
        return data
    def q(self,address):return struct.unpack('<Q',self.read(address,8))[0]
    def u32(self,address):return struct.unpack('<I',self.read(address,4))[0]
    def text(self,address):
        header=self.read(address,32);length,capacity=struct.unpack('<QQ',header[16:32])
        if length>1024 or capacity<length or capacity>16777216:raise ValueError('Invalid bounded native string')
        if not length:return ''
        data=header[:length] if capacity<16 else self.read(struct.unpack('<Q',header[:8])[0],length)
        return data.decode('utf-8','replace')
    def getter(self,obj,slot):
        """Decode a trivial native getter; NEVER execute its code."""
        vtable=self.q(obj);fn=self.q(vtable+slot)
        if not self.base<=fn<self.base+0x3000000:raise ValueError('Getter is outside verified code image')
        code=self.read(fn,12)
        if code.startswith('\x33\xc0\xc3') or code.startswith('\x31\xc0\xc3'):return 0
        if code[:3] in ('\x48\x8b\x81','\x48\x8d\x81') and code[7:8]=='\xc3':
            offset=struct.unpack('<i',code[3:7])[0];kind=code[1:2]
        elif code[:3] in ('\x48\x8b\x41','\x48\x8d\x41') and code[4:5]=='\xc3':
            offset=struct.unpack('<b',code[3:4])[0];kind=code[1:2]
        else:raise ValueError('Unsupported native getter at RVA '+hex(fn-self.base)+' code='+code.encode('hex'))
        if not 0<=offset<16384:raise ValueError('Invalid getter object offset')
        return self.q(obj+offset) if kind=='\x8b' else obj+offset


def snapshot(r):
    # These instruction bytes and RVAs come from this exact Tanki.exe, not 1.23.
    if r.read(r.base,2)!='MZ':raise ValueError('Native module has no DOS header')
    pe=r.u32(r.base+0x3c)
    if pe>0x100000 or r.read(r.base+pe,6)!='PE\0\0\x64\x86':raise ValueError('Not an x64 PE image')
    checks=((0x1ee7720,'\x48\x8b\x05\x51\xd4\xf0\x01\x48\x8b\x40\x10\xc3'),
            (0x1ed3910,'\x48\x8b\x05\x29\xdf\xfb\x01\xc3'))
    for offset,expected in checks:
        if r.read(r.base+offset,len(expected))!=expected:raise ValueError('Native renderer signature differs')
    info=dict(read_only=True,version_signatures_verified=True)
    manager=r.q(r.base+0x3df4b78)
    if not manager:raise ValueError('Native renderer accessor is uninitialized')
    pipeline=r.q(manager+0x10);info['pipeline_present']=bool(pipeline)
    if not pipeline:return info
    sky=r.getter(pipeline,0x190);info['sky_feature_present']=bool(sky)
    if sky:
        info['sky_vtable_rva']=hex(r.q(sky)-r.base)
        if r.q(sky)!=r.base+0x2dd6018:raise ValueError('Unexpected native sky feature type')
        enabled,animation=struct.unpack('<BB',r.read(sky+0x10,2))
        info.update(sky_enabled=bool(enabled),sky_animation_enabled=bool(animation),
                    native_sky_model_present=bool(r.q(sky+0x20)))
        info['sky_matrix']=list(struct.unpack('<16f',r.read(sky+0x48,64)))
        info['sky_matrix_forward']=list(struct.unpack('<16f',r.read(sky+0x88,64)))
        model=r.q(sky+0x20)
        if model:
            try:
                resource=r.q(model+0x18)
                info['native_sky_model_path']=r.text(resource+0x18) if resource else ''
            except Exception:info['native_sky_model_path_warning']=traceback.format_exc()
    try:
        env=r.getter(pipeline,0x250);info['environment_system_present']=bool(env)
        if env:
            info['active_environment_words']=['%08X'%v for v in struct.unpack('<4I',r.read(env+0x50,16))]
            info['default_environment_words']=['%08X'%v for v in struct.unpack('<4I',r.read(env+0x60,16))]
            head=r.q(env+0x18);node=r.q(head);presets=[];seen=set()
            while node!=head and len(presets)<32:
                if node in seen:raise ValueError('Native environment list cycle')
                seen.add(node);preset=r.q(node+0x20)
                presets.append(dict(id_words=['%08X'%v for v in struct.unpack('<4I',r.read(node+0x10,16))],
                    name=r.text(preset+0x10d0),resource_root=r.text(preset+0x10f8)))
                node=r.q(node)
            info['registered_environments']=presets
    except Exception:info['environment_system_warning']=traceback.format_exc()
    # Renderer::instance()->current render context. Sky pass checks high-byte
    # 0x10 and 0x80 at context+0xa1 before invoking the native sky feature.
    try:
        renderer=r.q(r.base+0x3e91840)
        context=r.q(renderer+0x620) if renderer else 0
        info['render_context_present']=bool(context)
        if context:
            flags=r.u32(context+0xa0)
            info.update(render_context_flags=hex(flags),sky_pass_gate_1000=bool(flags&0x1000),
                        sky_pass_gate_8000=bool(flags&0x8000))
    except Exception:info['render_context_warning']=traceback.format_exc()
    info.update(read_calls=r.calls,read_bytes=r.bytes)
    return info


def inspect(session):
    from . import native_match as N
    info=dict(read_only=True,status='unavailable')
    N._REPORT['native_sky_diagnostics']=info
    try:
        if not session.valid():return
        if N._REPORT.get('exe_sha256')!=N.EXPECTED_EXE_SHA256:raise ValueError('Executable fingerprint not verified')
        import ctypes
        if ctypes.sizeof(ctypes.c_void_p)!=8:raise ValueError('Native snapshot requires x64 Python')
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetModuleHandleW.argtypes=[ctypes.c_wchar_p];kernel.GetModuleHandleW.restype=ctypes.c_void_p
        kernel.GetCurrentProcess.argtypes=[];kernel.GetCurrentProcess.restype=ctypes.c_void_p
        kernel.ReadProcessMemory.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_size_t)]
        kernel.ReadProcessMemory.restype=ctypes.c_int
        base=kernel.GetModuleHandleW(None);process=kernel.GetCurrentProcess()
        def read(address,size):
            buffer=ctypes.create_string_buffer(size);done=ctypes.c_size_t()
            if not kernel.ReadProcessMemory(process,address,buffer,size,ctypes.byref(done)) or done.value!=size:
                raise ValueError('ReadProcessMemory diagnostic read failed')
            return buffer.raw
        info.update(snapshot(Reader(read,base)));info['status']='captured'
    except Exception:info['warning']=traceback.format_exc()
    session.mark('native_sky_snapshot',native_sky_snapshot_status=info['status'])
