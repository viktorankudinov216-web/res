# -*- coding: utf-8 -*-
"""Separate local profile. No reads/writes of real-account saves."""
from __future__ import absolute_import
import copy,json,os,time
try: integer_types=(int,long)
except NameError: integer_types=(int,)

class Profile(object):
    def __init__(self,path):
        self.path=path
        self.value={'schema':1,'build':'1.46.0.0#2304','wallet':{'credits':100000000,'gold':1000000,'crystal':1000000,'freeXP':1000000},'vehicles':{},'settings':{},'revision':0}
        # Recover the last committed save if interrupted between the two renames.
        if not os.path.exists(path) and os.path.isfile(path+'.bak'):
            os.rename(path+'.bak',path)
        if os.path.isfile(path):
            with open(path,'rb') as f: loaded=json.load(f)
            if loaded.get('schema')!=1 or loaded.get('build')!=self.value['build']:raise ValueError('Profile schema/build mismatch; refusing migration')
            self.value=loaded
        self.validate(self.value)
    def wallet(self):return dict(self.value['wallet'])
    def validate(self,v):
        if not isinstance(v.get('wallet'),dict) or not isinstance(v.get('vehicles'),dict):raise ValueError('Invalid profile structure')
        for required in ('credits','gold','crystal','freeXP'):
            if required not in v['wallet']:raise ValueError('Missing wallet currency: '+required)
        for key,n in v.get('stock',{}).items():
            if not str(key).isdigit() or int(key)<=0 or isinstance(n,bool) or not isinstance(n,integer_types) or n<0:raise ValueError('Invalid depot stock')
        for rawcd,bounds in v.get('c11n_stock',{}).items():
            if not str(rawcd).isdigit() or int(rawcd)<=0 or not isinstance(bounds,dict):raise ValueError('Invalid customization depot')
            for bound,n in bounds.items():
                if not str(bound).isdigit() or isinstance(n,bool) or not isinstance(n,integer_types) or n<0:raise ValueError('Invalid customization quantity')
        for k,n in v['wallet'].items():
            if isinstance(n,bool) or not isinstance(n,integer_types) or n<0:raise ValueError('Invalid wallet amount: '+k)
    def transact(self,mutator):
        proposal=copy.deepcopy(self.value);result=mutator(proposal);proposal['revision']+=1;self.validate(proposal)
        self._write(proposal);self.value=proposal;return result
    def _write(self,proposal):
        folder=os.path.dirname(self.path)
        if not os.path.isdir(folder):os.makedirs(folder)
        tmp=self.path+'.tmp';backup=self.path+'.bak'
        with open(tmp,'wb') as f:
            f.write(json.dumps(proposal,ensure_ascii=True,sort_keys=True).encode('ascii'));f.flush();os.fsync(f.fileno())
        if os.path.exists(backup):os.remove(backup)
        if os.path.exists(self.path):os.rename(self.path,backup)
        try:os.rename(tmp,self.path)
        except Exception:
            if os.path.exists(backup):os.rename(backup,self.path)
            raise
    def debit(self,amount):
        if not isinstance(amount,dict):raise ValueError('Cost must be currency dictionary')
        def change(v):
            for k,n in amount.items():
                if isinstance(n,bool) or not isinstance(n,integer_types) or n<0:raise ValueError('Invalid debit')
                if v['wallet'].get(k,0)<n:raise ValueError('Insufficient '+k)
            for k,n in amount.items():v['wallet'][k]=v['wallet'].get(k,0)-n
        return self.transact(change)
