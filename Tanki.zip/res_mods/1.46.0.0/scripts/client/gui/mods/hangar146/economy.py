# -*- coding: utf-8 -*-
"""Transactional garage commands for MT 1.46. No success-only fallbacks."""
from __future__ import absolute_import
import base64,copy,math
from . import runtime_data as R

class Reject(ValueError):pass

def number(x,minimum=0,maximum=1000000000):
    if isinstance(x,bool) or not isinstance(x,(int,long)) or not minimum<=x<=maximum:raise Reject('INVALID_INTEGER')
    return int(x)

def item_type(cd):
    from items import getTypeOfCompactDescr
    return getTypeOfCompactDescr(cd)

def row(v,vid):
    key=str(number(vid,1))
    if key not in v['vehicles']:raise Reject('VEHICLE_NOT_OWNED')
    return v['vehicles'][key]

def descriptor(rec):
    from items import vehicles
    if rec.get('vpp') or rec.get('customRoleSlot'):
        from .progression import ext
        return vehicles.VehicleDescr(compactDescr=base64.b64decode(rec['compactDescr_b64']),extData=ext(rec))
    return vehicles.VehicleDescr(compactDescr=base64.b64decode(rec['compactDescr_b64']))

def stock(v,cd,change):
    depot=v.setdefault('stock',{});key=str(number(cd,1));new=depot.get(key,0)+change
    if new<0:raise Reject('NOT_ENOUGH_DEPOT_ITEMS: '+key)
    depot[key]=new

def charge(v,cost):
    for cur,amount in cost.items():
        number(amount)
        if v['wallet'].get(cur,0)<amount:raise Reject('INSUFFICIENT_'+cur.upper())
    for cur,amount in cost.items():v['wallet'][cur]=v['wallet'].get(cur,0)-amount

def cost(cd,count=1,alternative=False):
    cd=number(cd,1);count=number(count,1,1000000);cat=R.catalog()
    if cd not in cat['prices']:raise Reject('ITEM_HAS_NO_PRICE')
    values=dict(cat['prices'][cd]);shop=cat['shop'];itype=item_type(cd)
    blocked=shop.get('items',{}).get('notInShopItems',())
    if cd in blocked:raise Reject('ITEM_NOT_IN_SHOP')
    if alternative:
        if itype not in (10,11):raise Reject('ALTERNATIVE_CURRENCY_NOT_SUPPORTED')
        values['credits']=values.get('credits',0)+values.pop('gold',0)*number(shop['exchangeRateForShellsAndEqs'])
    return dict((k,number(n)*count) for k,n in values.items())

def buy(v,cd,count=1,alternative=False):
    if item_type(cd) not in (2,3,4,5,6,7,9,10,11):raise Reject('UNSUPPORTED_ITEM_TYPE')
    charge(v,cost(cd,count,alternative));stock(v,cd,count)

def sell(v,cd,count):
    cd=number(cd,1);count=number(count,1,1000000)
    if item_type(cd) not in (2,3,4,5,6,7,9,10,11):raise Reject('UNSUPPORTED_ITEM_TYPE')
    cat=R.catalog();prices=cat['prices'].get(cd)
    if prices is None:raise Reject('ITEM_HAS_NO_PRICE')
    if cd in cat['shop'].get('items',{}).get('forbiddenToSellItems',()):raise Reject('ITEM_CANNOT_BE_SOLD')
    stock(v,cd,-count)
    # Native Shop.getSellPrice converts gold/crystal to credits. Event tokens
    # and other currencies need their own policy; never silently discard them.
    if any(n for k,n in prices.items() if k not in ('credits','gold','crystal')):raise Reject('UNSUPPORTED_SELL_CURRENCY')
    shop=cat['shop'];base=prices.get('credits',0)+prices.get('gold',0)*shop['exchangeRate']+prices.get('crystal',0)*shop['crystalExchangeRate']
    proceeds=int(math.ceil(float(shop['sellPriceFactor'])*base))*count
    v['wallet']['credits']+=proceeds

def native_allowed(result):
    allowed,reason=result
    if not allowed:raise Reject('INCOMPATIBLE_ITEM: '+str(reason))

def mounted_modules(d):
    return [getattr(d,name).compactDescr for name in ('chassis','turret','gun','engine','radio','fuelTank')]

def unload(v,rec,field):
    values=rec.get(field,[])
    if field=='shells':
        for cd,count in pairs(values):
            if cd:stock(v,abs(cd),count)
    else:
        for cd in values:
            if cd:stock(v,abs(cd),1)
    rec[field]=[]

def install_module(v,vid,cd,gun=0):
    rec=row(v,vid);d=descriptor(rec);itype=item_type(number(cd,1));before=mounted_modules(d)
    if cd in before and (not gun or gun in before):return
    if itype==3:
        native_allowed(d.mayInstallTurret(cd,gun));d.installTurret(cd,gun)
    elif itype in (2,4,5,6,7):
        native_allowed(d.mayInstallComponent(cd));d.installComponent(cd)
    else:raise Reject('NOT_A_MODULE')
    after=mounted_modules(d)
    for new in after:
        if new not in before:stock(v,new,-1)
    for old in before:
        if old not in after:stock(v,old,1)
    if d.gun.compactDescr!=before[2]:
        unload(v,rec,'shells');rec['shellsLayout']=[]
    rec['compactDescr_b64']=base64.b64encode(d.makeCompactDescr())

def removal_cost(device):
    shop=R.catalog()['shop']
    if getattr(device,'isModernized',False):key='paidModernized%dRemovalCost'%number(device.level,1,3)
    elif getattr(device,'isDeluxe',False) or R.catalog()['prices'].get(device.compactDescr,{}).get('crystal'):key='paidDeluxeRemovalCost'
    elif getattr(device,'isUpgradable',False):key='paidTrophyBasicRemovalCost'
    elif getattr(device,'isUpgraded',False):key='paidTrophyUpgradedRemovalCost'
    else:key='paidRemovalCost'
    value=shop[key]
    return value if isinstance(value,dict) else {'gold':number(value)}

def install_device(v,vid,cd,slot,mode=0,use_kit=0):
    rec=row(v,vid);d=descriptor(rec);slot=number(slot,0,len(d.optionalDevices)-1);mode=number(mode,0,2)
    if use_kit:raise Reject('DEMOUNT_KIT_NOT_IMPLEMENTED')
    old=d.optionalDevices[slot];oldcd=old.compactDescr if old else 0
    if cd==oldcd:return
    installed=[dev.compactDescr if dev else 0 for dev in d.optionalDevices]
    if cd and cd in installed:
        source=installed.index(cd);native_allowed(d.maySwapOptionalDevice(source,slot));d.swapOptionalDevice(source,slot)
        rec['compactDescr_b64']=base64.b64encode(d.makeCompactDescr());return
    if cd:
        if item_type(number(cd,1))!=9:raise Reject('NOT_OPTIONAL_DEVICE')
        native_allowed(d.mayInstallOptionalDevice(cd,slot));stock(v,cd,-1)
    if old:
        if mode==2:raise Reject('SPECIAL_REMOVAL_MODE_NOT_IMPLEMENTED')
        from .loadouts import held_elsewhere
        if held_elsewhere(rec,oldcd) or getattr(old,'removable',False):stock(v,oldcd,1)
        elif mode==1:
            charge(v,removal_cost(old));stock(v,oldcd,1)
        # mode 0 explicitly destroys the old device; no free depot copy.
        d.removeOptionalDevice(slot)
    if cd:d.installOptionalDevice(cd,slot)
    rec['compactDescr_b64']=base64.b64encode(d.makeCompactDescr())

def install_sequence(v,vid,desired):
    rec=row(v,vid);d=descriptor(rec);old=[dev for dev in d.optionalDevices]
    if len(desired)!=len(old):raise Reject('INVALID_DEVICE_SEQUENCE_CAPACITY')
    desired=[number(cd) for cd in desired]
    if len([cd for cd in desired if cd])!=len(set(cd for cd in desired if cd)):raise Reject('DUPLICATE_DEVICE')
    installed=[dev.compactDescr if dev else 0 for dev in old]
    # Clear only the temporary descriptor. Ownership is reconciled separately.
    for idx,dev in enumerate(old):
        if dev:d.removeOptionalDevice(idx)
    for idx,cd in enumerate(desired):
        if not cd:continue
        if item_type(cd)!=9:raise Reject('NOT_OPTIONAL_DEVICE')
        native_allowed(d.mayInstallOptionalDevice(cd,idx));d.installOptionalDevice(cd,idx)
    for dev in old:
        if dev and dev.compactDescr not in desired:
            from .loadouts import held_elsewhere
            if not held_elsewhere(rec,dev.compactDescr) and not getattr(dev,'removable',False):charge(v,removal_cost(dev))
            stock(v,dev.compactDescr,1)
    for cd in desired:
        if cd and cd not in installed:ensure(v,cd,1,True)
    rec['compactDescr_b64']=base64.b64encode(d.makeCompactDescr())

def pairs(values):
    if not isinstance(values,(list,tuple)) or len(values)%2:raise Reject('INVALID_LAYOUT_PAIRS')
    result=[]
    for i in range(0,len(values),2):
        cd=values[i]
        if isinstance(cd,bool) or not isinstance(cd,(int,long)):raise Reject('INVALID_DESCRIPTOR')
        result.append((cd,number(values[i+1],0,1000000)))
    return result

def ensure(v,cd,count,autobuy,alternative=False):
    available=v.setdefault('stock',{}).get(str(cd),0)
    if available<count:
        if not autobuy:raise Reject('NOT_ENOUGH_DEPOT_ITEMS')
        buy(v,cd,count-available,alternative)
    stock(v,cd,-count)

def fit_shells(v,vid,values,autobuy=False):
    rec=row(v,vid);d=descriptor(rec);layout=pairs(values);seen=set();allowed=set(s.shell.compactDescr for s in d.gun.shots)
    total=0
    for signed,count in layout:
        cd=abs(signed)
        if cd not in allowed or cd in seen:raise Reject('INVALID_OR_DUPLICATE_SHELL')
        seen.add(cd);total+=count
    if total>d.gun.maxAmmo:raise Reject('AMMO_CAPACITY_EXCEEDED')
    unload(v,rec,'shells')
    for signed,count in layout:
        if count:ensure(v,abs(signed),count,autobuy,signed<0)
    rec['shells']=[part for cd,n in layout for part in (abs(cd),n)]
    rec['shellsLayout']=list(values)

def equipment_slots(d,equipment_type):
    from items import ITEM_TYPES,vehicles
    slots=vehicles.g_cache.supplySlots().slotDescrs
    return [slots[sid] for sid in d.type.supplySlots.slotIDs if slots[sid].itemType==ITEM_TYPES.equipment and slots[sid].equipmentType==equipment_type]

def fit_equipment(v,vid,values,equipment_type=None,autobuy=False):
    from items import EQUIPMENT_TYPES
    if equipment_type is None:equipment_type=EQUIPMENT_TYPES.regular
    rec=row(v,vid);d=descriptor(rec);slots=equipment_slots(d,equipment_type)
    if len(values)>len(slots):raise Reject('TOO_MANY_EQUIPMENT_SLOTS')
    from items import EQUIPMENT_TYPES
    values=list(values)+[0]*(len(slots)-len(values));field='eqs' if equipment_type==EQUIPMENT_TYPES.regular else 'boosters'
    # Keep unsupported event abilities out of the ordinary garage.
    if equipment_type not in (EQUIPMENT_TYPES.regular,EQUIPMENT_TYPES.battleBoosters):raise Reject('UNSUPPORTED_EQUIPMENT_TYPE')
    nonzero=[abs(cd) for cd in values if cd]
    if len(nonzero)!=len(set(nonzero)):raise Reject('DUPLICATE_EQUIPMENT')
    for idx,signed in enumerate(values):
        if signed:
            cd=abs(signed)
            if item_type(number(cd,1))!=11:raise Reject('NOT_EQUIPMENT')
            native_allowed(slots[idx].checkSlotCompatibility(compDescr=cd))
    if equipment_type==EQUIPMENT_TYPES.regular:
        from items import vehicles
        descriptors=[vehicles.getItemByCompactDescr(cd) for cd in nonzero]
        for descr in descriptors:native_allowed(descr.checkCompatibilityWithVehicle(d))
        for i,descr in enumerate(descriptors):
            for j,other in enumerate(descriptors):
                if i!=j and (not other.checkCompatibilityWithActiveEquipment(descr) or not descr.checkCompatibilityWithEquipment(other)):
                    raise Reject('INCOMPATIBLE_EQUIPMENT_COMBINATION')
    unload(v,rec,field)
    for signed in values:
        if signed:ensure(v,abs(signed),1,autobuy,signed<0)
    rec[field]=[abs(cd) for cd in values];rec[field+'Layout']=list(values)

def set_fill(v,values):
    values=list(values)
    if len(values)<5:raise Reject('INVALID_FILL_REQUEST')
    vid=values[1];n=number(values[2],0,128);cursor=3+n
    if cursor+2>len(values):raise Reject('TRUNCATED_SHELL_LAYOUT')
    shells=values[3:cursor];etype=number(values[cursor]);m=number(values[cursor+1],0,128);cursor+=2
    if len(values)!=cursor+m:raise Reject('INVALID_EQUIPMENT_LAYOUT_LENGTH')
    if n:fit_shells(v,vid,shells,True)
    if m:
        equipment=[]
        for cd,count in pairs(values[cursor:]):
            if count not in (0,1):raise Reject('INVALID_EQUIPMENT_COUNT')
            equipment.append(cd if count else 0)
        # The 1.46 GUI sends regular slots followed by boosters, for EITHER edit.
        # Only the selected subtype is changed; the other segment is a snapshot.
        from items import EQUIPMENT_TYPES
        d=descriptor(row(v,vid));regular=len(equipment_slots(d,EQUIPMENT_TYPES.regular));boosters=len(equipment_slots(d,EQUIPMENT_TYPES.battleBoosters))
        if len(equipment)==regular+boosters:
            equipment=equipment[:regular] if etype==EQUIPMENT_TYPES.regular else equipment[regular:]
        fit_equipment(v,vid,equipment,etype,True)

def build_vehicle(catalog_row,crew=True,level=100):
    from items import tankmen
    rec=copy.deepcopy(catalog_row);d=descriptor(rec);nation,tid=[int(x) for x in rec['key'].split(':')]
    rec['crew']=[base64.b64encode(cd) for cd in tankmen.generateTankmen(nation,tid,d.type.crewRoles,False,level,0)] if crew else []
    rec['shells']=[];rec['shellsLayout']=[];rec['eqs']=[];rec['boosters']=[]
    return rec

def _command(v,cmd,args):
    import AccountCommands as C
    def iscmd(name):return cmd==getattr(C,name,None)
    arr=list(args[0]) if len(args)==1 and hasattr(args[0],'__iter__') and not isinstance(args[0],(basestring,dict)) else list(args)
    from . import customization,garage_ops,progression,crew
    for handler in (customization,progression,crew):
        name=next((name for name in handler.SUPPORTED if iscmd(name)),None)
        if name:return handler.command(v,name,args,arr)
    if iscmd('CMD_SELL_VEHICLE'):garage_ops.sell_vehicles(v,arr)
    elif iscmd('CMD_BUY_ITEM'):
        if len(args)!=4:raise Reject('INVALID_BUY_ARGS')
        buy(v,args[1],args[2],bool(number(args[3],0,1)))
    elif iscmd('CMD_SELL_ITEM'):
        if len(args)!=4:raise Reject('INVALID_SELL_ARGS')
        itype,inv,count=args[1:]
        if item_type(inv)==itype:cd=inv
        else:raise Reject('ITEM_TYPE_MISMATCH')
        sell(v,cd,count)
    elif iscmd('CMD_SELL_MULTIPLE_ITEMS'):
        if (len(arr)-1)%3:raise Reject('INVALID_MULTI_SELL')
        for i in range(1,len(arr),3):command(v,C.CMD_SELL_ITEM,[arr[0]]+arr[i:i+3])
    elif iscmd('CMD_EQUIP'):install_module(v,args[0],args[1],args[2])
    elif iscmd('CMD_EQUIP_OPTDEV'):
        if len(arr)!=8:raise Reject('INVALID_OPTDEV_ARGS')
        if arr[4]!=0:raise Reject('ALTERNATIVE_DEVICE_LAYOUT_NOT_IMPLEMENTED')
        install_device(v,arr[1],arr[2],arr[3],arr[6],arr[7])
    elif iscmd('CMD_EQUIP_OPT_DEVS_SEQUENCE'):
        if len(arr)<3 or len(arr)!=3+number(arr[2],0,16):raise Reject('INVALID_DEVICE_SEQUENCE')
        install_sequence(v,arr[1],arr[3:])
    elif iscmd('CMD_BUY_AND_EQUIP_ITEM'):
        if len(arr)!=6:raise Reject('INVALID_BUY_EQUIP_ARGS')
        rev,cd,vid,slot,mode,gun=arr;buy(v,cd)
        if item_type(cd)==3 and gun and gun!=descriptor(row(v,vid)).gun.compactDescr and not v.get('stock',{}).get(str(gun),0):buy(v,gun)
        if item_type(cd)==9:install_device(v,vid,cd,slot,mode)
        else:install_module(v,vid,cd,gun)
    elif iscmd('CMD_EQUIP_SHELLS'):fit_shells(v,arr[0],arr[1:])
    elif iscmd('CMD_EQUIP_EQS'):fit_equipment(v,arr[0],arr[1:])
    elif iscmd('CMD_SET_AND_FILL_LAYOUTS'):set_fill(v,arr)
    elif iscmd('CMD_REPAIR'):
        rec=row(v,args[0]);repair=rec.get('repair',[0,0]);charge(v,{'credits':number(repair[0])});rec['repair']=[0,0]
    elif iscmd('CMD_VEH_SETTINGS'):
        rec=row(v,args[0]);flag=number(args[1],1);on=number(args[2],0,1);rec['settings']=(rec.get('settings',0)|flag) if on else (rec.get('settings',0)&~flag)
    elif iscmd('CMD_SET_ACTIVE_VEH_SEASON'):
        from items.components.c11n_constants import SeasonType
        cd=number(args[0],1);season=number(args[1])
        if season not in SeasonType.RANGE and season!=SeasonType.UNDEFINED:raise Reject('INVALID_SEASON')
        if not any(r['typeCD']==cd for r in R.catalog()['vehicles']):raise Reject('UNKNOWN_VEHICLE_TYPE')
        v.setdefault('customizationDisplayType',{})[str(cd)]=season
    elif iscmd('CMD_ADD_INT_USER_SETTINGS'):
        if len(arr)%2:raise Reject('INVALID_SETTINGS_PAIRS')
        s=v.setdefault('intUserSettings',{})
        for i in range(0,len(arr),2):s[str(arr[i])]=arr[i+1]
    elif iscmd('CMD_DEL_INT_USER_SETTINGS'):
        for key in arr:v.setdefault('intUserSettings',{}).pop(str(key),None)
    elif iscmd('CMD_EXCHANGE'):
        gold=number(args[1],1);charge(v,{'gold':gold});v['wallet']['credits']+=gold*R.catalog()['shop']['exchangeRate']
    elif iscmd('CMD_BUY_SLOT'):
        from items.item_price import getNextSlotPrice
        slots=v.get('slots',100);cur,amount=getNextSlotPrice(slots,R.catalog()['shop']['slotsPrices']);charge(v,{cur:amount});v['slots']=slots+1
    elif iscmd('CMD_BUY_BERTHS'):
        from items.item_price import getNextBerthPackPrice
        packs=number(args[1],1,1000);berths=v.get('berths',100);prices=R.catalog()['shop']['berthsPrices'];cur,amount=getNextBerthPackPrice(berths,prices,packs*prices[1]);charge(v,{cur:amount});v['berths']=berths+packs*prices[1]
    elif iscmd('CMD_BUY_VEHICLE'):
        if len(arr)!=5:raise Reject('INVALID_BUY_VEHICLE_ARGS')
        rev,cd,flags,crew_cost,rent=arr
        if rent:raise Reject('RENT_NOT_IMPLEMENTED')
        existing=next((r for r in v['vehicles'].values() if r['typeCD']==cd),None)
        if existing is not None:
            if existing.get('visible',True):raise Reject('VEHICLE_ALREADY_OWNED')
            charge(v,cost(cd));existing['visible']=True;return {}
        if len(v['vehicles'])>=v.get('slots',100):raise Reject('NO_GARAGE_SLOT')
        match=next((r for r in R.catalog()['vehicles'] if r['typeCD']==cd),None)
        if match is None:raise Reject('UNKNOWN_VEHICLE')
        charge(v,cost(cd));crew=bool(flags&1);preset=R.catalog()['shop']['tankmanCost'][number(crew_cost,0,2)]
        rec=build_vehicle(match,crew,preset['roleLevel'])
        previous_ids=[int(i) for i in v['vehicles']]+[(int(tid)-100000)//100 for tid in v.get('barracks',{})]+[0]
        vid=max(max(previous_ids)+1,v.get('next_vehicle_id',1));v['next_vehicle_id']=vid+1
        if crew:charge(v,dict((k,preset.get(k,0)*len(rec['crew'])) for k in ('credits','gold')))
        v['vehicles'][str(vid)]=rec
        if flags&16:
            d=descriptor(rec);flat=[d.gun.shots[0].shell.compactDescr,d.gun.maxAmmo];fit_shells(v,vid,flat,True)
    elif iscmd('CMD_SELECT_BADGES'):
        from gui.doc_loaders.badges_loader import getAvailableBadges
        available=getAvailableBadges()
        if any(b and b not in available for b in arr) or len(arr)>2:raise Reject('INVALID_BADGES')
        layouts=[available[b].get('layout',0) for b in arr if b]
        if len(layouts)!=len(set(layouts)):raise Reject('DUPLICATE_BADGE_LAYOUT')
        v['badges']=[b for b in arr if b]
    elif iscmd('CMD_UPDATE_PLAYER_DOG_TAG'):
        from dog_tags_common.components_config import componentConfigAdapter
        if len(arr)!=2 or len(set(arr))!=2:raise Reject('INVALID_DOG_TAG')
        if any(i not in componentConfigAdapter.getAllComponents() for i in arr):raise Reject('UNKNOWN_DOG_TAG_COMPONENT')
        defaults=R.account_extra(v)['dogTags'];unlocked=defaults['unlockedComponents']
        if any(i not in unlocked for i in arr):raise Reject('DOG_TAG_COMPONENT_LOCKED')
        v['playerDogTag']=arr
    elif iscmd('CMD_SET_LANGUAGE'):v['language']=str(args[0])
    else:raise Reject('NOT_IMPLEMENTED_COMMAND_'+str(cmd))
    return {}

def command(v,cmd,args):
    from .loadouts import dispatch
    return dispatch(v,cmd,args,_command)

SUPPORTED=('CMD_EQUIP_OPT_DEVS_SEQUENCE','CMD_BUY_ITEM','CMD_SELL_ITEM','CMD_SELL_MULTIPLE_ITEMS','CMD_EQUIP','CMD_EQUIP_OPTDEV','CMD_BUY_AND_EQUIP_ITEM','CMD_EQUIP_SHELLS','CMD_EQUIP_EQS','CMD_SET_AND_FILL_LAYOUTS','CMD_REPAIR','CMD_VEH_SETTINGS','CMD_SET_ACTIVE_VEH_SEASON','CMD_ADD_INT_USER_SETTINGS','CMD_DEL_INT_USER_SETTINGS','CMD_EXCHANGE','CMD_BUY_SLOT','CMD_BUY_BERTHS','CMD_BUY_VEHICLE','CMD_SELECT_BADGES','CMD_UPDATE_PLAYER_DOG_TAG','CMD_SET_LANGUAGE')
from . import customization,garage_ops,progression,crew
from . import loadouts
SUPPORTED+=customization.SUPPORTED+garage_ops.SUPPORTED+progression.SUPPORTED+crew.SUPPORTED+loadouts.SUPPORTED

def execute(owner,cmd,args):
    # Native Avatar can issue int-user-setting commands as the HUD initializes.
    # Never transact garage state before discovering AvatarSyncData has no rev.
    if getattr(owner,'_hangar146_loading_avatar',False):raise Reject('GARAGE_COMMAND_REQUIRES_ACCOUNT')
    previous=getattr(getattr(owner,'syncData',None),'revision',None)
    if isinstance(previous,bool) or not isinstance(previous,(int,long)):raise Reject('INVALID_ACCOUNT_SYNC_REVISION')
    if getattr(owner,'_hangar146_refresh_failed',False):raise Reject('RESTART_REQUIRED_AFTER_REFRESH_FAILURE')
    p=R.state();old_values=copy.deepcopy(p.value);old=R.inventory()['inventory'];old_settings=dict(p.value.get('intUserSettings',{}))
    def mutation(v):
        result=command(v,cmd,args)
        # Native serialization/compatibility errors must occur BEFORE commit.
        R.inventory(v)
        return result
    result=p.transact(mutation)
    if cmd in (getattr(__import__('AccountCommands'),'CMD_BUY_VEHICLE',None),getattr(__import__('AccountCommands'),'CMD_SELL_VEHICLE',None)):
        try:
            from . import ownership
            ownership.sync(p.value)
        except Exception:
            from .logging import LOG_ERROR
            import traceback
            LOG_ERROR('Profile committed, but roster file could not be updated:',traceback.format_exc())
    new=R.inventory()['inventory']
    # Incremental diffs with explicit tombstones preserve the modern caches.
    def delta(a,b):
        out={}
        for key in set(a)|set(b):
            if key not in b:out[key]=None
            elif key not in a:out[key]=copy.deepcopy(b[key])
            elif isinstance(a[key],dict) and isinstance(b[key],dict):
                diff=delta(a[key],b[key])
                if diff:out[key]=diff
            elif a[key]!=b[key]:out[key]=copy.deepcopy(b[key])
        return out
    changed_stats=dict((k,n) for k,n in p.value['wallet'].items() if old_values['wallet'].get(k,0)!=n)
    for field in ('slots','berths'):
        if old_values.get(field,100)!=p.value.get(field,100):changed_stats[field]=p.value.get(field,100)
    diff={'rev':previous+1,'prevRev':previous,'inventory':delta(old,new),'stats':changed_stats}
    diff['intUserSettings']=delta(dict((int(k),v) for k,v in old_settings.items()),dict((int(k),v) for k,v in p.value.get('intUserSettings',{}).items()))
    extra=R.account_extra(p.value);extra.pop('intUserSettings',None)
    previous_extra=R.account_extra(old_values);previous_extra.pop('intUserSettings',None)
    diff.update(delta(previous_extra,extra))
    changed_xp=dict((rec['typeCD'],rec.get('xp',0)) for key,rec in p.value['vehicles'].items() if old_values['vehicles'].get(key,{}).get('xp',0)!=rec.get('xp',0))
    if changed_xp:diff['stats']['vehTypeXP']=changed_xp
    if set(old_values['vehicles'])!=set(p.value['vehicles']):diff['stats']['vehicleSellsLeft']=100000
    try:
        if owner._update(True,diff) is False:raise Reject('REVISION_REJECTED')
    except Exception:
        from .logging import LOG_ERROR
        import traceback
        LOG_ERROR('Native inventory refresh failed:',traceback.format_exc())
        owner._hangar146_refresh_failed=True
        raise Reject('COMMITTED_REFRESH_FAILED_RESTART_REQUIRED')
    return result
