# -*- coding: utf-8 -*-
"""Map-cache spawn planning, finite terrain support and conservative footprint clearance."""
from __future__ import absolute_import
import math


def point2(value):
    result=(float(value[0]),float(value[1]))
    if any(math.isnan(x) or math.isinf(x) for x in result):raise ValueError('Nonfinite map coordinate')
    return result


def bases(arena):
    result=[]
    for team in (0,1):
        values=getattr(arena,'teamBasePositions',())[team]
        points=[point2(p) for k,p in sorted(values.items())]
        if not points:raise ValueError('Selected CTF map has no base for team %d'%(team+1))
        result.append(points)
    return result


def footprint(descr):
    from .client_bounds import part_bounds
    boxes=[part_bounds(part) for part in (descr.chassis,descr.hull)]
    chassis,hull=boxes
    shift=descr.chassis.hullPosition
    low=tuple(min(chassis[0][i],hull[0][i]+float(shift[i])) for i in range(3))
    high=tuple(max(chassis[1][i],hull[1][i]+float(shift[i])) for i in range(3))
    if any(not 0.1<high[i]-low[i]<30. for i in range(3)):raise ValueError('Invalid collision dimensions')
    return low,high


def corners(x,z,yaw,box):
    lo,hi=box;s,c=math.sin(yaw),math.cos(yaw)
    return [(x+u*c+v*s,z-u*s+v*c) for u,v in ((lo[0],lo[2]),(hi[0],lo[2]),(hi[0],hi[2]),(lo[0],hi[2]))]


def separated(a,b,gap=2.):
    # Minkowski padding: each rectangle is expanded by gap/2 in each direction.
    # SAT handles unequal dimensions and opposite headings, not just centers.
    for poly in (a,b):
        for i in (0,1):
            dx=poly[(i+1)%4][0]-poly[i][0];dz=poly[(i+1)%4][1]-poly[i][1]
            length=math.hypot(dx,dz)
            if length<=0:raise ValueError('Degenerate footprint')
            axis=(-dz/length,dx/length)
            pa=[p[0]*axis[0]+p[1]*axis[1] for p in a]
            pb=[p[0]*axis[0]+p[1]*axis[1] for p in b]
            if max(pa)+gap<=min(pb) or max(pb)+gap<=min(pa):return True
    return False


def outside_base(poly,center,radius=5.):
    # Reject intersection of the entire footprint with the forbidden base disk.
    cx,cz=center
    signs=[]
    for i,(x,z) in enumerate(poly):
        nx,nz=poly[(i+1)%4];dx,dz=nx-x,nz-z
        signs.append(dx*(cz-z)-dz*(cx-x))
        t=max(0.,min(1.,((cx-x)*dx+(cz-z)*dz)/(dx*dx+dz*dz)))
        if math.hypot(x+t*dx-cx,z+t*dz-cz)<radius:return False
    return not (all(v>=0 for v in signs) or all(v<=0 for v in signs))


def candidates(arena,team,base,rng):
    points=[point2(p) for p in getattr(arena,'teamSpawnPoints',((),()))[team-1]]
    rng.shuffle(points)
    for p in points:yield p
    # No hard-coded map coordinates. Search around the configured own base.
    phase=rng.random()*math.pi*2
    for radius in (12.,18.,25.,35.,50.,70.):
        for i in range(32):
            angle=phase+i*math.pi/16
            yield base[0]+math.sin(angle)*radius,base[1]+math.cos(angle)*radius


def support(x,z,yaw,box,ground,rotate):
    poly=corners(x,z,yaw,box);heights=[ground(px,pz) for px,pz in poly]
    if any(h is None for h in heights):return
    lo,hi=box;width=hi[0]-lo[0];length=hi[2]-lo[2]
    left=(heights[0]+heights[3])*.5;right=(heights[1]+heights[2])*.5
    back=(heights[0]+heights[1])*.5;front=(heights[2]+heights[3])*.5
    pitch=-math.atan2(front-back,length);roll=math.atan2(right-left,width)
    if max(abs(pitch),abs(roll))>math.radians(20):return
    # Reject a step/ditch under the tank rather than make it float on one corner.
    residual=abs((heights[0]+heights[2])-(heights[1]+heights[3]))*.5
    center=ground(x,z)
    if center is None or residual>.22 or abs(center-sum(heights)*.25)>.3:return
    offsets=[rotate((u,lo[1],v),(yaw,pitch,roll)) for u,v in ((lo[0],lo[2]),(hi[0],lo[2]),(hi[0],hi[2]),(lo[0],hi[2]))]
    # Resample tilted contact coordinates; avoid an uphill rotated corner clipping.
    adjusted=[ground(x+v[0],z+v[2]) for v in offsets]
    if any(h is None for h in adjusted):return
    y=max(h-v[1] for h,v in zip(adjusted,offsets))+.025
    return dict(position=(x,y,z),yaw=yaw,pitch=pitch,roll=roll,footprint=poly,bounds=box)


def plan(arena,descriptors,ground,rotate,free,rng):
    team_bases=bases(arena);used=[];result=[]
    low,high=[point2(p) for p in arena.boundingBox]
    for index,descr in enumerate(descriptors):
        team=1 if index==0 else 2;home=team_bases[team-1][0];enemy=team_bases[2-team][0]
        box=footprint(descr);chosen=None
        for x,z in candidates(arena,team,home,rng):
            yaw=math.atan2(enemy[0]-x,enemy[1]-z)
            poly=corners(x,z,yaw,box)
            if not all(low[0]<px<high[0] and low[1]<pz<high[1] for px,pz in poly):continue
            if not all(outside_base(poly,b) for group in team_bases for b in group):continue
            if not all(separated(poly,old) for old in used):continue
            pose=support(x,z,yaw,box,ground,rotate)
            if pose is None or not free(pose):continue
            chosen=pose;break
        if chosen is None:raise ValueError('No collision-safe supported spawn for team %d slot %d'%(team,index))
        chosen.update(team=team,index=index);used.append(chosen['footprint']);result.append(chosen)
    return result
