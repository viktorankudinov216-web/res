# -*- coding: utf-8 -*-
"""Effective 1.46 CTF map validation; no account/economy imports."""
from __future__ import absolute_import
# Exact 1.46 gui.battle_control.arena_info.settings resource path.
def resource_exists(path):
    import ResMgr
    return bool(ResMgr.isFile(path))


SCREEN_PREVIEW_PATH='gui/maps/icons/map/screen/%s.dds'


def validate_map(arena,exists):
    """Validate the effective 1.46 cache, not a whitelist of map names."""
    from .spawn146 import bases,point2
    if getattr(arena,'gameplayName','')!='ctf':raise ValueError('NOT_CTF')
    if getattr(arena,'isDevelopment',False):raise ValueError('DEVELOPMENT_ARENA')
    name=arena.geometryName
    geometry=getattr(arena,'geometry','spaces/'+name).replace('\\','/').rstrip('/')
    if not geometry.startswith('spaces/') or '..' in geometry.split('/'):raise ValueError('INVALID_GEOMETRY_PATH')
    teams=getattr(arena,'teamBasePositions',())
    if len(teams)!=2:raise ValueError('TWO_TEAMS_REQUIRED')
    team_bases=bases(arena) # Reject empty/NaN/malformed bases BEFORE queuing.
    lo,hi=[point2(p) for p in arena.boundingBox]
    if not lo[0]<hi[0] or not lo[1]<hi[1]:raise ValueError('INVALID_ARENA_BOUNDS')
    for points in team_bases:
        for x,z in points:
            if not lo[0]<=x<=hi[0] or not lo[1]<=z<=hi[1]:raise ValueError('BASE_OUTSIDE_BOUNDS')
    spawns=getattr(arena,'teamSpawnPoints',((),()))
    if len(spawns)!=2:raise ValueError('INVALID_TEAM_SPAWNS')
    for points in spawns:
        for p in points:point2(p)
    if not exists(geometry+'/space.settings'):raise ValueError('SPACE_SETTINGS_MISSING')
    if not exists(SCREEN_PREVIEW_PATH%name):raise ValueError('MAP_PREVIEW_MISSING')
    return geometry

