# -*- coding: utf-8 -*-
"""A CTF loading-stage plan. No Vehicle entities, geometry, AI or damage yet."""
from __future__ import absolute_import
import base64,copy,time
from .economy import Reject,descriptor
from . import runtime_data as R
from .utils import local_session_id
EXCLUDED_BOT_TAGS={'SPG','observer','event_battles','epic_battles','battle_royale','comp7','maps_training','fun_random','mode_hidden'}

from .map146 import validate_map,resource_exists

def team_for_slot(index):
    return 1 if index==0 else 2

def available_maps(arena_cache,exists,diagnostics=None):
    candidates={};skipped=[]
    for aid,arena in sorted(arena_cache.items()):
        if getattr(arena,'gameplayName','')!='ctf':continue
        name=arena.geometryName
        try:geometry=validate_map(arena,exists)
        except (ValueError,TypeError,AttributeError,IndexError,KeyError) as error:
            skipped.append(name)
            if diagnostics is not None:diagnostics.append({'map':name,'arenaTypeID':int(aid),'reason':str(error)})
            continue
        candidates.setdefault(name,{'arenaTypeID':int(aid),'map':name,'geometry_path':geometry,'title':getattr(arena,'name',name)})
    if not candidates:raise Reject('NO_INSTALLED_CTF_MAPS')
    return sorted(candidates.values(),key=lambda m:m['map']),sorted(set(skipped)-set(candidates))

def prepare(vid,rng):
    import ArenaType,ResMgr
    rec=R.state().value['vehicles'].get(str(vid))
    if not rec or not rec.get('visible',True):raise Reject('VEHICLE_NOT_OWNED_OR_HIDDEN')
    if 'SPG' in rec.get('tags',[]):raise Reject('ARTILLERY_DISABLED_FOR_LOCAL_CTF')
    if rec.get('repair',[0,0])[0]:raise Reject('VEHICLE_REPAIR_REQUIRED')
    d=descriptor(rec)
    if len(rec.get('crew',[]))!=len(d.type.crewRoles) or not all(rec['crew']):raise Reject('FULL_CREW_REQUIRED')
    rejections=[]
    maps,skipped=available_maps(ArenaType.g_cache,resource_exists,rejections)
    choice=copy.deepcopy(rng.choice(maps));taken={rec['typeCD']};descs={rec['compactDescr_b64']}
    rows=[r for r in R.catalog()['vehicles'] if not set(r.get('tags',())) & EXCLUDED_BOT_TAGS and r['typeCD'] not in taken]
    rng.shuffle(rows);rows.sort(key=lambda r:abs(r['level']-rec['level']))
    bots=[];errors=[]
    for row in rows:
        if row['typeCD'] in taken or row['compactDescr_b64'] in descs:continue
        try:
            native=descriptor(row)
            if set(native.type.tags) & EXCLUDED_BOT_TAGS:continue
            from .battle_loadout146 import supported
            if not supported(native):continue
            raw=native.makeCompactDescr()
            if not raw:continue
        except Exception as error:
            errors.append({'typeCD':row['typeCD'],'error':type(error).__name__});continue
        bot=copy.deepcopy(row);bot['compactDescr_b64']=base64.b64encode(raw)
        if bot['compactDescr_b64'] in descs:continue
        taken.add(row['typeCD']);descs.add(bot['compactDescr_b64']);bots.append(bot)
        if len(bots)==1:break
    if len(bots)!=1:raise Reject('ONE_NON_SPG_OPPONENT_UNAVAILABLE')
    plan=dict(choice,roundID=int(time.time()*1000),gameplay='ctf',playerVehicleID=900001,
              player=copy.deepcopy(rec),bots=bots,installed_ctf_maps=[m['map'] for m in maps],skipped_maps=skipped,map_rejections=rejections,
              rejected_bot_descriptors=errors[:20],geometry_loaded=False,combat_enabled=False)
    from CurrentVehicle import g_currentVehicle
    from .battle_loadout146 import capture_player
    plan['player']['battle_loadout']=capture_player(g_currentVehicle.item,plan['player'],vid)
    from .battle_state146 import outfit_snapshot
    plan['player']['outfit_b64']=outfit_snapshot(R.state().value,rec,ArenaType.g_cache[choice['arenaTypeID']])
    return plan

def roster(plan,player_name,dbid):
    from .progression import ext
    result=[]
    for index,rec in enumerate([plan['player']]+plan['bots']):
        d=descriptor(rec);extra=ext(rec) if index==0 else {}
        hp=getattr(d,'maxHealth',None) or getattr(d.type,'maxHealth',1)
        name=player_name if index==0 else 'LocalBot_%d'%index
        # Exact 1.46 ClientArena.__vehicleInfoAsDict field order, length 30.
        info=((plan['entityIDs'][index] if 'entityIDs' in plan else 900001+index),base64.b64decode(rec['compactDescr_b64']),name,
              team_for_slot(index),True,False,False,dbid if index==0 else 0,
              '',0,0,False,True,{},0,[],{},None,'',local_session_id(plan['roundID'],dbid) if index==0 else '',
              0,'',[],0,int(hp),extra.get('vehPostProgression',[]),extra.get('customRoleSlotTypeId',0),0,0,0)
        result.append(info)
    return result
