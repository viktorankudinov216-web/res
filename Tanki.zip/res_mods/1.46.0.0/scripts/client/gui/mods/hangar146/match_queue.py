# -*- coding: utf-8 -*-
from __future__ import absolute_import
import random,time
from .economy import Reject,number

class MatchQueue(object):
    def __init__(self,owner,schedule,cancel,prepare,enter,rng=None):
        self.owner=owner;self.schedule=schedule;self.cancel=cancel;self.prepare=prepare;self.enter=enter
        self.rng=rng or random.Random();self.state='idle';self.generation=0;self.timer=None;self.plan=None;self.wait=None
    def enqueue(self,args):
        from constants import QUEUE_TYPE
        if len(args)!=5 or args[0]!=QUEUE_TYPE.RANDOMS:raise Reject('ONLY_RANDOM_CTF_QUEUE_SUPPORTED')
        if self.state=='queued':return {}
        if self.state!='idle':raise Reject('MATCH_ALREADY_LOADING')
        vid=number(args[1],1)
        from .queue_probe import mark
        mark('plan_prepare_before',vehicle=vid)
        plan=self.prepare(vid,self.rng)
        mark('plan_prepare_after',map=plan.get('map'),bots=len(plan['bots']))
        self.generation+=1;token=self.generation;self.plan=plan;self.state='queued'
        self.wait=self.rng.uniform(5.,15.);self.owner.onEnqueued(QUEUE_TYPE.RANDOMS)
        def finish():
            if self.state!='queued' or self.generation!=token:return
            self.timer=None;self.state='loading'
            # Match found is NOT a cancellation: onDequeued opens the hangar.
            mark('match_found_handoff',map=plan.get('map'))
            self.schedule(0.1,lambda:self.enter(plan) if self.state=='loading' and self.generation==token else None)
        self.timer=self.schedule(self.wait,finish)
        mark('queue_timer_started',seconds=self.wait)
        return {}
    def dequeue(self,args):
        from constants import QUEUE_TYPE
        if len(args)!=1 or args[0]!=QUEUE_TYPE.RANDOMS:raise Reject('INVALID_DEQUEUE_TYPE')
        if self.state!='queued':return {}
        self.generation+=1
        if self.timer is not None:self.cancel(self.timer)
        self.timer=None;self.state='idle';self.plan=None;self.owner.onDequeued(QUEUE_TYPE.RANDOMS);return {}
    def info(self,args):
        from constants import QUEUE_TYPE,VEHICLE_CLASS_INDICES
        if len(args)!=3 or args[0]!=QUEUE_TYPE.RANDOMS:raise Reject('INVALID_QUEUE_INFO_TYPE')
        classes=[0]*(max(VEHICLE_CLASS_INDICES.values())+1)
        if self.plan:
            for row in [self.plan['player']]+self.plan['bots']:
                for tag,index in VEHICLE_CLASS_INDICES.items():
                    if tag in row.get('tags',[]):classes[index]+=1;break
        self.owner.receiveQueueInfo({'classes':classes});return {}
    def stop(self):
        self.generation+=1
        if self.timer is not None:self.cancel(self.timer)
        self.timer=None;self.state='idle';self.plan=None

_CURRENT=None

def register():
    import AccountCommands as C,BigWorld
    from .server import BASE_REQUESTS
    from . import native_match,match_plan
    def handler(command):
        def call(requestID,*args):
            global _CURRENT
            owner=BigWorld.player()
            if _CURRENT is None or _CURRENT.owner is not owner:
                if _CURRENT is not None:_CURRENT.stop()
                _CURRENT=MatchQueue(owner,BigWorld.callback,BigWorld.cancelCallback,match_plan.prepare,lambda plan:native_match.begin(owner,plan))
            values=list(args[0]) if len(args)==1 and isinstance(args[0],(list,tuple)) else list(args)
            if command==C.CMD_ENQUEUE_IN_BATTLE_QUEUE:
                try:result=_CURRENT.enqueue(values)
                except Exception as error:
                    from constants import QUEUE_TYPE
                    owner.onEnqueueFailure(QUEUE_TYPE.RANDOMS,C.RES_FAILURE,str(error))
                    raise
            elif command==C.CMD_DEQUEUE_FROM_BATTLE_QUEUE:result=_CURRENT.dequeue(values)
            else:result=_CURRENT.info(values)
            return requestID,C.RES_SUCCESS,'',result
        return call
    for command in (C.CMD_ENQUEUE_IN_BATTLE_QUEUE,C.CMD_DEQUEUE_FROM_BATTLE_QUEUE,C.CMD_REQ_QUEUE_INFO):BASE_REQUESTS[command]=handler(command)

def stop():
    global _CURRENT
    if _CURRENT is not None:_CURRENT.stop();_CURRENT=None
