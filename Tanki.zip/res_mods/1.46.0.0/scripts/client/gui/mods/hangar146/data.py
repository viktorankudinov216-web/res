# -*- coding: utf-8 -*-
def getOfflineInventory():
    from gui.mods.hangar146.runtime_data import inventory
    return inventory()

def getOfflineShop():
    from gui.mods.hangar146.runtime_data import shop
    return shop()

def getOfflineStats():
    from gui.mods.hangar146.runtime_data import catalog, state
    unlocksSet = set(catalog()['prices'])
    vehiclesSet = set(row['typeCD'] for row in catalog()['vehicles'])
    from constants import ACCOUNT_ATTR
    # Native selector locks random battles independently of Vehicle readiness.
    attrs = ACCOUNT_ATTR.RANDOM_BATTLES
    vehTypeXP = {i: 0 for i in vehiclesSet}
    result = {
        'stats': {
            'crystalExchangeRate': 200, 'berths': 40000, 'accOnline': 0, 'gold': 10000000, 'crystal': 10000000,
            'finPswdAttemptsLeft': 0, 'denunciationsLeft': 0, 'freeVehiclesLeft': 0, 'refSystem': {'referrals': {}},
            'slots': 1000, 'battlesTillCaptcha': 0, 'hasFinPassword': True, 'clanInfo': (None, None, 0, 0, 0),
            'unlocks': unlocksSet, 'freeTMenLeft': 0, 'vehicleSellsLeft': 100000, 'SPA': {'/common/goldfish_bonus_applied/': '1'},
            'vehTypeXP': vehTypeXP, 'globalVehicleLocks': {}, 'freeXP': 10000000, 'captchaTriesLeft': 0, 'fortResource': 0,
            'tkillIsSuspected': False, 'credits': 100000000, 'vehTypeLocks': {}, 'dailyPlayHours': [0], 'restrictions': {},
            'accOffline': 0, 'dossier': '', 'multipliedXPVehs': {}, 'tutorialsCompleted': 33553532, 'eliteVehicles': vehiclesSet,
            'playLimits': ((86400, ''), (604800, '')),
        },
        'account': {'clanDBID': 0, 'attrs': attrs, 'premiumExpiryTime': 8000, 'autoBanTime': 0, 'globalRating': 0},
        'cache': {'isFinPswdVerified': True, 'mayConsumeWalletResources': True, 'unitAcceptDeadline': 0, 'oldVehInvIDs': ()},
    }
    from . import bonds
    result['stats']['weeklyVehicleCrystals']=bonds.stats(state().value)
    result['stats'].update(state().wallet())
    result['stats']['slots'] = state().value.get('slots',100)
    result['stats']['berths'] = state().value.get('berths',100)
    result['stats']['hasFinPassword'] = False
    for rec in state().value['vehicles'].values():result['stats']['vehTypeXP'][rec['typeCD']]=rec.get('xp',0)
    from .runtime_data import account_extra
    result.update(account_extra())
    return result

def getOfflineQuestsProgress():
    return {
        'tokens': {},
        'pmQuestsStates': {},
        'cache': {'pmQuestsStates': {}},
        'personalMissionQuests': {
            'regular': {'selected': [], 'slots': 0, 'lastIDs': {}},
            'pm2': {'selected': [], 'slots': 0, 'lastIDs': {}},
            'pm3': {'selected': [], 'slots': 0, 'lastIDs': {}},
        },
        'pm_progress': {},
        'potapovQuests': {
            'compDescr': '',
            'regular': {'tiles': set(), 'rewards': {}, 'compDescr': '', 'selected': {1, 17, 31, 46, 61}, 'lastIDs': {}, 'slots': 2},
            'fallout': {'tiles': set(), 'rewards': {}, 'compDescr': '', 'selected': {301, 401}, 'lastIDs': {}, 'slots': 2},
        },
        'quests': {},
    }