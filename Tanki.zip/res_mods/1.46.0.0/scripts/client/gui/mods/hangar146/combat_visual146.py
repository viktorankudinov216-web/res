# -*- coding: utf-8 -*-
"""Local-only 1.46 appearance lifecycle, hit feedback and drivetrain inputs.

No proxy replaces a native filter. No nearest-point snapping or global RTPCs.
"""
from __future__ import absolute_import
import math,weakref,time

def pin_filter(vehicle):
    app=getattr(vehicle,'appearance',None)
    if app is None:return None
    native=app.filter
    if native is None or not callable(getattr(native,'setVehiclePhysics',None)):
        raise RuntimeError('Appearance has no native VehicleFilter')
    if vehicle.filter is not native:vehicle.filter=native
    app._CompoundAppearance__originalFilter=native
    return native

def prepare_native_refresh(vehicle):
    """Keep the filter attached and give reset/syncGunAngles a real owner.

    Names/initialisation are copied from 1.46 Vehicle.__startPhysics, NOT
    the 1.23 WG* constructors. staticMode prevents a second motion authority.
    """
    import BigWorld,physics_shared
    native=pin_filter(vehicle)
    if native is None:return
    cached=getattr(vehicle,'_hangar146_refresh_physics',None)
    if cached is not None and cached[0] is native:return
    descr=vehicle.typeDescriptor
    body=BigWorld.WheeledPhysics() if descr.type.isWheeledVehicle else BigWorld.TankPhysics()
    physics_shared.initVehiclePhysicsClient(body,descr)
    body.setArenaBounds((-10000,-10000),(10000,10000))
    body.owner=weakref.ref(vehicle);body.staticMode=True;body.movementSignals=0
    native.setVehiclePhysics(body)
    vehicle._hangar146_refresh_physics=(native,body)

def install():
    from vehicle_systems.CompoundAppearance import CompoundAppearance
    from .utils import override
    from . import native_match as N
    def make_guard(refresh):
        def guarded(base,app,*args,**kwargs):
            vehicle=getattr(app,'_vehicle',None)
            if vehicle is None or not getattr(vehicle,'_hangar146_vehicle',False):return base(app,*args,**kwargs)
            try:prepare_native_refresh(vehicle)
            except Exception:
                import traceback
                N.mark('native_model_refresh_blocked',vehicle_id=vehicle.id,warning=traceback.format_exc())
                # A Python failure must NOT fall through into the known C++ AV.
                return None
            N.mark('native_model_refresh_guarded',vehicle_id=vehicle.id,filter_pinned=app._CompoundAppearance__originalFilter is vehicle.filter,physics_class=type(vehicle._hangar146_refresh_physics[1]).__name__)
            result=refresh_models_local(app,*args,**kwargs) if refresh else base(app,*args,**kwargs)
            runtime=getattr(vehicle,'_hangar146_combat_runtime',None)
            if runtime is not None and getattr(app,'_vehicle',None) is vehicle:
                runtime.rebind_model(vehicle)
                N.mark('native_model_refresh_complete',vehicle_id=vehicle.id)
            return result
        return guarded
    override(CompoundAppearance,'_CompoundAppearance__onModelsRefresh')(make_guard(True))
    override(CompoundAppearance,'deactivate')(make_guard(False))

def swing_edge(flags,previous):
    if (flags&3)^(previous&3):return (2.,-1. if flags&1 else 1. if flags&2 else 0.)
    if not flags&3 and (flags&12)^(previous&12):return (1.,0.)
    return None

def bind_motion(vehicle,actor,matrix):
    import Math
    app=vehicle.appearance
    if actor.health<=0:
        actor._swing_animator=None;actor._engine_state=None;return
    animator=getattr(app,'swingingAnimator',None)
    if animator is not None and animator is not getattr(actor,'_swing_animator',None):
        identity=Math.Matrix();identity.setIdentity()
        actor._swing_compensation=identity;actor._swing_animator=animator
        animator.placingCompensationMatrix=identity;animator.worldMatrix=matrix
    state=getattr(app,'detailedEngineState',None)
    if state is not None and state is not getattr(actor,'_engine_state',None):
        # Stock 1.46 fields accept callables; relative physics RPM is 0..1.
        state.vehicleSpeedLink=lambda:a_speed(actor)
        state.rotationSpeedLink=lambda:actor.omega
        state.physicRPMLink=lambda:getattr(actor,'audio_rpm',0.)
        state.physicGearLink=lambda:getattr(actor,'audio_gear',0)
        state.vehicleMatrixLink=app.compoundModel.root
        actor._engine_state=state

def a_speed(actor):return actor.v

def update_motion(vehicle,actor,dt):
    app=vehicle.appearance
    if actor.health<=0:actor.audio_rpm=0.;actor.audio_gear=0;return
    flags=actor.flags&15;previous=getattr(actor,'_swing_flags',0);actor._swing_flags=flags
    animator=getattr(app,'swingingAnimator',None)
    edge=swing_edge(flags,previous)
    if edge is not None and animator is not None and not hasattr(actor,'rigid'):
        animator.accelSwingingDirection=edge[1]
        animator.accelSwingingPeriod=max(float(animator.accelSwingingPeriod),edge[0])
    maximum=max(1.,actor.params['speedFwd'] if actor.v>=0 else actor.params['speedBwd'])
    fraction=min(1.,abs(actor.v)/maximum)
    driving=bool(flags&3) or abs(actor.omega)>.01
    desired=max(.2+.75*fraction,.58 if driving else 0.)
    alpha=1.-math.exp(-max(0.,dt)/.18)
    actor.audio_rpm=getattr(actor,'audio_rpm',.2)+(desired-getattr(actor,'audio_rpm',.2))*alpha
    actor.audio_gear=(-1 if actor.v<-.15 else min(6,1+int(fraction*5.)) if actor.v>.15 else 0)

def clip_segment(start,end,minimum,maximum):
    """Clip the actual component-local ray to its bbox; no surface snapping."""
    lo,hi=0.,1.
    for i in range(3):
        delta=end[i]-start[i]
        if abs(delta)<1e-12:
            if not minimum[i]-1e-8<=start[i]<=maximum[i]+1e-8:return None
        else:
            a=(minimum[i]-start[i])/delta;b=(maximum[i]-start[i])/delta
            lo=max(lo,min(a,b));hi=min(hi,max(a,b))
            if lo>hi:return None
    return (tuple(start[i]+(end[i]-start[i])*lo for i in range(3)),tuple(start[i]+(end[i]-start[i])*hi for i in range(3)))

def encode_segment(component,effect,start,end,minimum,maximum):
    clipped=clip_segment(start,end,minimum,maximum)
    if clipped is None:return None
    code=int(effect)&255|((int(component)&255)<<8)
    packed=[]
    for point in clipped:
        for i in range(3):
            span=maximum[i]-minimum[i]
            packed.append(max(0,min(255,int(round((point[i]-minimum[i])*255./span)))) if span>1e-10 else 0)
    if packed[:3]==packed[3:]:return None
    for i,value in enumerate(packed):code|=long(value)<<(16+i*8)
    return code

def hit_feedback(vehicle,shot,contact,start,end,damage):
    import Math
    from constants import VEHICLE_HIT_EFFECT
    from VehicleEffects import DamageFromShotDecoder as Decoder
    from vehicle_systems.tankStructure import TankPartIndexes
    runtime=getattr(vehicle,'_hangar146_combat_runtime',None)
    def timed(label,call,*args):
        before=time.clock()
        try:return call(*args)
        finally:
            elapsed=(time.clock()-before)*1000.
            if runtime is not None and elapsed>8.:
                runtime.s.mark('shot_slow_stage',stage_name=label,elapsed_ms=elapsed,victim_id=vehicle.id)
    component=int(contact['component']);name=TankPartIndexes.getName(component)
    if not name:return False
    app=vehicle.appearance;collisions=app.collisions
    if collisions is None:return False
    node=app.compoundModel.node(name)
    if node is None:return False
    inverse=Math.Matrix(node);inverse.invert()
    local_start=inverse.applyPoint(Math.Vector3(*start));local_end=inverse.applyPoint(Math.Vector3(*end))
    effect=(VEHICLE_HIT_EFFECT.ARMOR_PIERCED if contact['result']==2 else VEHICLE_HIT_EFFECT.FINAL_RICOCHET if contact['result']==0 else VEHICLE_HIT_EFFECT.ARMOR_NOT_PIERCED)
    converted=Decoder.convertComponentIndex(component,vehicle.typeDescriptor)
    bbox=collisions.getBoundingBox(converted)
    segment=encode_segment(component,effect,tuple(local_start),tuple(local_end),tuple(bbox[0]),tuple(bbox[1]))
    if segment is None:return False
    decoded=timed('decodeSegment',Decoder.decodeSegment,segment,collisions,vehicle.calcMaxComponentIdx(),vehicle.typeDescriptor)
    if decoded[0]<0:return False
    # Reject an incorrectly quantised/translated ray rather than placing a hole
    # on the nearest unrelated surface (the troublesome 1.23 fallback).
    distance=timed('collideLocal',collisions.collideLocal,converted,decoded[2],decoded[3])
    if distance is None or distance<0.:return False
    nominal=max(1.,float(shot['type'].shell.damage[0]))
    timed('native_showDamageFromShot',vehicle.showDamageFromShot,int(shot['actor']),[segment],int(shot['type'].shell.effectsIndex),min(1.,max(0.,damage/nominal)),contact['layer']=='external')
    # Chassis/track hits must not be remapped to a hull sticker.
    if component in (TankPartIndexes.HULL,TankPartIndexes.TURRET,TankPartIndexes.GUN):
        stickers=list(getattr(vehicle,'damageStickers',()) or ())
        if segment not in stickers:
            stickers.append(segment);vehicle.damageStickers=stickers[-100:];timed('native_damageStickers',vehicle.set_damageStickers)
    return True


def set_safe_gun_angles(appearance,yaw,pitch):
    """Static postmortem gun matrices; no BWConnection gun-history clock."""
    import Math
    class Targets(object):pass
    targets=Targets();targets.turretMatrix=Math.Matrix();targets.gunMatrix=Math.Matrix()
    targets.turretMatrix.setRotateYPR((yaw,0.,0.));targets.gunMatrix.setRotateYPR((0.,pitch,0.))
    appearance._vehicle._hangar146_dead_gun_targets=targets
    appearance.setupGunMatrixTargets(targets)

def refresh_models_local(self, modelState, resourceList):
    # Exact 1.46 refresh sequence, except offline gun-angle binding below.
    import BigWorld,Math,GenericComponents,logging
    from vehicle_systems import model_assembler
    from vehicle_systems.CompoundAppearance import CompoundHolder
    from items.components.component_constants import MAIN_TRACK_PAIR_IDX
    _logger=logging.getLogger(__name__)
    if not self.damageState.isCurrentModelDamaged:
        _logger.error('Current model is not damaged. Wrong refresh request!')
    if modelState != self.damageState.modelState:
        _logger.error('Required modelState differs from actual one. Wrong refresh request!')
    if self._vehicle is None:
        return
    else:
        self.highlighter.highlight(False)
        if self.tracks is not None:
            self.tracks.reset()
        if self.trackScrollController is not None:
            self.trackScrollController.deactivate()
            self.trackScrollController.setData(None)
        oldHolder = self.findComponentByType(CompoundHolder)
        if oldHolder is not None:
            self.gameObject.removeComponent(oldHolder)
        holder = self.gameObject.createComponent(CompoundHolder, self._vehicle.model)
        self.gameObject.removeComponent(holder)
        prevTurretYaw = Math.Matrix(self.turretMatrix).yaw
        prevGunPitch = Math.Matrix(self.gunMatrix).pitch
        newCompoundModel = resourceList[self.typeDescriptor.name]
        isRightSideFlying = self.isRightSideFlying
        isLeftSideFlying = self.isLeftSideFlying
        self._vehicle.filter = self._CompoundAppearance__originalFilter
        self.filter.reset()
        self.shadowManager.reattachCompoundModel(self._vehicle, self.compoundModel, newCompoundModel)
        if self._CompoundAppearance__inSpeedTreeCollision:
            BigWorld.setSpeedTreeCollisionBody(None)
            self._CompoundAppearance__inSpeedTreeCollision = False
        self._compoundModel = newCompoundModel
        self.removeComponentByType(GenericComponents.DynamicModelComponent)
        self.createComponent(GenericComponents.DynamicModelComponent, self._compoundModel)
        self.collisions = None
        self.collisions = self.createComponent(BigWorld.CollisionComponent, resourceList['collisionAssembler'])
        model_assembler.setupCollisions(self.typeDescriptor, self.collisions)
        self._CompoundAppearance__linkCompound()
        self._CompoundAppearance__prepareSystemsForDamagedVehicle(self._vehicle, self.isTurretDetached)
        self._CompoundAppearance__processPostmortemComponents()
        if isRightSideFlying:
            self.fashion.changeTrackVisibility(False, False, MAIN_TRACK_PAIR_IDX)
        if isLeftSideFlying:
            self.fashion.changeTrackVisibility(True, False, MAIN_TRACK_PAIR_IDX)
        self._setupModels()
        self._CompoundAppearance__reattachComponents(self.compoundModel)
        self._connectCollider()
        set_safe_gun_angles(self,prevTurretYaw,prevGunPitch)
        model_assembler.setupTurretRotations(self)
        self.onModelChanged()
        return
