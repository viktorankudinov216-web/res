# -*- coding: utf-8 -*-
import functools
import pickle
import zlib

import BigWorld
import AccountCommands
import game

from collections import namedtuple

from gui.mods.hangar146.server import BASE_REQUESTS
from gui.mods.hangar146._constants import REQUEST_CALLBACK_TIME
from gui.mods.hangar146.data import (
    getOfflineInventory,
    getOfflineStats,
    getOfflineQuestsProgress,
    getOfflineShop,
)


RequestResult = namedtuple('RequestResult', ['resultID', 'errorStr', 'data'])


def baseRequest(cmdID):
    def wrapper(func):
        def requester(requestID, *args):
            result = func(requestID, *args)
            return (
                requestID,
                result.resultID,
                result.errorStr,
                result.data,
            )

        BASE_REQUESTS[cmdID] = requester
        return func

    return wrapper

def packStream(requestID, data):
    payload = zlib.compress(pickle.dumps(data, protocol=2))
    desc = pickle.dumps((len(payload), zlib.crc32(payload)), protocol=2)
    owner = BigWorld.player()
    def deliver():
        if owner is BigWorld.player():
            game.onStreamComplete(requestID, desc, payload)
    return deliver

# In some 1.44 builds CMD_COMPLETE_TUTORIAL may be missing.
_COMPLETE_TUTORIAL_CMD = getattr(AccountCommands, 'CMD_COMPLETE_TUTORIAL', None)

if _COMPLETE_TUTORIAL_CMD is not None:
    @baseRequest(_COMPLETE_TUTORIAL_CMD)
    def completeTutorial(requestID, revision, dataLen, dataCrc):
        return RequestResult(AccountCommands.RES_SUCCESS, '', {})


from gui.mods.hangar146.utils import deepUpdate

@baseRequest(AccountCommands.CMD_SYNC_DATA)
def syncData(requestID, revision, crc, _):
    data = {'rev': revision + 1}

    for chunk in (getOfflineInventory(), getOfflineStats(), getOfflineQuestsProgress()):
        if chunk:
            deepUpdate(data, chunk)

    return RequestResult(AccountCommands.RES_SUCCESS, '', data)


@baseRequest(AccountCommands.CMD_SYNC_SHOP)
def syncShop(requestID, revision, dataLen, dataCrc):
    data = {
        'rev': revision + 1,
        'prevRev': revision,
    }

    data.update(getOfflineShop())
    data['rev'] = revision + 1
    data.pop('prevRev', None)  # Full stream, not an incremental diff.

    BigWorld.callback(REQUEST_CALLBACK_TIME, packStream(requestID, data))

    return RequestResult(AccountCommands.RES_STREAM, '', None)


@baseRequest(AccountCommands.CMD_SYNC_DOSSIERS)
def syncDossiers(requestID, revision, maxChangeTime, _):
    BigWorld.callback(
        REQUEST_CALLBACK_TIME,
        packStream(requestID, (revision + 1, []))
    )

    return RequestResult(AccountCommands.RES_STREAM, '', None)

def register_economy():
    from . import economy
    for name in economy.SUPPORTED:
        cmd=getattr(AccountCommands,name,None)
        if cmd is None:continue
        def bind(command):
            def execute(requestID,*args):
                return (requestID,AccountCommands.RES_SUCCESS,'',economy.execute(BigWorld.player(),command,args))
            return execute
        BASE_REQUESTS[cmd]=bind(cmd)
