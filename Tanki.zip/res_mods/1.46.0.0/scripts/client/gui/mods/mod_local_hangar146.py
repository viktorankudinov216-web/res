# -*- coding: utf-8 -*-
from __future__ import print_function
_bootstrap=None

def init():
    global _bootstrap
    try:
        from hangar146 import bootstrap
        _bootstrap=bootstrap;bootstrap.init()
    except Exception:
        import traceback
        print('[Hangar146 M05] loader failed\n'+traceback.format_exc())

def fini():
    if _bootstrap is not None:_bootstrap.fini()
